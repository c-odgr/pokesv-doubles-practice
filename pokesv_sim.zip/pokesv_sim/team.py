"""Teams: the Showdown export format and the rules every team must follow.

The rules checked here hold in every regulation (constitution VI): known names, legal stat
spreads, learnable moves. Which Pokémon a regulation allows is not checked here.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass, field

from pokesv_sim.dex import STAT_IDS, default_tera_type, get_dex, tera_forme, to_id

DEFAULT_LEVEL = 50
MAX_TEAM_SIZE = 6
MAX_MOVES = 4
MAX_EV = 252
MAX_EV_TOTAL = 510
MAX_IV = 31

_STAT_NAMES = {"hp": "hp", "atk": "atk", "def": "def", "spa": "spa", "spd": "spd", "spe": "spe"}
_IGNORED_PREFIXES = ("Shiny:", "Happiness:", "Gigantamax:", "Dynamax Level:", "Pokeball:")
_HEADER = re.compile(
    r"^(?P<body>.*?)(?:\s+\((?P<gender>[MF])\))?(?:\s+@\s+(?P<item>.+))?$",
)


@dataclass(frozen=True, slots=True)
class PokemonSet:
    """One team member as written by the user (names are not resolved yet)."""

    species: str
    moves: tuple[str, ...] = ()
    nickname: str | None = None
    gender: str | None = None
    item: str | None = None
    ability: str | None = None  # None: the species' first ability
    level: int = DEFAULT_LEVEL
    nature: str = "Serious"
    tera_type: str | None = None
    evs: Mapping[str, int] = field(default_factory=lambda: dict.fromkeys(STAT_IDS, 0))
    ivs: Mapping[str, int] = field(default_factory=lambda: dict.fromkeys(STAT_IDS, MAX_IV))
    unknown_lines: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class Team:
    members: tuple[PokemonSet, ...]


@dataclass(frozen=True, slots=True)
class TeamError:
    """A problem with a team. ``index`` is the member's position, or -1 for the whole team."""

    index: int
    field: str
    message: str


def _parse_spread(text: str, default: int) -> tuple[dict[str, int], list[str]]:
    spread = dict.fromkeys(STAT_IDS, default)
    bad: list[str] = []
    for part in text.split("/"):
        m = re.fullmatch(r"\s*(-?\d+)\s+(\w+)\s*", part)
        stat = _STAT_NAMES.get(to_id(m.group(2))) if m else None
        if m is None or stat is None:
            bad.append(part.strip())
            continue
        spread[stat] = int(m.group(1))
    return spread, bad


def _parse_member(lines: list[str]) -> PokemonSet:
    header = _HEADER.match(lines[0].strip())
    assert header is not None  # the pattern matches any line
    body = header.group("body").strip()
    nick_match = re.fullmatch(r"(?P<nick>.+?)\s+\((?P<species>[^()]+)\)", body)
    nickname, species = (
        (nick_match.group("nick"), nick_match.group("species")) if nick_match else (None, body)
    )
    values: dict[str, object] = {
        "species": species,
        "nickname": nickname,
        "gender": header.group("gender"),
        "item": header.group("item"),
    }
    moves: list[str] = []
    unknown: list[str] = []
    for raw in lines[1:]:
        line = raw.strip()
        if line.startswith("-"):
            moves.append(line[1:].strip())
        elif line.startswith("Ability:"):
            values["ability"] = line.removeprefix("Ability:").strip()
        elif line.startswith("Level:"):
            level = line.removeprefix("Level:").strip()
            values["level"] = int(level) if level.lstrip("-").isdigit() else -1
        elif line.startswith("Tera Type:"):
            values["tera_type"] = line.removeprefix("Tera Type:").strip()
        elif line.startswith("EVs:"):
            values["evs"], bad = _parse_spread(line.removeprefix("EVs:"), 0)
            unknown += [f"EVs: {b}" for b in bad]
        elif line.startswith("IVs:"):
            values["ivs"], bad = _parse_spread(line.removeprefix("IVs:"), MAX_IV)
            unknown += [f"IVs: {b}" for b in bad]
        elif line.endswith(" Nature"):
            values["nature"] = line.removesuffix(" Nature").strip()
        elif not line.startswith(_IGNORED_PREFIXES):
            unknown.append(line)
    return PokemonSet(
        moves=tuple(moves),
        unknown_lines=tuple(unknown),
        **values,  # type: ignore[arg-type]
    )


def parse_team(text: str) -> Team:
    """Read a team in Showdown's export format. Missing fields take their defaults."""
    blocks: list[list[str]] = []
    current: list[str] = []
    for line in text.splitlines():
        if line.strip():
            current.append(line)
        elif current:
            blocks.append(current)
            current = []
    if current:
        blocks.append(current)
    return Team(tuple(_parse_member(b) for b in blocks))


def _validate_member(i: int, s: PokemonSet) -> list[TeamError]:
    dex = get_dex()
    errors: list[TeamError] = []

    def err(field_name: str, message: str) -> None:
        errors.append(TeamError(i, field_name, message))

    for line in s.unknown_lines:
        err("line", f"unrecognized line: {line!r}")
    species = dex.species(s.species)
    if species is None:
        err("species", f"unknown species: {s.species!r}")
    elif species.battle_only:
        err("species", f"{species.name} is a battle-only forme (enter as {species.battle_only})")
    if s.item is not None and dex.item(s.item) is None:
        err("item", f"unknown item: {s.item!r}")
    if s.ability is not None and to_id(s.ability) != "noability":
        ability = dex.ability(s.ability)
        if ability is None:
            err("ability", f"unknown ability: {s.ability!r}")
        elif species is not None and ability.name not in species.abilities:
            err("ability", f"{species.name} cannot have {ability.name}")
    if dex.nature(s.nature) is None:
        err("nature", f"unknown nature: {s.nature!r}")
    if s.tera_type is not None and to_id(s.tera_type) not in dex.type_ids():
        err("tera_type", f"unknown type: {s.tera_type!r}")
    required = species.required_item if species is not None else None
    if required and (s.item is None or to_id(s.item) != to_id(required)):
        err("item", f"{s.species} must hold {required}")
    forme = tera_forme(species) if species is not None else None
    if species is not None and forme is not None:
        # 017: Ogerpon can only terastallize into its forme's type (else the game crashes)
        tera = s.tera_type or default_tera_type(species)
        if to_id(tera) != to_id(forme.types[-1]):
            err("tera_type", f"{species.name} must have Tera Type {forme.types[-1]}")
    if not 1 <= s.level <= 100:
        err("level", f"level must be 1-100: {s.level}")
    if any(not 0 <= v <= MAX_EV for v in s.evs.values()) or sum(s.evs.values()) > MAX_EV_TOTAL:
        err("evs", f"EVs must be 0-{MAX_EV} each and {MAX_EV_TOTAL} in total: {dict(s.evs)}")
    if any(not 0 <= v <= MAX_IV for v in s.ivs.values()):
        err("ivs", f"IVs must be 0-{MAX_IV}: {dict(s.ivs)}")

    if not 1 <= len(s.moves) <= MAX_MOVES:
        err("moves", f"a Pokémon needs 1-{MAX_MOVES} moves, has {len(s.moves)}")
    seen: set[str] = set()
    for name in s.moves:
        move = dex.move(name)
        if move is None:
            err("moves", f"unknown move: {name!r}")
            continue
        if move.id in seen:
            err("moves", f"duplicate move: {move.name}")
        seen.add(move.id)
        if species is not None and not dex.can_learn(species.id, move.id):
            err("moves", f"{species.name} cannot learn {move.name}")
    return errors


def validate_team(team: Team) -> list[TeamError]:
    """Every problem with the team (never stops at the first one). Empty when the team is legal."""
    errors: list[TeamError] = []
    if not 1 <= len(team.members) <= MAX_TEAM_SIZE:
        errors.append(
            TeamError(
                -1, "team", f"a team needs 1-{MAX_TEAM_SIZE} Pokémon, has {len(team.members)}"
            )
        )
    for i, member in enumerate(team.members):
        errors += _validate_member(i, member)
    return errors
