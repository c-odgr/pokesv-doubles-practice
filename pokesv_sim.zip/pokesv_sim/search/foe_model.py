"""049: how likely the foe is to choose each pair, learned from what players chose.

The search (036) weighs the foe's candidate pairs by a softmax of the smart AI's scores. Here
each pair has a few features (its score against the best, whether it protects, switches, uses
a status move, Terastallizes, hits both foes) and P(pair) = softmax(w . features) over the
pairs considered; ``w`` is fitted on battles by ``tools/fit_foe.py`` (conditional logit).
"""

from __future__ import annotations

import json
import math
from collections.abc import Sequence
from functools import cache
from pathlib import Path

from pokesv_sim.choices import MoveChoice, SwitchChoice
from pokesv_sim.dex import get_dex
from pokesv_sim.view import SideView

type Option = MoveChoice | SwitchChoice | None
type Pair = tuple[Option, ...]

FOE_FEATURES = ("gap", "best", "protect", "switch", "status", "tera", "spread")
_DATA = Path(__file__).resolve().parent.parent / "data"
PROTECTS = frozenset({"protect", "detect", "spikyshield", "kingsshield", "banefulbunker",
                      "silktrap", "burningbulwark", "obstruct"})  # fmt: skip


def pair_features(view: SideView, pair: Pair, value: float, top: float) -> list[float]:
    """``value``: the smart AI's score of the pair; ``top``: the best pair's."""
    dex = get_dex()
    protect = switch = status = tera = spread = 0.0
    for position, c in enumerate(pair):
        if isinstance(c, SwitchChoice):
            switch += 1
            continue
        if not isinstance(c, MoveChoice) or c.move_index < 0:
            continue
        tera += c.terastallize
        user = next((p for p in view.team if p.position == position and not p.fainted), None)
        if user is None or c.move_index >= len(user.moves):
            continue
        move = dex.move(user.moves[c.move_index].name)
        if move is None:
            continue
        if move.id in PROTECTS:
            protect += 1
        elif move.category == "Status":
            status += 1
        elif move.target in ("allAdjacentFoes", "allAdjacent"):
            spread += 1
    gap = value - top
    return [gap, float(gap > -1e-9), protect, switch, status, tera, spread]


@cache
def foe_weights(name: str) -> tuple[float, ...]:
    path = _DATA / f"foe_weights_{name}.json"
    raw = json.loads(path.read_text(encoding="utf-8"))["weights"]
    return tuple(float(raw[f]) for f in FOE_FEATURES)


def foe_logits(rows: Sequence[Sequence[float]], weights: Sequence[float]) -> list[float]:
    return [sum(w * x for w, x in zip(weights, row, strict=True)) for row in rows]


def softmax(logits: Sequence[float]) -> list[float]:
    if not logits:
        return []
    top = max(logits)
    raw = [math.exp(v - top) for v in logits]
    total = sum(raw)
    return [r / total for r in raw]
