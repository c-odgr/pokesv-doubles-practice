"""039: Japanese labels for what the player sees (names from the generated data)."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from pokesv_sim.choices import MoveChoice, PassChoice, SwitchChoice
from pokesv_sim.dex import get_dex, to_id
from pokesv_sim.events import Event
from pokesv_sim.view import OwnPokemonView, SideView

SPRITE = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/{num}.png"

STATS = {"atk": "こうげき", "def": "ぼうぎょ", "spa": "とくこう", "spd": "とくぼう",
         "spe": "すばやさ", "accuracy": "めいちゅう", "evasion": "かいひ"}  # fmt: skip
STATUS = {"brn": "やけど", "par": "まひ", "psn": "どく", "tox": "もうどく", "slp": "ねむり",
          "frz": "こおり"}  # fmt: skip
TYPE_COLORS = {
    "Normal": "#9fa19f", "Fire": "#e62829", "Water": "#2980ef", "Electric": "#fac000",
    "Grass": "#3fa129", "Ice": "#3dcef3", "Fighting": "#ff8000", "Poison": "#9141cb",
    "Ground": "#915121", "Flying": "#81b9ef", "Psychic": "#ef4179", "Bug": "#91a119",
    "Rock": "#afa981", "Ghost": "#704170", "Dragon": "#5060e1", "Dark": "#624d4e",
    "Steel": "#60a1b8", "Fairy": "#ef70ef", "Stellar": "#44628d",
}  # fmt: skip
TYPES_JA = {
    "Normal": "ノーマル", "Fire": "ほのお", "Water": "みず", "Electric": "でんき", "Grass": "くさ",
    "Ice": "こおり", "Fighting": "かくとう", "Poison": "どく", "Ground": "じめん",
    "Flying": "ひこう", "Psychic": "エスパー", "Bug": "むし", "Rock": "いわ", "Ghost": "ゴースト",
    "Dragon": "ドラゴン", "Dark": "あく", "Steel": "はがね", "Fairy": "フェアリー",
    "Stellar": "ステラ",
}  # fmt: skip
STRUGGLE, RECHARGE = -1, -2  # choices: move_index of Struggle / Recharge


def species(name: str) -> dict[str, Any]:
    s = get_dex().species(name)
    if s is None:
        return {"name": name, "num": 0, "types": [], "colors": []}
    return {
        "name": s.display_ja or s.name_ja or s.name,
        "num": s.num,
        "types": list(s.types),
        "colors": [TYPE_COLORS.get(t, "#888") for t in s.types],
        "types_ja": [TYPES_JA.get(t, t) for t in s.types],
        "base": dict(s.base_stats),
        "sprite": SPRITE.format(num=s.num) if s.num > 0 else "",
    }


CATEGORY = {"Physical": "物理", "Special": "特殊", "Status": "変化"}


def move_info(name: str) -> dict[str, Any]:
    """039: a move as a card shows it: type, category, power, accuracy."""
    m = get_dex().move(name)
    if m is None:
        return {"name": name}
    return {
        "name": m.name_ja or m.name,
        "type": TYPES_JA.get(m.type, m.type),
        "color": TYPE_COLORS.get(m.type, "#888"),
        "category": CATEGORY.get(m.category, m.category),
        "power": m.base_power or None,
        "accuracy": m.accuracy,
    }


def move_name(name: str) -> str:
    m = get_dex().move(name)
    return (m.name_ja or m.name) if m else name


def ability_name(name: str) -> str:
    a = get_dex().ability(name) if name else None
    return (a.name_ja or a.name) if a else name


def item_name(name: str) -> str:
    i = get_dex().item(name) if name else None
    return (i.name_ja or i.name) if i else name


def condition_name(cid: str) -> str:
    """Weather, terrain, field and side conditions and hazards are named after their moves."""
    m = get_dex().move(cid)
    return (m.name_ja or m.name) if m else cid


def cause_name(d: str) -> str:
    """What caused damage or healing: an item, an ability, a move, a status or recoil."""
    kind, _, name = d.partition(": ")
    if kind == "item" and name:
        return item_name(name)
    if kind == "ability" and name:
        return ability_name(name)
    if kind == "move" and name:
        return move_name(name)
    return {"recoil": "反動", "confusion": "こんらん", **STATUS}.get(d, condition_name(d))


def boosts(pairs: Sequence[tuple[str, int]]) -> list[str]:
    return [f"{STATS.get(k, k)}{v:+d}" for k, v in pairs if v]


def stages(pairs: Sequence[tuple[str, int]]) -> list[tuple[str, int]]:
    """044: the stat stages that are not 0, in the games' order, as (name, stage)."""
    have = dict(pairs)
    return [(name, have[k]) for k, name in STATS.items() if have.get(k)]


def _cond(cid: str, left: int | None, layers: int | None = None) -> dict[str, Any]:
    out: dict[str, Any] = {"id": to_id(cid), "name": condition_name(cid)}
    if left is not None:
        out["left"] = left
    if layers is not None:
        out["layers"] = layers
    return out


def own(p: OwnPokemonView) -> dict[str, Any]:
    return {
        **species(p.species),
        "index": p.team_index,
        "hp": p.hp,
        "max_hp": p.max_hp,
        "percent": round(100 * p.hp / p.max_hp) if p.max_hp else 0,
        "fainted": p.fainted,
        "position": p.position,
        "status": STATUS.get(p.status or "", p.status or ""),
        "boosts": boosts(p.boosts),
        "stages": stages(p.boosts),
        "confused": p.confused,
        "item": item_name(p.item),
        "ability": ability_name(p.ability),
        "tera_type": TYPES_JA.get(p.tera_type, p.tera_type),
        "tera_color": TYPE_COLORS.get(p.tera_type, "#888"),
        "terastallized": TYPES_JA.get(p.terastallized or "", p.terastallized),
        "moves": [move_info(m.name) | {"pp": m.pp, "max_pp": m.max_pp} for m in p.moves],
    }


def board(view: SideView) -> dict[str, Any]:
    foe: list[dict[str, Any] | None] = []
    for f in view.foe_active:
        if f is None:
            foe.append(None)
            continue
        foe.append({
            **species(f.species),
            "percent": f.hp_percent,
            "status": STATUS.get(f.status or "", f.status or ""),
            "boosts": boosts(f.boosts),
            "stages": stages(f.boosts),
            "confused": f.confused,
            "terastallized": TYPES_JA.get(f.terastallized or "", f.terastallized),
        })  # fmt: skip
    field = [f"{condition_name(c)}（あと{t}）" for c, t in view.field_conditions]
    if view.weather:
        field.insert(0, f"{condition_name(view.weather[0])}（あと{view.weather[1]}）")
    if view.terrain:
        field.insert(0, f"{condition_name(view.terrain[0])}（あと{view.terrain[1]}）")
    side = [f"{condition_name(c)}（あと{t}）" for c, t in view.own_side_conditions]
    side += [f"{condition_name(c)}×{n}" for c, n in view.own_hazards]
    foe_side = [f"{condition_name(c)}（あと{t}）" for c, t in view.foe_side_conditions]
    foe_side += [f"{condition_name(c)}×{n}" for c, n in view.foe_hazards]
    return {
        "turn": view.turn,
        "team": [own(p) for p in view.team],
        "brought": list(view.brought),
        "foe_preview": [species(s) for s in view.foe_preview],
        "foe_active": foe,
        "foe_left": view.foe_left,
        "field": field,
        "side": side,
        "foe_side": foe_side,
        "can_terastallize": view.can_terastallize,
        # 044: the same as data for the arena: ids for the backdrop, turns left as numbers
        "weather_id": view.weather[0] if view.weather else "",
        "terrain_id": view.terrain[0] if view.terrain else "",
        "conditions": {
            "field": [_cond(c, t) for c, t in view.field_conditions]
            + ([_cond(*view.weather)] if view.weather else [])
            + ([_cond(*view.terrain)] if view.terrain else []),
            "me": [_cond(c, t) for c, t in view.own_side_conditions]
            + [_cond(c, None, n) for c, n in view.own_hazards],
            "foe": [_cond(c, t) for c, t in view.foe_side_conditions]
            + [_cond(c, None, n) for c, n in view.foe_hazards],
        },
    }


def _target(target: int | None, position: int, view: SideView) -> str:
    if target is None:
        return ""
    if target > 0:
        f = view.foe_active[target - 1] if target - 1 < len(view.foe_active) else None
        return f"→ 相手の{species(f.species)['name']}" if f else "→ 相手の" + "左右"[target - 1]
    pos = -target - 1
    if pos == position:
        return "→ 自分"
    mate = next((p for p in view.team if p.position == pos and not p.fainted), None)
    return f"→ 味方の{species(mate.species)['name']}" if mate else "→ 味方"


def choice_label(c: MoveChoice | SwitchChoice | PassChoice, position: int, view: SideView) -> str:
    by_index = {p.team_index: p for p in view.team}
    if isinstance(c, SwitchChoice):
        return f"交代: {species(by_index[c.team_index].species)['name']}"
    if isinstance(c, PassChoice):
        return "（なし）"
    user = next(p for p in view.team if p.position == position and not p.fainted)
    if c.move_index == STRUGGLE:
        name = move_name("Struggle")
    elif c.move_index == RECHARGE:
        name = "反動で動けない"
    elif c.move_index < 0:  # 041-5: a locked move it does not know (Copycat)
        name = "続けて技を出す"
    else:
        name = move_name(user.moves[c.move_index].name)
    tera = "（テラスタル）" if c.terastallize else ""
    return f"{name}{tera} {_target(c.target, position, view)}".strip()


def effectiveness(move: str, view: SideView) -> list[float | None]:
    """044: the type matchup of a damaging move against each foe on the field, from the types
    the player can see (the Tera Type once it terastallized). None: no foe there, or a
    status move. Abilities and items are left out (a hint on the move card)."""
    dex = get_dex()
    m = dex.move(move)
    out: list[float | None] = []
    for f in view.foe_active:
        if f is None or m is None or m.category == "Status" or not m.base_power:
            out.append(None)
            continue
        s = dex.species(f.species)
        types = (f.terastallized,) if f.terastallized else (s.types if s else ())
        if not types or f.terastallized == "Stellar":
            out.append(None)
        elif dex.is_immune(m.type, tuple(types)):
            out.append(0.0)
        else:
            out.append(2.0 ** dex.type_mod(m.type, tuple(types)))
    return out


def target_label(c: MoveChoice | SwitchChoice, position: int, view: SideView) -> str:
    """039: only the target part of a move choice ("相手のカイリュー", "" for none)."""
    if not isinstance(c, MoveChoice):
        return ""
    return _target(c.target, position, view).removeprefix("→ ")


class LogWriter:
    """Japanese lines for the events one side sees, following who stands where."""

    def __init__(self, side: str) -> None:
        self.side = side
        self.at: dict[str, str] = {}

    def who(self, pos: str | None) -> str:
        if not pos:
            return ""
        name = self.at.get(pos[:3], pos)
        return name if pos.startswith(self.side) else f"相手の{name}"

    def lines(self, events: Sequence[Event], foe_hp: bool = True) -> list[str]:
        return [entry["text"] for entry in self.entries(events, foe_hp)]

    def entries(self, events: Sequence[Event], foe_hp: bool = True) -> list[dict[str, Any]]:
        """044: each shown event as the page replays it: its log line and what changes on the
        board (who, the new HP, the stat, the condition), one entry per log line."""
        out: list[dict[str, Any]] = []
        for e in events:
            line = self.line(e, foe_hp)
            if line:
                out.append(self._entry(e, line, foe_hp))
        return out

    def _entry(self, e: Event, line: str, foe_hp: bool) -> dict[str, Any]:
        k, d = e.kind, e.detail or ""
        entry: dict[str, Any] = {"text": line, "kind": k, "turn": e.turn}
        for key in ("actor", "target"):
            pos = getattr(e, key)
            if pos and len(pos) >= 3 and pos[:2] in ("p1", "p2"):
                entry[key] = ("me" if pos.startswith(self.side) else "foe") + str(
                    "ab".index(pos[2])
                )
            elif pos in ("p1", "p2"):
                entry["side"] = "me" if pos == self.side else "foe"  # a side condition's side
        if k in ("switch", "drag", "replace"):
            pos = (e.actor if k != "replace" else e.target) or ""
            entry["slot"] = ("me" if pos.startswith(self.side) else "foe") + str(
                "ab".index(pos[2]) if len(pos) > 2 else 0
            )
            entry["species"] = species(d.split(",")[0])
            if e.team_index is not None and pos.startswith(self.side):
                entry["index"] = e.team_index
        if k in ("damage", "heal", "switch", "drag") and e.hp is not None:
            mine = (e.target or "").startswith(self.side)
            if mine or foe_hp:
                entry["hp"] = e.hp  # own: HP; foe: percent
        if k in ("boost", "unboost"):
            entry["stat"] = STATS.get(d, d)
            entry["value"] = e.value or 0
        if k == "move":
            m = get_dex().move(d)
            entry["move"] = move_name(d)
            entry["color"] = TYPE_COLORS.get(m.type, "#888") if m else "#888"
        if k in ("status", "curestatus"):
            entry["status"] = STATUS.get(d, d)
        if k == "terastallize":
            entry["type"] = TYPES_JA.get(d, d)
            entry["color"] = TYPE_COLORS.get(d, "#888")
        if k in ("weather", "fieldstart", "fieldend", "sidestart", "sideend"):
            name = d.split(": ")[-1]
            entry["condition"] = "none" if d == "none" else to_id(name)
            entry["name"] = move_name(name)
        return entry

    def line(self, e: Event, foe_hp: bool = True) -> str | None:
        k, d = e.kind, e.detail or ""
        t = self.who(e.target)
        if k in ("switch", "drag", "replace", "detailschange"):
            pos = (e.actor if k in ("switch", "drag") else e.target) or ""
            self.at[pos[:3]] = species(d.split(",")[0])["name"]
            if k == "replace":
                return f"イリュージョンが解けた！ 正体は{self.who(pos)}だった"
            if k == "detailschange":
                return None
            who = "" if pos.startswith(self.side) else "相手は "
            return f"{who}{self.at[pos[:3]]}を繰り出した" + ("（ほえる等）" if k == "drag" else "")
        if k == "turn":
            return f"── ターン {e.value} ──"
        if k == "move":
            return f"{self.who(e.actor)}の {move_name(d)}！"
        if k == "damage":
            mine = (e.target or "").startswith(self.side)
            hp = "" if e.hp is None or (not mine and not foe_hp) else (
                f"（残り {e.hp}）" if mine else f"（残り {e.hp}%）")  # fmt: skip
            cause = f"〔{cause_name(d)}〕" if d else ""
            return f"{t}に ダメージ{cause}{hp}"
        if k == "heal":
            return f"{t}の HP が回復した"
        simple = {
            "fail": "しかし うまく決まらなかった！",
            "immune": f"{t}には 効果がないようだ…",
            "miss": f"{t}には 当たらなかった！",
            "crit": "急所に 当たった！",
            "supereffective": "効果は ばつぐんだ！",
            "resisted": "効果は いまひとつのようだ…",
            "faint": f"{t}は たおれた！",
            "tie": "引き分け",
            "mustrecharge": f"{t}は 反動で動けない",
            "clearallboost": "すべての能力変化が元に戻った",
            "swapsideconditions": "おたがいの場の効果が入れ替わった",
        }
        if k in simple:
            return simple[k]
        if k == "status":
            return f"{t}は {STATUS.get(d, d)}になった"
        if k == "curestatus":
            return f"{t}の {STATUS.get(d, d)}が治った"
        if k in ("boost", "unboost"):
            word = "上がった" if k == "boost" else "下がった"
            return f"{t}の {STATS.get(d, d)}が {e.value}段階 {word}"
        if k == "cant":
            return f"{self.who(e.actor) or t}は 動けない〔{STATUS.get(d, d)}〕"
        if k == "terastallize":
            return f"{t}は テラスタルした！（{TYPES_JA.get(d, d)}）"
        if k == "ability":
            return f"{t}の {ability_name(d)}"
        if k == "enditem":
            return f"{t}の {item_name(d)}が なくなった"
        if k in ("weather", "fieldstart", "fieldend", "sidestart", "sideend"):
            name = d.split(": ")[-1]
            m = get_dex().move(name)
            label = (m.name_ja or m.name) if m else name
            if k == "weather":
                return "天気が 元に戻った" if d == "none" else f"天気: {label}"
            side = ""
            if k in ("sidestart", "sideend") and e.actor in ("p1", "p2"):
                side = "味方の場の " if e.actor == self.side else "相手の場の "  # 044
            return f"{side}{label}" + ("が 始まった" if k.endswith("start") else "が 終わった")
        if k == "win":
            return "あなたの 勝ち！" if e.actor == self.side else "あなたの 負け…"
        if k == "start" and d.startswith(("protosynthesis", "quarkdrive")):
            # 依頼者 2026-11-23: which stat Booster Energy (or the sun / Electric Terrain) raised
            name = "Protosynthesis" if d.startswith("protosynthesis") else "Quark Drive"
            stat = d.removeprefix("protosynthesis").removeprefix("quarkdrive")
            return f"{t}の {ability_name(name)}で {STATS.get(stat, stat)}が 高まった"
        if k in ("preview", "weatherupkeep", "hitcount", "activate", "start", "end", "singleturn"):
            if k == "singleturn":
                name = d.split(": ")[-1]
                return f"{t}は {move_name(name)}の 構え"
            return None
        return None
