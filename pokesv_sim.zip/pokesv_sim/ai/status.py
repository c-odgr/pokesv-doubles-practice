"""035 US6 (FR-016): status moves in the currency of ``score`` (shares of HP over ``HORIZON``).

A status move is worth what it changes in the trade of damage over the next turns:

- sleep, burn, paralysis, poison: the foe's threat it takes away (whole turns asleep, half a
  physical attacker's damage, a full paralysis in four and the turns it lets this side move
  first) and the damage it deals over the turns;
- Follow Me / Rage Powder: the threat aimed at the ally that hits the user instead (Rage Powder
  does not draw Grass types, Overcoat or Safety Goggles);
- Taunt: the share of the foe's guessed moves that are status moves;
- lowering a foe's attack (Parting Shot): the share of its threat it removes;
- raising the user's attack: what its best attack gains over the turns after this one;
- raising the user's defenses: the share of the threat it removes over the turns after;
- healing: the HP it gives back; Wide Guard: the spread attacks it blocks;
- Stealth Rock: one eighth of HP for each foe still to come in.

Moves with no formula here are valued by their kind (status condition, stat stages) or at 0.
Helping Hand is valued in ``score`` (it changes the ally's damage).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pokesv_sim.choices import MoveChoice
from pokesv_sim.dex import Move

if TYPE_CHECKING:
    from pokesv_sim.ai.score import Evaluator

HORIZON = 2  # turns (plan R5)
# a raised stat pays only on later turns, if the user is still there and the foe has not
# switched; half of the gain, after the chance it survives (vs. the random AI, valuing the full
# gain made the AI weaker: 95.0% -> 93.7%)
BOOST_SHARE = 0.5
SLEEP_TURNS = 2.0  # turns a sleeping foe loses, on average within the horizon
YAWN_SHARE = 0.5  # Yawn's sleep comes a turn later and can be switched out of
FULL_PARALYSIS = 0.25
TAUNT_VALUE = 0.3  # a foe made of status moves loses this much
ROCK_SHARE = 1 / 8
POWDER_PROOF = frozenset({"overcoat"})
POWDER_ITEMS = frozenset({"safetygoggles"})
SLEEP_PROOF = frozenset({"insomnia", "vitalspirit", "sweetveil", "comatose", "purifyingsalt"})
STATUS_PROOF = frozenset({"comatose", "purifyingsalt", "goodasgold"})
# the share of max HP a healing move gives back (``heal`` in Showdown's data; the generated
# data keeps only the key); the weather-dependent ones at their plain value
HEAL = {
    "recover": 0.5, "roost": 0.5, "softboiled": 0.5, "slackoff": 0.5, "milkdrink": 0.5,
    "moonlight": 0.5, "synthesis": 0.5, "morningsun": 0.5, "shoreup": 0.5,
    "lunarblessing": 0.25, "lifedew": 0.25, "junglehealing": 0.25,
}  # fmt: skip
TEAM_HEAL = frozenset({"lunarblessing", "lifedew", "junglehealing"})


def _accuracy(move: Move) -> float:
    return 1.0 if move.accuracy is None else min(1.0, move.accuracy / 100)


def _boost_gain(stages: int) -> float:
    """How much a stat raised by ``stages`` (from 0) multiplies by, minus one."""
    return (2 + stages) / 2 - 1 if stages >= 0 else 2 / (2 - stages) - 1


def status_value(ev: Evaluator, position: int, choice: MoveChoice, move: Move) -> float:
    """The value of status move ``move`` used from own ``position`` (0 when it does nothing)."""
    foe = choice.target - 1 if choice.target is not None and choice.target > 0 else None
    if foe is not None and foe not in ev.foes:
        foe = next(iter(sorted(ev.foes)), None)
    if move.id in ("followme", "ragepowder"):
        return _redirect(ev, position, move)
    if move.id == "taunt" and foe is not None:
        return _accuracy(move) * TAUNT_VALUE * ev.status_share(foe)
    if move.id == "stealthrock":
        return ROCK_SHARE * ev.foe_bench()
    if move.id == "wideguard":
        return sum(ev.threat(f, aim, False) for f, aim in ev.spread_aims())
    if move.id in HEAL:
        return _heal(ev, position, move.id)
    if move.status is not None and foe is not None:
        return _condition(ev, foe, move, move.status)
    if move.volatile_status == "yawn" and foe is not None:
        return YAWN_SHARE * _condition(ev, foe, move, "slp")
    if move.boosts and foe is not None and move.target in ("normal", "adjacentFoe", "any"):
        return _lower(ev, foe, move, dict(move.boosts))
    if move.boosts and move.target in ("self", "allies", "adjacentAllyOrSelf"):
        return _raise(ev, position, dict(move.boosts))
    return 0.0


def _redirect(ev: Evaluator, position: int, move: Move) -> float:
    ally = 1 - position
    if ally not in ev.own:
        return 0.0
    gained = 0.0
    for f, aim in ev.aims():
        if aim != ally:
            continue
        drawn = 1.0
        if move.id == "ragepowder":
            drawn = 1.0 - ev.powder_proof(f)
        gained += drawn * (ev.threat(f, ally, False) - ev.threat(f, position, False))
    return gained


def _heal(ev: Evaluator, position: int, move_id: str) -> float:
    share = HEAL[move_id]
    targets = sorted(ev.own) if move_id in TEAM_HEAL else [position]
    total = 0.0
    for p in targets:
        me = ev.own[p]
        total += min(share, (me.max_hp - me.hp) / me.max_hp)
    return total


def _condition(ev: Evaluator, foe: int, move: Move, status: str) -> float:
    shown, _ = ev.foes[foe]
    if shown.status is not None:
        return 0.0
    types = ev.foe_types(foe)
    if ev.dex.effect_immune(status, types):
        return 0.0
    if status == "par" and move.id == "thunderwave" and ev.dex.is_immune("Electric", types):
        return 0.0
    if "powder" in move.flags and (ev.dex.effect_immune("powder", types) or ev.powder_proof(foe)):
        return 0.0
    proof = SLEEP_PROOF if status == "slp" else STATUS_PROOF
    blocked = ev.foe_ability_share(foe, proof)
    if status != "slp":
        blocked = max(blocked, ev.foe_ability_share(foe, STATUS_PROOF))
    p = _accuracy(move) * (1 - blocked)
    threat = ev.foe_threat(foe)
    max_hp_share = 0.0
    if status == "slp":
        gained = threat * SLEEP_TURNS
    elif status == "brn":
        gained = 0.5 * ev.physical_share(foe) * threat * HORIZON
        max_hp_share = HORIZON / 16
    elif status == "par":
        gained = FULL_PARALYSIS * threat * HORIZON + ev.paralysis_flips(foe)
    else:  # psn, tox
        max_hp_share = HORIZON / 8
        gained = 0.0
    return p * (gained + max_hp_share)


def _lower(ev: Evaluator, foe: int, move: Move, boosts: dict[str, int]) -> float:
    cut = 0.0
    physical = ev.physical_share(foe)
    if boosts.get("atk", 0) < 0:
        cut += physical * (1 - 1 / (1 + _boost_gain(-boosts["atk"])))
    if boosts.get("spa", 0) < 0:
        cut += (1 - physical) * (1 - 1 / (1 + _boost_gain(-boosts["spa"])))
    return _accuracy(move) * cut * ev.foe_threat(foe) * HORIZON


def _raise(ev: Evaluator, position: int, boosts: dict[str, int]) -> float:
    """Attack raised: the best attack's value gains over the turns after this one. Defenses:
    the share of the threat aimed at it removed over those turns."""
    later = HORIZON - 1
    value = 0.0
    physical, special = ev.own_best(position)
    if boosts.get("atk", 0) > 0:
        value += _boost_gain(boosts["atk"]) * physical * later
    if boosts.get("spa", 0) > 0:
        value += _boost_gain(boosts["spa"]) * special * later
    for stat, kind in (("def", True), ("spd", False)):
        if boosts.get(stat, 0) > 0:
            cut = 1 - 1 / (1 + _boost_gain(boosts[stat]))
            for f, aim in ev.aims():
                if aim == position:
                    share = ev.physical_share(f) if kind else 1 - ev.physical_share(f)
                    value += cut * share * ev.threat(f, aim, False) * later
    return BOOST_SHARE * survive(ev, position) * value


def survive(ev: Evaluator, position: int) -> float:
    """A rough chance that own ``position`` is still there next turn: one minus the HP share
    the foes aiming at it are expected to take (capped)."""
    incoming = sum(ev.threat(f, aim, False) for f, aim in ev.aims() if aim == position)
    return max(0.0, 1.0 - incoming)
