"""Seeded random numbers compatible with Pokémon Showdown's Gen 5 PRNG (``sim/prng.ts``).

Given the same seed, :class:`Prng` produces the same numbers as Showdown's ``PRNG`` created with a
``gen5,`` seed, and its helpers (``random``, ``randomChance``, ``sample``, ``shuffle``) consume
them the same way.
"""

from __future__ import annotations

import sys
from collections.abc import MutableSequence, Sequence

# x_{n+1} = (a * x_n + c) mod 2^64
_A = 0x5D588B656C078965
_C = 0x00269EC3
_MASK64 = (1 << 64) - 1
_TWO32 = 1 << 32

type Seed = tuple[int, int, int, int]  # four 16-bit words, most significant first


class Prng:
    """A deterministic random source. Never shares state with other instances."""

    __slots__ = ("_state", "trace")

    def __init__(self, seed: Seed) -> None:
        if len(seed) != 4 or any(not 0 <= w <= 0xFFFF for w in seed):
            raise ValueError(f"seed must be four 16-bit integers: {seed!r}")
        self._state = (seed[0] << 48) | (seed[1] << 32) | (seed[2] << 16) | seed[3]
        # When a list, every draw is recorded as (value, call sites) for comparing the order of
        # draws with Showdown (tools/trace_diff.py). None (the default) records nothing.
        self.trace: list[tuple[int, str]] | None = None

    @classmethod
    def from_showdown_seed(cls, text: str) -> Prng:
        """Build from Showdown's ``gen5,XXXXXXXXXXXXXXXX`` (16 hex digits) seed string."""
        if not text.startswith("gen5,") or len(text) != 21:
            raise ValueError(f"expected 'gen5,' followed by 16 hex digits: {text!r}")
        hex_part = text[5:]
        words = tuple(int(hex_part[i : i + 4], 16) for i in range(0, 16, 4))
        return cls((words[0], words[1], words[2], words[3]))

    @property
    def seed(self) -> Seed:
        s = self._state
        return ((s >> 48) & 0xFFFF, (s >> 32) & 0xFFFF, (s >> 16) & 0xFFFF, s & 0xFFFF)

    def showdown_seed(self) -> str:
        """The current state in Showdown's ``Gen5RNG.getSeed()`` form (decimal words)."""
        return ",".join(str(w) for w in self.seed)

    def _next(self) -> int:
        self._state = (_A * self._state + _C) & _MASK64
        value = self._state >> 32  # upper 32 bits
        if self.trace is not None:
            self.trace.append((value, _call_sites()))
        return value

    def random(self) -> float:
        """A real number in [0, 1)."""
        return self._next() / _TWO32

    def random_int(self, n: int) -> int:
        """An integer in [0, n) (Showdown ``random(n)``)."""
        return (self._next() * n) // _TWO32

    def random_range(self, lo: int, hi: int) -> int:
        """An integer in [lo, hi) (Showdown ``random(m, n)``)."""
        return (self._next() * (hi - lo)) // _TWO32 + lo

    def random_chance(self, numerator: int, denominator: int) -> bool:
        return self.random_int(denominator) < numerator

    def sample[T](self, items: Sequence[T]) -> T:
        if not items:
            raise ValueError("cannot sample an empty sequence")
        return items[self.random_int(len(items))]

    def shuffle[T](self, items: MutableSequence[T], start: int = 0, end: int | None = None) -> None:
        """Fisher-Yates shuffle of ``items[start:end]`` in place (how speed ties are resolved)."""
        stop = len(items) if end is None else end
        while start < stop - 1:
            j = self.random_range(start, stop)
            if j != start:
                items[start], items[j] = items[j], items[start]
            start += 1


def _call_sites(depth: int = 5) -> str:
    """The Prng method used, then the functions that called it (innermost first)."""
    frame = sys._getframe(2)
    method = frame.f_code.co_name
    names: list[str] = []
    while frame is not None and len(names) < depth:
        if frame.f_globals.get("__name__") == __name__:
            method = frame.f_code.co_name  # the outermost Prng method (e.g. sample, not random_int)
        else:
            names.append(frame.f_code.co_name)
        frame = frame.f_back  # type: ignore[assignment]
    return f"{method}: " + " < ".join(names)
