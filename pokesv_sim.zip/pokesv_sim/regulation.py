"""Regulations: which Pokémon and teams a regulation allows (018).

A regulation is data (``data/regulations.json``): banned tags and species, Species Clause, Item
Clause, the level and the team sizes. This module reads it; the battle engine never does
(constitution VI). The rules that hold in every regulation are in ``team.validate_team``.
"""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, replace
from functools import cache
from importlib import resources
from typing import Literal

from pokesv_sim.dex import get_dex, to_id
from pokesv_sim.team import Team

ProblemKind = Literal["not_in_game", "banned", "species_clause", "item_clause", "team_size"]


@dataclass(frozen=True, slots=True)
class Regulation:
    id: str
    name: str
    banned_tags: frozenset[str]
    banned_species: frozenset[str]  # species ids
    species_clause: bool
    item_clause: int | None  # at most this many of one item; None: no limit
    level: int
    min_team_size: int
    max_team_size: int
    picked_team_size: int


@dataclass(frozen=True, slots=True)
class RegulationProblem:
    kind: ProblemKind
    members: tuple[int, ...]  # positions in the team; empty for the whole team
    message: str


@cache
def _table() -> dict[str, Regulation]:
    text = resources.files("pokesv_sim.data").joinpath("regulations.json").read_text("utf-8")
    out = {}
    for rid, r in json.loads(text).items():
        if rid.startswith("_"):
            continue
        out[rid] = Regulation(
            id=rid,
            name=r["name"],
            banned_tags=frozenset(r["banned_tags"]),
            banned_species=frozenset(to_id(s) for s in r["banned_species"]),
            species_clause=r["species_clause"],
            item_clause=r["item_clause"],
            level=r["level"],
            min_team_size=r["min_team_size"],
            max_team_size=r["max_team_size"],
            picked_team_size=r["picked_team_size"],
        )
    return out


def regulation_ids() -> tuple[str, ...]:
    return tuple(_table())


def get_regulation(regulation_id: str) -> Regulation:
    """The regulation with this id (e.g. ``regf``). Raises KeyError for an unknown id."""
    return _table()[to_id(regulation_id)]


def check_regulation(team: Team, reg: Regulation) -> list[RegulationProblem]:
    """Every way the team breaks the regulation (empty when it follows it). The level is not a
    problem: ``adjust_team`` sets it, as Showdown does."""
    dex = get_dex()
    problems: list[RegulationProblem] = []
    size = len(team.members)
    if not reg.min_team_size <= size <= reg.max_team_size:
        problems.append(
            RegulationProblem(
                "team_size",
                (),
                f"{reg.name} needs {reg.min_team_size}-{reg.max_team_size} Pokémon, has {size}",
            )
        )
    by_num: dict[int, list[int]] = defaultdict(list)
    by_item: dict[str, list[int]] = defaultdict(list)
    for i, member in enumerate(team.members):
        species = dex.species(member.species)
        if species is None:
            problems.append(
                RegulationProblem("not_in_game", (i,), f"#{i + 1} {member.species} is not in SV")
            )
        else:
            tags = sorted(reg.banned_tags.intersection(species.tags))
            if tags or species.id in reg.banned_species:
                why = f"tagged {tags[0]}" if tags else "banned"
                problems.append(
                    RegulationProblem("banned", (i,), f"#{i + 1} {species.name} is {why}")
                )
            by_num[species.num].append(i)
        if member.item:
            item = dex.item(member.item)
            by_item[item.id if item else to_id(member.item)].append(i)
    if reg.species_clause:
        for indices in by_num.values():
            if len(indices) > 1:
                names = ", ".join(f"#{i + 1} {team.members[i].species}" for i in indices)
                problems.append(
                    RegulationProblem(
                        "species_clause",
                        tuple(indices),
                        f"Species Clause: the same Pokémon ({names})",
                    )
                )
    if reg.item_clause is not None:
        for indices in by_item.values():
            if len(indices) > reg.item_clause:
                item_name = team.members[indices[0]].item
                members = ", ".join(f"#{i + 1}" for i in indices)
                problems.append(
                    RegulationProblem(
                        "item_clause", tuple(indices), f"Item Clause: {item_name} on {members}"
                    )
                )
    return problems


def adjust_team(team: Team, reg: Regulation) -> Team:
    """The team at the regulation's level (Showdown's Adjust Level)."""
    return Team(tuple(replace(m, level=reg.level) for m in team.members))
