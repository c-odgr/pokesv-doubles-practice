"""036 (plan R1): a hypothetical battle built from what a side sees and its guesses.

Its own side is as the view shows it (stats, HP, moves and PP, item, ability, status, boosts,
Terastallization). The foe's Pokémon get the ``rank``-th heaviest guess at their sets
(``Belief.top``); what a guess leaves open (moves, item, ability, Tera Type) is filled from the
species' heaviest tournament set, then from what was seen. The foe's bench not seen yet comes
from team preview's species. The field (weather, terrain, Trick Room, side conditions, entry
hazards) is set as the view shows it, after the start (whose switch-in effects it overrides).

Nothing here reads a real battle: the view and the guesses are all there is, and the battle's
random numbers come from the ``seed`` given (FR-004).
"""

from __future__ import annotations

from dataclasses import dataclass

from pokesv_sim.ai.belief import Belief, Beliefs
from pokesv_sim.ai.sets import SetHypothesis, prior
from pokesv_sim.battle import Battle
from pokesv_sim.choices import Preview
from pokesv_sim.dex import STAT_IDS, get_dex
from pokesv_sim.prng import Prng, Seed
from pokesv_sim.state import BattlePokemon
from pokesv_sim.team import PokemonSet, Team
from pokesv_sim.view import OwnPokemonView, SideView, species_key

BROUGHT = 4


class WorldError(Exception):
    """The view cannot be made into a battle (e.g. a foe with no move known or guessed)."""


@dataclass(frozen=True, slots=True)
class World:
    battle: Battle
    weight: float  # how likely the guesses it was built from are (the worlds' weights add to 1)


def build_world(view: SideView, beliefs: Beliefs, rank: int, seed: Seed) -> World:
    """The battle for ``view`` with each foe's ``rank``-th guess (0: the heaviest)."""
    me, foe = view.side, ("p2" if view.side == "p1" else "p1")
    own_order = _own_brought(view)
    foe_sets, foe_lead, weight = _foe_brought(view, beliefs, rank)
    own_team = Team(tuple(_own_set(p) for p in own_order))
    foe_team = Team(tuple(foe_sets))
    teams = (own_team, foe_team) if me == "p1" else (foe_team, own_team)
    battle = Battle(teams[0], teams[1], Prng(seed))
    own_preview = Preview(tuple(range(len(own_order))))
    foe_preview = Preview(foe_lead)
    previews = (own_preview, foe_preview) if me == "p1" else (foe_preview, own_preview)
    battle.start(*previews)
    _fix_own(battle, me, view, own_order)
    _fix_foe(battle, foe, view)
    _fix_field(battle, me, foe, view)
    return World(battle, weight)


# -- own side -----------------------------------------------------------------------------------


def _own_brought(view: SideView) -> list[OwnPokemonView]:
    """The own Pokémon still able to fight, those on the field first (in their positions)."""
    by_index = {p.team_index: p for p in view.team}
    alive = [by_index[i] for i in view.order if not by_index[i].fainted]
    active = sorted((p for p in alive if p.position is not None), key=lambda p: p.position or 0)
    return active + [p for p in alive if p.position is None]


def _own_set(p: OwnPokemonView) -> PokemonSet:
    return PokemonSet(
        p.species,
        tuple(m.name for m in p.moves),
        item=p.item or None,
        ability=p.ability or None,
        tera_type=p.tera_type or None,
    )


def _fix_own(battle: Battle, side: str, view: SideView, order: list[OwnPokemonView]) -> None:
    team = battle.state.sides[side].team
    for mon, seen in zip(team, order, strict=True):
        stats = dict(seen.stats)
        mon.stats.update({k: v for k, v in stats.items() if k != "hp"})
        mon.max_hp = seen.max_hp
        mon.hp = seen.hp
        mon.status = seen.status
        mon.boosts.update(dict(seen.boosts))
        mon.item = seen.item
        for slot, move in zip(mon.moves, seen.moves, strict=False):
            slot.pp = move.pp
        if seen.terastallized:
            _terastallize(mon, seen.terastallized)
    _place(battle, side, [p.position for p in order])
    battle.state.sides[side].tera_used = not view.can_terastallize


# -- foe side -----------------------------------------------------------------------------------


def _foe_brought(
    view: SideView, beliefs: Beliefs, rank: int
) -> tuple[list[PokemonSet], tuple[int, ...], float]:
    """The foe's sets (those on the field first), the preview that leads with them, and the
    weight of the guesses used for those on the field."""
    active = [f for f in view.foe_active if f is not None and not f.fainted]
    on_field = {species_key(f.species) for f in active}
    alive = max(view.foe_left, len(active))
    gone = on_field | beliefs.fainted  # (review P2: those seen fainting are not on the bench)
    bench = [s for s in view.foe_preview if species_key(s) not in gone]
    bench = bench[: max(0, min(alive, BROUGHT) - len(active))]
    sets: list[PokemonSet] = []
    weight = 1.0
    for f in active:
        made, w = _foe_set(beliefs, f.species, rank)
        sets.append(made)
        weight *= w
    for species in bench:
        sets.append(_foe_set(beliefs, species, 0)[0])
    if not sets:
        raise WorldError("no foe left")
    return sets, tuple(range(len(sets))), weight


def _belief(beliefs: Beliefs, species: str) -> Belief | None:
    try:
        return beliefs[species]
    except KeyError:
        return None


def _foe_set(beliefs: Beliefs, species: str, rank: int) -> tuple[PokemonSet, float]:
    belief = _belief(beliefs, species)
    guesses = []
    if belief is not None:  # (054: a hidden forme is built as the likelier one)
        guesses = belief.top(2, belief.species if belief.hidden else None)
    if not guesses:
        guesses = list(prior(species)[:1])
    hyp, weight = guesses[min(rank, len(guesses) - 1)]
    if rank >= len(guesses):
        weight = 0.0
    full = _filled(hyp, belief)
    if not full.moves:
        raise WorldError(f"no move known for {species}")
    evs = dict(full.evs) or dict.fromkeys(STAT_IDS, 0)
    if species.endswith("-*"):  # 054: a hidden forme is built as the guess's forme
        forme = get_dex().species(hyp.species)
        species = forme.name if forme is not None else species.removesuffix("-*")
    made = PokemonSet(
        species,
        full.moves[:4],
        item=full.item or None,
        ability=full.ability or None,
        nature=full.nature,
        tera_type=full.tera_type,
        evs=evs,
    )
    return made, weight


def _filled(hyp: SetHypothesis, belief: Belief | None) -> SetHypothesis:
    """What the guess leaves open, from the species' heaviest tournament set (then the moves
    seen)."""
    seen = list(belief.moves) if belief is not None else []
    if hyp.moves and hyp.item is not None and hyp.ability is not None:
        return hyp
    base = next((h for h, _ in prior(hyp.species) if not h.generic), None)
    moves = list(hyp.moves) or seen
    if base is not None:
        moves += [m for m in base.moves if m not in moves]
    return SetHypothesis(
        hyp.species,
        hyp.nature,
        hyp.evs,
        hyp.item if hyp.item is not None else (base.item if base else ""),
        hyp.ability if hyp.ability is not None else (base.ability if base else None) or "",
        hyp.tera_type if hyp.tera_type is not None else (base.tera_type if base else None),
        tuple(moves[:4]),
    )


def _fix_foe(battle: Battle, side: str, view: SideView) -> None:
    team = battle.state.sides[side].team
    shown = [f for f in view.foe_active if f is not None and not f.fainted]
    for mon, f in zip(team, shown, strict=False):
        mon.hp = max(1, -(-mon.max_hp * f.hp_percent // 100)) if f.hp_percent > 0 else 0
        mon.status = f.status
        mon.boosts.update(dict.fromkeys(mon.boosts, 0) | dict(f.boosts))
        if f.terastallized:
            _terastallize(mon, f.terastallized)
    positions: list[int | None] = [f.position for f in shown]
    positions += [None] * (len(team) - len(shown))
    _place(battle, side, positions)
    battle.state.sides[side].tera_used = any(f.terastallized for f in shown)


# -- both ---------------------------------------------------------------------------------------


def _terastallize(mon: BattlePokemon, tera: str) -> None:
    mon.terastallized = tera


def _place(battle: Battle, side: str, positions: list[int | None]) -> None:
    """Put the side's brought Pokémon where the view has them (the start put the first two at
    0 and 1); an empty position has no Pokémon."""
    state = battle.state.sides[side]
    active: list[BattlePokemon | None] = [None, None]
    for mon, position in zip(state.team, positions, strict=False):
        mon.position = position
        if position is not None:
            active[position] = mon
    state.active = active


def _fix_field(battle: Battle, me: str, foe: str, view: SideView) -> None:
    field = battle.state.field
    field.weather, field.weather_turns = view.weather or (None, 0)
    field.terrain, field.terrain_turns = view.terrain or (None, 0)
    field.pseudo_weather = dict(view.field_conditions)
    field.sides = {me: dict(view.own_side_conditions), foe: dict(view.foe_side_conditions)}
    field.hazards = {me: dict(view.own_hazards), foe: dict(view.foe_hazards)}
    battle.state.turn = view.turn
