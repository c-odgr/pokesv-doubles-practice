"""Small statistics toolkit (standard library only): chi-square, Kolmogorov-Smirnov, Wilson."""

from __future__ import annotations

import bisect
import math
from collections.abc import Mapping, Sequence

_Z95 = 1.959963984540054


def wilson_interval(successes: int, n: int, z: float = _Z95) -> tuple[float, float]:
    """95% Wilson score interval for a proportion."""
    if n == 0:
        return (0.0, 1.0)
    p = successes / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


def chi_square_p(a: Mapping[str, int], b: Mapping[str, int], min_expected: float = 5.0) -> float:
    """p-value of the chi-square test that two count tables come from the same distribution.

    Categories (sorted by key) whose expected count is below ``min_expected`` are merged with
    their neighbours.
    """
    keys = sorted(set(a) | set(b), key=_sort_key)
    n1, n2 = sum(a.values()), sum(b.values())
    if n1 == 0 or n2 == 0:
        return 1.0
    bins: list[tuple[int, int]] = []
    cur1 = cur2 = 0
    for k in keys:
        cur1 += a.get(k, 0)
        cur2 += b.get(k, 0)
        total = cur1 + cur2
        if min(total * n1, total * n2) / (n1 + n2) >= min_expected:
            bins.append((cur1, cur2))
            cur1 = cur2 = 0
    if cur1 or cur2:
        if bins:
            last1, last2 = bins.pop()
            bins.append((last1 + cur1, last2 + cur2))
        else:
            bins.append((cur1, cur2))
    if len(bins) < 2:
        return 1.0
    stat = 0.0
    for o1, o2 in bins:
        total = o1 + o2
        for o, n in ((o1, n1), (o2, n2)):
            e = total * n / (n1 + n2)
            stat += (o - e) ** 2 / e
    return chi2_sf(stat, len(bins) - 1)


def ks_2samp(x: Sequence[float], y: Sequence[float]) -> tuple[float, float]:
    """Two-sample Kolmogorov-Smirnov statistic D and its asymptotic p-value."""
    xs, ys = sorted(x), sorted(y)
    n1, n2 = len(xs), len(ys)
    d = 0.0
    for v in sorted(set(xs) | set(ys)):
        d = max(d, abs(bisect.bisect_right(xs, v) / n1 - bisect.bisect_right(ys, v) / n2))
    ne = n1 * n2 / (n1 + n2)
    lam = (math.sqrt(ne) + 0.12 + 0.11 / math.sqrt(ne)) * d
    return d, _kolmogorov_q(lam)


def _kolmogorov_q(lam: float) -> float:
    """Q_KS(lambda) = 2 * sum_{j>=1} (-1)^(j-1) exp(-2 j^2 lambda^2) (Numerical Recipes)."""
    if lam < 1e-3:
        return 1.0
    total, sign = 0.0, 1.0
    for j in range(1, 101):
        term = sign * math.exp(-2 * j * j * lam * lam)
        total += term
        if abs(term) < 1e-12:
            break
        sign = -sign
    return min(1.0, max(0.0, 2 * total))


def chi2_sf(x: float, df: int) -> float:
    """Survival function of the chi-square distribution (regularized upper gamma)."""
    if df <= 0 or x <= 0:
        return 1.0
    a, z = df / 2, x / 2
    log_prefix = -z + a * math.log(z) - math.lgamma(a)
    if z < a + 1:  # series for the lower incomplete gamma
        term = total = 1 / a
        k = a
        for _ in range(1000):
            k += 1
            term *= z / k
            total += term
            if term < total * 1e-15:
                break
        return max(0.0, 1 - total * math.exp(log_prefix))
    # continued fraction for the upper incomplete gamma (Lentz)
    tiny = 1e-300
    b = z + 1 - a
    c = 1 / tiny
    d = 1 / b
    h = d
    for i in range(1, 1000):
        an = -i * (i - a)
        b += 2
        d = an * d + b
        d = 1 / (d if abs(d) > tiny else tiny)
        c = b + an / c
        c = c if abs(c) > tiny else tiny
        h *= d * c
        if abs(d * c - 1) < 1e-15:
            break
    return math.exp(log_prefix) * h


def _sort_key(key: str) -> tuple[int, float, str]:
    try:
        return (0, float(key), "")
    except ValueError:
        return (1, 0.0, key)
