"""Entry hazards (020): Stealth Rock, Spikes, Toxic Spikes and Sticky Web.

Side conditions without a duration (Showdown ``sideConditions`` with ``layers``), kept apart from
the timed ones in ``FieldState.sides``: id -> layers, in the order they were set (Showdown's
``effectOrder``, which orders a Pokémon's switch-in handlers). Their effects on a Pokémon that
comes in are in ``battle.py`` (``_hazard_switch_in``).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pokesv_sim.field import Emit, FieldState

STEALTH_ROCK = "stealthrock"
SPIKES = "spikes"
TOXIC_SPIKES = "toxicspikes"
STICKY_WEB = "stickyweb"
HEAVY_DUTY_BOOTS = "heavydutyboots"
TOXIC_DEBRIS = "toxicdebris"


@dataclass(frozen=True, slots=True)
class Hazard:
    name: str  # Showdown's condition name (the -sidestart / -sideend detail without "move: ")
    max_layers: int  # onSideRestart refuses more (1: no onSideRestart)


HAZARDS = {
    STEALTH_ROCK: Hazard("Stealth Rock", 1),
    SPIKES: Hazard("Spikes", 3),
    TOXIC_SPIKES: Hazard("Toxic Spikes", 2),
    STICKY_WEB: Hazard("Sticky Web", 1),
}
# The order Rapid Spin, Mortal Spin, Defog and Tidy Up remove them in (gmaxsteelsurge: none in SV)
REMOVE_ORDER = (SPIKES, TOXIC_SPIKES, STEALTH_ROCK, STICKY_WEB)
SPIKES_DAMAGE = (0, 3, 4, 6)  # per layer count, in 24ths of the max HP


def add_hazard(field_state: FieldState, side_id: str, hazard: str, *, emit: Emit) -> bool:
    """``side.addSideCondition``: a layer more (``-sidestart``), or False at the limit."""
    hazards = field_state.hazards[side_id]
    layers = hazards.get(hazard, 0)
    if layers >= HAZARDS[hazard].max_layers:
        return False
    hazards[hazard] = layers + 1
    emit("sidestart", actor=side_id, detail=HAZARDS[hazard].name)
    return True


def remove_hazard(field_state: FieldState, side_id: str, hazard: str) -> bool:
    """``side.removeSideCondition``: True when it was there. The caller reports ``-sideend``."""
    return field_state.hazards[side_id].pop(hazard, None) is not None
