"""055: looking back at a battle played against the AI.

Each turn the person chose is kept with what the latest AI would have chosen (``Point``). On
demand, the two are played out from that turn many times: on battles built from what the
person's side saw then and the AI's guesses (never the real battle), with the same foe first
move and random numbers for both, and the smart AI (035) on both sides from the next turn on.
The win rates are a rough guide, not the truth.
"""

from __future__ import annotations

import copy
import math
import random
from collections.abc import Sequence
from dataclasses import dataclass

from pokesv_sim.ai import SmartPlayer
from pokesv_sim.ai.belief import Beliefs
from pokesv_sim.battle import Battle
from pokesv_sim.choices import Choice, MoveChoice, PassChoice, SwitchChoice, is_legal_turn
from pokesv_sim.events import Event
from pokesv_sim.play import labels
from pokesv_sim.prng import Prng
from pokesv_sim.protection import PROTECTIONS, SINGLE_TURN_NAMES, STALL, add_stall
from pokesv_sim.runner import choose_replacements, choose_turn
from pokesv_sim.search import SearchPlayer
from pokesv_sim.search.player import Pair, Settings
from pokesv_sim.search.world import World, build_world, own_choices
from pokesv_sim.view import SideView, side_view

GAMES = 100  # playouts of each choice for one turn
STEP = 10  # played at each request (the page asks again until ``GAMES``)
GAP = 0.15  # the difference in win rate that is worth saying
MAX_TURNS = 60
# the foe's first move: the latest search's reading, told who is on the field
_READER = Settings(own=6, foe=10, extras=True, foe_sees=True)
# the one-turn effects whose success makes the next protecting move less likely to work
STALLING = frozenset(
    SINGLE_TURN_NAMES[v] for v in (*PROTECTIONS, "endure", "wideguard", "quickguard")
)


@dataclass(frozen=True)
class Point:
    """A turn the person chose, with the AI's choice (None: it gave none)."""

    view: SideView
    mine: tuple[Choice, ...]
    ai: tuple[Choice, ...] | None
    beliefs: Beliefs | None  # the AI's guesses when it chose (a copy)
    # positions ("p1a") of both sides: came in since the last turn chosen (Fake Out may
    # work), and protected successfully in it (the next protect may fail)
    fresh: frozenset[str] = frozenset()
    stalled: frozenset[str] = frozenset()


def picks_to_choices(
    legal: Sequence[Sequence[MoveChoice | SwitchChoice]], picks: Sequence[Sequence[object]]
) -> tuple[Choice, ...]:
    """The page's answer ``[(option index or None, tera)]`` as choices."""
    out: list[Choice] = []
    for options, (k, tera) in zip(legal, picks, strict=True):
        if not options or not isinstance(k, int):
            out.append(PassChoice())
            continue
        c = options[k]
        if tera and isinstance(c, MoveChoice):
            c = MoveChoice(c.move_index, c.target, True)
        out.append(c)
    return tuple(out)


def differences(a: Choice, b: Choice) -> list[str]:
    """What differs between two choices for one position."""
    if a == b:
        return []
    if not (isinstance(a, MoveChoice) and isinstance(b, MoveChoice)):
        switched = isinstance(a, SwitchChoice) or isinstance(b, SwitchChoice)
        return ["交代" if switched else "行動"]
    moved = a.move_index != b.move_index
    out = ["技"] if moved else ["対象"] * (a.target != b.target)
    if a.terastallize != b.terastallize:
        out.append("テラスタル")
    return out


def rows(points: dict[int, Point]) -> list[dict[str, object]]:
    """The list shown after the battle, a row a turn."""
    out: list[dict[str, object]] = []
    for turn, p in sorted(points.items()):
        said = [labels.choice_label(c, i, p.view) for i, c in enumerate(p.mine)]
        row: dict[str, object] = {"turn": turn, "mine": said, "ai": None, "diff": []}
        if p.ai is not None:
            row["ai"] = [labels.choice_label(c, i, p.view) for i, c in enumerate(p.ai)]
            row["diff"] = [differences(a, b) for a, b in zip(p.mine, p.ai, strict=True)]
        out.append(row)
    return out


class Review:
    """The playouts of one turn, a few at a time (``run``)."""

    def __init__(self, point: Point, seed: int = 0) -> None:
        self.point = point
        self.rng = random.Random(f"review:{seed}:{point.view.turn}")
        self.played = 0
        self.results: list[tuple[float, float]] = []  # (mine, the AI's), paired
        self.error: str | None = None
        self.worlds: list[tuple[World, list[Pair], list[float]]] = []
        if point.ai is None or point.beliefs is None:
            self.error = "このターンは AI の案がないので打ち直せません"
            return
        try:
            self._build(point)
        except Exception:  # (WorldError, or a position the engine cannot take)
            self.worlds = []
        if not self.worlds:
            self.error = "このターンは打ち直せません（その局面を盤面に組み直せません）"

    def _build(self, point: Point) -> None:
        assert point.ai is not None and point.beliefs is not None
        view = point.view
        foe = "p2" if view.side == "p1" else "p1"
        reader = SearchPlayer(0, _READER)
        for rank in range(2):
            seed = tuple(self.rng.getrandbits(16) for _ in range(4))
            world = build_world(view, point.beliefs, rank, (seed[0], seed[1], seed[2], seed[3]))
            if world.weight <= 0:
                continue
            state = world.battle.state
            _remember(world, point)
            pairs, probs = reader._foe_candidates(world, view.side)
            legal = [
                (pair, p)
                for pair, p in zip(pairs, probs, strict=True)
                if is_legal_turn(state, foe, _filled(pair))
            ]
            mine_ok = all(
                is_legal_turn(state, view.side, _filled(own_choices(world, c)))
                for c in (point.mine, point.ai)
            )
            if mine_ok and sum(p for _, p in legal) > 0:
                self.worlds.append((world, [x for x, _ in legal], [p for _, p in legal]))

    def run(self, n: int = STEP) -> None:
        """``n`` more paired playouts (fewer at the end of ``GAMES``)."""
        point = self.point
        if self.error is not None or point.ai is None:
            return
        weights = [w.weight for w, _, _ in self.worlds]
        for _ in range(min(n, GAMES - self.played)):
            self.played += 1
            world, pairs, probs = self.rng.choices(self.worlds, weights=weights)[0]
            foe_pair = self.rng.choices(pairs, weights=probs)[0]
            seed = (
                self.rng.getrandbits(16),
                self.rng.getrandbits(16),
                self.rng.getrandbits(16),
                self.rng.getrandbits(16),
            )
            mine = self._play(world, point.mine, foe_pair, seed)
            theirs = self._play(world, point.ai, foe_pair, seed)
            if mine is not None and theirs is not None:
                self.results.append((mine, theirs))

    def _play(
        self,
        world: World,
        choices: Sequence[Choice],
        foe_pair: Pair,
        seed: tuple[int, int, int, int],
    ) -> float | None:
        """One game to the end: 1 if the person's side wins, 0.5 a tie, None unfinished."""
        me = self.point.view.side
        try:
            sim = copy.deepcopy(world.battle)
            sim.prng = Prng(seed)
            players = {side: self._player(world, sim, side) for side in ("p1", "p2")}
            seen = {side: len(sim.events) for side in players}
            first = (_filled(own_choices(world, choices)), _filled(foe_pair))
            sim.play_turn(*(first if me == "p1" else (first[1], first[0])))
            for side, player in players.items():  # what each protected in the turn given
                player._protected = frozenset(
                    "ab".index(label[2])
                    for label in _stalling(sim.events[seen[side] :])
                    if label[:2] == side
                )
            for _ in range(MAX_TURNS):
                if sim.state.ended:
                    break
                if sim.awaiting_replacements:
                    picks: list[list[SwitchChoice | PassChoice]] = []
                    for side, player in players.items():
                        need = sim.needs_replacement(side)
                        if not any(need):
                            picks.append([PassChoice()] * len(need))
                            continue
                        view = side_view(sim.state, side, sim.events, seen[side])
                        seen[side] = len(sim.events)
                        picks.append(choose_replacements(sim, side, player, view, need))
                    sim.replace(*picks)
                else:
                    turn = []
                    for side, player in players.items():
                        turn.append(choose_turn(sim, side, player, seen[side]))
                        seen[side] = len(sim.events)
                    sim.play_turn(*turn)
        except Exception:  # a position the engine cannot go on from: leave the game out
            return None
        if not sim.state.ended:
            return None
        return 0.5 if sim.state.winner is None else float(sim.state.winner == me)

    def _player(self, world: World, sim: Battle, side: str) -> SmartPlayer:
        """The smart AI that goes on from here: the person's side keeps the guesses of the
        moment; the foe's knows only who is on the field."""
        view = side_view(sim.state, side)
        player = SmartPlayer(0)
        if side == self.point.view.side and self.point.beliefs is not None:
            player.beliefs = copy.deepcopy(self.point.beliefs)
            player.beliefs.reindex_own(world.own_index)
        else:
            player.beliefs = Beliefs(view.foe_preview, side)
            player.beliefs.see_field(view)
        return player

    def summary(self) -> dict[str, object]:
        out: dict[str, object] = {
            "turn": self.point.view.turn,
            "played": self.played,
            "games": GAMES,
            "done": self.error is not None or self.played >= GAMES,
        }
        if self.error is not None:
            return out | {"error": self.error}
        n = len(self.results)
        if not n:
            return out | {"counted": 0}
        mine = sum(a for a, _ in self.results) / n
        theirs = sum(b for _, b in self.results) / n
        gap = mine - theirs
        spread = sum((a - b - gap) ** 2 for a, b in self.results) / max(1, n - 1)
        half = 1.96 * math.sqrt(spread / n)
        verdict = "none"  # FR-6: only a gap worth saying whose interval does not include 0
        if n > 1 and abs(gap) >= GAP and abs(gap) > half:
            verdict = "mine" if gap > 0 else "ai"
        return out | {
            "counted": n,
            "mine": mine,
            "ai": theirs,
            "gap": gap,
            "low": gap - half,
            "high": gap + half,
            "verdict": verdict,
        }


def _stalling(events: Sequence[Event]) -> list[str]:
    return [
        e.target for e in events if e.kind == "singleturn" and e.target and e.detail in STALLING
    ]


def watch(events: Sequence[Event], fresh: set[str], stalled: set[str]) -> None:
    """Bring ``fresh`` and ``stalled`` (see ``Point``) up to date with a side's log."""
    for e in events:
        if e.kind in ("switch", "drag") and e.actor:
            fresh.add(e.actor)
            stalled.discard(e.actor)  # (the one that protected has left)
        stalled.update(_stalling([e]))


def _remember(world: World, point: Point) -> None:
    """The imagined battle starts with every Pokémon just out: give those on the field the
    past that decides this turn."""
    for side_id, side in world.battle.state.sides.items():
        for position, mon in enumerate(side.active):
            if mon is None:
                continue
            label = f"{side_id}{'ab'[position]}"
            if label not in point.fresh:
                mon.active_move_actions = 1  # (Fake Out and First Impression now fail)
            if label in point.stalled:
                add_stall(mon)
                mon.timed[STALL] = 1  # (a turn has ended since)


def _filled(choices: Sequence[Choice | None]) -> list[Choice]:
    return [PassChoice() if c is None else c for c in choices]
