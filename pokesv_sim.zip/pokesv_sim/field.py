"""Field and side conditions (Showdown ``pseudoWeather`` and ``sideConditions``).

A condition lasts a number of turns, counted down at the end of each turn (the turn it was set
counts as the first). 006: Trick Room (the whole field) and Tailwind (one side); 008: the
screens (one side). 007: the
weather (at most one; Showdown ``field.weather``, kept apart from pseudoWeather). Events are
reported through ``emit(kind, **fields)``, the battle's event recorder.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

type Emit = Callable[..., Any]

TRICK_ROOM = "trickroom"
TAILWIND = "tailwind"
REFLECT, LIGHT_SCREEN, AURORA_VEIL = "reflect", "lightscreen", "auroraveil"  # 008
SCREENS = (REFLECT, LIGHT_SCREEN, AURORA_VEIL)
WIDE_GUARD, QUICK_GUARD = "wideguard", "quickguard"  # 009: one turn, silent
NO_ORDER = 1 << 32  # comparePriority: a handler without an order sorts last

ECHOED_VOICE = "echoedvoice"  # 041-1f: a pseudo-weather with no messages
MIST, SAFEGUARD = "mist", "safeguard"  # 041-3e: side conditions
GRAVITY = "gravity"  # 041-4e: a pseudo-weather
FAIRY_LOCK = "fairylock"  # 041-6f: a pseudo-weather (duration 2, onTrapPokemon)
WONDER_ROOM = "wonderroom"  # 041-6f: a pseudo-weather (Def and SpD swap)
MAGIC_ROOM = "magicroom"  # 041-6f: a pseudo-weather (ignoringItem)
# 041-5: the Pledge combinations (sea of fire, swamp, rainbow; side conditions)
FIRE_PLEDGE, GRASS_PLEDGE, WATER_PLEDGE = "firepledge", "grasspledge", "waterpledge"
DURATION = {TRICK_ROOM: 5, TAILWIND: 4, REFLECT: 5, LIGHT_SCREEN: 5, AURORA_VEIL: 5,
            WIDE_GUARD: 1, QUICK_GUARD: 1, ECHOED_VOICE: 2, MIST: 5, SAFEGUARD: 5,
            GRAVITY: 5, FIRE_PLEDGE: 4, GRASS_PLEDGE: 4, WATER_PLEDGE: 4,
            FAIRY_LOCK: 2, WONDER_ROOM: 5, MAGIC_ROOM: 5}  # fmt: skip
NAMES = {TRICK_ROOM: "Trick Room", TAILWIND: "Tailwind", REFLECT: "Reflect",
         LIGHT_SCREEN: "Light Screen", AURORA_VEIL: "Aurora Veil", MIST: "Mist",
         SAFEGUARD: "Safeguard", GRAVITY: "Gravity", FIRE_PLEDGE: "Fire Pledge",
         GRASS_PLEDGE: "Grass Pledge", WATER_PLEDGE: "Water Pledge",
         WONDER_ROOM: "Wonder Room", MAGIC_ROOM: "Magic Room"}  # fmt: skip
# Residual handlers: (onFieldResidualOrder / onSideResidualOrder, ...SubOrder).
RESIDUAL_ORDER = {
    TAILWIND: (26, 5),
    TRICK_ROOM: (27, 1),
    GRAVITY: (27, 2),  # 041-4e
    WONDER_ROOM: (27, 5),  # 041-6f
    MAGIC_ROOM: (27, 6),  # 041-6f
    REFLECT: (26, 1),
    LIGHT_SCREEN: (26, 2),
    AURORA_VEIL: (26, 10),
    MIST: (26, 4),  # 041-3e
    SAFEGUARD: (26, 3),
    WATER_PLEDGE: (26, 7),  # 041-5
    FIRE_PLEDGE: (26, 8),
    GRASS_PLEDGE: (26, 9),
    WIDE_GUARD: (NO_ORDER, 4),  # no onSideResidualOrder; subOrder 4 (side condition)
    QUICK_GUARD: (NO_ORDER, 4),
    FAIRY_LOCK: (NO_ORDER, 5),  # 041-6f: duration only, like Echoed Voice
    ECHOED_VOICE: (NO_ORDER, 5),  # 041-1f: duration only; subOrder 5 (field condition)
}
# Side conditions that start and end without a -sidestart / -sideend message.
SILENT = frozenset({WIDE_GUARD, QUICK_GUARD})
# Field conditions that end when set again (onFieldRestart: removePseudoWeather).
_RESTART_ENDS = frozenset({TRICK_ROOM, WONDER_ROOM, MAGIC_ROOM})

SUN, RAIN, SAND, SNOW = "sunnyday", "raindance", "sandstorm", "snowscape"
WEATHER_DURATION = 5
# The names Showdown's protocol uses (``-weather|RainDance``).
WEATHER_NAMES = {SUN: "SunnyDay", RAIN: "RainDance", SAND: "Sandstorm", SNOW: "Snowscape"}
WEATHER_RESIDUAL_ORDER = 1  # onFieldResidualOrder (subOrder 0)

ELECTRIC, GRASSY = "electricterrain", "grassyterrain"
PSYCHIC, MISTY = "psychicterrain", "mistyterrain"
TERRAIN_DURATION = 5
TERRAIN_NAMES = {ELECTRIC: "Electric Terrain", GRASSY: "Grassy Terrain",
                 PSYCHIC: "Psychic Terrain", MISTY: "Misty Terrain"}  # fmt: skip
TERRAIN_RESIDUAL_ORDER = (27, 7)  # onFieldResidualOrder, ...SubOrder


@dataclass(slots=True)
class FieldState:
    """Conditions in play: condition id -> turns left, in the order they were set."""

    pseudo_weather: dict[str, int] = field(default_factory=dict)
    echoed_voice: int = 1  # 041-1f: the echoedvoice pseudo-weather's multiplier
    sides: dict[str, dict[str, int]] = field(default_factory=lambda: {"p1": {}, "p2": {}})
    weather: str | None = None
    weather_turns: int = 0
    # 043-4g: suppressingWeather (an active Cloud Nine / Air Lock, kept by the battle)
    weather_suppressed: bool = False
    terrain: str | None = None  # 010: Showdown field.terrain (apart from the weather)
    terrain_turns: int = 0
    # 020: entry hazards per side, id -> layers, in the order they were set (see hazards.py)
    hazards: dict[str, dict[str, int]] = field(default_factory=lambda: {"p1": {}, "p2": {}})
    # 025: Showdown ``side.slotConditions`` per side and position (Healing Wish); they stay
    # with the position whoever stands there. The value is True once a runEvent ran the
    # condition's handler (Ally Switch's Swap): its effectState.target is then a Pokémon, and
    # fieldEvent's state check skips it from then on (a Showdown quirk, found in friends-3).
    slot_conditions: dict[str, list[dict[str, bool]]] = field(
        default_factory=lambda: {"p1": [{}, {}], "p2": [{}, {}]}
    )
    # 041-4b: the slot conditions with an onResidual (futuremove, wish), per side and position:
    # id -> effectState (futuremove: source, ending_turn; wish: source, hp, starting_turn)
    slot_effects: dict[str, list[dict[str, dict[str, Any]]]] = field(
        default_factory=lambda: {"p1": [{}, {}], "p2": [{}, {}]}
    )

    @property
    def active_weather(self) -> str | None:
        """043-4g: ``field.effectiveWeather()`` before the holder's item: None while
        Cloud Nine / Air Lock suppresses the weather."""
        return None if self.weather_suppressed else self.weather

    @property
    def trick_room(self) -> bool:
        return TRICK_ROOM in self.pseudo_weather

    def has_side(self, side_id: str, condition: str) -> bool:
        return condition in self.sides[side_id]


def add_pseudo_weather(field_state: FieldState, condition: str, *, source: str, emit: Emit) -> bool:
    """``field.addPseudoWeather``: start the condition, or restart it (Trick Room ends)."""
    if condition in field_state.pseudo_weather:
        if condition not in _RESTART_ENDS:
            return False
        end_pseudo_weather(field_state, condition, emit)
        return True
    field_state.pseudo_weather[condition] = DURATION[condition]
    if condition == FAIRY_LOCK:
        emit("fieldactivate", detail="move: Fairy Lock")  # 041-6f: onFieldStart
        return True
    emit("fieldstart", actor=source, detail=NAMES[condition])
    return True


def end_pseudo_weather(field_state: FieldState, condition: str, emit: Emit) -> None:
    del field_state.pseudo_weather[condition]
    if condition in (ECHOED_VOICE, FAIRY_LOCK):
        return  # 041-1f: no onFieldEnd (041-6f)
    emit("fieldend", detail=NAMES[condition])


def set_weather(
    field_state: FieldState, weather: str, *, emit: Emit, duration: int | None = None
) -> bool:
    """``field.setWeather`` from a move: False when that weather is already up; otherwise it
    replaces any other weather (whose FieldEnd is not run). The caller then runs Showdown's
    ``eachEvent('WeatherChange')``."""
    if field_state.weather == weather:
        return False
    field_state.weather = weather
    field_state.weather_turns = duration or WEATHER_DURATION  # 013: 8 with the weather's rock
    emit("weather", detail=WEATHER_NAMES[weather])
    return True


def clear_weather(field_state: FieldState, *, emit: Emit) -> None:
    """``field.clearWeather`` (the caller then runs ``eachEvent('WeatherChange')``)."""
    field_state.weather = None
    field_state.weather_turns = 0
    emit("weather", detail="none")


def set_terrain(
    field_state: FieldState, terrain: str, *, emit: Emit, duration: int | None = None
) -> bool:
    """``field.setTerrain`` from a move: False when that terrain is already up; otherwise it
    replaces any other terrain (whose FieldEnd is not run). The caller then runs Showdown's
    ``eachEvent('TerrainChange')``."""
    if field_state.terrain == terrain:
        return False
    field_state.terrain = terrain
    field_state.terrain_turns = duration or TERRAIN_DURATION  # (040-4b: Terrain Extender)
    emit("fieldstart", detail=TERRAIN_NAMES[terrain])
    return True


def clear_terrain(field_state: FieldState, *, emit: Emit) -> bool:
    """``field.clearTerrain``: ``-fieldend`` (the caller then runs ``eachEvent('TerrainChange')``).
    False when there is no terrain."""
    if field_state.terrain is None:
        return False
    emit("fieldend", detail=TERRAIN_NAMES[field_state.terrain])
    field_state.terrain = None
    field_state.terrain_turns = 0
    return True


def add_side_condition(
    field_state: FieldState,
    side_id: str,
    condition: str,
    *,
    emit: Emit,
    duration: int | None = None,
) -> bool:
    """``side.addSideCondition``: False when the side already has it (no onSideRestart)."""
    conditions = field_state.sides[side_id]
    if condition in conditions:
        return False
    conditions[condition] = duration or DURATION[condition]  # 013: 8 for a screen with Light Clay
    if condition not in SILENT:
        emit("sidestart", actor=side_id, detail=NAMES[condition])
    return True


def end_side_condition(field_state: FieldState, side_id: str, condition: str, emit: Emit) -> None:
    del field_state.sides[side_id][condition]
    if condition not in SILENT:
        emit("sideend", actor=side_id, detail=NAMES[condition])
