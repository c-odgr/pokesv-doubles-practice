"""056: how a team does against the tournament teams, from the page.

The page asks for one opponent at a time (``step``), so it can show the results so far and stop
at any point, without threads (the same code in the offline version). Both sides are the smart
AI (035). The battles and tables are 019's (``team_eval``); with a fixed seed and label, the
same team gets the same results, and a changed team meets the same opponents with the same
seeds (``compare``).
"""

from __future__ import annotations

import math
import random
from collections.abc import Mapping
from typing import Any

from pokesv_sim.analysis.simulate import smart_player
from pokesv_sim.analysis.stats import wilson_interval
from pokesv_sim.analysis.team_eval import (
    PairResult,
    loss_patterns,
    play_pair,
    select_field,
    tally,
)
from pokesv_sim.play import labels
from pokesv_sim.regf_teams import RegfTeam
from pokesv_sim.runner import check_teams
from pokesv_sim.team import Team

SEED = 56
OWN_LABEL = "eval"  # (not the team's name: a changed team must get the same seeds)
BATTLES = 6  # against each opponent, half as p1
POOLS = ("top8", "all")  # the opponents: teams placed 8th or better, or as many from all
MIN_FOE = 30  # a foe species is listed from this many battles it was brought to
MIN_LEADS = 20  # a lead pair from this many battles
FOE_ROWS = 10
GAP = 0.03  # the difference in win rate from the earlier result that is worth saying
MIN_COMPARE = 30  # opponents both have played before saying better or worse


def opponents(pool: str) -> list[RegfTeam]:
    """The opponents of ``pool``, in the order they are played: shuffled, so a stopped run is
    not made of the oldest tournaments alone."""
    if pool not in POOLS:
        raise ValueError(f"相手の選び方 {pool} はありません")
    top = list(select_field(max_placing=8).teams)
    rng = random.Random(SEED)
    if pool == "all":
        return rng.sample(list(select_field().teams), len(top))
    rng.shuffle(top)
    return top


class TeamCheck:
    """One team's evaluation, played one opponent at a time."""

    def __init__(
        self,
        team: Team,
        pool: str,
        version: str,
        previous: Mapping[str, Any] | None = None,
        field: list[RegfTeam] | None = None,
    ) -> None:
        """Raises ``TeamInvalidError`` / ``UnsupportedError`` before any battle (FR-006).
        ``previous``: an earlier result's ``record``. ``field``: instead of ``pool``'s (tests)."""
        self.field = opponents(pool) if field is None else field
        check_teams(team, self.field[0].team)
        self.team, self.pool, self.version = team, pool, version
        self.previous = previous
        self.pairs: list[PairResult] = []

    @property
    def done(self) -> bool:
        return len(self.pairs) >= len(self.field)

    def step(self) -> dict[str, Any]:
        """Play the next opponent (if any is left) and report."""
        if not self.done:
            foe = self.field[len(self.pairs)]
            self.pairs.append(
                play_pair(
                    self.team,
                    OWN_LABEL,
                    foe.team,
                    foe.id,
                    BATTLES,
                    SEED,
                    player_factory=smart_player,
                )
            )
        return self.report()

    def record(self) -> dict[str, Any]:
        """What a later evaluation compares itself with."""
        return {
            "version": self.version,
            "pool": self.pool,
            "seed": SEED,
            "wins": {p.opponent: p.wins for p in self.pairs},
        }

    def report(self) -> dict[str, Any]:
        total = tally(b for p in self.pairs for b in p.battles)
        out: dict[str, Any] = {
            "opponents": len(self.pairs),
            "of": len(self.field),
            "done": self.done,
            "battles": total.n,
            "wins": total.wins,
            "win_rate": total.win_rate,
            "ci": list(total.ci) if total.n else [0.0, 1.0],
            "aborted": total.aborted,
            "foes": [],
            "own": [],
            "leads": [],
            "record": self.record(),
            "compare": None,
            "min_compare": MIN_COMPARE,
        }
        if not self.pairs:
            return out
        found = loss_patterns(self.team, self.pairs, {t.id: t.team for t in self.field})
        out["foes"] = [
            {
                "name": labels.species(f.species)["name"],
                "brought": f.brought,
                "win_rate": f.win_rate,
                "ci": _ci(round(f.win_rate * f.brought), f.brought),
                "delta": f.delta,
            }
            for f in found.foes
            if f.brought >= MIN_FOE and f.delta < 0
        ][:FOE_ROWS]
        out["own"] = [
            {
                "name": labels.species(o.species)["name"],
                "brought": o.win.battles + o.loss.battles,
                "sent_in": o.win.sent_in + o.loss.sent_in,
                "first_fainted": o.win.first_fainted + o.loss.first_fainted,
                "fainted": o.win.fainted + o.loss.fainted,
                "knockouts": o.win.knockouts + o.loss.knockouts,
            }
            for o in found.own
        ]
        out["leads"] = [
            {
                "names": [labels.species(s)["name"] for s in row.species],
                "battles": row.battles,
                "win_rate": row.win_rate,
                "ci": _ci(row.wins, row.battles),
            }
            for row in found.leads
            if row.battles >= MIN_LEADS
        ]
        if self.previous is not None:
            out["compare"] = compare(self.previous, self.record())
        return out


def _ci(wins: int, n: int) -> list[float]:
    return list(wilson_interval(wins, n))


def compare(before: Mapping[str, Any], now: Mapping[str, Any]) -> dict[str, Any]:
    """``now`` against ``before`` over the opponents both have played: the difference in win
    rate with its 95% interval from the differences by opponent. ``verdict``: "better" or
    "worse" only when the difference is at least ``GAP`` and the interval leaves out 0, over
    ``MIN_COMPARE`` opponents or more (``few`` otherwise: the normal interval of a handful
    says nothing, and is 0 wide when they happen to differ alike)."""
    for key, why in (
        ("version", "アプリの版が違います"),
        ("pool", "相手の選び方が違います"),
        ("seed", "乱数の種が違います"),
    ):
        if before.get(key) != now.get(key):
            return {"error": why + "。前の結果とは比べられません"}
    old = before.get("wins") or {}
    both = [(old[k], w) for k, w in now["wins"].items() if k in old]
    if len(both) < 2:
        return {"error": "両方が戦った相手がまだ足りません"}
    m = len(both)
    gaps = [(new - was) / BATTLES for was, new in both]
    mean = sum(gaps) / m
    spread = math.sqrt(sum((g - mean) ** 2 for g in gaps) / (m - 1) / m)
    low, high = mean - 1.96 * spread, mean + 1.96 * spread
    verdict = "none"
    few = m < MIN_COMPARE
    if not few and abs(mean) >= GAP - 1e-9 and (low > 0 or high < 0):
        verdict = "better" if mean > 0 else "worse"
    return {
        "opponents": m,
        "before": sum(was for was, _ in both) / (m * BATTLES),
        "now": sum(new for _, new in both) / (m * BATTLES),
        "gap": mean,
        "ci": [low, high],
        "verdict": verdict,
        "few": few,
    }
