"""Action order within a turn (Showdown ``comparePriority``, ``speedSort``, ``BattleQueue``).

Actions are sorted by order (switches before moves), then priority (high first), then speed
(high first). Ties are gathered by a selection sort and shuffled with the battle's PRNG, exactly
as Showdown does, so the same seed resolves ties the same way.
"""

from __future__ import annotations

from collections.abc import Callable, Iterator, MutableSequence
from typing import Protocol

from pokesv_sim.prng import Prng

# Showdown BattleQueue.resolveAction orders (lower acts first).
SWITCH_ORDER = 103
TERA_ORDER = 106  # 017: terastallize (after switches, before moves)
MOVE_ORDER = 200
PRIORITIZED_ORDER = 3  # 025: queue.prioritizeAction (After You)


class Sortable(Protocol):
    kind: str
    order: int
    priority: int
    fractional: float  # 032: action.fractionalPriority (Custap Berry)
    speed: int


def compare(a: Sortable, b: Sortable) -> int:
    """Negative when ``a`` acts first, positive when ``b`` does, 0 for a tie (the priority is
    ``priority + fractionalPriority``)."""
    if a.order != b.order:
        return a.order - b.order
    a_priority, b_priority = a.priority + a.fractional, b.priority + b.fractional
    if a_priority != b_priority:
        return 1 if b_priority > a_priority else -1
    return b.speed - a.speed


def speed_sort[T](items: MutableSequence[T], prng: Prng, comparator: Callable[[T, T], int]) -> None:
    """Sort in place; equal elements are shuffled (consumes PRNG draws only on ties)."""
    if len(items) < 2:
        return
    done = 0
    while done + 1 < len(items):
        nexts = [done]
        for i in range(done + 1, len(items)):
            delta = comparator(items[nexts[0]], items[i])
            if delta < 0:
                continue
            if delta > 0:
                nexts = [i]
            else:
                nexts.append(i)
        for offset, index in enumerate(nexts):
            if index != done + offset:
                items[done + offset], items[index] = items[index], items[done + offset]
        if len(nexts) > 1:
            prng.shuffle(items, done, done + len(nexts))
        done += len(nexts)


class ActionQueue[T: Sortable]:
    """The actions left in a turn, in the order they will run."""

    def __init__(self, actions: list[T], prng: Prng) -> None:
        self._list = list(actions)
        self._prng = prng
        speed_sort(self._list, prng, compare)

    def __bool__(self) -> bool:
        return bool(self._list)

    def __iter__(self) -> Iterator[T]:
        return iter(self._list)

    def pop(self) -> T:
        return self._list.pop(0)

    def peek(self) -> T | None:
        return self._list[0] if self._list else None

    def remove(self, predicate: Callable[[T], bool]) -> None:
        """Drop queued actions (e.g. those of a Pokémon that fainted)."""
        self._list = [a for a in self._list if not predicate(a)]

    def prioritize(self, action: T) -> None:
        """Showdown ``queue.prioritizeAction`` (025, After You): the action moves to the front
        with order 3, so it stays first through the sorts that follow."""
        self._list = [a for a in self._list if a is not action]
        action.order = PRIORITIZED_ORDER
        self._list.insert(0, action)

    def resort_if_move_next(self, refresh: Callable[[T], None] | None = None) -> None:
        """Gen 8+: when a move is next, update speeds and sort again (Showdown ``runAction``)."""
        if self._list and self._list[0].kind == "move":
            if refresh is not None:
                for action in self._list:
                    refresh(action)
            speed_sort(self._list, self._prng, compare)
