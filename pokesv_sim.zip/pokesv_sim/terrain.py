"""Terrain effects (010; Showdown ``data/moves.ts`` terrain conditions and the moves that use them).

Terrains affect grounded Pokémon only. In 010 a Pokémon is grounded unless it is Flying-type
(Levitate and Air Balloon come with abilities and items in 011 and 012).
"""

from __future__ import annotations

from dataclasses import replace

from pokesv_sim.dex import Move
from pokesv_sim.field import ELECTRIC, GRASSY, MISTY, PSYCHIC

TERRAIN_BOOST = (5325, 4096)  # onBasePower: chainModify([5325, 4096])
_BOOSTED_TYPE = {ELECTRIC: "Electric", GRASSY: "Grass", PSYCHIC: "Psychic"}
_GRASSY_WEAKENED = frozenset({"earthquake", "bulldoze", "magnitude"})
_PULSE_TYPE = {ELECTRIC: "Electric", GRASSY: "Grass", MISTY: "Fairy", PSYCHIC: "Psychic"}
TERRAIN_PRIORITY = 6  # onBasePowerPriority
GRASSY_HEAL_ORDER = (5, 2)  # Grassy Terrain onResidualOrder, onResidualSubOrder


def is_grounded(
    types: tuple[str, ...],
    ability: str = "",
    item: str = "",
    smacked: bool = False,
    *,
    rising: bool = False,
) -> bool:
    """``pokemon.isGrounded()``: Smack Down (041-2) and Iron Ball (032) ground it; otherwise
    not Flying-type (010), not Levitate (011) and not holding an Air Balloon (032)."""
    if smacked or item == "ironball":
        return True
    # (041-6f: magnetrise, after Levitate)
    return "Flying" not in types and ability != "levitate" and not rising and item != "airballoon"


def base_power_modifier(
    terrain: str | None,
    move: Move,
    *,
    attacker_grounded: bool,
    defender_grounded: bool,
) -> tuple[int, int] | None:
    """The terrain's ``onBasePower`` (priority 6), or None."""
    if terrain == GRASSY and move.id in _GRASSY_WEAKENED and defender_grounded:
        return (1, 2)
    if terrain == MISTY:
        return (1, 2) if move.type == "Dragon" and defender_grounded else None
    if terrain in _BOOSTED_TYPE and move.type == _BOOSTED_TYPE[terrain] and attacker_grounded:
        return TERRAIN_BOOST
    return None


def move_base_power_modifier(
    terrain: str | None, move: Move, *, attacker_grounded: bool
) -> tuple[int, int] | None:
    """The move's own ``onBasePower`` (priority 0): Expanding Force, Psyblade."""
    if move.id == "expandingforce" and terrain == PSYCHIC and attacker_grounded:
        return (3, 2)
    if move.id == "psyblade" and terrain == ELECTRIC:
        return (3, 2)
    if move.id == "mistyexplosion" and terrain == MISTY and attacker_grounded:
        return (3, 2)  # 041-1c
    return None


def base_power_callback(terrain: str | None, move: Move, *, defender_grounded: bool) -> int:
    """``basePowerCallback``: Rising Voltage doubles on a grounded target in Electric Terrain."""
    if move.id == "risingvoltage" and terrain == ELECTRIC and defender_grounded:
        return move.base_power * 2
    return move.base_power


def modify_move(move: Move, terrain: str | None, *, user_grounded: bool) -> Move:
    """ModifyType / ModifyMove: Terrain Pulse (type, double power) and Expanding Force (both
    foes in Psychic Terrain)."""
    if terrain is None or not user_grounded:
        return move
    if move.id == "terrainpulse":
        return replace(move, type=_PULSE_TYPE[terrain], base_power=move.base_power * 2)
    if move.id == "expandingforce" and terrain == PSYCHIC:
        return replace(move, target="allAdjacentFoes")
    return move


def priority(move: Move, terrain: str | None, *, user_grounded: bool) -> int:
    """``onModifyPriority``: Grassy Glide +1 in Grassy Terrain."""
    if move.id == "grassyglide" and terrain == GRASSY and user_grounded:
        return move.priority + 1
    return move.priority


def blocks_status(terrain: str | None, status: str, *, grounded: bool) -> bool:
    """``onSetStatus``: Misty Terrain blocks every status, Electric Terrain sleep."""
    if not grounded:
        return False
    return terrain == MISTY or (terrain == ELECTRIC and status == "slp")


def blocks_confusion(terrain: str | None, *, grounded: bool) -> bool:
    """Misty Terrain ``onTryAddVolatile`` (confusion)."""
    return terrain == MISTY and grounded


def blocks_priority(
    terrain: str | None, move: Move, *, target_grounded: bool, from_ally: bool
) -> bool:
    """Psychic Terrain ``onTryHit`` (priority 4): a foe's raised-priority move on a grounded
    target."""
    if terrain != PSYCHIC or move.priority <= 0.1 or move.target == "self":
        return False
    return target_grounded and not from_ally
