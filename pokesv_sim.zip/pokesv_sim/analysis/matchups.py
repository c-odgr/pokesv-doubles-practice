"""The light form of Showdown's battles per team pair (023).

Each battle keeps a digest of its normalized lines (to tell whether our engine played it the same
move by move) and its ``Metrics`` (to compare distributions). The seeds are not kept: they follow
from the pair's ``seed`` and the battle's index (``derive`` in tools/oracle/run_matchups.mjs).
To see where a battle differs, play that one battle in Showdown again (``--trace``).
"""

from __future__ import annotations

import dataclasses
import gzip
import hashlib
import json
from collections.abc import Iterable, Iterator, Sequence
from pathlib import Path
from typing import Any

from pokesv_sim.analysis.normalize import Metrics, metrics

METRIC_FIELDS: tuple[str, ...] = tuple(f.name for f in dataclasses.fields(Metrics))
_ROLES = ("battle", "p1", "p2")


def derive_seeds(base: int | str, index: int) -> dict[str, str]:
    """The Showdown seeds of battle ``index`` of a pair (same formula as run_matchups.mjs)."""
    return {
        role: "gen5," + hashlib.sha256(f"{base}:{index}:{role}".encode()).hexdigest()[:16]
        for role in _ROLES
    }


def lines_digest(lines: Sequence[str]) -> str:
    """64 bits of SHA-256 over the normalized lines joined by newlines."""
    return hashlib.sha256("\n".join(lines).encode()).hexdigest()[:16]


def slim_battle(lines: Sequence[str]) -> dict[str, Any]:
    """One battle of the fixture: ``{"h": digest, "m": metric values in METRIC_FIELDS order}``."""
    m = metrics(lines)
    return {"h": lines_digest(lines), "m": [getattr(m, name) for name in METRIC_FIELDS]}


def battle_metrics(battle: dict[str, Any]) -> Metrics:
    return Metrics(*battle["m"])


def read_full_matchups(path: Path) -> Iterator[dict[str, Any]]:
    """Pairs with every battle's lines, as Showdown played them: ``*.jsonl.gz`` holds one pair
    per line (read one at a time); otherwise the old whole fixture (before 023)."""
    if path.name.endswith(".jsonl.gz"):
        with gzip.open(path, "rt", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    yield json.loads(line)
        return
    yield from json.loads(gzip.decompress(path.read_bytes()))["matchups"]


def write_fixture(matchups: Iterable[dict[str, Any]], target: Path, source: str) -> None:
    """Write the light fixture one pair at a time, through a temporary file (a stopped run leaves
    the old fixture as it was). Refuses battles whose seeds are not the formula's."""
    partial = target.with_name(target.name + ".partial")
    try:
        with gzip.open(partial, "wt", encoding="utf-8", compresslevel=9) as out:
            head = {"source": source, "metrics": list(METRIC_FIELDS)}
            out.write(json.dumps(head, separators=(",", ":"))[:-1] + ',"matchups":[')
            for k, m in enumerate(matchups):
                battles = []
                for i, b in enumerate(m["battles"]):
                    if b["seeds"] != derive_seeds(m["seed"], i):
                        raise ValueError(f"{m['id']}#{i}: the seeds are not derive_seeds")
                    battles.append(slim_battle(b["lines"]))
                pair = {key: v for key, v in m.items() if key != "battles"}
                pair["battles"] = battles
                out.write(("," if k else "") + json.dumps(pair, separators=(",", ":")))
            out.write("]}")
        partial.replace(target)
    finally:
        partial.unlink(missing_ok=True)
