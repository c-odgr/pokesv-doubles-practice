"""039: the local web server (``python -m pokesv_sim play``). Listens on 127.0.0.1 only;
045: with ``--lan`` on every address, for a phone on the same Wi-Fi, behind a key."""

from __future__ import annotations

import hmac
import json
import random
import secrets
import socket
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources
from typing import Any
from urllib.parse import parse_qs, unquote, urlsplit

from pokesv_sim.play import builder, labels
from pokesv_sim.play.evaluation import TeamCheck
from pokesv_sim.play.session import AIS, DEFAULT_AI, DESCRIPTIONS, Game
from pokesv_sim.regf_teams import get_regf_team, regf_teams, status
from pokesv_sim.runner import TeamInvalidError, UnsupportedError, check_teams
from pokesv_sim.team import Team, parse_team


def load_team(spec: str | dict[str, Any]) -> Team:
    if isinstance(spec, dict):  # the team builder's team
        return builder.team_from_json(spec.get("members", []))
    spec = spec.strip()
    if spec.startswith("regf:") or (spec and "\n" not in spec and " " not in spec):
        found = get_regf_team(spec if spec.startswith("regf:") else "regf:" + spec)
        if found is None:
            raise ValueError(f"大会のチーム {spec} が見つかりません")
        return found.team
    return parse_team(spec)


def version() -> str:
    """The app's version (``play/VERSION``): 1.x for small changes, 2.0 for a large one."""
    return (
        resources.files("pokesv_sim.play").joinpath("VERSION").read_text(encoding="utf-8").strip()
    )


class App:
    def __init__(self, game_class: type[Game] = Game) -> None:
        self.lock = threading.Lock()
        self.game_class = game_class  # 047: StepGame in the offline version (no threads)
        self.game: Game | None = None
        self.check: tuple[int, TeamCheck] | None = None  # 056: (its number, the evaluation)
        self.checks = 0
        self._teams: list[dict[str, Any]] | None = None

    def teams(self) -> list[dict[str, Any]]:
        if self._teams is None:
            self._teams = [
                {
                    "id": t.id,
                    "names": "・".join(labels.species(m.species)["name"] for m in t.team.members),
                }
                for t in regf_teams()
                if status(t.id).runnable
            ]
        return self._teams

    def get(self, path: str) -> Any:
        """The answer to ``GET /api/...`` (the same for the server and the offline version),
        or None for an unknown path."""
        if path == "/api/options":
            ais = [{"id": i, "label": label, "desc": DESCRIPTIONS[i]} for i, label, _ in AIS]
            return {"ais": ais, "default": DEFAULT_AI, "teams": self.teams(), "version": version()}
        if path == "/api/catalog":
            return builder.catalog()
        if path.startswith("/api/randomset?id="):
            return builder.random_set(unquote(path.split("=", 1)[1]), random) or {}
        if path.startswith("/api/team?id="):
            try:
                return builder.team_to_json(load_team(unquote(path.split("=", 1)[1])))
            except ValueError:
                return []
        if path.startswith("/api/species?id="):
            return builder.species_detail(unquote(path.split("=", 1)[1]))
        if path == "/api/state":
            return self.game.state() if self.game else {"phase": "setup"}
        return None

    def post(self, path: str, body: dict[str, Any]) -> Any:
        if path == "/api/new":
            return self.new(body)
        if path == "/api/choose" and self.game is not None:
            self.game.choose(body["answer"])
            return {"ok": True}
        if path == "/api/review":
            turn = int(body["turn"])
            with self.lock:
                if self.game is None:
                    return {"turn": turn, "done": True, "error": "対戦がありません"}
                return self.game.review_step(turn)
        if path == "/api/eval/start":
            return self.start_check(body)
        if path == "/api/eval/step":
            return self.step_check(body)
        return None

    def start_check(self, body: dict[str, Any]) -> dict[str, Any]:
        """056: an evaluation of one team; ``step_check`` plays it."""
        try:
            made = TeamCheck(
                load_team(body.get("team", "")),
                body.get("pool") or "top8",
                version(),
                body.get("previous"),
            )
        except (TeamInvalidError, UnsupportedError, ValueError) as e:
            return {"ok": False, "error": str(e)}
        with self.lock:
            self.checks += 1
            self.check = (self.checks, made)
            return {"ok": True, "id": self.checks, "report": made.report()}

    def step_check(self, body: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            if self.check is None or self.check[0] != body.get("id"):
                return {"ok": False, "error": "この調査は終わっています（別の画面で始め直した等）"}
            try:
                return {"ok": True, "report": self.check[1].step()}
            except Exception as e:  # shown on the page, which stops asking
                return {"ok": False, "error": f"調査を続けられません: {e}"}

    def new(self, body: dict[str, Any]) -> dict[str, Any]:
        try:
            mine, foe = load_team(body.get("mine", "")), load_team(body.get("foe", ""))
            check_teams(mine, foe)
        except (TeamInvalidError, UnsupportedError, ValueError) as e:
            return {"ok": False, "error": str(e)}
        ai = body.get("ai") or DEFAULT_AI
        if ai not in {i for i, _, _ in AIS}:
            return {"ok": False, "error": f"AI {ai} はありません"}
        seed = int(body.get("seed") or random.randrange(1, 2**31))
        with self.lock:
            if self.game is not None:
                self.game.stop()
            self.game = self.game_class(mine, foe, ai, seed)
        return {"ok": True, "seed": seed}


COOKIE = "pokesv_key"
_KEY_PAGE = """<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>鍵を入れてください</title>
<style>body{font-family:system-ui,sans-serif;margin:24px;line-height:1.6;max-width:32em}
input,button{font:inherit;padding:10px;min-height:44px;width:100%;box-sizing:border-box;
margin:6px 0}
button{background:#2f6fde;color:#fff;border:0;border-radius:8px}</style></head><body>
<h1 style="font-size:20px">鍵がありません</h1>
<p>PC に表示された「スマホで開く URL」をそのまま開くか、
URL の最後の <b>key=</b> のあとの文字を入れてください。
PC で対戦の画面を起動し直すと鍵は変わります。</p>
<form method="get" action="/"><input name="key" autocomplete="off" autocapitalize="off"
spellcheck="false" placeholder="鍵（key= のあとの文字）">
<button>開く</button></form></body></html>"""


def make_handler(
    app: App, key: str | None = None, phone_url: str = ""
) -> type[BaseHTTPRequestHandler]:
    """045: ``key``: every request needs it (a cookie, set by opening ``/?key=...`` once)."""

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:  # quiet
            pass

        remember = False  # 045: this answer sets the key's cookie

        def _allowed(self) -> bool:
            """045: no key (127.0.0.1 only), or the key from its cookie, the page's ``X-Key``
            header (a browser that keeps no cookies) or ``?key=`` (the page is served and the
            key remembered)."""
            if key is None:
                return True
            given = [self.headers.get("X-Key") or ""]
            for part in (self.headers.get("Cookie") or "").split(";"):
                name, _, value = part.strip().partition("=")
                if name == COOKIE:
                    given.append(value)
            from_url = parse_qs(urlsplit(self.path).query).get("key", [""])[0].strip()
            if any(hmac.compare_digest(g, key) for g in given if g):
                return True
            if from_url and hmac.compare_digest(from_url, key):
                self.remember = True
                return True
            self._send(403, _KEY_PAGE.encode(), "text/html; charset=utf-8")
            return False

        def _send(self, code: int, body: bytes, kind: str) -> None:
            self.send_response(code)
            self.send_header("Content-Type", kind)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            if self.remember and key:
                self.send_header(
                    "Set-Cookie", f"{COOKIE}={key}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000"
                )
            self.end_headers()
            self.wfile.write(body)

        def _json(self, data: Any) -> None:
            self._send(200, json.dumps(data, ensure_ascii=False).encode(), "application/json")

        def do_GET(self) -> None:
            if not self._allowed():
                return
            if self.path == "/manifest.webmanifest":  # 045: added to a phone's home screen
                self._send(200, _manifest(), "application/manifest+json")
            elif self.path == "/api/phone":
                self._json({"url": phone_url})
            elif urlsplit(self.path).path in ("/", "/index.html"):
                page = resources.files("pokesv_sim.play").joinpath("index.html").read_bytes()
                self._send(200, page, "text/html; charset=utf-8")
            elif (data := app.get(self.path)) is not None:
                self._json(data)
            else:
                self._send(404, b"not found", "text/plain")

        def do_POST(self) -> None:
            if not self._allowed():
                return
            size = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(size) or b"{}")
            if (data := app.post(self.path, body)) is not None:
                self._json(data)
            else:
                self._send(404, b"not found", "text/plain")

    return Handler


def _manifest() -> bytes:
    data = {"name": "ポケモンSVダブルバトルシミュレータ", "short_name": "ダブル練習",
            "start_url": "/", "display": "standalone", "background_color": "#121519",
            "theme_color": "#2f6fde"}  # fmt: skip
    return json.dumps(data, ensure_ascii=False).encode()


def lan_address() -> str:
    """045: this PC's address on the local network (the interface that would reach outside;
    nothing is sent), or 127.0.0.1 when there is none."""
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        try:
            s.connect(("10.255.255.255", 1))
            return str(s.getsockname()[0])
        except OSError:
            return "127.0.0.1"


def _in_use(port: int) -> bool:
    """045: something already answers on 127.0.0.1:``port``."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def serve(port: int = 8765, open_browser: bool = True, lan: bool = False) -> None:
    """039: on 127.0.0.1. 045 (``lan``): on every address, behind a new key; the phone opens
    the LAN address with the key."""
    if port and _in_use(port):
        # 045: on Windows a second server can bind 0.0.0.0 next to an older one on 127.0.0.1,
        # and the PC's browser then reaches the older one ("not found" for ?key=)
        print(f"ポート {port} は別のプログラム（前に起動した対戦の画面など）が使っています。")
        print("そのウィンドウを閉じてから起動し直すか、--port で別の番号を指定してください。")
        return
    key = secrets.token_urlsafe(12) if lan else None
    host = "0.0.0.0" if lan else "127.0.0.1"
    app = App()
    server = ThreadingHTTPServer((host, port), make_handler(app, key))
    port = server.server_address[1]
    query = f"?key={key}" if key else ""
    local = f"http://127.0.0.1:{port}/{query}"
    phone = f"http://{lan_address()}:{port}/{query}" if lan else ""
    server.RequestHandlerClass = make_handler(app, key, phone)  # (the port is known now)
    print(f"対戦の画面: {local}  （止めるときは Ctrl+C）")
    if lan:
        print(f"スマホで開く URL（同じ Wi-Fi）: {phone}")
        print("鍵つきの URL です。他の人に見せないでください。起動するたびに変わります。")
    if open_browser:
        webbrowser.open(phone or local)  # 045: the same address as the phone
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
