"""035 (plan R4): damage estimates from what a side sees and the guesses at the foe's sets.

Own Pokémon are exact (``OwnPokemonView``); a foe is built from one ``SetHypothesis`` (its
stats from the species, the guessed spread and nature, level 50, every IV 31) with what is shown
of it (stat stages, status, Tera Type). The rolls come from the engine's public ``damage_rolls``
(FR-011, FR-015).
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from functools import cache

from pokesv_sim.abilities import RUIN
from pokesv_sim.ai.sets import Evs, SetHypothesis
from pokesv_sim.damage import Combatant, damage_rolls
from pokesv_sim.dex import STAT_IDS, Move, get_dex, to_id
from pokesv_sim.field import SCREENS
from pokesv_sim.stats import calc_stats
from pokesv_sim.view import FoePokemonView, OwnPokemonView, SideView

LEVEL = 50
BOOSTERS = frozenset({"protosynthesis", "quarkdrive"})


@dataclass(frozen=True, slots=True)
class Field:
    """The damage conditions on the field, as the side sees them."""

    weather: str | None = None
    terrain: str | None = None
    own_screens: frozenset[str] = frozenset()  # on this side (they cut the foe's damage)
    foe_screens: frozenset[str] = frozenset()
    ruin: frozenset[str] = frozenset()


def field_of(view: SideView, foe_abilities: Sequence[str] = ()) -> Field:
    """``foe_abilities``: the abilities known or guessed for the foe's active Pokémon."""
    own = [p.ability for p in view.team if p.position is not None and not p.fainted]
    return Field(
        weather=view.weather[0] if view.weather else None,
        terrain=view.terrain[0] if view.terrain else None,
        own_screens=frozenset(k for k, _ in view.own_side_conditions if k in SCREENS),
        foe_screens=frozenset(k for k, _ in view.foe_side_conditions if k in SCREENS),
        ruin=frozenset(a for a in (*own, *foe_abilities) if a in RUIN),
    )


@cache
def _stats(species: str, nature: str, evs: Evs) -> dict[str, int]:
    dex = get_dex()
    found = dex.species(species)
    found_nature = dex.nature(nature)
    assert found is not None and found_nature is not None, (species, nature)
    return calc_stats(found.base_stats, dict.fromkeys(STAT_IDS, 31), dict(evs), LEVEL, found_nature)


def hypothesis_stats(hyp: SetHypothesis) -> dict[str, int]:
    """The foe's six stats under the guess."""
    return _stats(hyp.species, hyp.nature, hyp.evs)


def own_combatant(p: OwnPokemonView) -> Combatant:
    species = get_dex().species(p.species)
    assert species is not None
    return Combatant(
        level=LEVEL,
        types=(p.terastallized,)
        if p.terastallized and p.terastallized != "Stellar"
        else (p.types or species.types),
        base_types=species.types,
        tera=p.terastallized,
        species=species.name,
        stats=dict(p.stats),
        burned=p.status == "brn",
        boosts=dict(p.boosts),
        ability=p.ability,
        booster=p.booster,
        statused=p.status is not None,
        full_hp=p.hp >= p.max_hp,
        item=p.item,
        nfe=species.nfe,
        status=p.status,
        hp=p.hp,
        max_hp=p.max_hp,
        weight_hg=max(1, round(species.weightkg * 10)),
    )


def foe_combatant(
    hyp: SetHypothesis,
    shown: FoePokemonView | None = None,
    *,
    item: str | None = None,
    weather: str | None = None,
    terrain: str | None = None,
    tera: str | None = None,
) -> Combatant:
    """``item``: the item the foe holds now when known (it may have lost the guessed one);
    ``tera``: the Tera Type it took, when ``shown`` is not there to say (it fainted)."""
    species = get_dex().species(hyp.species)
    assert species is not None
    stats = hypothesis_stats(hyp)
    tera = shown.terastallized if shown is not None else tera
    held = item if item is not None else (hyp.item or "")
    ability = hyp.ability or (to_id(species.abilities[0]) if species.abilities else "")
    booster = None
    if ability in BOOSTERS and (
        held == "boosterenergy"
        or (ability == "protosynthesis" and weather in ("sunnyday", "desolateland"))
        or (ability == "quarkdrive" and terrain == "electricterrain")
    ):
        booster = max(("atk", "def", "spa", "spd", "spe"), key=lambda s: stats[s])
    percent = shown.hp_percent if shown is not None else 100
    max_hp = stats["hp"]
    return Combatant(
        level=LEVEL,
        types=(tera,) if tera and tera != "Stellar" else species.types,
        base_types=species.types,
        tera=tera,
        species=species.name,
        stats=stats,
        burned=shown is not None and shown.status == "brn",
        boosts=dict(shown.boosts) if shown is not None else None,
        ability=ability,
        booster=booster,
        statused=shown is not None and shown.status is not None,
        full_hp=percent >= 100,
        item=held,
        nfe=species.nfe,
        status=shown.status if shown is not None else None,
        hp=max(1, max_hp * percent // 100),
        max_hp=max_hp,
        weight_hg=max(1, round(species.weightkg * 10)),
    )


def rolls(
    attacker: Combatant,
    defender: Combatant,
    move: Move,
    field: Field,
    *,
    attacker_is_own: bool,
    crit: bool = False,
    spread: bool = False,
    helping_hand: bool = False,
) -> list[int]:
    """The 16 damage values (empty when immune). Screens are on the defender's side."""
    screens = field.foe_screens if attacker_is_own else field.own_screens
    return damage_rolls(
        attacker, defender, move,
        crit=crit, spread=spread, weather=field.weather, screens=screens,
        helping_hand=helping_hand, terrain=field.terrain, ruin=field.ruin,
    )  # fmt: skip
