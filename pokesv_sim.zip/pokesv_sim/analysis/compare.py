"""Compare two sets of battles: metric distributions, and battles move by move."""

from __future__ import annotations

from collections import Counter
from collections.abc import Callable, Sequence
from dataclasses import dataclass

from pokesv_sim.analysis.normalize import Metrics
from pokesv_sim.analysis.stats import chi_square_p, ks_2samp

MIN_SAMPLE = 100
_QUANTITY_BINS = 10


@dataclass(frozen=True, slots=True)
class MetricComparison:
    name: str  # e.g. "winner:chi2", "turns:ks"
    ours_mean: float
    theirs_mean: float
    p_value: float
    passed: bool


@dataclass(frozen=True, slots=True)
class DistributionComparison:
    metrics: list[MetricComparison]
    threshold: float  # per-test significance level after the Bonferroni correction
    decided: bool  # False when a sample is too small to judge
    passed: bool


def _category_counts(values: Sequence[object]) -> dict[str, int]:
    return {str(k): v for k, v in Counter(values).items()}


def _binned(
    ours: Sequence[float], theirs: Sequence[float]
) -> tuple[dict[str, int], dict[str, int]]:
    """Counts in bins at the pooled sample's deciles (for a chi-square test on a quantity)."""
    pooled = sorted([*ours, *theirs])
    edges = sorted({pooled[len(pooled) * k // _QUANTITY_BINS] for k in range(1, _QUANTITY_BINS)})

    def bin_of(v: float) -> str:
        return str(sum(v >= e for e in edges))

    return _category_counts([bin_of(v) for v in ours]), _category_counts(
        [bin_of(v) for v in theirs]
    )


def _mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


_CATEGORICAL: dict[str, Callable[[Metrics], object]] = {
    "winner": lambda m: m.winner or "none",
    "aborted": lambda m: m.aborted,
    "crits": lambda m: m.crits,
    "misses": lambda m: m.misses,
    "faints_p1": lambda m: m.faints_p1,
    "faints_p2": lambda m: m.faints_p2,
    "statuses": lambda m: m.statuses,
    "flinches": lambda m: m.flinches,
    "confusions": lambda m: m.confusions,
    "trick_rooms": lambda m: m.trick_rooms,
    "tailwinds": lambda m: m.tailwinds,
    "weathers": lambda m: m.weathers,
    "screens": lambda m: m.screens,
    "protects": lambda m: m.protects,
    "single_turns": lambda m: m.single_turns,
    "terrains": lambda m: m.terrains,
    "abilities": lambda m: m.abilities,
}
_QUANTITIES: dict[str, Callable[[Metrics], float]] = {
    "turns": lambda m: m.turns,
    "damage_p1": lambda m: m.damage_p1,
    "damage_p2": lambda m: m.damage_p2,
}


def _numeric(value: object) -> float:
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, int | float):
        return float(value)
    return 1.0 if value == "p1" else 0.0  # winner: share of p1 wins


def compare_distributions(
    ours: Sequence[Metrics],
    theirs: Sequence[Metrics],
    *,
    alpha: float = 0.01,
    families: int = 1,
) -> DistributionComparison:
    """Test every metric for a difference; ``families`` is how many such comparisons are made."""
    raw: list[tuple[str, float, float, float]] = []
    for name, get in _CATEGORICAL.items():
        a, b = [get(m) for m in ours], [get(m) for m in theirs]
        p = chi_square_p(_category_counts(a), _category_counts(b))
        mean_a = _mean([_numeric(v) for v in a])
        mean_b = _mean([_numeric(v) for v in b])
        raw.append((f"{name}:chi2", mean_a, mean_b, p))
    for name, get_q in _QUANTITIES.items():
        qa, qb = [get_q(m) for m in ours], [get_q(m) for m in theirs]
        _, p_ks = ks_2samp(qa, qb) if qa and qb else (0.0, 1.0)
        raw.append((f"{name}:ks", _mean(qa), _mean(qb), p_ks))
        ca, cb = _binned(qa, qb) if qa and qb else ({}, {})
        raw.append((f"{name}:chi2", _mean(qa), _mean(qb), chi_square_p(ca, cb)))

    threshold = alpha / (len(raw) * families)
    decided = len(ours) >= MIN_SAMPLE and len(theirs) >= MIN_SAMPLE
    metrics = [MetricComparison(n, a, b, p, p > threshold) for n, a, b, p in raw]
    return DistributionComparison(
        metrics=metrics,
        threshold=threshold,
        decided=decided,
        passed=decided and all(m.passed for m in metrics),
    )


@dataclass(frozen=True, slots=True)
class Divergence:
    index: int  # position in the line lists
    turn: int  # turn in progress at that point (0 before turn 1)
    ours: str | None  # None when our list ended first
    theirs: str | None


def first_divergence(ours: Sequence[str], theirs: Sequence[str]) -> Divergence | None:
    """Where two normalized battles first differ, or None when they are identical."""
    turn = 0
    for i in range(max(len(ours), len(theirs))):
        a = ours[i] if i < len(ours) else None
        b = theirs[i] if i < len(theirs) else None
        if a != b:
            return Divergence(i, turn, a, b)
        if a is not None and a.startswith("turn "):
            turn = int(a.split()[1])
    return None
