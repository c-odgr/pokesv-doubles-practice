"""035: the smart AI. It sees only its ``SideView`` (constitution VII) and the legal choices."""

from __future__ import annotations

import itertools
from collections.abc import Sequence
from dataclasses import replace

from pokesv_sim.ai.belief import Beliefs
from pokesv_sim.ai.preview import bring, replacement
from pokesv_sim.ai.score import Evaluator
from pokesv_sim.choices import Choice, MoveChoice, PassChoice, Preview, SwitchChoice
from pokesv_sim.players import seed_words
from pokesv_sim.prng import Prng, Seed
from pokesv_sim.view import SideView

TIE = 1e-9
SHORTLIST = 6  # options per position kept for the pair search (SC-005)

type Option = MoveChoice | SwitchChoice | None


class SmartPlayer:
    """Chooses the pair of actions with the best value (``score.Evaluator``). Ties are broken
    by its own PRNG, so the same seed in the same battle makes the same choices (FR-007)."""

    def __init__(self, seed: int | Seed) -> None:
        self.prng = Prng(seed_words(seed))
        self.beliefs: Beliefs | None = None
        self._fresh: set[int] = set()  # positions whose Pokémon came in since the last turn
        self._protected: frozenset[int] = frozenset()  # used a protecting move last turn
        # the turn last chosen for and what was known before it: asked again for the same turn
        # (022, a refused choice, ``log=()``), the AI chooses from the same knowledge
        self._asked: tuple[int, frozenset[int], frozenset[int]] | None = None

    def _read(self, view: SideView) -> Beliefs:
        if self.beliefs is None:
            self.beliefs = Beliefs(view.foe_preview, view.side)
        self.beliefs.read(view.log, view)
        for event in view.log:
            if event.kind in ("switch", "drag") and event.actor and event.actor[:2] == view.side:
                self._fresh.add(ord(event.actor[2]) - ord("a"))
        return self.beliefs

    def choose_preview(self, view: SideView) -> Preview:
        """US3: the four that trade best with the foe's six, the best two leading."""
        self.beliefs = Beliefs(view.foe_preview, view.side)
        foes = [self.beliefs[s] for s in view.foe_preview]
        return Preview(bring(view.team, foes))

    def choose_turn(
        self, view: SideView, legal: Sequence[Sequence[MoveChoice | SwitchChoice]]
    ) -> list[Choice]:
        beliefs = self._read(view)
        if self._asked is not None and self._asked[0] == view.turn and not view.log:
            _, fresh, self._protected = self._asked
            self._fresh = set(fresh)
        self._asked = (view.turn, frozenset(self._fresh), self._protected)
        evaluator = Evaluator(view, beliefs, frozenset(self._fresh), self._protected)
        best = _best_of(scored_pairs(evaluator, view, legal))
        chosen = best[0] if len(best) == 1 else best[self.prng.random_int(len(best))]
        self._fresh = set()
        self._protected = frozenset(
            i for i, c in enumerate(chosen) if c is not None and evaluator.protects(i, c)
        )
        return [PassChoice() if c is None else c for c in chosen]

    def choose_replacements(
        self, view: SideView, need: Sequence[bool]
    ) -> list[SwitchChoice | PassChoice]:
        """US3: the bench Pokémon that trades best with the foes on the field."""
        beliefs = self._read(view)
        by_index = {p.team_index: p for p in view.team}
        bench = [by_index[i] for i in view.order]
        bench = [p for p in bench if not p.fainted and p.position is None]
        labels = [
            f"{beliefs.foe}{'ab'[f.position]}" for f in view.foe_active if f and not f.fainted
        ]
        foes = [b for b in (beliefs.at(label) for label in labels) if b is not None]
        out: list[SwitchChoice | PassChoice] = []
        for must in need:
            chosen = replacement(bench, foes) if must else None
            if chosen is None:
                out.append(PassChoice())
                continue
            out.append(SwitchChoice(chosen))
            bench = [p for p in bench if p.team_index != chosen]
        return out


def _with_tera(
    view: SideView, position: int, options: Sequence[MoveChoice | SwitchChoice]
) -> list[Option]:
    """The legal options plus each move with Terastallization, when it may (as the random AI:
    not with a locked move, Struggle or a recharge)."""
    out: list[Option] = list(options)
    user = next((p for p in view.team if p.position == position and not p.fainted), None)
    moves = [c for c in options if isinstance(c, MoveChoice)]
    if (
        view.can_terastallize
        and user is not None
        and not user.locked
        and moves
        and all(c.move_index >= 0 for c in moves)
    ):
        out += [replace(c, terastallize=True) for c in moves]
    return out


def scored_pairs(
    evaluator: Evaluator, view: SideView, legal: Sequence[Sequence[MoveChoice | SwitchChoice]]
) -> list[tuple[float, tuple[Option, ...]]]:
    """Each allowed pair of the search with its value, in the search's order (036 takes its
    candidates from it). SC-005: only each position's best options alone go into the pair
    search; when no pair of them is allowed (both only Terastallized), all options are."""
    per_position: list[list[Option]] = [
        _with_tera(view, position, options) or [None] for position, options in enumerate(legal)
    ]
    short = [_best_alone(evaluator, i, opts) for i, opts in enumerate(per_position)]
    return _scored(evaluator, short) or _scored(evaluator, per_position)


def _scored(
    evaluator: Evaluator, per_position: Sequence[list[Option]]
) -> list[tuple[float, tuple[Option, ...]]]:
    return [
        (evaluator.value(pair), pair)
        for pair in itertools.product(*per_position)
        if _compatible(pair)
    ]


def _best_of(scored: Sequence[tuple[float, tuple[Option, ...]]]) -> list[tuple[Option, ...]]:
    """The pairs with the highest value (within ``TIE``), as the search met them."""
    best: list[tuple[Option, ...]] = []
    top = float("-inf")
    for value, pair in scored:
        if value > top + TIE:
            top, best = value, [pair]
        elif value > top - TIE:
            best.append(pair)
    return best


def _best_alone(evaluator: Evaluator, position: int, options: list[Option]) -> list[Option]:
    """The ``SHORTLIST`` options with the highest value alone (the ally doing nothing), in the
    order given among equals."""
    if len(options) <= SHORTLIST:
        return options
    alone = [
        evaluator.value(tuple(c if i == position else None for i in range(2))) for c in options
    ]
    order = sorted(range(len(options)), key=lambda k: -alone[k])[:SHORTLIST]
    return [options[k] for k in sorted(order)]


def _compatible(pair: Sequence[Option]) -> bool:
    """One Terastallization per side; not the same Pokémon switched in twice."""
    teras = sum(isinstance(c, MoveChoice) and c.terastallize for c in pair)
    switches = [c.team_index for c in pair if isinstance(c, SwitchChoice)]
    return teras <= 1 and len(switches) == len(set(switches))
