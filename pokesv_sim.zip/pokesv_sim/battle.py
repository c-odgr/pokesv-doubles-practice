"""A doubles battle: team preview, turns, replacements and the result.

The battle is driven step by step: ``start`` with both previews, then ``play_turn`` with both
sides' choices, and ``replace`` whenever ``needs_replacement`` reports an empty position that can
be filled. Each step appends to ``events``. Processing order follows Showdown (``battle.ts``,
``battle-actions.ts``); see specs/001-battle-core/research.md.
"""

from __future__ import annotations

import math
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace
from functools import cache, partial

from pokesv_sim.abilities import (
    ABSORBERS,
    AFTER_FAINT_BOOSTS,
    AFTERMATH,
    AROMA_VEIL,
    AROMA_VEIL_BLOCKS,
    BAD_DREAMS,
    BERSERK,
    BOOSTERS,
    BULLETPROOF,
    BURN_CURERS,
    COMATOSE,
    COMMANDER,
    CONTACT_STATUS,
    DAMP,
    DAMP_MOVES,
    DOWNLOAD,
    DRAG_OUT_BLOCKERS,
    EFFECT_SPORE,
    EMBODY_ASPECT,
    FILTERS,
    FLAME_BODY,
    FLOWER_VEIL,
    FRIEND_GUARD,
    GALVANIZE,
    GLUTTONY,
    GOOD_AS_GOLD,
    HADRON_ENGINE,
    HEALER,
    HEATPROOF,
    HOSPITALITY,
    HYDRATION,
    ICE_BODY,
    ILLUSION,
    INFILTRATOR,
    INTIMIDATE,
    KEEN_EYE,
    LEAF_GUARD,
    LIQUID_OOZE,
    LIQUID_VOICE,
    LONG_REACH,
    MAGIC_BOUNCE,
    MAGMA_ARMOR,
    MINDS_EYE,
    MIRROR_ARMOR,
    MODIFY_ATTACK_PRIORITY,
    MOLD_BREAKERS,
    MULTISCALE,
    NATURAL_CURE,
    NEUTRALIZING_GAS,
    NO_GUARD,
    NO_RECEIVER,
    ON_HIT_BOOSTS,
    ORICHALCUM_PULSE,
    OVERCOAT,
    OWN_TEMPO,
    PIXILATE,
    POISON_HEAL,
    PRANKSTER,
    PRESSURE,
    PRIORITY_BLOCKERS,
    PUNK_ROCK,
    PURIFYING_SALT,
    RECEIVERS,
    REDIRECT_ABILITIES,
    REGENERATOR,
    ROCK_HEAD,
    ROUGH_SKIN,
    RUIN,
    RUIN_NAMES,
    SAND_VEIL,
    SAP_SIPPER,
    SHED_SKIN,
    SHEER_FORCE,
    SLOW_START,
    SNIPER,
    SNOW_CLOAK,
    SOUNDPROOF,
    SOURCE_MODIFY_ATTACK_PRIORITY,
    SPEED_BOOST,
    STATUS_GUARDS,
    STURDY,
    SUPREME_OVERLORD,
    SWEET_VEIL,
    SYMBIOSIS,
    TELEPATHY,
    TERRAIN_SETTERS,
    TINTED_LENS,
    TOXIC_CHAIN,
    TRACE,
    TRACKERS,
    UNAWARE,
    UNBURDEN,
    UNNERVERS,
    UNSEEN_FIST,
    WEAK_ARMOR,
    WEATHER_DAMAGE_IMMUNE,
    WEATHER_SETTERS,
    best_stat,
    blocks_priority_move,
    booster_active,
    download_stat,
    fails_skill_swap,
    has_sheer_force,
    has_switch_in,
    is_breakable,
    modify_priority,
    pixilate_changes,
    switch_in_priority,
)
from pokesv_sim.boosts import (
    BOOST_IDS,
    apply_boosts,
    boosted_accuracy,
    boosted_stat,
    wonder_swapped,
)
from pokesv_sim.choices import (
    ALLY_OR_SELF,
    ALLY_TARGETS,
    DISABLE,
    HEAL_BLOCK,
    LOCKED_EXTERNAL,
    LOCKED_MOVE,
    MUST_RECHARGE,
    RECHARGE,
    REVIVAL_BLESSING,
    ROLLOUT,
    SINGLE_TARGETS,
    STRUGGLE,
    THROAT_CHOP,
    TWO_TURN,
    UPROAR,
    USER_TARGETS,
    Choice,
    MoveChoice,
    PassChoice,
    Preview,
    SwitchChoice,
    _holds_berry,
    is_legal_preview,
    is_legal_replacement,
    is_legal_turn,
    locked_move_id,
    locked_slot,
    revivable,
    reviving,
)
from pokesv_sim.choices import needs_replacement as _needs_replacement
from pokesv_sim.damage import (
    FRIEND_GUARD_MODIFIER,
    IGNORES_DEFENSIVE,
    MULTISCALE_MODIFIER,
    STELLAR,
    TERA_BLAST,
    DamageHandler,
    DamageResult,
    calc_damage,
    chain_modify,
    modify,
    tera_modify_move,
    type_immune,
    type_mod,
)
from pokesv_sim.dex import Move, Secondary, get_dex, tera_forme, to_id
from pokesv_sim.events import Event, EventKind
from pokesv_sim.field import (
    ECHOED_VOICE,
    ELECTRIC,
    FAIRY_LOCK,
    FIRE_PLEDGE,
    GRASS_PLEDGE,
    GRASSY,
    RAIN,
    SAND,
    SCREENS,
    SNOW,
    SUN,
    TAILWIND,
    TERRAIN_RESIDUAL_ORDER,
    WATER_PLEDGE,
    WEATHER_NAMES,
    WEATHER_RESIDUAL_ORDER,
    WONDER_ROOM,
    add_pseudo_weather,
    add_side_condition,
    clear_terrain,
    clear_weather,
    end_pseudo_weather,
    end_side_condition,
    set_terrain,
    set_weather,
)
from pokesv_sim.field import (
    RESIDUAL_ORDER as FIELD_RESIDUAL_ORDER,
)
from pokesv_sim.hazards import (
    HAZARDS,
    HEAVY_DUTY_BOOTS,
    REMOVE_ORDER,
    SPIKES,
    SPIKES_DAMAGE,
    STEALTH_ROCK,
    STICKY_WEB,
    TOXIC_DEBRIS,
    TOXIC_SPIKES,
    add_hazard,
    remove_hazard,
)
from pokesv_sim.items import (
    ABILITY_SHIELD,
    ADRENALINE_ORB,
    AIR_BALLOON,
    BIG_ROOT,
    BIG_ROOT_MODIFIER,
    BLACK_SLUDGE,
    BLUNDER_POLICY,
    BOOSTER_ENERGY,
    COVERT_CLOAK,
    CUSTAP_BERRY,
    EJECT_BUTTON,
    EJECT_PACK,
    ENIGMA_BERRY,
    EXPERT_BELT,
    EXPERT_BELT_MODIFIER,
    FLAME_ORB,
    FOCUS_BAND,
    FOCUS_SASH,
    HEALING_BERRIES,
    HIT_BERRIES,
    HIT_BOOST_ITEMS,
    KINGS_ROCK,
    LAGGING_TAIL,
    LANSAT_BERRY,
    LEFTOVERS,
    LEPPA_BERRY,
    LIFE_ORB,
    LIFE_ORB_MODIFIER,
    LIGHT_CLAY,
    LOADED_DICE,
    LUM_BERRY,
    MENTAL_HERB,
    MICLE_BERRY,
    MICLE_MODIFIER,
    MIRROR_HERB,
    NO_EAT_BERRIES,
    ORAN_BERRY,
    PERSIM_BERRY,
    PINCH_BERRIES,
    PROTECTIVE_PADS,
    PUNCHING_GLOVE,
    QUICK_CLAW,
    RAZOR_CLAW,
    RAZOR_FANG,
    RED_CARD,
    RESIST_BERRIES,
    RESIST_BERRY_MODIFIER,
    RETALIATE_BERRIES,
    ROCKY_HELMET,
    ROOM_SERVICE,
    SAFETY_GOGGLES,
    SCOPE_LENS,
    SEEDS,
    SHED_SHELL,
    SHELL_BELL,
    SITRUS_BERRY,
    SOURCE_ACCURACY_ITEMS,
    STARF_BERRY,
    STAT_PINCH_BERRIES,
    STATUS_BERRIES,
    STICKY_BARB,
    TARGET_ACCURACY_ITEMS,
    TERRAIN_EXTENDER,
    THROAT_SPRAY,
    TOXIC_ORB,
    TYPE_BOOSTERS,
    WEAKNESS_POLICY,
    WEATHER_ROCKS,
    WHITE_HERB,
    ZOOM_LENS,
    can_be_taken,
    is_choice,
    item_name,
    resist_berry,
)
from pokesv_sim.order import MOVE_ORDER, SWITCH_ORDER, TERA_ORDER, ActionQueue, speed_sort
from pokesv_sim.prng import Prng
from pokesv_sim.protection import (
    BREAKABLE,
    GUARD_NAMES,
    GUARDS,
    ONE_TURN_MOVES,
    REDIRECTORS,
    SINGLE_TURN_NAMES,
    STALL,
    add_stall,
    add_timed,
    ally_switch_check,
    breaks_protect,
    contact_effect,
    guard_blocks,
    is_stalling,
    protection_of,
    protects_against,
    stall_check,
)
from pokesv_sim.screens import breaks_screens, modify_type
from pokesv_sim.state import (
    ACTIVE_PER_SIDE,
    SIDE_IDS,
    SLOT_NAMES,
    BattlePokemon,
    BattleState,
    MoveSlot,
    SideState,
    action_speed,
    foe_of,
)
from pokesv_sim.stats import calc_stats
from pokesv_sim.status import (
    RESIDUAL_ORDER,
    cure,
    full_paralysis,
    residual_damage,
    residual_order,
    sleep_or_freeze,
    thaw_by_own_move,
    try_set_status,
)
from pokesv_sim.targeting import (
    Targeting,
    bounce_targeting,
    fires_at_once,
    is_charging,
    is_smart,
    random_targeting,
    redirect,
    redirecting_foes,
    resolve_targets,
)
from pokesv_sim.team import Team
from pokesv_sim.terrain import GRASSY_HEAL_ORDER, blocks_priority, is_grounded
from pokesv_sim.terrain import modify_move as terrain_modify_move
from pokesv_sim.terrain import priority as terrain_priority
from pokesv_sim.volatiles import (
    MAGNET_RISE,
    MAGNET_RISE_RESIDUAL_ORDER,
    PARTIALLY_TRAPPED,
    PARTIALLY_TRAPPED_RESIDUAL_ORDER,
    SALT_CURE,
    SALT_CURE_RESIDUAL_ORDER,
    SYRUP_BOMB,
    SYRUP_BOMB_RESIDUAL_ORDER,
    YAWN,
    YAWN_RESIDUAL_ORDER,
    add_partially_trapped,
    add_volatile,
    clear_volatiles,
    confusion_before_move,
    copy_volatiles,
    flinch_before_move,
    is_active,
)
from pokesv_sim.weather import SAND_IMMUNE, effective_weather, modify_move

TURN_LIMIT = 1000  # Showdown ties the battle when turn 1001 would begin


# 041-6f: the side conditions Court Change swaps (the ones in play in gen 9 doubles)
COURT_CHANGE = frozenset({"mist", "lightscreen", "reflect", "spikes", "safeguard",
                          "tailwind", "toxicspikes", "stealthrock", "waterpledge",
                          "firepledge", "grasspledge", "stickyweb", "auroraveil"})  # fmt: skip


def _type_locked(pokemon: BattlePokemon) -> bool:
    """``setType`` is false (unless enforced) for a terastallized Pokémon and, since gen 5,
    for Arceus and Silvally (species num 493 / 773)."""
    return pokemon.terastallized is not None or pokemon.species.num in (493, 773)


class IllegalChoiceError(ValueError):
    """A player submitted a choice that is not in the legal list."""


class EngineError(RuntimeError):
    """The engine reached a state it cannot go on from (a bug in the engine, not in the
    caller's choices): it stops at once instead of looping or carrying on silently (014)."""


@dataclass(slots=True)
class _Action:
    kind: str  # "move" | "switch" | "terastallize" (017)
    order: int
    priority: int
    speed: int
    pokemon: BattlePokemon
    choice: MoveChoice | SwitchChoice | None  # None for "terastallize"
    fractional: float = 0.0  # 032 (R6): fractionalPriority (Custap Berry)
    loc: int | None = None  # 041-4a: a beforeTurnMove action's targetLoc
    round_boosted: bool = False  # 041-1f: prioritizeAction's sourceEffect Round
    pledge_source: str | None = None  # 041-5: prioritizeAction's sourceEffect (a Pledge)


BEFORE_TURN_ORDER = 5  # 041-4a: resolveAction's beforeTurnMove
BEFORE_TURN_MOVES = frozenset({"counter", "mirrorcoat"})  # 041-4a: beforeTurnCallback
REFLECT_CATEGORY = {"counter": "Physical", "mirrorcoat": "Special"}  # 041-4a
METAL_BURST = "metalburst"  # 041-4a
METAL_BURSTS = frozenset({METAL_BURST, "comeuppance"})  # 041-6f: Comeuppance is the same
FUTURE_SIGHT = "futuresight"  # 041-4b
FUTURE_MOVES = frozenset({FUTURE_SIGHT, "doomdesire"})  # 041-6f: Doom Desire is the same
LEECH_SEED = "leechseed"  # 041-4c
STOCKPILE = "stockpile"  # 041-4d
MEMENTO = "memento"  # 041-4e
DESTINY_BOND = "destinybond"  # 041-4e
GRAVITY = "gravity"  # 041-4e
FOCUS_PUNCH = "focuspunch"  # 041-4e
BEAK_BLAST = "beakblast"  # 041-6f: the move and its volatile (duration 1)
LAST_RESORT = "lastresort"  # 041-4e
PLEDGES = (FIRE_PLEDGE, GRASS_PLEDGE, WATER_PLEDGE)  # 041-5
# 041-5: the combined Pledge (the pair, either order): its type and the side condition
PLEDGE_COMBOS = {
    frozenset({FIRE_PLEDGE, GRASS_PLEDGE}): ("Fire", FIRE_PLEDGE),
    frozenset({GRASS_PLEDGE, WATER_PLEDGE}): ("Grass", GRASS_PLEDGE),
    frozenset({WATER_PLEDGE, FIRE_PLEDGE}): ("Water", WATER_PLEDGE),
}


def _last_resort_ok(user: BattlePokemon) -> bool:
    """041-4e: Last Resort's onTry: two moves or more, it is one of them, and every other
    one was used since switching in."""
    if len(user.moves) < 2:
        return False
    others = [s for s in user.moves if s.move.id != LAST_RESORT]
    return len(others) < len(user.moves) and all(s.used for s in others)


SPIT_UP = "spitup"  # 041-4d
SWALLOW = "swallow"  # 041-4d
AQUA_RING = "aquaring"  # 041-4c
INGRAIN = "ingrain"  # 041-4c
FUTURE_MOVE = "futuremove"  # 041-4b: its slot condition
WISH = "wish"  # 041-4b
_SLOT = "slot:"  # 041-4b: a residual handler of a slot condition
_SLOT_RESIDUAL = {FUTURE_MOVE: 3, WISH: 4}  # 041-4b: onResidualOrder (subOrder 3)

ABILITY_MOVES = frozenset({"soak", "gastroacid", "roleplay", "entrainment", "worryseed",
                           "simplebeam"})  # 041-3h  # fmt: skip


class Battle:
    def __init__(self, team1: Team, team2: Team, prng: Prng) -> None:
        """Teams must already be validated and supported (see ``runner.run_battle``)."""
        self.prng = prng
        sides = {}
        for side_id, team in zip(SIDE_IDS, (team1, team2), strict=True):
            mons = [BattlePokemon.from_set(side_id, i, s) for i, s in enumerate(team.members)]
            for mon in mons:
                if mon.gender is None:
                    # Showdown's Pokemon constructor: a gender that is neither given nor fixed
                    # by the species is drawn from the battle's PRNG (in team order, p1 first).
                    mon.gender = prng.sample(["M", "F"])
            sides[side_id] = SideState(side_id, mons)
        self.state = BattleState(sides)
        for side in sides.values():
            for mon in side.team:
                mon.arena = self.state  # 029
                if to_id(mon.ability) == NEUTRALIZING_GAS:
                    self.state.gas_possible = True
        self.events: list[Event] = []
        self._effect_order = 0  # Showdown effectOrder: when each status was set
        self._ability_order = 0  # abilityState.effectOrder, set on switching in (012)
        self._stellar_move = False  # 017: the running move's stellarBoosted
        # 032 (R7): getMoveHitData(move).typeMod of the latest hit on each target (by id)
        # 032 (R8): the Pokémon with the fling volatile (their item goes at the next Update)
        self._flinging: list[BattlePokemon] = []
        self._type_mods: dict[int, int] = {}
        self._in_residual = False  # 043-4h: the residual action is running
        self._crit_hits: set[int] = set()  # 043-4e: getMoveHitData(move).crit (Anger Point)
        self._move_loc: int | None = None  # 020: the running move's lastMoveTargetLoc
        # 029: the user of the running move with ignoreAbility (Mold Breaker), for
        # Battle.suppressingAbility (a Ruin ability's onStart)
        self._ignoring_user: BattlePokemon | None = None
        # 022: faint() during the residual (Perish Song) waits for the next faintMessages
        self._faint_queue: list[BattlePokemon] = []
        self._last_faint_source: BattlePokemon | None = None  # 043-1
        # 041-6f: revived on the field with no move next: its instaswitch, pushed to the end
        # of the queue, waits until after the residual action
        self._revive_later: list[BattlePokemon] = []
        self._move_succeeded = False  # useMoveInner's moveResult (013: Life Orb, Throat Spray)
        self._total_damage = 0  # 040-4b: move.totalDamage (Shell Bell)
        # 013: the target that fainted last during a move whose user stands: the win is
        # decided at the end of runMove (after Life Orb, Throat Spray and AfterMove)
        self._win_pending: BattlePokemon | None = None
        self._direct_damage = False  # 023: a directDamage line (no hurtThisTurn)
        self._not_fail_blocks = 0  # 015: targets stopped by NOT_FAIL in the current move
        # 025: the result of the move Sleep Talk called (useMove's moveThisTurnResult), boxed
        self._called_result: tuple[bool | None] | None = None
        # 041-5: Battle.activeMove (set in useMoveInner: a called move replaces its caller) and
        # Battle.lastMove (clearActiveMove at the end of a move action that got past BeforeMove;
        # a Future Sight hit leaves it alone). Copycat calls lastMove.
        self._active_move: Move | None = None
        self._calling = False  # 041-5: the running move was called (Copycat's useMove)
        self._last_move: Move | None = None
        # 027: the active move's accuracy became true (Flash Fire's onTryHit)
        self._sure_hit = False
        # 030: the active move's smartTarget is still on (Dragon Darts; off at its first failure)
        self._smart = False
        # 043-2b: id(pokemon) -> action.originalTarget (resolveAction), for tracksTarget
        self._original_targets: dict[int, BattlePokemon | None] = {}
        # 034 (T011): the fainting Neutralizing Gas holder and its speed during its End
        self._gas_fainting: tuple[BattlePokemon, int] | None = None
        # 034 (review P3): the Pokémon a Mold Breaker's Roar dragged in, suppressed until it ends
        self._drag_suppressed: list[BattlePokemon] = []
        self._mirroring = False  # 040-3b: a Mirror Herb's boost is running (not recorded)
        # 040-3: attackers whose own switch an Eject Button cancelled (this move)
        self._eject_cancelled: list[BattlePokemon] = []
        self._round_boosted = False  # 041-1f
        self._hit_targets: list[BattlePokemon] | None = None  # 041-6f
        self._external_move = False  # 043-5h: activeMove.isExternal (Dancer)
        self._sleep_usable = False  # 043-5i: a move Sleep Talk called (isSleepUsable)
        self._pledge_source: str | None = None  # 041-5: move.sourceEffect (a Pledge)
        self._last_successful: str | None = None  # 041-6a: lastSuccessfulMoveThisTurn
        self._bounced = False  # 031: the running move is a bounced one (move.hasBounced)
        self._sheer_force = False  # 033: the running move's hasSheerForce (its ModifyMove)
        self._present_heal = False  # 041-6f: Present rolled its heal (move.heal)
        self._accuracy_last: BattlePokemon | None = None  # 032: hitStepAccuracy's activeTarget
        self._queue: ActionQueue[_Action] | None = None  # the actions left this turn
        # 014: what a flag request resumes once answered: the turn's queue, or the next turn
        self._after_request = "turn"

    # -- helpers --------------------------------------------------------------------------

    def _emit(self, kind: EventKind, **fields: object) -> None:
        self.events.append(Event(kind, self.state.turn, **fields))  # type: ignore[arg-type]
        if kind == "damage" and fields.get("value") and not self._direct_damage:
            # 023: spreadDamage sets hurtThisTurn (directDamage does not: Substitute,
            # Struggle's recoil)
            target = self._active_by_label(str(fields["target"]))
            if target is not None:
                target.hurt_this_turn = target.hp

    def _active_by_label(self, label: str) -> BattlePokemon | None:
        side = self.state.sides.get(label[:2])
        if side is None or len(label) != 3:
            return None
        return side.active[SLOT_NAMES.index(label[2])]

    @property
    def ended(self) -> bool:
        return self.state.ended

    def abort(self, reason: str) -> None:
        """Stop the battle without a winner (an ``aborted`` event with ``reason``)."""
        self.state.ended = True
        self.state.winner = None
        self._emit("aborted", detail=reason)

    def _end(self, winner: str | None) -> None:
        if self.state.ended:
            return  # 041-4e: Battle.win() does nothing once the battle has ended
        self.state.ended = True
        self.state.winner = winner
        if winner is None:
            self._emit("tie")
        else:
            self._emit("win", actor=winner)

    def _switch_in(
        self, side: SideState, position: int, pokemon: BattlePokemon, *, drag: bool = False
    ) -> None:
        old = side.active[position]
        if old is not None:
            old.position = None
            # (034 T011: pokemon.illusion stays when called back: Illusion's End shows nothing)
            old.cached_speed = old.stats["spe"]  # clearVolatile -> setSpecies when called back
            old.reset_boosts()  # clearVolatile
            clear_volatiles(old)
            old.ability = old.own_ability  # 027: clearVolatile (after its End)
            old.stats_raised_this_turn = False  # 027: switchIn's oldActive
            old.stats_lowered_this_turn = False
            # side.pokemon: the outgoing and incoming Pokémon trade places.
            if not side.order:
                side.order = list(side.brought)
            i, j = side.order.index(old), side.order.index(pokemon)
            side.order[i], side.order[j] = side.order[j], side.order[i]
        side.active[position] = pokemon
        pokemon.position = position
        if pokemon.base_moves is not None:  # 041-6f: fainted while transformed
            pokemon.moves, pokemon.base_moves = pokemon.base_moves, None
        if pokemon.mimicked is not None:  # 041-6f (review P2): fainted after Mimic
            index, slot = pokemon.mimicked
            pokemon.moves[index], pokemon.mimicked = slot, None
        self._ability_order += 1
        pokemon.ability_order = self._ability_order
        pokemon.active_move_actions = 0
        pokemon.active_turns = 0  # 015: switchIn
        for move_slot in pokemon.moves:
            move_slot.used = False  # 041-4e
        pokemon.newly_switched = True
        pokemon.item_started = False  # 013: switchIn sets a new itemState
        pokemon.eject_pending = False  # (014)
        pokemon.mirror_boosts.clear()  # (040-3b)
        pokemon.gas_ending = pokemon.embodied = False  # 029: a new abilityState
        if pokemon.status == "tox":
            pokemon.toxic_stage = 0  # tox onSwitchIn
        if pokemon.ability_id == ILLUSION or pokemon.base_ability_id != ILLUSION:
            # 034: runEvent('BeforeSwitchIn'). (T011: under Neutralizing Gas the handler does
            # not run and the look from its last time out stays; the gas then reveals it)
            pokemon.illusion = self._illusion_target(side, pokemon)
        self._emit(
            "drag" if drag else "switch",  # 034: dragged in by Roar / Whirlwind
            actor=pokemon.label,
            value=pokemon.hp,
            detail=_display_name(pokemon.illusion or pokemon),
            team_index=pokemon.team_index,
        )

    def _illusion_target(self, side: SideState, pokemon: BattlePokemon) -> BattlePokemon | None:
        """034 (R6): Illusion's onBeforeSwitchIn: the last Pokémon not fainted after it in
        ``side.pokemon`` (a Terastallized holder skips Ogerpon and Terapagos, and stops there).
        Not while Neutralizing Gas suppresses the ability."""
        if pokemon.ability_id != ILLUSION:
            return None
        order = side.order or list(side.brought)
        for other in reversed(order[order.index(pokemon) + 1 :]):
            if other.fainted:
                continue
            if pokemon.terastallized and other.species.base_species in ("Ogerpon", "Terapagos"):
                return None
            return other
        return None

    def _illusion_end(self, pokemon: BattlePokemon) -> None:
        """034 (R6): Illusion's End while disguised: ``replace`` (the true details), then
        ``-end … Illusion``."""
        pokemon.illusion = None
        self._emit("replace", target=pokemon.label, detail=_display_name(pokemon))
        self._emit("end", target=pokemon.label, detail="Illusion")

    def _next_turn(self) -> None:
        self.state.turn += 1
        self._last_successful = None  # 041-6a: endTurn
        if self.state.turn > TURN_LIMIT:
            self.state.turn = TURN_LIMIT
            self._end(None)
            return
        # 015: nextTurn's records: the last turn's move result, then activeTurns (not for a
        # fainted Pokémon still in its slot)
        for pokemon in self.state.all_active():
            pokemon.move_last_turn_result = pokemon.move_this_turn_result
            pokemon.move_this_turn_result = None
            if not pokemon.fainted:
                pokemon.active_turns += 1
        # 013: runEvent('DisableMove') for each active Pokémon: choicelock ends when the item is
        # no longer a Choice item or the locked move is not one of its moves (Struggle).
        for pokemon in self.state.all_active():
            speed_sort(self._disable_move_speeds(pokemon), self.prng, lambda a, b: b - a)
            lock = pokemon.choice_lock
            if lock is not None and (
                not is_choice(pokemon.held_item) or all(s.move.id != lock for s in pokemon.moves)
            ):
                pokemon.choice_lock = None
            # 034 (T011): nextTurn shows the types when they differ from what was shown (a
            # Zoroark disguised as a Terastallized teammate that has switched out since)
            seen = pokemon.illusion or pokemon
            # (041-6f: getTypes(true), then the added type: -start … typeadd)
            if pokemon.terastallized is None and seen.own_types != seen.apparent_type:
                self._emit("start", target=pokemon.label, detail="typechange")
                seen.apparent_type = seen.own_types
                if pokemon.added_type:
                    self._emit("start", target=pokemon.label, detail="typeadd")
            # 024 R3: pokemon.trapped = false, then runEvent('TrapPokemon'): partiallytrapped's
            # onTrapPokemon (the binder still active) -> tryTrap (a Ghost is immune). One
            # handler: no draw.
            source = pokemon.trap_source
            pokemon.trapped = (
                PARTIALLY_TRAPPED in pokemon.timed
                and source is not None
                and is_active(source)
                and "Ghost" not in pokemon.types
                and pokemon.item != SHED_SHELL  # 040-4b: onTrapPokemon (-10)
            )
            # 041-3g, 041-4c: the trapped and ingrain volatiles' onTrapPokemon tie with
            # partiallytrapped's (two or more: a shuffle)
            ties = sum(
                (PARTIALLY_TRAPPED in pokemon.timed, pokemon.trapper is not None,
                 INGRAIN in pokemon.timed, pokemon.no_retreat)
            )  # fmt: skip
            if ties >= 2:
                speed_sort([pokemon.cached_speed] * ties, self.prng, lambda a, b: b - a)
            if (
                (
                    pokemon.trapper is not None
                    or INGRAIN in pokemon.timed
                    or pokemon.no_retreat
                    # 041-6f: Fairy Lock's onTrapPokemon (a field handler: speed 0, no tie)
                    or FAIRY_LOCK in self.state.field.pseudo_weather
                )
                and "Ghost" not in pokemon.types
                and pokemon.item != SHED_SHELL
            ):
                pokemon.trapped = True
            # 043-5b: Shadow Tag, Arena Trap, Magnet Pull: tryTrap(true) ('hidden' unless
            # already trapped: the request shows it only when another Pokemon chooses after)
            pokemon.trap_hidden = False
            if self._ability_trapped(pokemon):
                pokemon.trap_hidden = not pokemon.trapped
                pokemon.trapped = True
            # 028: commanding / commanded's onTrapPokemon (priority -11: no tie with the
            # binding's handler, so no draw) traps it, a Ghost too
            if pokemon.commanding or pokemon.commanded_by is not None:
                pokemon.trapped = True
                pokemon.trap_hidden = False
        self._emit("turn", value=self.state.turn)  # (034: after the typechange lines)

    def _disable_move_speeds(self, pokemon: BattlePokemon) -> list[int]:
        """The speeds of the ``DisableMove`` handlers of ``pokemon``. 015: the volatiles'
        handlers (choicelock, taunt, encore; 021: throatchop; 023: healblock, disable) tie (same
        speed, subOrder 2): two or more are shuffled. 022: a foe's imprison (onFoeDisableMove)
        has that foe's speed."""
        handlers = [pokemon.choice_lock is not None]
        handlers += [v in pokemon.timed for v in (THROAT_CHOP, HEAL_BLOCK, DISABLE, *MOVE_LOCKS)]
        handlers.append(pokemon.torment)  # 041-3g
        speeds = [pokemon.cached_speed] * sum(handlers)
        speeds += [
            p.cached_speed
            for p in self.state.sides[foe_of(pokemon.side)].active
            if p is not None and p.hp > 0 and p.imprison
        ]
        return speeds

    def _check_win(self, last_fainted: BattlePokemon | None) -> bool:
        left = {s: self.state.sides[s].pokemon_left() for s in SIDE_IDS}
        if all(n == 0 for n in left.values()):
            # Gen 5+: the side whose Pokémon fainted last wins (Showdown checkWin).
            self._end(last_fainted.side if last_fainted else None)
            return True
        for side_id, n in left.items():
            if n == 0:
                self._end("p2" if side_id == "p1" else "p1")
                return True
        return False

    # -- start ----------------------------------------------------------------------------

    def start(self, preview1: Preview, preview2: Preview) -> None:
        for side_id, preview in zip(SIDE_IDS, (preview1, preview2), strict=True):
            side = self.state.sides[side_id]
            if not is_legal_preview(side, preview):
                raise IllegalChoiceError(f"{side_id}: illegal preview {preview.order}")
            side.brought = [side.team[i] for i in preview.order]
            side.order = list(side.brought)
            self._emit(
                "preview", actor=side_id, detail=",".join(p.species.name for p in side.brought)
            )
        # The 'team' actions (one per brought Pokémon, priority -index) are sorted by speed first.
        team_actions = [
            (-i, self._speed(p))
            for s in SIDE_IDS
            for i, p in enumerate(self.state.sides[s].brought)
        ]
        speed_sort(team_actions, self.prng, _by_priority_then_speed)
        # Showdown's 'start' action switches the leads in, each inserting a runSwitch action into
        # the queue; the runSwitch actions then run as one batch (verified with the draw trace).
        pending: list[BattlePokemon] = []
        for side_id in SIDE_IDS:
            side = self.state.sides[side_id]
            for position, pokemon in enumerate(side.brought[:ACTIVE_PER_SIDE]):
                self._switch_in(side, position, pokemon)
                self._insert_run_switch(pending, pokemon)
        self._switch_in_abilities(pending, self._run_switch_sort())
        self._update()  # eachEvent('Update') after runSwitch
        if self._flag_request_after_switch_in():
            return
        self._next_turn()

    def _flag_request_after_switch_in(self) -> bool:
        """The switch request at the end of a runSwitch action before the next turn (014:
        Eject Pack after Intimidate); ``replace`` then starts the next turn."""
        return self._request_switches("next_turn")

    def _request_switches(self, resume: str) -> bool:
        """makeRequest('switch') for the switch flags (014). ``resume``: what ``replace`` goes
        on with ("turn": the rest of the turn's queue; "next_turn"). A request that no position
        can answer is an engine bug: it would leave the turn suspended for good."""
        if not self._switch_requested():
            return False
        self.state.flag_request = True
        self._after_request = resume
        if not self.awaiting_replacements:
            raise EngineError("a switch request with no Pokémon to choose for")
        return True

    # -- requests -------------------------------------------------------------------------

    def needs_replacement(self, side_id: str) -> list[bool]:
        if self.state.ended:
            return [False] * ACTIVE_PER_SIDE
        return _needs_replacement(self.state, side_id)

    def reviving(self, side_id: str) -> list[bool]:
        """041-6f: per position, the request's ``reviving`` (Revival Blessing's pick)."""
        side = self.state.sides[side_id]
        return [
            p is not None and bool(p.switch_flag) and reviving(self.state, p) for p in side.active
        ]

    @property
    def awaiting_replacements(self) -> bool:
        return any(any(self.needs_replacement(s)) for s in SIDE_IDS)

    # -- a turn ---------------------------------------------------------------------------

    def play_turn(self, choices1: Sequence[Choice], choices2: Sequence[Choice]) -> None:
        if self.state.ended or self.awaiting_replacements:
            raise IllegalChoiceError("the battle is not waiting for turn choices")
        if self.state.flag_request:
            raise EngineError("the turn is suspended for a switch request")  # (014)
        for side_id, choices in zip(SIDE_IDS, (choices1, choices2), strict=True):
            if not is_legal_turn(self.state, side_id, list(choices)):
                raise IllegalChoiceError(f"{side_id}: illegal choices {choices}")
        for active in self.state.all_active():
            active.newly_switched = False  # (switched in before this turn)
            active.hurt_this_turn = None  # 023: nextTurn
            active.used_item_this_turn = False  # 043-5c
            if self.state.turn != 1:
                active.stats_raised_this_turn = False  # 027: nextTurn (not on turn 1)
                active.stats_lowered_this_turn = False
            active.damaged_by.clear()  # 041-1e: attackedBy's thisTurn = false
            active.damaged_log[:] = [  # 041-4a: nextTurn drops a source not active
                e for e in active.damaged_log if is_active(e[0])
            ]
        for side in self.state.sides.values():  # 041-1e: nextTurn
            side.fainted_last_turn, side.fainted_this_turn = side.fainted_this_turn, False
        self._update_speed()  # commitChoices
        actions: list[_Action] = []
        for side_id, choices in zip(SIDE_IDS, (choices1, choices2), strict=True):
            side = self.state.sides[side_id]
            for position, choice in enumerate(choices):
                pokemon = side.active[position]
                if pokemon is None or isinstance(choice, PassChoice):
                    continue
                if isinstance(choice, MoveChoice) and locked_slot(pokemon) is not None:
                    # 020: chooseMove's locked move: aimed at the remembered location
                    # (022: lockedmove's is lastMoveTargetLoc)
                    loc = pokemon.charge_loc if TWO_TURN in pokemon.timed else pokemon.last_move_loc
                    pokemon.queued_external = locked_move_id(pokemon)  # 041-5
                    choice = MoveChoice(choice.move_index, loc)
                action = self._make_action(pokemon, choice, speed=False)
                # 017: chooseMove drops the flag with Struggle (its branch returns first)
                tera = (
                    isinstance(choice, MoveChoice)
                    and choice.terastallize
                    and choice.move_index != STRUGGLE
                )
                before_turn = (
                    isinstance(choice, MoveChoice)
                    and choice.move_index != STRUGGLE
                    and chosen_move(pokemon, choice).id in BEFORE_TURN_MOVES
                )
                if before_turn:
                    # 041-4a: resolveAction unshifts a 'beforeTurnMove' action first; it has no
                    # targetLoc, so getRandomTarget picks a foe (one draw)
                    foe = self._random_foe_draw(pokemon)
                    speed = self._speed(pokemon)
                    btm = _Action("beforeturn", BEFORE_TURN_ORDER, 0, speed, pokemon, choice)
                    btm.loc = (
                        foe.position + 1 if foe is not None and foe.position is not None else None
                    )
                first = len(actions)  # 041-6f: where this Pokemon's unshifted actions start
                if tera and pokemon.terastallized is None:
                    # 017: resolveAction unshifts a 'terastallize' action (no target lookup)
                    speed = self._speed(pokemon)
                    actions.append(_Action("terastallize", TERA_ORDER, 0, speed, pokemon, None))
                if before_turn:
                    actions.append(btm)  # (unshifted before the terastallize action)
                if (
                    isinstance(choice, MoveChoice)
                    and choice.move_index != STRUGGLE
                    and chosen_move(pokemon, choice).id
                    in (FOCUS_PUNCH, CHILLY_RECEPTION, BEAK_BLAST)
                ):
                    # 041-4e: resolveAction unshifts a 'priorityChargeMove' action (order 107);
                    # without a targetLoc, its resolveAction draws a random foe (unused;
                    # 041-6d: getRandomTarget gives the user itself for Chilly Reception)
                    if chosen_move(pokemon, choice).id in (FOCUS_PUNCH, BEAK_BLAST):
                        self._random_foe_draw(pokemon)
                    speed = self._speed(pokemon)
                    # 041-6f: unshifted last, so it comes before the terastallize action
                    actions.insert(first, _Action("prioritycharge", 107, 0, speed, pokemon, choice))
                if isinstance(choice, MoveChoice):
                    # 032 (R6): resolveAction's runEvent('FractionalPriority'), after the
                    # terastallize action and before the target lookup
                    action.fractional = self._fractional_priority(pokemon, choice)
                    # BattleQueue.resolveAction: a move chosen without a target gets one at
                    # random, then getActionSpeed looks the target up again.
                    move_target = chosen_move(pokemon, choice).target
                    pokemon.resolved_loc = choice.target
                    if choice.target is None and move_target in USER_TARGETS:
                        # 026: getRandomTarget gives the user itself (no draw)
                        pokemon.resolved_loc = -((pokemon.position or 0) + 1)
                    elif choice.target is None:
                        foe = self._random_foe_draw(pokemon)  # (these target the user)
                        if foe is not None and foe.position is not None:
                            pokemon.resolved_loc = foe.position + 1  # 022: action.targetLoc
                    loc = pokemon.resolved_loc
                    self._original_targets[id(pokemon)] = (
                        self._at_loc(pokemon, loc) if loc else None
                    )  # 043-2b: action.originalTarget
                    self._action_speed_draws(action)
                action.speed = self._speed(pokemon)  # (028: after the target lookup's draws)
                actions.append(action)

        queue = ActionQueue(actions, self.prng)
        self._queue = queue
        self._in_residual = False  # 043-4h: the queue has actions (and the residual) again
        self._sort_active_by_speed()  # beforeTurn: eachEvent('BeforeTurn')
        if self._after_action(queue):
            return
        self._continue_turn()

    def _continue_turn(self) -> None:
        """Showdown ``turnLoop``: run the actions left in the queue, then the end of the turn
        (residual, the replacements request, the next turn)."""
        queue = self._queue
        assert queue is not None
        while queue and not self.state.ended:
            action = queue.pop()
            if action.pokemon.fainted or action.pokemon.position is None:
                continue  # Showdown's runAction returns early: no Update, no re-sort
            if action.kind == "beforeturn":
                self._before_turn_move(action)
            elif action.kind == "prioritycharge":
                # 041-4e: Focus Punch's priorityChargeCallback: addVolatile('focuspunch')
                pokemon = action.pokemon
                assert isinstance(action.choice, MoveChoice)
                if chosen_move(pokemon, action.choice).id == CHILLY_RECEPTION:
                    # 041-6d: addVolatile('chillyreception') (duration 1, no message)
                    if pokemon.hp > 0:
                        pokemon.timed.setdefault(CHILLY_RECEPTION, 1)
                elif chosen_move(pokemon, action.choice).id == BEAK_BLAST:
                    # 041-6f: addVolatile('beakblast'): -singleturn (duration 1)
                    if BEAK_BLAST not in pokemon.timed and pokemon.hp > 0:
                        pokemon.timed[BEAK_BLAST] = 1
                        self._emit("singleturn", target=pokemon.label, detail="move: Beak Blast")
                elif FOCUS_PUNCH not in pokemon.timed and pokemon.hp > 0:
                    pokemon.timed[FOCUS_PUNCH] = 1
                    pokemon.counters[FOCUS_PUNCH] = 0
                    self._emit("singleturn", target=pokemon.label, detail="move: Focus Punch")
            elif isinstance(action.choice, SwitchChoice):
                if action.pokemon.status:  # 043-1: singleEvent('CheckShow', naturalcure)
                    self._natural_cure_check_show(action.pokemon, queue)
                self._run_switch(action.pokemon, action.choice)
            elif action.choice is None:
                self._terastallize(action.pokemon)
            else:
                self._round_boosted = action.round_boosted
                self._pledge_source = action.pledge_source
                self._active_move = None
                self._run_move(action.pokemon, action.choice)
                self._round_boosted = False
                self._pledge_source = None
                if self._active_move is not None:  # 041-5: clearActiveMove() -> lastMove
                    self._last_move, self._active_move = self._active_move, None
            if self.state.ended:
                break
            if self._after_action(queue):
                return  # a switch request: replace() resumes the queue

        if not self.state.ended:
            self._residual()
        if not self.state.ended:
            self._check_fainted()
            self._update()  # eachEvent('Update') after the residual action
        if not self.state.ended and self._revive_later:
            revived, self._revive_later = self._revive_later, []
            pending: list[BattlePokemon] = []
            for target in revived:  # 041-6f: the instaswitch after the residual action
                assert target.position is not None
                self._switch_in(self.state.sides[target.side], target.position, target)
                self._insert_run_switch(pending, target)
                self._update(run_switch_next=True)
            self._switch_in_abilities(pending, self._run_switch_sort())
            self._check_fainted()
            self._update()
            self._switch_requested()  # (drops flags with nobody to bring in)
        if not self.state.ended and not self.awaiting_replacements:
            self._next_turn()

    def _terastallize(self, pokemon: BattlePokemon) -> None:
        """017: ``actions.terastallize`` (research R1). Ogerpon changes forme for good, which
        sets the new forme's ability (Embody Aspect) and runs its onStart."""
        illusion = pokemon.illusion
        if illusion is not None and illusion.species.base_species in ("Ogerpon", "Terapagos"):
            self._illusion_end(pokemon)  # 034 (R6): actions.terastallize
        self._emit("terastallize", target=pokemon.label, detail=pokemon.tera_type)
        pokemon.terastallized = pokemon.tera_type
        pokemon.apparent_type = (pokemon.tera_type,)  # 034
        self.state.sides[pokemon.side].tera_used = True
        if pokemon.species.name == "Morpeko-Hangry":
            pokemon.hangry_base = True  # 042-3: baseSpecies = species (no message)
        if pokemon.species.name == "Terapagos-Terastal":
            # 042-6: formeChange('Terapagos-Stellar', null, true) (formeRegression), then
            # runEvent('AfterTerastallization'): Teraform Zero
            self._forme_for_good(pokemon, "Terapagos-Stellar")
            field_state = self.state.field
            if pokemon.ability_id == "teraformzero" and (
                field_state.weather is not None or field_state.terrain is not None
            ):
                self._emit("ability", target=pokemon.label, detail="Teraform Zero")
                if field_state.weather is not None:
                    clear_weather(field_state, emit=self._emit_kw)
                    self._weather_change()
                self._clear_terrain()
            self._after_terastallization()
            return
        forme = tera_forme(pokemon.species)
        if forme is None:
            self._after_terastallization()
            return
        pokemon.species = forme
        pokemon.base_types = forme.types
        pokemon.added_type = None  # (041-6f: setSpecies)
        # (034: formeChange's setSpecies, then apparentType = terastallized again: unchanged)
        pokemon.cached_speed = pokemon.stats["spe"]  # setSpecies: speed = storedStats.spe
        self._emit("detailschange", target=pokemon.label, detail=forme.name)
        pokemon.ability = forme.abilities[0]  # setAbility: a new abilityState
        pokemon.own_ability = pokemon.ability  # 027: a permanent forme change
        self._ability_order += 1
        pokemon.ability_order = self._ability_order
        self._ability_start(pokemon)
        self._after_terastallization()

    def _forme_for_good(self, pokemon: BattlePokemon, name: str) -> None:
        """042-6: ``formeChange(…, isPermanent)``: setSpecies, detailschange, updateMaxHp
        (``-heal … [silent]``), then setAbility to the forme's first ability."""
        forme = get_dex().species(name)
        assert forme is not None
        pokemon.set_species(forme)
        self._emit("detailschange", target=pokemon.label, detail=forme.name)
        if pokemon.update_max_hp() and pokemon.hp > 0:
            self._emit("heal", target=pokemon.label, hp=pokemon.hp)
        pokemon.ability = forme.abilities[0]
        pokemon.own_ability = pokemon.ability
        self._ability_order += 1
        pokemon.ability_order = self._ability_order

    def _disguise_holds(self, user: BattlePokemon, move: Move, target: BattlePokemon) -> bool:
        """043-6e: Disguise (Mimikyu) / Ice Face (Eiscue, a physical move) still up: its
        onCriticalHit / onEffectiveness (not behind a substitute, not an immune target)."""
        if move.category == "Status":
            return False
        if target.ability_id == "disguise":
            up = target.species.name == "Mimikyu"
        elif target.ability_id == "iceface":
            up = target.species.name == "Eiscue" and move.category == "Physical"
        else:
            return False
        if not up or self._hits_substitute(user, move, target):
            return False
        return not type_immune(move, user.combatant(), target.combatant())

    def _tera_shell(self, user: BattlePokemon, target: BattlePokemon, move: Move) -> bool:
        """042-6: Tera Shell in runEffectiveness: a Terapagos-Terastal at full HP takes a
        damaging move (not Struggle, not already not very effective) as not very effective
        (``-activate … ability: Tera Shell`` once; the move's later hits too)."""
        if target.species.name != "Terapagos-Terastal" or target.ability_id != "terashell":
            return False
        if target.shell_resisted:
            return True
        if (
            move.category == "Status"
            or move.id == "struggle"
            or target.hp < target.max_hp
            or type_mod(move, target.combatant(self.state.field)) < 0
        ):
            return False
        self._emit("activate", target=target.label, detail="ability: Tera Shell")
        target.shell_resisted = True
        return True

    def _check_fainted(self) -> None:
        """Showdown ``checkFainted`` (after the last action of the turn): status becomes 'fnt',
        so paralysis no longer halves the speed a fainted Pokémon is sorted by."""
        for side_id in SIDE_IDS:
            for pokemon in self.state.sides[side_id].active:
                if pokemon is not None and pokemon.fainted:
                    pokemon.status = None

    def _residual(self) -> None:
        """The residual action: Showdown ``fieldEvent('Residual')`` over the field, side and
        Pokémon handlers, sorted by order, then speed, then subOrder (ties shuffled)."""
        self._update_speed()
        self._in_residual = True  # 043-4h: queue.peek() is null until the next turn
        field_state = self.state.field
        # Collected like fieldEvent: the field, then per side its conditions and its active
        # Pokémon (status, then volatile statuses with a duration). Fainted Pokémon still hold
        # their status here (and are sorted, then skipped).
        # findFieldEventHandlers: pseudo-weathers, then the weather.
        handlers: list[_Residual] = [_Residual(None, c) for c in field_state.pseudo_weather]
        if field_state.weather is not None:
            handlers.append(_Residual(None, _WEATHER))
        if field_state.terrain is not None:
            handlers.append(_Residual(None, _TERRAIN))  # 010: then the terrain
        for side_id in SIDE_IDS:
            handlers += [_Residual(None, c, side_id) for c in field_state.sides[side_id]]
            for p in self.state.sides[side_id].active:
                if p is None:
                    continue
                if p.status in RESIDUAL_ORDER:
                    handlers.append(_Residual(p, p.status))
                handlers += self._volatile_residuals(p)
                if p.base_ability_id == MOODY:
                    handlers.append(_Residual(p, MOODY))  # 023: the ability, then the item
                if p.base_ability_id == HUNGER_SWITCH:
                    handlers.append(_Residual(p, HUNGER_SWITCH))  # 042-3: order 29
                if p.base_ability_id == BAD_DREAMS:
                    handlers.append(_Residual(p, BAD_DREAMS))  # 043-3b: 28, subOrder 2
                if p.base_ability_id == "cudchew":
                    handlers.append(_Residual(p, "cudchew"))  # 043-4h: 28, subOrder 2
                if p.base_ability_id == "pickup":
                    handlers.append(_Residual(p, "pickup"))  # 043-5c: 28, subOrder 2
                if p.base_ability_id == "opportunist":
                    handlers.append(_Residual(p, "opportunist"))  # 043-4i: 29, subOrder 7
                if p.base_ability_id == "shieldsdown":
                    handlers.append(_Residual(p, "shieldsdown"))  # 043-6d: 29
                if p.base_ability_id == "harvest":
                    handlers.append(_Residual(p, "harvest"))  # 043-4f: 28, subOrder 2
                if p.base_ability_id == SPEED_BOOST:
                    handlers.append(_Residual(p, SPEED_BOOST))  # 043-4b: 28, subOrder 2
                if p.base_ability_id in (HYDRATION, SHED_SKIN):
                    handlers.append(_Residual(p, p.base_ability_id))  # 043-3a: 5, subOrder 3
                if p.base_ability_id == HEALER:
                    handlers.append(_Residual(p, HEALER))  # 043-1: order 5, subOrder 3
                if p.base_ability_id == SLOW_START:
                    handlers.append(_Residual(p, SLOW_START))  # 033 (R12): order 28
                if p.held_item in ITEM_RESIDUAL_ORDER:  # (041-6f: sorted while ignored)
                    handlers.append(_Residual(p, _ITEM + p.held_item))  # 013: after the ability
                if p.position is not None:  # 041-4b: then the slot conditions (subOrder 3)
                    slots = field_state.slot_effects[side_id][p.position]
                    handlers += [_Residual(p, _SLOT + c) for c in slots]
                if FIRE_PLEDGE in field_state.sides[side_id]:
                    handlers.append(_Residual(p, _FIRE_SEA))  # 041-5: the side's onResidual
                if field_state.terrain == GRASSY:
                    # 010: the field's onResidual, one handler per active Pokémon, collected
                    # after the Pokémon's own (findFieldEventHandlers after
                    # findPokemonEventHandlers; 014: seen with Leftovers and Eject Pack)
                    handlers.append(_Residual(p, _GRASSY_HEAL))
        speed_sort(handlers, self.prng, _by_residual)
        for handler in handlers:
            # fieldEvent: faintMessages after each handler that did not end (022: a Perish Song
            # count that ran out faints there); the handlers of a fainted holder are skipped
            if self._residual_handler(handler) and self._flush_faints():
                return
            if self.state.ended:
                return  # 041-4b: futuremove's onEnd checkWin
        self._flush_faints()  # runAction's faintMessages

    def _volatile_residuals(self, pokemon: BattlePokemon) -> list[_Residual]:
        """The volatiles' residual handlers in the order they were added (009: those with a
        duration: Protect, stall, Helping Hand, ...; 005: flinch, which 023 places after the
        ones it came after, as pokemon.volatiles does)."""
        handlers = [_Residual(pokemon, v) for v in pokemon.timed]
        if pokemon.flinched:
            at = sum(1 for v in pokemon.timed if v in pokemon.flinch_after)
            handlers.insert(at, _Residual(pokemon, "flinch"))
        return handlers

    def _residual_handler(self, handler: _Residual) -> bool:
        """One residual handler; True when it did not end (faintMessages follows)."""
        pokemon = handler.pokemon
        if pokemon is None and handler.effect == _WEATHER:
            return self._weather_residual()
        if pokemon is None and handler.effect == _TERRAIN:
            return self._terrain_residual()
        if pokemon is None:
            return self._count_down(handler)
        if handler.effect.startswith(_SLOT):  # 041-4b: run for a fainted holder too
            return self._slot_residual(pokemon, handler.effect.removeprefix(_SLOT))
        if pokemon.fainted or pokemon in self._revive_later:  # (041-6f: not isActive)
            return False
        if handler.effect == "flinch":
            pokemon.flinched = False  # duration 1 runs out (no message)
            return False
        if handler.effect == _FIRE_SEA:  # 041-5: damage(baseMaxhp / 8) unless Fire type
            if FIRE_PLEDGE in self.state.field.sides[pokemon.side] and "Fire" not in pokemon.types:
                self._chip(pokemon, pokemon.max_hp / 8, "fire pledge")
                if pokemon.hp == 0 and pokemon not in self._faint_queue:
                    self._faint_queue.append(pokemon)
            return True
        if handler.effect == _GRASSY_HEAL:
            if self.state.field.terrain != GRASSY:
                return False  # the terrain ended earlier this turn
            self._grassy_heal(pokemon)
            return True
        if handler.effect == MOODY:
            if not pokemon.neutralized:  # 029: skipped by singleEvent (faintMessages still runs)
                self._moody(pokemon)
            return True
        if handler.effect == "shieldsdown":
            if pokemon.hp > 0:
                self._shields_down(pokemon)  # 043-6d: onResidual (not at 0 HP)
            return True
        if handler.effect == HUNGER_SWITCH:
            if pokemon.ability_id == HUNGER_SWITCH:
                self._hunger_switch(pokemon)
            return True
        if handler.effect == "pickup":  # 043-5c: an adjacent Pokemon's item used this turn
            if pokemon.ability_id == "pickup" and not pokemon.held_item:
                found = [
                    p for p in self.state.all_active()
                    if p is not pokemon and p.last_item and p.used_item_this_turn
                ]  # fmt: skip
                if found:
                    chosen = self.prng.sample(found)
                    item, chosen.last_item = chosen.last_item, ""
                    self._emit("item", target=pokemon.label, detail=item_name(item))
                    self._set_item(pokemon, item)
            return True
        if handler.effect == "opportunist":
            self._opportunist(pokemon)
            return True
        if handler.effect == "cudchew":  # 043-4h: the kept berry is eaten again
            if pokemon.ability_id == "cudchew" and pokemon.cud_chew and pokemon.hp:
                berry, counter = pokemon.cud_chew
                pokemon.cud_chew = (berry, counter - 1)
                if counter - 1 <= 0:
                    self._emit("activate", target=pokemon.label, detail="ability: Cud Chew")
                    self._emit("enditem", target=pokemon.label, detail=item_name(berry))
                    self._berry_on_eat(pokemon, berry)
                    self._eat_item_event(pokemon, berry)
                    pokemon.ate_berry = pokemon.ate_berry or berry not in NO_EAT_BERRIES
                    pokemon.cud_chew = None
            return True
        if handler.effect == "harvest":  # 043-4f: the sun, else randomChance(1, 2)
            if pokemon.ability_id == "harvest" and (
                self.state.field.active_weather == SUN or self.prng.random_chance(1, 2)
            ):
                last = get_dex().item(pokemon.last_item) if pokemon.last_item else None
                if pokemon.hp and not pokemon.held_item and last is not None and last.is_berry:
                    item, pokemon.last_item = pokemon.last_item, ""
                    self._set_item(pokemon, item)
                    self._emit("item", target=pokemon.label, detail=item_name(item))
            return True
        if handler.effect == SPEED_BOOST:  # 043-4b: after its first turn, Speed +1
            if pokemon.ability_id == SPEED_BOOST and pokemon.active_turns and pokemon.hp:
                apply_boosts(
                    pokemon, {"spe": 1}, primary=False, foes_left=self._foes_left(pokemon),
                    emit=self._emit_kw, source=pokemon, ability="Speed Boost",
                )  # fmt: skip
            return True
        if handler.effect == BAD_DREAMS:  # 043-3b: each sleeping foe loses 1/8
            if pokemon.ability_id == BAD_DREAMS and pokemon.hp:
                for foe in self.state.sides[foe_of(pokemon.side)].alive_active():
                    if foe.hp > 0 and _asleep(foe):
                        self._chip(foe, foe.max_hp / 8, "ability: bad dreams", pokemon)
                        if foe.hp == 0 and foe not in self._faint_queue:
                            self._faint_queue.append(foe)
            return True
        if handler.effect == HYDRATION:  # 043-3a: the status in the user's effectiveWeather rain
            rain = effective_weather(self.state.field.active_weather, pokemon.item) == RAIN
            if pokemon.ability_id == HYDRATION and pokemon.status and rain:
                self._emit("activate", target=pokemon.label, detail="ability: Hydration")
                cure(pokemon, self._emit_kw)
            return True
        if handler.effect == SHED_SKIN:  # 043-3a: hp and status, randomChance(33, 100)
            shed = pokemon.ability_id == SHED_SKIN and pokemon.hp and pokemon.status
            if shed and self.prng.random_chance(33, 100):
                self._emit("activate", target=pokemon.label, detail="ability: Shed Skin")
                cure(pokemon, self._emit_kw)
            return True
        if handler.effect == HEALER:
            if pokemon.ability_id == HEALER:
                self._healer(pokemon)
            return True
        if handler.effect == SLOW_START:  # 033 (R12): onResidual
            if pokemon.ability_id == SLOW_START and pokemon.active_turns and pokemon.slow_start:
                pokemon.slow_start -= 1
                if not pokemon.slow_start:
                    self._emit("end", target=pokemon.label, detail="Slow Start")
            return True
        if handler.effect.startswith(_ITEM):
            self._item_residual(pokemon, handler.effect.removeprefix(_ITEM))
            if pokemon.hp == 0 and pokemon not in self._faint_queue:
                self._faint_queue.append(pokemon)
            return True
        if handler.effect not in RESIDUAL_ORDER:  # 009: a timed volatile
            return self._timed_residual(pokemon, handler.effect)
        if pokemon.status != handler.effect:
            return False
        cause = pokemon.status
        damage = residual_damage(pokemon)
        if cause == "brn" and pokemon.ability_id == HEATPROOF:
            damage = max(1, damage // 2)  # 032 (R10): Heatproof's onDamage, then clampIntRange
        if cause in ("psn", "tox") and pokemon.ability_id == POISON_HEAL:
            # 043-3b: Poison Heal's onDamage (priority 1): heal 1/8 and false (no Focus Band)
            self._heal(pokemon, pokemon.max_hp / 8, "ability: poison heal")
            return True
        if self._magic_guard(pokemon):
            return True
        dealt = self._damage_event(pokemon, damage, by_move=False)
        dealt = min(dealt, pokemon.hp)
        pokemon.hp -= dealt
        self._emit("damage", target=pokemon.label, value=dealt, hp=pokemon.hp, detail=cause)
        if pokemon.hp == 0:
            self._faint_queue.append(pokemon)
        return True

    def _stockpile(self, user: BattlePokemon) -> None:
        """041-4d: stockpile's onStart / onRestart: one more layer (-start stockpileN), then
        Def and SpD +1; a stage that moved is counted to take back."""
        if user.stockpile is None:
            user.stockpile = [0, 0, 0]
        user.stockpile[0] += 1
        self._emit("start", target=user.label, detail=f"stockpile{user.stockpile[0]}")
        before = user.boosts["def"], user.boosts["spd"]
        self._boost(user, {"def": 1, "spd": 1}, user)
        if user.boosts["def"] != before[0]:
            user.stockpile[1] -= 1
        if user.boosts["spd"] != before[1]:
            user.stockpile[2] -= 1

    def _end_stockpile(self, user: BattlePokemon) -> None:
        """041-4d: removeVolatile('stockpile'): onEnd takes the counted stages back, then
        ``-end … Stockpile``."""
        assert user.stockpile is not None
        _, defense, spdef = user.stockpile
        user.stockpile = None
        changes = {k: v for k, v in (("def", defense), ("spd", spdef)) if v}
        if changes:
            self._boost(user, changes, user)
        self._emit("end", target=user.label, detail="Stockpile")

    def _leech_seed_residual(self, pokemon: BattlePokemon) -> None:
        """041-4c: leechseed's onResidual (order 8): the Pokemon at the seeder's slot, if it
        stands, gets the damage of baseMaxhp / 8 as healing (``[silent]``; Big Root)."""
        assert pokemon.leech_slot is not None
        side, position = pokemon.leech_slot
        target = self.state.at(side, position)
        if target is None or target.fainted or target.hp <= 0:
            return
        before = pokemon.hp
        self._chip(pokemon, pokemon.max_hp / 8, "leech seed")
        dealt = before - pokemon.hp
        if pokemon.hp == 0 and pokemon not in self._faint_queue:
            self._faint_queue.append(pokemon)
        if dealt:
            amount = self._big_root(target, dealt)
            if not self._oozed(target, pokemon, amount):  # 043-3b
                self._heal(target, amount, "")
            elif target.hp == 0 and target not in self._faint_queue:
                self._faint_queue.append(target)

    def _slot_residual(self, pokemon: BattlePokemon, effect: str) -> bool:
        """041-4b: a slot condition's onResidual. futuremove (order 3) ends on its ending turn
        and wish (order 4) after its starting turn: removeSlotCondition runs the onEnd on the
        Pokemon in the slot now."""
        assert pokemon.position is not None
        slots = self.state.field.slot_effects[pokemon.side][pokemon.position]
        data = slots.get(effect)
        if data is None:
            return False
        turn = self.state.turn
        if effect == FUTURE_MOVE:
            if turn < data["ending_turn"]:
                return True
            del slots[effect]
            self._future_hit(data["source"], pokemon, data.get("move", FUTURE_SIGHT))
            return True
        if turn <= data["starting_turn"]:
            return True
        del slots[effect]
        # wish onEnd: heal (TryHeal: Heal Block), -heal [from] move: Wish
        if not pokemon.fainted and HEAL_BLOCK not in pokemon.timed:
            healed = min(max(1, int(data["hp"])), pokemon.max_hp - pokemon.hp)
            if pokemon.hp > 0 and healed > 0:
                pokemon.hp += healed
                self._emit(
                    "heal",
                    target=pokemon.label,
                    value=healed,
                    hp=pokemon.hp,
                    detail="move: wish",
                )  # fmt: skip  ([wisher] not compared)
        return True

    def _future_hit(
        self, source: BattlePokemon, target: BattlePokemon, move_id: str = FUTURE_SIGHT
    ) -> None:
        """041-4b: futuremove's onEnd: nothing on a fainted target or the user itself; else
        ``-end``, Protect and Endure removed, ``trySpreadMoveHit([target], source, move,
        notActive)`` (no move line), then the source's Life Orb if it is active."""
        if target.fainted or target is source:
            return
        move = get_dex().move(move_id)
        assert move is not None
        self._emit("end", target=target.label, detail=f"move: {move.name}")
        for volatile in ("protect", "endure"):
            target.timed.pop(volatile, None)
        benched = not is_active(source)
        saved = source.held_item, source.ability
        if benched:  # ignoringItem / ignoringAbility: a source off the field (not isActive)
            source.item, source.ability = "", ""
        try:
            self._future_hit_steps(source, move, target)
        finally:
            if benched:
                source.item, source.ability = saved
        if is_active(source) and source.item == LIFE_ORB:
            self._chip(source, source.max_hp / 10, "item: life orb")
        self._check_win(None)  # (a source at 0 HP still counts: it faints after this)
        if not self.state.ended and source.hp == 0 and source not in self._faint_queue:
            self._faint_queue.append(source)  # (fieldEvent's faintMessages)

    def _future_hit_steps(self, source: BattlePokemon, move: Move, target: BattlePokemon) -> None:
        """041-4b: trySpreadMoveHit's steps for the future move."""
        self._not_fail_blocks = 0
        self._sure_hit = False
        self._smart = False
        targets = self._invulnerability(source, move, [target])
        targets = self._try_hit(source, move, targets)
        hit = []
        for t in targets:
            if type_immune(move, source.combatant(), t.combatant()):
                self._emit("immune", target=t.label)
            else:
                hit.append(t)
        self._accuracy_last = hit[-1] if hit else None
        landed = []
        for t in hit:
            modifier = self._accuracy_modifier(source, move, t)
            self._accuracy_boost_draws(source, move, t)
            stage = max(-6, min(6, source.boosts["accuracy"])) - t.boosts["evasion"]
            assert move.accuracy is not None
            accuracy = boosted_accuracy(modify(_wonder_skin(move, t), modifier, 4096), stage)
            if self._accuracy_true(t, move, source) or self.prng.random_chance(accuracy, 100):
                landed.append(t)
            else:
                self._emit("miss", actor=source.label, target=t.label)
        self._move_succeeded = False
        self._total_damage = 0
        self._run_hits(source, move, landed, spread=False)

    def _future_sight(
        self, user: BattlePokemon, target: BattlePokemon, move_id: str = FUTURE_SIGHT
    ) -> bool:
        """041-4b: Future Sight's onTry: addSlotCondition(target, 'futuremove') (false when the
        slot has one), ``-start`` on the user, NOT_FAIL (the move does not fail)."""
        assert target.position is not None
        slots = self.state.field.slot_effects[target.side][target.position]
        if FUTURE_MOVE in slots:
            self._emit("fail", actor=user.label)
            return False
        slots[FUTURE_MOVE] = {"source": user, "ending_turn": self.state.turn + 2,
                              "move": move_id}  # fmt: skip
        # (041-6f: Doom Desire's onTry shows -start … Doom Desire, without move:)
        detail = "move: Future Sight" if move_id == FUTURE_SIGHT else "Doom Desire"
        self._emit("start", target=user.label, detail=detail)
        return True

    def _wish(self, user: BattlePokemon) -> bool:
        """041-4b: Wish's slotCondition on the user's position (no onRestart: false when there
        is one): onStart keeps half the user's max HP and the turn."""
        assert user.position is not None
        slots = self.state.field.slot_effects[user.side][user.position]
        if WISH in slots:
            return False
        slots[WISH] = {"source": user, "hp": user.max_hp / 2, "starting_turn": self.state.turn}
        return True

    def _shields_down(self, pokemon: BattlePokemon) -> None:
        """043-6d: Shields Down (a Minior, not transformed): above half HP the Meteor forme,
        otherwise the set's forme (formeChange, not for good: ``-formechange``)."""
        if pokemon.species.base_species != "Minior" or pokemon.transform_base is not None:
            return
        meteor = pokemon.species.name == "Minior-Meteor"
        if pokemon.hp > pokemon.max_hp / 2:
            name = None if meteor else "Minior-Meteor"
        else:
            own = pokemon.pokemon_set
            name = (own.species if own is not None else "Minior") if meteor else None
        if name is None:
            return
        forme = get_dex().species(name)
        assert forme is not None
        pokemon.set_species(forme)
        self._emit("formechange", target=pokemon.label, detail=forme.name)

    def _bust(self, pokemon: BattlePokemon) -> None:
        """043-6e: Disguise's onUpdate (Mimikyu-Busted for good, then baseMaxhp / 8 from the
        species) / Ice Face's (Eiscue-Noice for good)."""
        if pokemon.ability_id == "disguise" and pokemon.species.name == "Mimikyu":
            self._forme_for_good(pokemon, "Mimikyu-Busted")
            self._chip(pokemon, pokemon.max_hp / 8, "pokemon: mimikyu-busted")
        elif pokemon.ability_id == "iceface" and pokemon.species.name == "Eiscue":
            self._forme_for_good(pokemon, "Eiscue-Noice")

    def _gulp(self, pokemon: BattlePokemon) -> None:
        """043-6f: Gulp Missile's formeChange (not for good): Gorging at half HP or less."""
        gorging = pokemon.hp <= pokemon.max_hp / 2
        self._temporary_forme(pokemon, "Cramorant-Gorging" if gorging else "Cramorant-Gulping")

    def _temporary_forme(self, pokemon: BattlePokemon, name: str) -> None:
        """``formeChange`` not for good from a move: setSpecies and ``-formechange``."""
        forme = get_dex().species(name)
        assert forme is not None
        pokemon.set_species(forme)
        self._emit("formechange", target=pokemon.label, detail=forme.name)

    def _hunger_switch(self, pokemon: BattlePokemon) -> None:
        """042-3: Hunger Switch's onResidual (order 29): a Morpeko not terastallized
        switches between its formes (formeChange, not permanent: ``-formechange … [from]
        ability: Hunger Switch``; setSpecies: the types and stats from the set)."""
        if pokemon.species.base_species != "Morpeko" or pokemon.terastallized is not None:
            return
        name = "Morpeko-Hangry" if pokemon.species.name == "Morpeko" else "Morpeko"
        forme = get_dex().species(name)
        assert forme is not None
        pokemon.set_species(forme)  # (review: Soak's type and Power Trick do not stay)
        self._emit("formechange", target=pokemon.label, detail=forme.name)

    def _healer(self, pokemon: BattlePokemon) -> None:
        """043-1: Healer's onResidual: each adjacent ally with a status condition,
        randomChance(3, 10): ``-activate ... ability: Healer``, then cureStatus."""
        for ally in self.state.sides[pokemon.side].alive_active():
            if ally is pokemon or ally.hp <= 0 or not ally.status:
                continue
            if self.prng.random_chance(3, 10):
                self._emit("activate", target=pokemon.label, detail="ability: Healer")
                cure(ally, self._emit_kw)

    def _moody(self, pokemon: BattlePokemon) -> None:
        """moody ``onResidual`` (023 R12): a stat below +6 (not accuracy or evasion) goes up
        by 2, then another one above -6 goes down by 1, in one boost."""
        stats = [s for s in BOOST_IDS[:5] if pokemon.boosts[s] < 6]
        up = self.prng.sample(stats) if stats else None
        changes = {up: 2} if up else {}
        stats = [s for s in BOOST_IDS[:5] if pokemon.boosts[s] > -6 and s != up]
        if stats:
            changes[self.prng.sample(stats)] = -1
        # like Download: announced once (-ability … boost), a stuck stage silent
        apply_boosts(
            pokemon, changes, primary=False, foes_left=self._foes_left(pokemon),
            emit=self._emit_kw, source=pokemon, ability="Moody",
        )  # fmt: skip

    def _timed_residual(self, pokemon: BattlePokemon, effect: str) -> bool:
        """A volatile with a duration at the residual: ``duration--``, ending at 0 (its onEnd),
        otherwise its onResidual. True when it did not end."""
        if effect == LOCKED_MOVE and LOCKED_MOVE in pokemon.timed:
            return self._locked_move_residual(pokemon)  # 022
        if effect == UPROAR and UPROAR in pokemon.timed:
            return self._uproar_residual(pokemon)  # 033
        if effect == PERISH_SONG and PERISH_SONG in pokemon.timed:
            return self._perish_residual(pokemon)  # 022
        if effect not in pokemon.timed:
            return False  # ended earlier this turn
        if effect in (AQUA_RING, INGRAIN):  # 041-4c: heal(baseMaxhp / 16)
            name = "Aqua Ring" if effect == AQUA_RING else "Ingrain"
            self._heal(pokemon, pokemon.max_hp / 16, name.lower())
            return True
        if effect == LEECH_SEED:
            self._leech_seed_residual(pokemon)
            return True
        if effect in (CURSE, SALT_CURE):
            # 032: Curse (R15, order 12) damage(baseMaxhp / 4); Salt Cure (R16, order 13)
            # baseMaxhp / 4 for a Water or Steel type, else / 8; no duration
            if effect == CURSE:
                self._chip(pokemon, pokemon.max_hp / 4, "curse")
            else:
                hard = "Water" in pokemon.types or "Steel" in pokemon.types
                self._chip(pokemon, pokemon.max_hp / (4 if hard else 8), "salt cure")
            if pokemon.hp == 0 and pokemon not in self._faint_queue:
                self._faint_queue.append(pokemon)
            return True
        if effect == PARTIALLY_TRAPPED:
            return self._partially_trapped_residual(pokemon)  # 024
        if effect == YAWN:
            return self._yawn_residual(pokemon)  # 025
        if effect == ENCORE and pokemon.timed[ENCORE] > 1:
            pokemon.timed[ENCORE] -= 1
            if not any(s.move.id == pokemon.encore_move and s.pp > 0 for s in pokemon.moves):
                self._end_move_lock(pokemon, ENCORE)  # onResidual: no PP left
            return True
        pokemon.timed[effect] -= 1
        if pokemon.timed[effect] > 0:
            if effect == SYRUP_BOMB:  # 041-6f: onResidual: boost({spe: -1}, source)
                apply_boosts(
                    pokemon, {"spe": -1}, primary=False, foes_left=self._foes_left(pokemon),
                    emit=self._emit_kw, source=pokemon.syrup_source,
                )  # fmt: skip
            return True
        if effect in MOVE_LOCKS:
            self._end_move_lock(pokemon, effect)  # 015: -end
            return False
        if effect in (DISABLE, HEAL_BLOCK):  # 023: onEnd
            self._end_move_lock(pokemon, effect)
            return False
        if effect == MAGNET_RISE:  # 041-6f: onEnd
            del pokemon.timed[MAGNET_RISE]
            self._emit("end", target=pokemon.label, detail="Magnet Rise")
            return False
        if effect == SYRUP_BOMB:  # 041-6f: onEnd, -end [silent]
            self._end_syrup_bomb(pokemon)
            return False
        if effect == THROAT_CHOP:  # 021: onEnd, -end [silent]
            del pokemon.timed[THROAT_CHOP]
            self._emit("end", target=pokemon.label, detail="Throat Chop")
            return False
        del pokemon.timed[effect]  # ends silently
        pokemon.counters.pop(effect, None)
        if effect == TWO_TURN:  # 020: onEnd removes the move's volatile
            pokemon.two_turn_move, pokemon.charge_loc = None, None
            pokemon.charged = False
            _clear_vanished(pokemon)  # 026 (041-2: every semi-invulnerable volatile)
        return False

    def _add_attract(
        self,
        target: BattlePokemon,
        source: BattlePokemon,
        *,
        from_move: bool,
        knot: bool = False,
    ) -> bool | None:
        """041-6f: addVolatile('attract'): false at 0 HP, when it has it (no onRestart) or
        Oblivious (runStatusImmunity, no message); TryAddVolatile (Aroma Veil: null);
        onStart: false unless the genders are opposite, then runEvent('Attract') (the
        target's Destiny Knot attracts the source: its ``-start`` comes first), then
        ``-start … Attract``."""
        if target.hp <= 0 or target.attract_source is not None:
            return False
        if target.ability_id == OBLIVIOUS:
            return False
        if self._volatile_veil(target, "attract", from_move=from_move):
            return None
        if not _opposite_genders(target, source):
            return False
        target.attract_source = source
        if target.item == DESTINY_KNOT and source is not target and source.attract_source is None:
            # (its -start … [from] item: Destiny Knot)
            self._add_attract(source, target, from_move=False, knot=True)
        self._emit("start", target=target.label, detail="Attract")
        return True

    def _end_attract(self, pokemon: BattlePokemon) -> None:
        """041-6f: attract's onEnd: ``-end … Attract [silent]``."""
        pokemon.attract_source = None
        self._emit("end", target=pokemon.label, detail="Attract")

    def _attract_before_move(self, user: BattlePokemon) -> bool:
        """041-6f: attract's onBeforeMove (priority 2): ``-activate … move: Attract``, then
        half the time ``cant … Attract``."""
        if user.attract_source is None:
            return True
        self._emit("activate", target=user.label, detail="move: Attract")
        if self.prng.random_chance(1, 2):
            self._emit("cant", actor=user.label, detail="Attract")
            return False
        return True

    def _end_syrup_bomb(self, pokemon: BattlePokemon) -> None:
        """041-6f: syrupbomb's onEnd: ``-end … Syrup Bomb [silent]``."""
        del pokemon.timed[SYRUP_BOMB]
        pokemon.syrup_source = None
        self._emit("end", target=pokemon.label, detail="Syrup Bomb")

    def _partially_trapped_residual(self, pokemon: BattlePokemon) -> bool:
        """partiallytrapped at the residual (024 R2, order 13): ``duration--``, ending at 0
        (onEnd: ``-end … X [partiallytrapped]``). Otherwise onResidual: the binder gone (not
        active, no HP, or no turn started on the field) ends it silently; else 1/8 of the max
        HP. True when it did not end."""
        pokemon.timed[PARTIALLY_TRAPPED] -= 1
        if pokemon.timed[PARTIALLY_TRAPPED] <= 0:
            self._end_partially_trapped(pokemon)
            return False
        source = pokemon.trap_source
        if source is not None and (not is_active(source) or source.hp <= 0
                                   or not source.active_turns):  # fmt: skip
            self._end_partially_trapped(pokemon)  # -end … [partiallytrapped] [silent]
            return True
        move = get_dex().move(pokemon.trap_move or "")
        assert move is not None
        self._chip(pokemon, pokemon.max_hp / pokemon.trap_divisor, f"move: {move.name.lower()}")
        if pokemon.hp == 0 and pokemon not in self._faint_queue:
            self._faint_queue.append(pokemon)
        return True

    def _yawn_residual(self, pokemon: BattlePokemon) -> bool:
        """yawn at the residual (025 R2, order 23): ``duration--``; at 0 its onEnd:
        ``-end … move: Yawn [silent]``, then ``trySetStatus('slp')`` (silent when it already has
        a status; a terrain reports itself). True when it did not end."""
        pokemon.timed[YAWN] -= 1
        if pokemon.timed[YAWN] > 0:
            return True
        del pokemon.timed[YAWN]
        self._emit("end", target=pokemon.label, detail="move: Yawn")
        if pokemon.status is None:
            veil = self._veil_holder(pokemon, SWEET_VEIL)
            applied = try_set_status(
                pokemon, "slp", user=pokemon, status_move=False, prng=self.prng,
                emit=self._emit_kw,
                weather=effective_weather(self.state.field.active_weather, pokemon.item),
                terrain=self.state.field.terrain, from_yawn=True,
                sweet_veil=veil.label if veil else None, uproar=self._in_uproar(),
                uproar_first=self._uproar_first(veil),
            )  # fmt: skip
            if applied:
                self._effect_order += 1
                pokemon.status_order = self._effect_order
                if pokemon.item == LUM_BERRY:
                    self._lum_berry(pokemon)  # 032 (R5): runEvent('AfterSetStatus')
        return False

    def _end_partially_trapped(self, pokemon: BattlePokemon) -> None:
        """024: the volatile ends (``-end … X [partiallytrapped]``, with or without [silent])."""
        move = get_dex().move(pokemon.trap_move or "")
        assert move is not None
        del pokemon.timed[PARTIALLY_TRAPPED]
        pokemon.trap_source, pokemon.trap_move = None, None
        self._emit("end", target=pokemon.label, detail=move.name)

    def _flush_faints(self) -> bool:
        """``faintMessages`` for the Pokémon that fainted by ``faint()`` (022: Perish Song),
        then the win (by the last one); True when the battle ended."""
        if not self._faint_queue:
            return False
        queue, self._faint_queue = self._faint_queue, []
        for pokemon in queue:
            if not pokemon.fainted:
                self._faint_out(pokemon)
        return self._check_win(queue[-1])

    def _perish_residual(self, pokemon: BattlePokemon) -> bool:
        """perishsong at the residual (order 24): ``duration--``; at 0 its onEnd (``perish0``,
        ``faint()``: no faintMessages yet), otherwise onResidual shows the count. True when
        the callback ran (faintMessages follows)."""
        pokemon.timed[PERISH_SONG] -= 1
        left = pokemon.timed[PERISH_SONG]
        if left <= 0:
            del pokemon.timed[PERISH_SONG]
            self._emit("start", target=pokemon.label, detail="perish0")
            if pokemon.hp > 0 or pokemon not in self._faint_queue:
                pokemon.hp = 0
                self._faint_queue.append(pokemon)
            return False
        self._emit("start", target=pokemon.label, detail=f"perish{left}")
        return True

    def _perish_song(self, user: BattlePokemon, move: Move) -> bool:
        """perishsong ``onHitField`` (022 R5): every active Pokémon without a count gets one
        (``perish3``) unless its TryHit stops the move (Good as Gold); the move fails when
        nothing was tried."""
        result = message = False
        for pokemon in self.state.all_active():
            # 026 (R8): runEvent('Invulnerability'); 028: commanding's onInvulnerability too
            if vanished(pokemon) or pokemon.commanding:
                self._emit("miss", actor=user.label, target=pokemon.label)
                result = True
            elif not self._try_hit(user, move, [pokemon]):
                result = True  # TryHit returned null
            elif PERISH_SONG not in pokemon.timed:
                pokemon.timed[PERISH_SONG] = 4
                self._emit("start", target=pokemon.label, detail="perish3")
                result = message = True
        if not result:
            self._emit("fail", actor=user.label)
            return False
        if message:
            self._emit("fieldactivate", detail="move: Perish Song")
        return True

    def _sparkling_aria(self, user: BattlePokemon, move: Move) -> None:
        """041-6f: Sparkling Aria's onAfterMove: a fainted user, no hitTargets or Sheer Force
        deletes the volatile from every active Pokemon; otherwise each other hit target still
        active cures a burn when it loses the volatile, or always with two targets or more."""
        hit = self._hit_targets
        if user.fainted or not hit or has_sheer_force(user.ability_id, move):
            for pokemon in self.state.all_active():
                pokemon.sparkling_aria = False
            return
        for pokemon in hit:
            if pokemon is user or pokemon.position is None or pokemon.fainted:
                continue
            removed = pokemon.sparkling_aria and pokemon.hp > 0  # (removeVolatile: HP)
            if removed:
                pokemon.sparkling_aria = False
            if (removed or len(hit) > 1) and pokemon.status == "brn":
                cure(pokemon, self._emit_kw)

    def _court_change(self, user: BattlePokemon) -> bool:
        """041-6f: Court Change's onHitField: the listed side conditions of both sides
        are taken out (in the order they were set) and put after the other side's rest;
        none: false."""
        mine, foe = user.side, foe_of(user.side)
        moved = False
        for table in (self.state.field.sides, self.state.field.hazards):
            taken = {}
            for side in (mine, foe):
                taken[side] = {k: v for k, v in table[side].items() if k in COURT_CHANGE}
                for k in taken[side]:
                    del table[side][k]
                moved = moved or bool(taken[side])
            table[foe].update(taken[mine])
            table[mine].update(taken[foe])
        if not moved:
            self._emit("fail", actor=user.label)
            return False
        self._emit("swapsideconditions")
        self._emit("activate", target=user.label, detail="move: Court Change")
        return True

    def _teatime(self, user: BattlePokemon, move: Move) -> bool:
        """041-6f: Teatime's onHitField: every active Pokemon: Invulnerability (-miss), else
        TryHit and a berry; ``-fieldactivate``; nobody: ``-fail`` and NOT_FAIL (the result is
        false); otherwise each eats its berry (eatItem(true))."""
        targets = []
        for pokemon in self.state.all_active():
            if vanished(pokemon) or pokemon.commanding:
                self._emit("miss", actor=user.label, target=pokemon.label)
            elif self._try_hit(user, move, [pokemon]) and _holds_berry(pokemon):
                targets.append(pokemon)
        self._emit("fieldactivate", detail="move: Teatime")
        if not targets:
            self._emit("fail", actor=user.label)
            return False
        for pokemon in targets:
            item = pokemon.item
            self._eat_item(pokemon, partial(self._berry_on_eat, pokemon, item), force=True)
        return True

    def _weather_residual(self) -> bool:
        """The weather's residual handler; True when it did not end. ``duration--`` (ending:
        ``-weather none`` and WeatherChange), otherwise the upkeep: eachEvent('Weather') (the
        sandstorm's damage) and eachEvent('Update'); faintMessages follows."""
        field_state = self.state.field
        weather = field_state.weather
        assert weather is not None
        field_state.weather_turns -= 1
        if field_state.weather_turns == 0:
            clear_weather(field_state, emit=self._emit_kw)
            self._weather_change()
            return False  # continue: no faintMessages
        self._emit("weatherupkeep", detail=WEATHER_NAMES[weather])
        if field_state.weather_suppressed:
            weather = None  # 043-4g: isWeather() is false: no eachEvent('Weather')
        actives = self.state.all_active()
        speed_sort(actives, self.prng, _by_speed)  # eachEvent('Weather')
        hurt: list[BattlePokemon] = []
        if weather == SAND:
            for pokemon in actives:
                if (
                    SAND_IMMUNE & set(pokemon.types)
                    or vanished(pokemon) in ("dig", "dive")  # 041-2: their onImmunity
                    or pokemon.ability_id in WEATHER_DAMAGE_IMMUNE
                    or pokemon.item == SAFETY_GOGGLES
                ):
                    continue  # runStatusImmunity('sandstorm') (012: Overcoat; 013: Goggles)
                if self._magic_guard(pokemon):
                    continue
                dealt = self._damage_event(pokemon, max(1, pokemon.max_hp // 16), by_move=False)
                dealt = min(dealt, pokemon.hp)
                pokemon.hp -= dealt
                self._emit("damage", target=pokemon.label, value=dealt, hp=pokemon.hp,
                           detail="sandstorm")  # fmt: skip
                hurt.append(pokemon)
        elif weather == SUN:
            for pokemon in actives:  # 043-2a: Solar Power's onWeather (effectiveWeather)
                # (043-4c: Dry Skin's onWeather is the same in the sun)
                if pokemon.ability_id not in ("solarpower", "dryskin") or pokemon.hp <= 0:
                    continue
                if effective_weather(weather, pokemon.item) != SUN:
                    continue
                dealt = self._damage_event(pokemon, max(1, pokemon.max_hp // 8), by_move=False)
                dealt = min(dealt, pokemon.hp)
                pokemon.hp -= dealt
                name = "solar power" if pokemon.ability_id == "solarpower" else "dry skin"
                self._emit("damage", target=pokemon.label, value=dealt, hp=pokemon.hp,
                           detail=f"ability: {name}")  # fmt: skip
                hurt.append(pokemon)
        elif weather == RAIN:
            for pokemon in actives:  # 043-4c: Rain Dish / Dry Skin's onWeather (effective)
                heal = {"raindish": 16, "dryskin": 8}.get(pokemon.ability_id)
                if heal is None or pokemon.hp <= 0:
                    continue
                if effective_weather(weather, pokemon.item) == RAIN:
                    name = "rain dish" if heal == 16 else "dry skin"
                    self._heal(pokemon, pokemon.max_hp / heal, f"ability: {name}")
        elif weather == SNOW:
            for pokemon in actives:  # 032 (R14): Ice Body's onWeather
                if pokemon.ability_id == ICE_BODY and pokemon.hp > 0:
                    self._heal(pokemon, pokemon.max_hp / 16, "ability: ice body")
        self._update()  # eachEvent('Update') (gen 7+, after 'Weather')
        for pokemon in hurt:  # faint(), in the order they were hit
            if pokemon.hp == 0 and pokemon not in self._faint_queue:
                self._faint_queue.append(pokemon)
        return True

    def _terrain_residual(self) -> bool:
        """The terrain's residual handler (010): ``duration--``; at 0 ``clearTerrain``
        (``-fieldend`` and TerrainChange). True when it did not end."""
        field_state = self.state.field
        field_state.terrain_turns -= 1
        if field_state.terrain_turns == 0:
            self._clear_terrain()
            return False
        return True

    def _clear_terrain(self) -> None:
        """``field.clearTerrain``: the terrain ends, then ``eachEvent('TerrainChange')``."""
        if clear_terrain(self.state.field, emit=self._emit_kw):
            self._terrain_change()

    def _grassy_heal(self, pokemon: BattlePokemon) -> None:
        """Grassy Terrain ``onResidual``: a grounded Pokémon heals 1/16 of its max HP (nothing at
        full HP)."""
        grounded = is_grounded(
            pokemon.types,
            pokemon.ability_id,
            pokemon.item,
            pokemon.pinned,
            rising="magnetrise" in pokemon.timed,
        )
        if self.state.field.terrain != GRASSY or not grounded:
            return
        if vanished(pokemon):
            return  # 032: !isSemiInvulnerable() (026's Phantom Force; found in moves032-0)
        if HEAL_BLOCK in pokemon.timed:
            return  # 023: healblock onTryHeal
        amount = max(1, pokemon.max_hp // 16)
        healed = min(amount, pokemon.max_hp - pokemon.hp)
        if healed <= 0:
            return
        pokemon.hp += healed
        self._emit("heal", target=pokemon.label, value=healed, hp=pokemon.hp,
                   detail="grassy terrain")  # fmt: skip

    def _count_down(self, handler: _Residual) -> bool:
        """A field or side condition's residual handler: ``duration--``, ending at 0. True when
        it did not end."""
        field_state = self.state.field
        if handler.side is None:
            turns = field_state.pseudo_weather
        else:
            turns = field_state.sides[handler.side]
        if handler.effect not in turns:
            return False  # ended earlier this turn
        turns[handler.effect] -= 1
        if turns[handler.effect] > 0:
            return True
        if handler.side is None:
            end_pseudo_weather(field_state, handler.effect, self._emit_kw)
            if handler.effect == GRAVITY:
                self._set_gravity(False)
        else:
            end_side_condition(field_state, handler.side, handler.effect, self._emit_kw)
        return False

    def _speed(self, pokemon: BattlePokemon) -> int:
        """Showdown ``pokemon.getActionSpeed()`` in the current field (getStat: 028 its
        ModifyBoost event)."""
        self._spe_events(pokemon)
        return action_speed(pokemon, self.state.field)

    def _make_action(
        self, pokemon: BattlePokemon, choice: MoveChoice | SwitchChoice, *, speed: bool = True
    ) -> _Action:
        """``speed``: getActionSpeed now (a move's comes after its target lookup's draws: the
        caller sets it, 028)."""
        value = self._speed(pokemon) if speed else 0  # Showdown getActionSpeed
        if isinstance(choice, SwitchChoice):
            return _Action("switch", SWITCH_ORDER, 0, value, pokemon, choice)
        return _Action("move", MOVE_ORDER, self._priority(pokemon, choice), value, pokemon, choice)

    def _fractional_priority(self, pokemon: BattlePokemon, choice: MoveChoice) -> float:
        """runEvent('FractionalPriority', relay 0): each handler's value replaces the relay.
        Priority 0: Stall (043-5b), then Lagging Tail (an item: subOrder 8) -0.1; priority -1:
        Mycelium Might (a status move, -0.1; 043-5b) and Quick Draw (043-4e: randomChance(3,
        10), +0.1); priority -2: Quick Claw (040-4b: randomChance(1, 5)) and Custap Berry (032:
        eaten at 1/4 HP, Gluttony 1/2), both only while the relay is <= 0 and not for a
        Mycelium Might holder's status move."""
        status = chosen_move(pokemon, choice).category == "Status"
        value = 0.0
        if pokemon.ability_id == "stall":
            value = -0.1
        if pokemon.item == LAGGING_TAIL:
            value = -0.1  # 040-4b
        mycelium = pokemon.ability_id == "myceliummight" and status
        if mycelium:
            value = -0.1
        if pokemon.ability_id == "quickdraw" and not status and self.prng.random_chance(3, 10):
            self._emit("activate", target=pokemon.label, detail="ability: Quick Draw")
            value = 0.1
        if mycelium or value > 0:
            return value
        if pokemon.item == QUICK_CLAW:
            if self.prng.random_chance(1, 5):
                self._emit("activate", target=pokemon.label, detail="item: Quick Claw")
                return 0.1
            return value
        if pokemon.item != CUSTAP_BERRY or pokemon.hp <= 0:
            return value
        low = pokemon.hp <= pokemon.max_hp / 4 or (
            pokemon.hp <= pokemon.max_hp / 2 and pokemon.ability_id == GLUTTONY
        )
        if low and self._eat_item(pokemon):
            self._emit("activate", target=pokemon.label, detail="item: Custap Berry")
            return 0.1
        return value

    def _priority(self, pokemon: BattlePokemon, choice: MoveChoice) -> int:
        """``getActionSpeed``: the base move's priority after ModifyPriority (Grassy Glide,
        Prankster)."""
        return self._move_priority(pokemon, chosen_move(pokemon, choice))

    def _move_priority(self, pokemon: BattlePokemon, move: Move) -> int:
        terrain = self.state.field.terrain
        # A fainted Pokémon is no longer active: ignoringAbility() skips its ability (Prankster)
        ability = "" if pokemon.fainted else pokemon.ability_id
        grounded = is_grounded(
            pokemon.types,
            ability,
            pokemon.item,
            pokemon.pinned,
            rising="magnetrise" in pokemon.timed,
        )
        priority = terrain_priority(move, terrain, user_grounded=grounded)
        return priority + modify_priority(ability, move, full_hp=pokemon.hp == pokemon.max_hp)

    def _run_switch(self, pokemon: BattlePokemon, choice: SwitchChoice) -> None:
        side = self.state.sides[pokemon.side]
        incoming = side.team[choice.team_index]
        assert pokemon.position is not None
        if incoming.position is not None:
            return  # 014: switchIn fails when it already came in (Eject Pack, U-turn's switch)
        # switchIn: calling back a Pokémon that has not fainted runs eachEvent('Update') first.
        self._update()
        self._switch_out(pokemon)
        self._switch_in(side, pokemon.position, incoming)
        # insertChoice of its runSwitch action: updateSpeed, then resolveAction's getActionSpeed
        # (028: each runs ModifyBoost)
        self._update_one_speed(incoming)
        self._spe_events(incoming)
        # Then its runSwitch action, which Showdown inserts at the front of the queue.
        self._update(run_switch_next=True)  # eachEvent('Update') after the switch action
        self._switch_in_abilities([incoming], self._run_switch_sort())

    # -- PRNG parity with Showdown --------------------------------------------------------
    # Showdown draws random numbers in places where the outcome cannot matter in 001 (sorting
    # Pokémon for events nobody listens to, looking targets up while ordering actions). Drawing
    # at the same places keeps both PRNGs in step, so the same seed gives the same battle.

    def _random_foe_draw(self, user: BattlePokemon) -> BattlePokemon | None:
        """``side.randomFoe()``: one draw among the foes still standing (none if no foe)."""
        foes = self.state.sides[foe_of(user.side)].alive_active()
        return self.prng.sample(foes) if foes else None

    def _action_speed_draws(self, action: _Action) -> None:
        """``Battle.getActionSpeed`` calls ``getTarget``, which may pick a random foe."""
        if not isinstance(action.choice, MoveChoice):
            return
        move = chosen_move(action.pokemon, action.choice)
        loc = action.choice.target
        if loc is None and (move.id in (CURSE, "terastarstorm") or move.target == "scripted"):
            # 032: a non-Ghost Curse's action.targetLoc (042-6: and Terapagos-Stellar's Tera
            # Starstorm, chosen as a spread move: getTarget sees its 'normal' target)
            loc = action.pokemon.resolved_loc
        if (
            move.target in USER_TARGETS
            or move.target in ALLY_TARGETS
            or move.target == ALLY_OR_SELF
        ):
            return  # the user itself; the ally (even fainted) without a draw
        scripted = move.target == "scripted"  # 041-4a: a valid adjacent location (Counter)
        if (move.target not in SINGLE_TARGETS and not scripted) or loc is None:
            self._random_foe_draw(action.pokemon)  # spread moves never have a valid location
            return
        side = foe_of(action.pokemon.side) if loc > 0 else action.pokemon.side
        target = self.state.at(side, abs(loc) - 1)
        if loc > 0 and (target is None or target.fainted):
            self._random_foe_draw(action.pokemon)
        elif target is action.pokemon and (
            TWO_TURN in action.pokemon.timed or move.target not in SELF_LOC_NULL_TARGETS
        ):
            # 026: its own location (a charging move started by an Encore override) is no
            # valid target location; getTarget gives null (no draw) only outside twoturnmove
            self._random_foe_draw(action.pokemon)

    def _update(self, *, run_switch_next: bool = False) -> None:
        """``eachEvent('Update')``: in speed order, each Pokémon's onUpdate handlers (028: the
        ability's, subOrder 7: Commander; 013: then the held item's: Sitrus Berry, the pinch
        berries, Booster Energy). ``run_switch_next``: the queue's next action is a runSwitch
        (between a switch and its runSwitch)."""
        for pokemon in self._sort_active_by_speed():
            if pokemon in self._flinging:
                self._fling_end(pokemon)  # 032 (R8): the fling volatile's onUpdate (first)
            # 041-6f: the syrupbomb and attract volatiles' onUpdate (both: a tie, shuffled;
            # removeVolatile does nothing at 0 HP)
            updates = [v for v in (SYRUP_BOMB, "attract") if self._has_source_volatile(pokemon, v)]
            speed_sort(updates, self.prng, lambda a, b: 0)
            for volatile in updates:
                if volatile == SYRUP_BOMB:
                    source = pokemon.syrup_source
                    if source is not None and not is_active(source) and pokemon.hp > 0:
                        self._end_syrup_bomb(pokemon)
                else:
                    source = pokemon.attract_source
                    if source is not None and not is_active(source) and pokemon.hp > 0:
                        self._end_attract(pokemon)
            if pokemon.ability_id == COMMANDER:
                self._commander(pokemon, run_switch_next=run_switch_next)
            elif pokemon.ability_id in ("disguise", "iceface") and pokemon.disguise_busted:
                self._bust(pokemon)  # 043-6e: onUpdate
            elif pokemon.ability_id == OBLIVIOUS and (
                TAUNT in pokemon.timed or pokemon.attract_source is not None
            ):
                # 029: Oblivious's onUpdate (a taunt from while the gas suppressed it;
                # 041-6f: attract first, ``-end … move: Attract [from] ability: Oblivious``)
                if pokemon.attract_source is not None:
                    self._emit("activate", target=pokemon.label, detail="ability: Oblivious")
                    if pokemon.hp > 0:
                        self._end_attract(pokemon)
                    self._emit("end", target=pokemon.label, detail="move: Attract")
                if TAUNT in pokemon.timed:
                    self._emit("activate", target=pokemon.label, detail="ability: Oblivious")
                    if pokemon.hp > 0:  # removeVolatile does nothing at 0 HP (015)
                        self._end_move_lock(pokemon, TAUNT)
            elif pokemon.ability_id == OWN_TEMPO and pokemon.confusion_turns:
                # 029: Own Tempo's onUpdate (confusion from while the gas suppressed it)
                self._emit("activate", target=pokemon.label, detail="ability: Own Tempo")
                if pokemon.hp > 0:  # removeVolatile: confusion's onEnd
                    pokemon.confusion_turns = 0
                    self._emit("end", target=pokemon.label, detail="confusion")
            elif pokemon.ability_id == TRACE and pokemon.trace_seeking:
                self._trace(pokemon)  # 031 (R6): Trace's onUpdate
            elif (
                pokemon.ability_id in STATUS_GUARDS
                and pokemon.status in STATUS_GUARDS[pokemon.ability_id][0]
            ) or (pokemon.ability_id == MAGMA_ARMOR and pokemon.status == "frz"):
                # 041-3h: Insomnia's onUpdate (an ability given while asleep; 041-6f: Limber's;
                # 043-3a: Vital Spirit, Immunity, Water Veil, Magma Armor)
                guard = STATUS_GUARDS.get(pokemon.ability_id)
                name = guard[1] if guard else "Magma Armor"
                self._emit("activate", target=pokemon.label, detail=f"ability: {name}")
                cure(pokemon, self._emit_kw)
            elif pokemon.ability_id in BURN_CURERS and pokemon.status == "brn":
                # 029: Thermal Exchange's onUpdate (cureStatus does nothing at 0 HP); 030: Water
                # Bubble's
                name = BURN_CURERS[pokemon.ability_id]
                self._emit("activate", target=pokemon.label, detail=f"ability: {name}")
                cure(pokemon, self._emit_kw)
            self._item_update(pokemon)

    def _trace(self, pokemon: BattlePokemon) -> None:
        """031 (R6): Trace's onUpdate. One sample among the foes (by HP) whose ability is not
        notrace nor No Ability, then ``setAbility(ability, target)``: Trace's End (none), the
        new ability with a new abilityState, ``-ability … [from] ability: Trace``, its Start.
        With no candidate it goes on seeking."""
        dex = get_dex()
        candidates = []
        for foe in self.state.sides[foe_of(pokemon.side)].alive_active():
            data = dex.ability(foe.base_ability_id)
            if foe.hp > 0 and foe.base_ability_id != NO_ABILITY and not (data and data.no_trace):
                candidates.append(foe)
        if not candidates:
            return
        target = self.prng.sample(candidates)
        if pokemon.hp <= 0:
            return  # setAbility does nothing at 0 HP
        pokemon.ability = target.ability
        pokemon.trace_seeking = False  # (the new abilityState)
        self._ability_order += 1
        pokemon.ability_order = self._ability_order
        self._emit("ability", target=pokemon.label, detail=target.ability)
        self._ability_start(pokemon)

    def _commander(self, pokemon: BattlePokemon, *, run_switch_next: bool = False) -> None:
        """028 (R1): Commander's onUpdate (also its onStart and onAnySwitchIn)."""
        if pokemon.fainted or run_switch_next:
            return
        allies = [
            p for p in self.state.sides[pokemon.side].active
            if p is not None and p is not pokemon and p.hp > 0
        ]  # fmt: skip
        ally = allies[0] if allies else None
        if pokemon.switch_flag or (ally is not None and ally.switch_flag):
            return
        if (
            ally is None
            or pokemon.species.base_species != "Tatsugiri"
            or ally.species.base_species != "Dondozo"
        ):
            if pokemon.hp > 0:
                pokemon.commanding = False  # removeVolatile: no message
            return
        if pokemon.commanding or ally.commanded_by is not None or pokemon.hp <= 0:
            return  # (the ally is alive: the "ally fainted" branch cannot happen here)
        if self._queue is not None:
            self._queue.remove(partial(_acts_for, pokemon))  # cancelAction
        self._emit("activate", target=pokemon.label, detail="ability: Commander")  # [of] ally
        pokemon.commanding = True
        ally.commanded_by = pokemon
        # the commanded volatile's onStart: boost (a condition: no -ability, a stuck stage shown)
        apply_boosts(
            ally, {"atk": 2, "spa": 2, "spe": 2, "def": 2, "spd": 2}, primary=True,
            foes_left=self._foes_left(ally), emit=self._emit_kw, source=pokemon,
        )  # fmt: skip

    def _sort_active_by_speed(self) -> list[BattlePokemon]:
        """``eachEvent``: the Pokémon on the field sorted by speed (ties shuffled). 034 (T011,
        an old bug from 029): inside Neutralizing Gas's End while its holder faints, the holder
        is still one of them (its fainted flag comes later), at its speed before fainting."""
        if self._gas_fainting is None:
            actives = self.state.all_active()
            speed_sort(actives, self.prng, _by_speed)
            return actives
        source, speed = self._gas_fainting
        actives = [
            p for s in SIDE_IDS for p in self.state.sides[s].active
            if p is not None and (not p.fainted or p is source)
        ]  # fmt: skip
        saved, source.cached_speed = source.cached_speed, speed
        try:
            speed_sort(actives, self.prng, _by_speed)
        finally:
            source.cached_speed = saved
        return [p for p in actives if p is not source]  # (fainted: no handler of its own)

    def _run_switch_sort(self) -> list[BattlePokemon]:
        """``BattleActions.runSwitch``: every active Pokémon, fainted ones included (the
        ``speedOrder`` that orders the switch-in handlers)."""
        active = [p for s in SIDE_IDS for p in self.state.sides[s].active if p is not None]
        speed_sort(active, self.prng, _by_speed)
        return active

    # -- 011: abilities -------------------------------------------------------------------

    def _switch_in_abilities(
        self, switchers: Sequence[BattlePokemon], order: list[BattlePokemon]
    ) -> None:
        """``fieldEvent('SwitchIn', switchersIn)``: the switchers' onStart handlers by
        onSwitchInPriority, then by speed shifted by the position in ``order`` (so no ties)."""
        # 013: the items' onStart (Booster Energy -2, the seeds -1, White Herb 0) and White
        # Herb's onAnySwitchIn (-2, every holder on the field); for one Pokémon the ability
        # (subOrder 7) comes before the item (8).
        # 020: the hazards of the switcher's side (side conditions: subOrder 4, then the order
        # they were set in), before its ability and item; faintMessages after each handler.
        handlers: list[tuple[BattlePokemon, str, int, int, int]] = [
            (p, hazard, 0, 4, i)
            for p in switchers
            for i, hazard in enumerate(self.state.field.hazards[p.side])
        ]
        # 025: Healing Wish's onSwitchIn (a slot condition: subOrder 3, before the hazards)
        # (041-6d: Lunar Dance's too, in the order the slot got them)
        handlers += [
            (p, key, 0, 3, 0)
            for p in switchers
            if p.position is not None
            for key in self.state.field.slot_conditions[p.side][p.position]
            if key in WISHES
        ]
        # (028: an ability with onAnySwitchIn has no onStart here (getCallback): Commander only
        # goes in through its onAnySwitchIn below)
        # (029: collected from the ability it has, suppressed or not; a suppressed one is
        # skipped when it runs, as singleEvent does)
        handlers += [(p, "ability", switch_in_priority(p.base_ability_id), 7, 0)
                     for p in switchers
                     if has_switch_in(p.base_ability_id)
                     and p.base_ability_id != COMMANDER]  # fmt: skip
        # 043-6d: Shields Down's onStart (onSwitchInPriority -1)
        handlers += [(p, "shieldsdown", -1, 7, 0) for p in switchers
                     if p.base_ability_id == "shieldsdown"]  # fmt: skip
        # 043-6e: Ice Face's onStart (onSwitchInPriority -2)
        handlers += [(p, "iceface", -2, 7, 0) for p in switchers
                     if p.base_ability_id == "iceface"]  # fmt: skip
        # 043-6b: Zero to Hero's onSwitchIn (priority 0)
        handlers += [(p, "zerotohero", 0, 7, 0) for p in switchers
                     if p.base_ability_id == "zerotohero"]  # fmt: skip
        # 043-5g: Imposter's onSwitchIn (priority 0)
        handlers += [(p, "imposter", 0, 7, 0) for p in switchers
                     if p.base_ability_id == "imposter"]  # fmt: skip
        # 042-6: Tera Shift's onSwitchIn (priority 2; cantsuppress)
        handlers += [(p, TERA_SHIFT, 2, 7, 0) for p in switchers
                     if p.base_ability_id == TERA_SHIFT]  # fmt: skip
        # 029: Neutralizing Gas's onSwitchIn (priority 2)
        handlers += [(p, NEUTRALIZING_GAS, 2, 7, 0) for p in switchers
                     if p.base_ability_id == NEUTRALIZING_GAS]  # fmt: skip
        # (041-6f: the items are collected from the held item; skipped when ignored)
        handlers += [(p, "item", SWITCH_IN_ITEMS[p.held_item], 8, 0) for p in switchers
                     if p.held_item in SWITCH_IN_ITEMS]  # fmt: skip
        handlers += [(p, "item", -2, 8, 0) for p in order if p.held_item == WHITE_HERB]
        # 028: Commander's onAnySwitchIn (-2, every holder on the field)
        handlers += [(p, COMMANDER, -2, 7, 0) for p in order if p.base_ability_id == COMMANDER]
        # 014: Eject Pack's onAnySwitchIn (-4, every holder on the field)
        handlers += [(p, "eject", -4, 8, 0) for p in order if p.held_item == EJECT_PACK]
        # 040-3b: Mirror Herb's onAnySwitchIn (-3, every holder on the field)
        handlers += [(p, MIRROR_HERB, -3, 8, 0) for p in order if p.held_item == MIRROR_HERB]
        handlers += [(p, "opportunist", -3, 7, 0) for p in order  # 043-4i
                     if p.base_ability_id == "opportunist"]  # fmt: skip
        handlers.sort(key=lambda h: (-h[2], order.index(h[0]), h[3], h[4]))
        for pokemon, kind, _, _, _ in handlers:
            if pokemon.fainted:
                continue
            if kind in HAZARDS:
                if self._hazard_switch_in(pokemon, kind):
                    return  # the battle ended
            elif kind in WISHES:
                slots = self.state.field.slot_conditions[pokemon.side]
                if pokemon.position is not None and not slots[pokemon.position].get(kind):
                    self._healing_wish_swap(pokemon, key=kind)  # singleEvent('Swap')
            elif kind == "ability":
                self._ability_start(pokemon)  # (029: does nothing while suppressed)
            elif kind == COMMANDER:
                if not pokemon.neutralized:
                    self._commander(pokemon)
            elif kind == NEUTRALIZING_GAS:
                self._gas_switch_in(pokemon)
            elif kind == TERA_SHIFT:
                if pokemon.species.base_species == "Terapagos" and (
                    pokemon.species.name != "Terapagos-Terastal"
                ):
                    self._emit("activate", target=pokemon.label, detail="ability: Tera Shift")
                    self._forme_for_good(pokemon, "Terapagos-Terastal")
            elif kind == "eject":
                self._eject_pack(pokemon)
            elif kind == MIRROR_HERB:
                self._mirror_herb(pokemon)
            elif kind == "opportunist":
                self._opportunist(pokemon)
            elif kind == "shieldsdown":
                self._shields_down(pokemon)
            elif kind == "iceface":
                if pokemon.ability_id == "iceface":
                    self._ice_face_restore(pokemon)
            elif kind == "zerotohero":
                if pokemon.species.name == "Palafin-Hero" and not pokemon.hero_shown:
                    self._emit("activate", target=pokemon.label, detail="ability: Zero to Hero")
                    pokemon.hero_shown = True
            elif kind == "imposter":
                # 043-5g: the foe in the opposite slot (foe.active[n - 1 - position])
                foes = self.state.sides[foe_of(pokemon.side)].active
                if pokemon.ability_id == "imposter" and pokemon.position is not None:
                    across = foes[len(foes) - 1 - pokemon.position]
                    if across is not None:
                        self._transform(pokemon, across)
            else:
                self._item_start(pokemon)

    def _healing_wish_swap(
        self, pokemon: BattlePokemon, *, run_event: bool = False, key: str = "healingwish"
    ) -> None:
        """025 (R6): the healingwish slot condition's onSwap (on switching in, and for both
        Pokémon of Ally Switch's swapPosition). A hurt or statused Pokémon is healed to full
        (``pokemon.heal``: no TryHeal), its status cleared silently (``clearStatus``), then
        ``-heal … [from] move: Healing Wish`` and the condition ends; otherwise it stays.
        ``run_event``: called by runEvent('Swap'), which sets effectState.target to the
        Pokémon (see ``FieldState.slot_conditions``)."""
        if pokemon.position is None:
            return
        slots = self.state.field.slot_conditions[pokemon.side][pokemon.position]
        if key not in slots:
            return
        if run_event:
            slots[key] = True
        if pokemon.fainted:
            return
        # 041-6d: Lunar Dance also checks and restores the PP
        pp = key == LUNAR_DANCE and any(m.pp < m.max_pp for m in pokemon.moves)
        if pokemon.hp < pokemon.max_hp or pokemon.status is not None or pp:
            if pokemon.hp > 0:
                pokemon.hp = pokemon.max_hp
                pokemon.status, pokemon.sleep_turns, pokemon.toxic_stage = None, 0, 0
            if key == LUNAR_DANCE:
                for slot in pokemon.moves:
                    slot.pp = slot.max_pp
            name = "healing wish" if key == HEALING_WISH else "lunar dance"
            self._emit("heal", target=pokemon.label, hp=pokemon.hp, detail=f"move: {name}")
            del slots[key]

    def _hazard_switch_in(self, pokemon: BattlePokemon, hazard: str) -> bool:
        """020: a hazard's ``onSwitchIn`` on a Pokémon that came in, then faintMessages.
        True when the battle ended."""
        side = pokemon.side
        layers = self.state.field.hazards[side].get(hazard)
        if layers is None:
            return False  # removed since the handlers were collected (state check)
        boots = pokemon.item == HEAVY_DUTY_BOOTS
        grounded = is_grounded(
            pokemon.types,
            pokemon.ability_id,
            pokemon.item,
            pokemon.pinned,
            rising="magnetrise" in pokemon.timed,
        )
        source = self.state.sides[foe_of(side)].active[0]  # pokemon.side.foe.active[0]
        if hazard == STEALTH_ROCK:
            if not boots:
                mod = max(-6, min(6, get_dex().type_mod("Rock", pokemon.types)))
                self._hazard_damage(pokemon, pokemon.max_hp * 2**mod / 8, "stealth rock")
        elif not grounded:
            return False
        elif hazard == SPIKES:
            if not boots:
                amount = SPIKES_DAMAGE[layers] * pokemon.max_hp / 24
                self._hazard_damage(pokemon, amount, "spikes")
        elif hazard == TOXIC_SPIKES:
            if "Poison" in pokemon.types:
                remove_hazard(self.state.field, side, TOXIC_SPIKES)
                self._emit("sideend", actor=side, detail=HAZARDS[TOXIC_SPIKES].name)
            elif "Steel" not in pokemon.types and not boots:
                status = "tox" if layers >= 2 else "psn"
                self._set_status(
                    pokemon, status, source or pokemon, status_move=False, from_hazard=True
                )
        elif hazard == STICKY_WEB and not boots:
            self._emit("activate", target=pokemon.label, detail="move: Sticky Web")
            apply_boosts(
                pokemon, {"spe": -1}, primary=True, foes_left=self._foes_left(pokemon),
                emit=self._emit_kw, source=source,
            )  # fmt: skip
        if pokemon.hp == 0 and not pokemon.fainted:
            self._faint_out(pokemon)
            return self._check_win(pokemon)
        return False

    def _hazard_damage(self, pokemon: BattlePokemon, amount: float, cause: str) -> None:
        """``battle.damage`` from a condition: at least 1, truncated, at most the HP left."""
        if pokemon.hp <= 0 or self._magic_guard(pokemon):
            return
        dealt = self._damage_event(pokemon, max(1, int(amount)), by_move=False)
        dealt = min(dealt, pokemon.hp)
        pokemon.hp -= dealt
        self._emit("damage", target=pokemon.label, value=dealt, hp=pokemon.hp, detail=cause)

    def _item_start(self, pokemon: BattlePokemon) -> None:
        """A held item's onStart (013)."""
        item = pokemon.item
        if item == BOOSTER_ENERGY:
            pokemon.item_started = True
            self._item_update(pokemon)
        elif item in SEEDS and self.state.field.terrain == SEEDS[item]:
            self._use_item(pokemon)
        elif item == WHITE_HERB:
            self._white_herb(pokemon)
        elif item == AIR_BALLOON:
            self._emit("item", target=pokemon.label, detail="Air Balloon")  # 032 (R4)
        elif item == ROOM_SERVICE and self.state.field.trick_room:
            self._use_item(pokemon)  # 040-2: Spe -1 (the item's boosts)
        elif item == METRONOME_ITEM and pokemon.metronome is None:
            pokemon.metronome = ("", 0)  # 042-1: addVolatile('metronome') (no restart)

    @staticmethod
    def _berry_low(pokemon: BattlePokemon) -> bool:
        """A 1/4 HP berry's check: 1/2 HP with Gluttony (032)."""
        if pokemon.hp <= pokemon.max_hp / 4:
            return True
        return pokemon.hp <= pokemon.max_hp / 2 and pokemon.ability_id == GLUTTONY

    def _lum_berry(self, pokemon: BattlePokemon) -> None:
        """032 (R5): Lum Berry's onAfterSetStatus / onUpdate: eatItem; onEat cures the status
        and ends confusion."""

        def on_eat() -> None:
            cure(pokemon, self._emit_kw)
            self._end_confusion(pokemon)

        self._eat_item(pokemon, on_eat)

    def _enigma_berry(self, pokemon: BattlePokemon) -> None:
        """040-4a: Enigma Berry's onHit: eatItem (onTryEatItem: Berserk, TryHeal), then heal
        baseMaxhp / 4."""
        if pokemon.checked_berserk is False or HEAL_BLOCK in pokemon.timed:
            return
        if self._eat_item(pokemon):
            self._heal(pokemon, pokemon.max_hp / 4, "item: enigma berry")

    def _end_confusion(self, pokemon: BattlePokemon) -> None:
        """``removeVolatile('confusion')``: confusion's onEnd."""
        if pokemon.confusion_turns:
            pokemon.confusion_turns = 0
            self._emit("end", target=pokemon.label, detail="confusion")

    def _leppa_berry(self, pokemon: BattlePokemon) -> None:
        """040-4a: Leppa Berry's onEat: the first move at 0 PP (else the first not at full PP)
        gets 10 PP back (``-activate``; the move's name is not compared)."""
        slot = next((s for s in pokemon.moves if s.pp == 0), None) or next(
            (s for s in pokemon.moves if s.pp < s.max_pp), None
        )
        if slot is None:
            return
        slot.pp = min(slot.pp + 10, slot.max_pp)
        self._emit("activate", target=pokemon.label, detail="item: Leppa Berry")

    def _item_update(self, pokemon: BattlePokemon) -> None:
        """A held item's onUpdate (013)."""
        item = pokemon.item
        if not item or pokemon.hp <= 0:
            return
        if item in HEALING_BERRIES and pokemon.checked_berserk is False:
            return  # Berserk's onTryEatItem (013; 040-4a: Oran Berry)
        if item in HEALING_BERRIES and HEAL_BLOCK in pokemon.timed:
            return  # 023: the berry's onTryEatItem runs TryHeal
        if item == LUM_BERRY and (pokemon.status or pokemon.confusion_turns):
            self._lum_berry(pokemon)
        elif item in STATUS_BERRIES and pokemon.status in STATUS_BERRIES[item]:
            self._eat_item(pokemon, lambda: cure(pokemon, self._emit_kw))  # 040-4a
        elif item == PERSIM_BERRY and pokemon.confusion_turns:
            self._eat_item(pokemon, lambda: self._end_confusion(pokemon))  # 040-4a
        elif item == ORAN_BERRY and pokemon.hp <= pokemon.max_hp / 2:
            self._eat_item(pokemon, lambda: self._heal(pokemon, 10, "item: oran berry"))
        elif item == LEPPA_BERRY and any(s.pp == 0 for s in pokemon.moves):
            self._eat_item(pokemon, lambda: self._leppa_berry(pokemon))  # 040-4a
        elif item == SITRUS_BERRY and pokemon.hp <= pokemon.max_hp / 2:
            self._eat_item(pokemon, lambda: self._heal(pokemon, pokemon.max_hp / 4,
                                                       "item: sitrus berry"))  # fmt: skip
        elif item in PINCH_BERRIES and self._berry_low(pokemon):
            self._eat_item(pokemon, lambda: self._pinch_berry(pokemon, item))
        elif item == LANSAT_BERRY and self._berry_low(pokemon):
            self._eat_item(pokemon, lambda: add_volatile(
                pokemon, "focusenergy", prng=self.prng, emit=self._emit_kw,
                terrain=self.state.field.terrain,
            ))  # fmt: skip
        elif item == STARF_BERRY and self._berry_low(pokemon):
            self._eat_item(pokemon, lambda: self._starf_berry(pokemon))
        elif item in STAT_PINCH_BERRIES and self._berry_low(pokemon):
            # 040-2: onEat: this.boost({stat: 1})
            stat = STAT_PINCH_BERRIES[item]
            self._eat_item(pokemon, lambda: apply_boosts(
                pokemon, {stat: 1}, primary=True, foes_left=self._foes_left(pokemon),
                emit=self._emit_kw, source=pokemon,
            ))  # fmt: skip
        elif item == MENTAL_HERB and (
            any(v in pokemon.timed for v in MENTAL_HERB_CURES)
            or pokemon.attract_source is not None
            or pokemon.torment
        ):
            # 015: useItem, then removeVolatile of each condition it cures (in its list order;
            # 023: disable, healblock)
            first_attract = pokemon.attract_source is not None
            if self._use_item(pokemon):
                # 041-6f: attract (its own -end after its onEnd's), taunt, encore, torment,
                # disable, healblock
                if pokemon.attract_source is not None:
                    self._end_attract(pokemon)
                if first_attract:
                    self._emit("end", target=pokemon.label, detail="move: Attract")
                for volatile in MENTAL_HERB_CURES:
                    if volatile == DISABLE and pokemon.torment:
                        pokemon.torment = False  # (torment comes before disable)
                        self._emit("end", target=pokemon.label, detail="Torment")
                    self._end_move_lock(pokemon, volatile)
        elif item == BOOSTER_ENERGY and pokemon.item_started:
            ability = pokemon.ability_id
            field_state = self.state.field
            if (
                ability in BOOSTERS
                and not booster_active(ability, field_state.active_weather, field_state.terrain)
                and self._use_item(pokemon)
            ):
                self._start_booster(pokemon, from_item=True)

    def _rest(self, user: BattlePokemon) -> None:
        """041-3d: Rest. onTry: false while asleep (-fail); null at full HP (``-fail … heal``)
        and with Insomnia / Vital Spirit. onHit: setStatus('slp') replaces another status (a
        failure keeps it); sleep's onStart draws its time, then Rest sets it to 3; then a full
        heal (``[silent]``)."""
        if _asleep(user):  # (043-3c: or Comatose)
            self._emit("fail", actor=user.label)
            return
        if user.hp >= user.max_hp:
            self._emit("fail", actor=user.label, detail="heal")
            return
        if user.ability_id in ("insomnia", "vitalspirit"):
            self._emit("fail", actor=user.label)
            return
        previous, previous_stage = user.status, user.toxic_stage
        user.status = None
        # (041-6d: Rest has no move.status: Misty Terrain blocks it without -activate)
        applied = self._set_status(user, "slp", user, status_move=True, rest=True)
        if not applied:
            user.status, user.toxic_stage = previous, previous_stage
            if applied is False:  # (041-6f: Uproar's / Sweet Veil's null adds none)
                self._emit("fail", actor=user.label)  # onHit's false: the move failed
            return
        user.sleep_turns = 3
        self._heal(user, user.max_hp, "")
        self._move_succeeded = True
        self._update()  # hitStepMoveHitLoop: eachEvent('Update')
        self._update()  # eachEvent('Update') after faint messages

    def _steal_berry(self, user: BattlePokemon, target: BattlePokemon, move: Move) -> None:
        """041-3c: Bug Bite / Pluck's onHit: a user with HP takes the target's berry
        (takeItem: Unburden), ``-enditem … [from] stealeat`` on the target, then the berry's
        onEat on the user. Incinerate's: a berry (gems are unsupported) is burnt up."""
        item = target.held_item
        dex_item = get_dex().item(item) if item else None
        if dex_item is None or not dex_item.is_berry:
            return
        if move.id != "incinerate" and user.hp <= 0:
            return
        if not can_be_taken(item, target.species, user.species):
            return
        if self._sticky_hold(target, user):
            return
        self._lose_item(target, unburden=True)
        self._emit("enditem", target=target.label, detail=item_name(item))
        if move.id != "incinerate":
            self._berry_on_eat(user, item)
            self._eat_item_event(user, item, stolen=True)  # (043-4f: runEvent('EatItem'))
            # 041-4e; 042-1: ``if (item.onEat) source.ateBerry = true``
            user.ate_berry = user.ate_berry or item not in NO_EAT_BERRIES

    def _berry_on_eat(self, pokemon: BattlePokemon, item: str) -> None:
        """041-3c: a berry's onEat on ``pokemon`` (singleEvent('Eat'), with no condition of
        its own; the berries with an empty onEat do nothing)."""
        if item == LUM_BERRY:
            cure(pokemon, self._emit_kw)
            self._end_confusion(pokemon)
        elif item in STATUS_BERRIES:
            if pokemon.status in STATUS_BERRIES[item]:
                cure(pokemon, self._emit_kw)
        elif item == PERSIM_BERRY:
            self._end_confusion(pokemon)
        elif item == ORAN_BERRY:
            self._heal(pokemon, 10, "item: oran berry")
        elif item == LEPPA_BERRY:
            self._leppa_berry(pokemon)
        elif item == SITRUS_BERRY:
            self._heal(pokemon, pokemon.max_hp / 4, "item: sitrus berry")
        elif item in PINCH_BERRIES:
            self._pinch_berry(pokemon, item)
        elif item == LANSAT_BERRY:
            add_volatile(
                pokemon, "focusenergy", prng=self.prng, emit=self._emit_kw,
                terrain=self.state.field.terrain,
            )  # fmt: skip
        elif item == STARF_BERRY:
            self._starf_berry(pokemon)
        elif item in STAT_PINCH_BERRIES:
            self._berry_boost(pokemon, STAT_PINCH_BERRIES[item])
        elif item == MICLE_BERRY:
            pokemon.timed[MICLE_BERRY] = 2
        elif item in HIT_BERRIES:
            self._berry_boost(pokemon, HIT_BERRIES[item][1])

    def _berry_boost(self, pokemon: BattlePokemon, stat: str) -> None:
        """040-2: a berry's onEat ``this.boost({stat: 1})`` (043-4h: Ripen doubles it)."""
        apply_boosts(
            pokemon, {stat: 2 if pokemon.ability_id == "ripen" else 1}, primary=True,
            foes_left=self._foes_left(pokemon),
            emit=self._emit_kw, source=pokemon,
        )  # fmt: skip

    def _starf_berry(self, pokemon: BattlePokemon) -> None:
        """040-2: Starf Berry's onEat: a random stat below +6 (not accuracy or evasion) +2."""
        stats = [s for s in ("atk", "def", "spa", "spd", "spe") if pokemon.boosts[s] < 6]
        if stats:
            stat = self.prng.sample(stats)
            apply_boosts(
                pokemon, {stat: 4 if pokemon.ability_id == "ripen" else 2}, primary=True,
                foes_left=self._foes_left(pokemon),
                emit=self._emit_kw, source=pokemon,
            )  # fmt: skip

    def _pinch_berry(self, pokemon: BattlePokemon, item: str) -> None:
        self._heal(pokemon, pokemon.max_hp / 3, f"item: {item_name(item).lower()}")
        if pokemon.nature_minus == PINCH_BERRIES[item]:
            add_volatile(
                pokemon, "confusion", prng=self.prng, emit=self._emit_kw,
                terrain=self.state.field.terrain,
            )  # fmt: skip

    def _ability_start(self, pokemon: BattlePokemon) -> None:
        """An ability's ``onStart``."""
        ability = pokemon.ability_id
        field_state = self.state.field
        if ability == INTIMIDATE:
            # side.foes() picks by HP: a foe at 0 HP waiting to faint (029: the gas ending in
            # faintMessages restarts Intimidate) is left out
            foes = [p for p in self.state.sides[foe_of(pokemon.side)].alive_active() if p.hp > 0]
            if foes:
                self._emit("ability", target=pokemon.label, detail="Intimidate")
            for foe in foes:
                if foe.substitute_hp:
                    self._emit("immune", target=foe.label)  # 016 (research R3)
                    continue
                at_floor = foe.boosts["atk"] == -6
                boosted = foe.hp > 0 and foe.position is not None and self._foes_left(foe)
                apply_boosts(
                    foe, {"atk": -1}, primary=False, foes_left=self._foes_left(foe),
                    emit=self._emit_kw, source=pokemon, ability="Intimidate",
                )  # fmt: skip
                # 040-4b: Adrenaline Orb's onAfterBoost: not at Spe +6, not boost.atk === 0 (a
                # stage at -6 stays 0; one a handler removed is undefined and still counts)
                orb = boosted and foe.item == ADRENALINE_ORB and not at_floor
                if orb and foe.boosts["spe"] != 6:
                    self._use_item(foe)
        elif ability in WEATHER_SETTERS:
            weather = WEATHER_SETTERS[ability]
            duration = _weather_duration(pokemon, weather)
            if set_weather(field_state, weather, emit=self._emit_kw, duration=duration):
                self._weather_change()
        elif ability == ORICHALCUM_PULSE:  # 043-1
            duration = _weather_duration(pokemon, SUN)
            if set_weather(field_state, SUN, emit=self._emit_kw, duration=duration):
                self._emit("activate", target=pokemon.label, detail="Orichalcum Pulse")
                self._weather_change()
            elif field_state.active_weather == SUN:
                self._emit("activate", target=pokemon.label, detail="ability: Orichalcum Pulse")
        elif ability == HADRON_ENGINE:  # 043-1
            duration = 8 if pokemon.item == TERRAIN_EXTENDER else None
            if set_terrain(field_state, ELECTRIC, emit=self._emit_kw, duration=duration):
                self._terrain_change()
            elif field_state.terrain == ELECTRIC:
                self._emit("activate", target=pokemon.label, detail="ability: Hadron Engine")
        elif ability in UNNERVERS:  # 043-1: onStart (once: effectState.unnerved)
            if not pokemon.unnerved:
                if ability != "unnerve":
                    self._emit("ability", target=pokemon.label, detail="As One")
                self._emit("ability", target=pokemon.label, detail="Unnerve")
                pokemon.unnerved = True
        elif ability == "costar":  # 043-1: onStart (-2)
            self._costar(pokemon)
        elif ability == SUPREME_OVERLORD:  # 043-1
            fainted = self.state.sides[pokemon.side].total_fainted
            if fainted:
                self._emit("activate", target=pokemon.label, detail="ability: Supreme Overlord")
                pokemon.fallen = min(fainted, 5)
                self._emit("start", target=pokemon.label, detail=f"fallen{pokemon.fallen}")
        elif ability in TERRAIN_SETTERS:
            duration = 8 if pokemon.item == TERRAIN_EXTENDER else None  # (040-4b)
            terrain = TERRAIN_SETTERS[ability]
            if set_terrain(field_state, terrain, emit=self._emit_kw, duration=duration):
                self._terrain_change()
        elif ability in RUIN:
            # 029: suppressingAbility (the gas leaving during a Mold Breaker's move)
            ignoring = self._ignoring_user
            if ignoring is None or ignoring is pokemon or pokemon.item == ABILITY_SHIELD:
                self._emit("ability", target=pokemon.label, detail=RUIN_NAMES[ability])
        elif ability == TRACE:
            # 031 (R6): onStart. A foe with No Ability, or the holder's Ability Shield, stops
            # the seeking; otherwise singleEvent('Update') (then every Update while seeking)
            foes = [p for p in self.state.sides[foe_of(pokemon.side)].alive_active() if p.hp > 0]
            pokemon.trace_seeking = all(f.base_ability_id != NO_ABILITY for f in foes)
            if pokemon.item == ABILITY_SHIELD:
                self._emit("block", target=pokemon.label, detail="item: Ability Shield")
                pokemon.trace_seeking = False
            if pokemon.trace_seeking:
                self._trace(pokemon)
        elif ability == DOWNLOAD:
            # pokemon.foes() picks by HP (029: as Intimidate)
            foes = [p for p in self.state.sides[foe_of(pokemon.side)].alive_active() if p.hp > 0]
            wonder = WONDER_ROOM in self.state.field.pseudo_weather  # 041-6f: getStat(…, true)
            stat = download_stat([(f.stats, wonder_swapped(f.boosts, wonder)) for f in foes])
            if stat is not None:
                apply_boosts(
                    pokemon, {stat: 1}, primary=False, foes_left=self._foes_left(pokemon),
                    emit=self._emit_kw, source=pokemon, ability="Download",
                )  # fmt: skip
        elif ability == HOSPITALITY:
            for ally in self.state.sides[pokemon.side].alive_active():
                if ally is pokemon or HEAL_BLOCK in ally.timed:  # 023: healblock onTryHeal
                    continue
                if ally.hp <= 0:  # 029: adjacentAllies picks by HP (as Intimidate)
                    continue
                healed = min(max(1, ally.max_hp // 4), ally.max_hp - ally.hp)
                if healed > 0:
                    ally.hp += healed
                    self._emit("heal", target=ally.label, value=healed, hp=ally.hp,
                               detail="ability: hospitality")  # fmt: skip
        elif ability in BOOSTERS:
            self._update_booster(pokemon)
        elif ability in MOLD_BREAKERS:
            self._emit("ability", target=pokemon.label, detail=MOLD_BREAKERS[ability])
        elif ability == "windrider":  # 043-4d: onStart with Tailwind on its side
            if TAILWIND in field_state.sides[pokemon.side]:
                apply_boosts(
                    pokemon, {"atk": 1}, primary=False, foes_left=self._foes_left(pokemon),
                    emit=self._emit_kw, source=pokemon, ability="Wind Rider",
                )  # fmt: skip
        elif ability == "supersweetsyrup" and not pokemon.syrup_triggered:
            pokemon.syrup_triggered = True  # 043-4e: once per battle
            self._emit("ability", target=pokemon.label, detail="Supersweet Syrup")
            for foe in self.state.sides[foe_of(pokemon.side)].alive_active():
                if foe.substitute_hp:
                    self._emit("immune", target=foe.label)
                else:
                    apply_boosts(
                        foe, {"evasion": -1}, primary=False, foes_left=self._foes_left(foe),
                        emit=self._emit_kw, source=pokemon, ability="Supersweet Syrup",
                    )  # fmt: skip
        elif ability == "curiousmedicine":  # 043-4e: onStart (adjacent allies)
            for ally in self.state.sides[pokemon.side].alive_active():
                if ally is not pokemon and ally.hp > 0:
                    ally.reset_boosts()
                    self._emit("clearboost", target=ally.label)
        elif ability in ("cloudnine", "airlock"):
            # 043-4g: onSwitchIn's -ability, then onStart: eachEvent('WeatherChange')
            self._emit("ability", target=pokemon.label, detail=_WEATHER_LOCKS[ability])
            self._sync_weather_suppression()
            self._weather_change(suppressing=True)
        elif ability == "truant":  # 043-5c: onStart (moveThisTurnResult set: it has acted,
            # so it will not move again)
            pokemon.truant = bool(pokemon.active_turns) and not self._will_move(pokemon)
        elif ability == "frisk":  # 043-5a: onStart: each foe's item
            for foe in self.state.sides[foe_of(pokemon.side)].alive_active():
                if foe.held_item:
                    self._emit("item", target=foe.label, detail=item_name(foe.held_item))
        elif ability == "anticipation":  # 043-5a: onStart
            if self._anticipates(pokemon):
                self._emit("ability", target=pokemon.label, detail="Anticipation")
        elif ability == "forewarn":  # 043-5a: onStart (sample among the strongest)
            self._forewarn(pokemon)
        elif ability == COMATOSE:  # 043-3c: onStart
            self._emit("ability", target=pokemon.label, detail="Comatose")
        elif ability == PRESSURE:  # 033 (R14)
            self._emit("ability", target=pokemon.label, detail="Pressure")
        elif ability == SLOW_START:  # 033 (R12)
            self._emit("start", target=pokemon.label, detail="ability: Slow Start")
            pokemon.slow_start = 5
        elif ability == COMMANDER:
            self._commander(pokemon)
        elif ability in ("intrepidsword", "dauntlessshield"):
            # 042-2: once a battle (pokemon.swordBoost / shieldBoost)
            stat = "atk" if ability == "intrepidsword" else "def"
            if stat not in pokemon.once_boosted:
                pokemon.once_boosted.add(stat)
                apply_boosts(
                    pokemon, {stat: 1}, primary=False, foes_left=self._foes_left(pokemon),
                    emit=self._emit_kw, source=pokemon,
                    ability=get_dex().ability(ability).name,  # type: ignore[union-attr]
                )  # fmt: skip
        elif ability in EMBODY_ASPECT:
            # 017: only the terastallized forme (its effectState is new on each switch-in);
            # 029: once (embodied), though the gas leaving starts it again
            if (
                pokemon.terastallized is not None
                and pokemon.species.name.endswith("-Tera")
                and not pokemon.embodied
            ):
                pokemon.embodied = True
                apply_boosts(
                    pokemon, {EMBODY_ASPECT[ability]: 1}, primary=False,
                    foes_left=self._foes_left(pokemon), emit=self._emit_kw, source=pokemon,
                    ability=get_dex().ability(ability).name,  # type: ignore[union-attr]
                )  # fmt: skip

    def _gas_switch_in(self, pokemon: BattlePokemon) -> None:
        """029 (R3): Neutralizing Gas's onSwitchIn. The other abilities are already suppressed
        (from when it came onto the field); Illusion, Slow Start and the strong weathers it ends
        are not supported. Each Pokémon on the field (the holder too) with an Ability Shield
        shows ``-block``."""
        self._emit("ability", target=pokemon.label, detail="Neutralizing Gas")
        pokemon.gas_ending = False
        for target in self.state.all_active():
            if target.item == ABILITY_SHIELD:
                self._emit("block", target=target.label, detail="item: Ability Shield")
            elif target.illusion is not None and not target.commanding:
                self._illusion_end(target)  # 034 (R6)

    def _gas_end(self, source: BattlePokemon, speed: int) -> None:
        """029 (R4): Neutralizing Gas's onEnd, while ``source`` is still on the field (before
        a replacement comes in). Nothing while another Pokémon on the field has the gas;
        otherwise ``-end``, then (once: abilityState.ending) the Start of every other ability
        on the field, in a speedSort of the field's Pokémon that includes ``source`` (a fainting
        one at its speed before faintMessages)."""
        others = self.state.all_active()
        if any(p is not source and p.base_ability_id == NEUTRALIZING_GAS for p in others):
            return
        self._emit("end", target=source.label, detail="ability: Neutralizing Gas")
        if source.gas_ending:
            return
        source.gas_ending = True
        # getAllActive: the Pokémon whose fainted flag is not set yet, in position order (the
        # source is one of them in Showdown, whose faintMessages sets it after the End)
        actives = [
            p for s in SIDE_IDS for p in self.state.sides[s].active
            if p is not None and (not p.fainted or p is source)
        ]  # fmt: skip
        saved, source.cached_speed = source.cached_speed, speed
        try:
            speed_sort(actives, self.prng, _by_speed)
        finally:
            source.cached_speed = saved
        outer, self._gas_fainting = self._gas_fainting, (source, speed) if source.fainted else None
        try:
            for pokemon in actives:
                if pokemon is not source and pokemon.item != ABILITY_SHIELD:
                    self._ability_start(pokemon)
        finally:
            self._gas_fainting = outer

    def _update_booster(self, pokemon: BattlePokemon) -> None:
        """Protosynthesis ``onWeatherChange`` / Quark Drive ``onTerrainChange``."""
        if pokemon.hp <= 0:
            return  # add/removeVolatile do nothing at 0 HP (015: KO'd by Ice Spinner)
        ability = pokemon.ability_id
        name = BOOSTERS[ability]
        field_state = self.state.field
        if booster_active(ability, field_state.active_weather, field_state.terrain):
            if pokemon.booster_stat is None:  # addVolatile (fails silently when it has it)
                self._start_booster(pokemon, from_item=False)
        elif pokemon.booster_stat is not None and not pokemon.booster_from_item:
            pokemon.booster_stat = None
            self._emit("end", target=pokemon.label, detail=name)

    def _start_booster(self, pokemon: BattlePokemon, *, from_item: bool) -> None:
        """The protosynthesis / quarkdrive volatile's onStart (``[fromitem]`` from Booster
        Energy, which keeps it when the sun or the terrain ends)."""
        ability = pokemon.ability_id
        pokemon.booster_stat = best_stat(
            pokemon.stats,
            wonder_swapped(pokemon.boosts, WONDER_ROOM in self.state.field.pseudo_weather),
        )
        pokemon.booster_from_item = from_item
        self._emit("activate", target=pokemon.label, detail=f"ability: {BOOSTERS[ability]}")
        self._emit("start", target=pokemon.label, detail=ability + pokemon.booster_stat)

    def _sync_weather_suppression(self, leaving: BattlePokemon | None = None) -> bool:
        """043-4g: ``suppressingWeather()``: an active, not fainted Cloud Nine / Air Lock
        holder not ignoring its ability (the gas, Gastro Acid; not Mold Breaker) whose End
        has not begun (``leaving``). True when it changed."""
        suppressed = any(
            p is not leaving and not p.fainted and _suppresses_weather(p)
            for p in self.state.all_active()
        )  # fmt: skip
        changed = suppressed != self.state.field.weather_suppressed
        self.state.field.weather_suppressed = suppressed
        return changed

    def _weather_change(self, *, suppressing: bool = False) -> None:
        """``eachEvent('WeatherChange')``: Protosynthesis, in speed order. 043-6e: Ice Face
        (not when the effect is Cloud Nine / Air Lock: ``suppressing``)."""
        for pokemon in self._sort_active_by_speed():
            if pokemon.ability_id == "protosynthesis":
                self._update_booster(pokemon)
            elif pokemon.ability_id == "iceface" and not suppressing and pokemon.hp > 0:
                self._ice_face_restore(pokemon)

    def _ice_face_restore(self, pokemon: BattlePokemon) -> None:
        """043-6e: Ice Face's onStart / onWeatherChange: Eiscue-Noice in the snow becomes
        Eiscue for good (``-activate`` first)."""
        if self.state.field.active_weather == SNOW and pokemon.species.name == "Eiscue-Noice":
            self._emit("activate", target=pokemon.label, detail="ability: Ice Face")
            pokemon.disguise_busted = False
            self._forme_for_good(pokemon, "Eiscue")

    def _pseudo_weather_change(self) -> None:
        """040-2: ``runEvent('PseudoWeatherChange')``: Room Service's onAnyPseudoWeatherChange,
        its holders speed-sorted (ties shuffled)."""
        holders = [p for p in self.state.all_active() if p.held_item == ROOM_SERVICE and p.hp > 0]
        speed_sort(holders, self.prng, _by_speed)
        for pokemon in holders:
            if self.state.field.trick_room and pokemon.item == ROOM_SERVICE:
                self._use_item(pokemon)

    def _terrain_change(self) -> None:
        """``eachEvent('TerrainChange')``: Quark Drive, in speed order."""
        for pokemon in self._sort_active_by_speed():
            if pokemon.ability_id == "quarkdrive":
                self._update_booster(pokemon)
            seed = SEEDS.get(pokemon.item)
            if seed is not None and self.state.field.terrain == seed:
                self._use_item(pokemon)  # the seed's onTerrainChange (013)

    def _ability_end(
        self, pokemon: BattlePokemon, speed: int | None = None, *, called_back: bool = False
    ) -> None:
        """The ability's ``End`` (switching out or fainting): Protosynthesis and Quark Drive
        always print ``-end ... [silent]``. ``speed``: a fainting Pokémon's ``pokemon.speed``
        before faintMessages (029: the speedSort of Neutralizing Gas's End)."""
        if _suppresses_weather(pokemon):
            # 043-4g: onEnd (abilityState.ending): eachEvent('WeatherChange'), always; a fainting
            # holder is still sorted with the rest (its fainted flag comes later)
            self._sync_weather_suppression(leaving=pokemon)
            fainting = (pokemon, speed) if pokemon.fainted and speed is not None else None
            outer, self._gas_fainting = self._gas_fainting, fainting or self._gas_fainting
            try:
                self._weather_change(suppressing=True)
            finally:
                self._gas_fainting = outer
        if pokemon.illusion is not None and not called_back:
            # 034 (T011): Illusion's onEnd, still disguised (its onFaint was suppressed by
            # Neutralizing Gas): replace, -end after the faint line
            self._illusion_end(pokemon)
        if pokemon.base_ability_id == NEUTRALIZING_GAS:
            self._gas_end(pokemon, pokemon.cached_speed if speed is None else speed)
        name = BOOSTERS.get(pokemon.base_ability_id)  # (029: End is never suppressed)
        if name is not None:
            pokemon.booster_stat = None
            self._emit("end", target=pokemon.label, detail=name)
        if pokemon.flash_fire:  # Flash Fire onEnd: removeVolatile (012)
            pokemon.flash_fire = False
            self._emit("end", target=pokemon.label, detail="ability: Flash Fire")
        if pokemon.base_ability_id == SUPREME_OVERLORD:  # 043-1: onEnd (-end ... [silent])
            self._emit("end", target=pokemon.label, detail=f"fallen{pokemon.fallen or 'undefined'}")
        pokemon.fallen = 0  # (the next switch-in's abilityState)
        pokemon.unnerved = False  # 043-1: Unnerve / As One's onEnd
        pokemon.cud_chew = None  # 043-4h: abilityState
        pokemon.protean_used = False  # 043-5c: effectState.protean
        pokemon.truant = False  # 043-5c: the truant volatile
        pokemon.opportunist.clear()  # 043-4i: onEnd
        if pokemon.base_ability_id == UNBURDEN:  # 027: Unburden onEnd (no message)
            pokemon.unburden = False
        if pokemon.base_ability_id == SLOW_START and not called_back:
            self._emit("end", target=pokemon.label, detail="Slow Start")  # 033: [silent]
        # 033: abilityState is new on the next switch-in (no counter until onStart)
        pokemon.slow_start = 0

    def _switch_out(self, pokemon: BattlePokemon) -> None:
        """``runEvent('SwitchOut')`` (Regenerator), then the ability's End."""
        if pokemon.ability_id == REGENERATOR and pokemon.hp > 0:
            pokemon.hp = min(pokemon.max_hp, pokemon.hp + pokemon.max_hp // 3)  # no message
        if pokemon.ability_id == NATURAL_CURE and pokemon.status:  # 043-1: onSwitchOut
            if pokemon.show_cure is None:
                pokemon.show_cure = True
            if pokemon.show_cure:
                self._emit("curestatus", target=pokemon.label, detail=pokemon.status)
            pokemon.status = None  # clearStatus
            pokemon.sleep_turns = 0
            if not pokemon.show_cure:
                pokemon.show_cure = None
        if (  # 043-6b: Zero to Hero's onSwitchOut (cantsuppress)
            pokemon.base_ability_id == "zerotohero"
            and pokemon.transform_base is None
            and pokemon.species.base_species == "Palafin"
            and pokemon.species.name != "Palafin-Hero"
        ):
            self._forme_for_good(pokemon, "Palafin-Hero")
            pokemon.hero_shown = False
        self._ability_end(pokemon, called_back=True)

    def _faint_out(self, pokemon: BattlePokemon) -> None:
        """faintMessages for one Pokémon: ``faint``, then its ability's End."""
        speed = pokemon.cached_speed  # (029: clearVolatile resets it only after the End)
        illusion_on = pokemon.ability_id == ILLUSION  # (before the fainted flag)
        bonded = pokemon.destiny_bond
        _faint(pokemon)
        if illusion_on:
            pokemon.illusion = None  # 034: Illusion's onFaint (runEvent: not under the gas)
        self._emit("faint", target=pokemon.label)
        side = self.state.sides[pokemon.side]
        side.total_fainted = min(100, side.total_fainted + 1)  # 023
        side.fainted_this_turn = True  # 041-1e
        source, pokemon.faint_source = pokemon.faint_source, None
        self._last_faint_source = source  # 043-1 (AfterFaint: faintData.source of a move)
        self._soul_heart()
        self._receiver(pokemon, speed)
        if bonded and source is not None and source.side != pokemon.side:
            # 041-4e: destinybond's onFaint: -activate, then source.faint() (queued)
            self._emit("activate", target=pokemon.label, detail="move: Destiny Bond")
            if source.hp > 0 and not source.fainted:
                source.hp = 0  # (faintMessages: the queue grew, so checkWin = true)
        self._ability_end(pokemon, speed)
        # 017: faintMessages deletes pokemon.terastallized; a forme changed for good by
        # Terastallization (formeRegression: Ogerpon) goes back to the set's species, with a
        # silent detailschange shown without a position (no longer active)
        pokemon.terastallized = None
        if pokemon.species.battle_only is not None and tera_forme(pokemon.species) is not None:
            original = get_dex().species(pokemon.species.battle_only)
            assert original is not None
            pokemon.species = original
            pokemon.base_types = original.types
            pokemon.added_type = None  # (041-6f: setSpecies)
            pokemon.own_ability = pokemon.set_ability  # 027: baseAbility = set.ability
            self._emit("detailschange", target=pokemon.side, detail=original.name)
        if pokemon.species.name == "Terapagos-Stellar":
            # 042-6: formeRegression: baseSpecies = the set's species, baseAbility the set's
            assert pokemon.pokemon_set is not None
            original = get_dex().species(pokemon.pokemon_set.species)
            assert original is not None
            pokemon.set_species(original)
            pokemon.own_ability = pokemon.set_ability
            self._emit("detailschange", target=pokemon.side, detail=original.name)
            pokemon.update_max_hp()
        if pokemon.hangry_base:
            pokemon.hangry_base = False  # 042-3: formeRegression (Morpeko-Hangry)
            morpeko = get_dex().species("Morpeko")
            assert morpeko is not None
            pokemon.species = morpeko
            self._emit("detailschange", target=pokemon.side, detail=morpeko.name)
        pokemon.ability = pokemon.own_ability  # 027: clearVolatile, after the End

    def _ruin_abilities(self) -> frozenset[str]:
        """The Ruin abilities of the Pokémon on the field (``onAny`` handlers)."""
        return frozenset(p.ability_id for p in self.state.all_active() if p.ability_id in RUIN)

    def _ruin_speeds(self) -> dict[str, list[int]]:
        """018: the speeds of each Ruin ability's holders on the field (their ``onAny``
        handlers, sorted by speed in the stat events). 029: a suppressed holder's handler is
        still collected and sorted (runEvent skips it only when it runs)."""
        speeds: dict[str, list[int]] = {}
        for p in self.state.all_active():
            if p.base_ability_id in RUIN:
                speeds.setdefault(p.base_ability_id, []).append(p.cached_speed)
        return speeds

    def _unnerved(self, pokemon: BattlePokemon) -> bool:
        """043-1: runEvent('TryEatItem'): a foe's Unnerve / As One (not suppressed) that
        started (effectState.unnerved)."""
        foes = self.state.sides[foe_of(pokemon.side)].alive_active()
        return any(f.ability_id in UNNERVERS and f.unnerved and f.hp > 0 for f in foes)

    def _costar(self, pokemon: BattlePokemon) -> None:
        """043-1: Costar's onStart: the first ally's stages and its Focus Energy / Dragon
        Cheer (-copyboost; nothing without an ally)."""
        allies = [p for p in self.state.sides[pokemon.side].alive_active() if p is not pokemon]
        if not allies:
            return
        self._psych_up(pokemon, allies[0])  # the same copy as Psych Up's

    def _after_faint(self, count: int, last: BattlePokemon, source: BattlePokemon | None) -> None:
        """043-1: runEvent('AfterFaint', the last fainted, its source, its effect, the queue's
        length): the source's Chilling Neigh / Grim Neigh / As One raise a stat by that many
        when the effect was a move (``source`` is None otherwise)."""
        if source is None or source.hp <= 0 or source.position is None:
            return
        if (  # 043-6c: Battle Bond's onSourceAfterFaint (once per battle)
            source.ability_id == "battlebond"
            and not source.bond_triggered
            and source.species.name == "Greninja-Bond"
            and source.transform_base is None
            and self._foes_left(source)
        ):
            apply_boosts(
                source, {"atk": 1, "spa": 1, "spe": 1}, primary=False,
                foes_left=self._foes_left(source), emit=self._emit_kw, source=source,
                ability="Battle Bond",
            )  # fmt: skip
            self._emit("activate", target=source.label, detail="ability: Battle Bond")
            source.bond_triggered = True
            return
        boost = AFTER_FAINT_BOOSTS.get(source.ability_id)
        if boost is None:
            return
        stat, name = boost
        apply_boosts(
            source, {stat: count}, primary=False, foes_left=self._foes_left(source),
            emit=self._emit_kw, source=source, ability=name,
        )  # fmt: skip

    def _soul_heart(self) -> None:
        """043-4e: Soul-Heart's onAnyFaint (priority 1, before Receiver's): SpA +1."""
        holders = [p for p in self.state.all_active() if p.ability_id == "soulheart" and p.hp > 0]
        speed_sort(holders, self.prng, _by_speed)
        for p in holders:
            apply_boosts(
                p, {"spa": 1}, primary=False, foes_left=self._foes_left(p),
                emit=self._emit_kw, source=p, ability="Soul-Heart",
            )  # fmt: skip

    def _receiver(self, fainted: BattlePokemon, speed: int) -> None:
        """043-1: an ally's Receiver / Power of Alchemy (onAllyFaint): it takes the fainted
        Pokemon's ability (getAbility; not a noreceiver one) with setAbility. The fainted one is
        still among the active Pokemon of an eachEvent (its fainted flag comes later)."""
        ability = fainted.base_ability_id
        if ability in NO_RECEIVER:
            return
        for holder in self.state.sides[fainted.side].active:
            if holder is None or holder is fainted or holder.hp <= 0:
                continue
            if holder.ability_id in RECEIVERS:
                outer, self._gas_fainting = self._gas_fainting, (fainted, speed)
                try:
                    self._set_ability(holder, ability, fainted, None)
                finally:
                    self._gas_fainting = outer

    def _ally_abilities(self, pokemon: BattlePokemon) -> frozenset[str]:
        """043-1: the abilities of ``pokemon``'s allies on the field (``pokemon.allies()``:
        not fainted; a suppressed one is left out, as hasAbility)."""
        return frozenset(
            p.ability_id for p in self.state.sides[pokemon.side].alive_active()
            if p is not pokemon and p.ability_id
        )  # fmt: skip

    def _attack_handlers(
        self, user: BattlePokemon, target: BattlePokemon, move: Move
    ) -> list[tuple[int, int]]:
        """030: (priority, speed) of the ability handlers of ``runEvent('ModifyAtk'/'SpA')``
        besides Ruin's: the user's own, then the target's onSource ones. They are collected
        (and sorted) whether they apply or not, also while Mold Breaker or the gas suppresses
        them (029)."""
        stat = "atk" if move.category == "Physical" else "spa"
        handlers = []
        own = MODIFY_ATTACK_PRIORITY.get(user.base_ability_id, {}).get(stat)
        if own is not None:
            handlers.append((own, user.cached_speed))
        source = SOURCE_MODIFY_ATTACK_PRIORITY.get(target.base_ability_id, {}).get(stat)
        if source is not None:
            handlers.append((source, target.cached_speed))
        return handlers

    def _priority_blocked(
        self, user: BattlePokemon, move: Move, targets: list[BattlePokemon]
    ) -> bool:
        """``runEvent('TryMove')``: a foe's Armor Tail / Queenly Majesty / Dazzling."""
        actives = [p for s in SIDE_IDS for p in self.state.sides[s].alive_active()]
        for holder in sorted(actives, key=lambda p: -p.cached_speed):
            name = PRIORITY_BLOCKERS.get(holder.ability_id)
            if name is None or holder.side == user.side:
                continue
            on_side = targets[-1].side == holder.side
            if blocks_priority_move(move, last_target_on_holder_side=on_side):
                self._emit("cant", actor=holder.label, detail=f"ability: {name}")
                return True
        return False

    def _damp(self, user: BattlePokemon) -> bool:
        """043-3b: Damp's onAnyTryMove (`cant … ability: Damp`), the fastest holder."""
        holders = [
            p for s in SIDE_IDS for p in self.state.sides[s].alive_active() if p.ability_id == DAMP
        ]
        if not holders:
            return False
        holder = max(holders, key=lambda p: p.cached_speed)
        self._emit("cant", actor=holder.label, detail="ability: Damp")
        return True

    def _damp_on_field(self) -> bool:
        """043-3b: Damp's onAnyDamage false for Aftermath."""
        return any(
            p.ability_id == DAMP for s in SIDE_IDS for p in self.state.sides[s].alive_active()
        )

    def _modify_boost(self, pokemon: BattlePokemon) -> None:
        """028 (R5): ``runEvent('ModifyBoost', pokemon)`` (getStat, calculateStat, the
        accuracy check). Only for a Pokémon on the field (not a fainted one); its handlers are
        the Unaware holders' ``onAnyModifyBoost`` (the field's Pokémon with HP left, collected
        even while Mold Breaker ignores them), sorted by the holders' speed: two or more at the
        same speed are shuffled, which draws. Unaware's effect itself is in ``damage`` and the
        accuracy check."""
        if pokemon.position is None or pokemon.fainted:
            return  # not isActive (faintMessages clears it: a replacement's own action)
        speeds = [
            p.cached_speed for s in SIDE_IDS for p in self.state.sides[s].active
            if p is not None and p.hp > 0 and p.base_ability_id == UNAWARE
        ]  # fmt: skip
        if len(speeds) > 1:
            speed_sort(speeds, self.prng, lambda a, b: b - a)

    def _modify_spe(self, pokemon: BattlePokemon) -> None:
        """041-5: ModifySpe's draw alone (Gyro Ball's getStat after its ModifyBoost)."""
        if pokemon.position is None or pokemon.fainted:
            return
        side = self.state.field.sides[pokemon.side]
        if TAILWIND in side and GRASS_PLEDGE in side:
            speed_sort([0, 0], self.prng, lambda a, b: 0)

    def _spe_events(self, pokemon: BattlePokemon) -> None:
        """getStat('spe')'s events: ModifyBoost (028), then ModifySpe. 041-5: Tailwind's and
        the swamp's onModifySpe are side handlers with no order or speed: both on the side
        tie and are shuffled (one draw)."""
        self._modify_boost(pokemon)
        if pokemon.position is None or pokemon.fainted:
            return
        side = self.state.field.sides[pokemon.side]
        if TAILWIND in side and GRASS_PLEDGE in side:
            speed_sort([0, 0], self.prng, lambda a, b: 0)

    def _update_speed(self) -> None:
        """``Battle.updateSpeed``: refresh the cached speed of every Pokémon on the field."""
        for pokemon in self.state.all_active():
            self._update_one_speed(pokemon)

    def _update_one_speed(self, pokemon: BattlePokemon) -> None:
        """``pokemon.updateSpeed()``: getActionSpeed (getStat: 028 ModifyBoost), then stored."""
        self._spe_events(pokemon)
        pokemon.update_speed(self.state.field)

    def _insert_run_switch(self, pending: list[BattlePokemon], pokemon: BattlePokemon) -> None:
        """``BattleQueue.insertChoice`` of a runSwitch action among earlier ones (start only).

        The queue also holds beforeTurn (always earlier) and residual (always later).
        insertChoice refreshes the switching-in Pokémon's speed first (updateSpeed), then
        resolveAction runs getActionSpeed (028: each runs ModifyBoost).
        """
        self._update_one_speed(pokemon)
        self._spe_events(pokemon)
        first = last = None
        for i, other in enumerate(pending):
            compared = _by_speed(pokemon, other)
            if compared <= 0 and first is None:
                first = i
            if compared < 0:
                last = i
                break
        if first is None:
            first = len(pending)  # just before residual
        if last is None:
            last = len(pending)  # residual compares lower
        index = first if first == last else self.prng.random_range(first, last + 1)
        pending.insert(index, pokemon)

    def _after_action(self, queue: ActionQueue[_Action]) -> bool:
        """End of ``runAction``: eachEvent('Update'), the switch request (014; True: the turn
        stops until ``replace``), then re-sort if a move is next (gen 8+)."""
        self._update()
        if self._request_switches("turn"):
            return True
        upcoming = queue.peek()
        if upcoming is not None and upcoming.kind == "move":
            # updateSpeed, then each action's getActionSpeed (its target lookup, then the speed;
            # 028: getStat's ModifyBoost draws): speeds may have changed (paralysis, Trick Room)
            self._update_speed()
            queue.resort_if_move_next(self._refresh_speed)
        return False

    def _switch_requested(self) -> bool:
        """runAction's end (014): a side with switch flags but nobody to bring in drops them;
        the flagged Pokémon run BeforeSwitchOut once; any flag left makes a switch request."""
        requested = False
        for side_id in SIDE_IDS:
            side = self.state.sides[side_id]
            flagged = [p for p in side.active if p is not None and p.switch_flag]
            if not flagged:
                continue
            if not side.bench():
                # 041-6f: a revivalblessing slot condition keeps its flag (reviveSwitch)
                kept = False
                for pokemon in flagged:
                    if reviving(self.state, pokemon):
                        kept = True
                    else:
                        pokemon.switch_flag = None
                requested = requested or kept
                continue
            for pokemon in flagged:
                pokemon.skip_before_switch_out = True  # BeforeSwitchOut (no supported handler)
            requested = True
        return requested

    def _at_loc(self, pokemon: BattlePokemon, loc: int) -> BattlePokemon | None:
        side = foe_of(pokemon.side) if loc > 0 else pokemon.side
        return self.state.at(side, abs(loc) - 1)

    def _tracked(self, pokemon: BattlePokemon) -> BattlePokemon | None:
        """043-2b: getTarget's ``tracksTarget && originalTarget?.isActive`` for a Stalwart /
        Propeller Tail user: the Pokemon at the action's location when it was queued."""
        if pokemon.ability_id not in TRACKERS:
            return None
        target = self._original_targets.get(id(pokemon))
        if target is None or target.fainted or target.position is None:
            return None
        if self.state.at(target.side, target.position) is not target:
            return None
        return target

    def _refresh_speed(self, action: _Action) -> None:
        self._action_speed_draws(action)
        action.speed = self._speed(action.pokemon)
        if isinstance(action.choice, MoveChoice):
            action.priority = self._priority(action.pokemon, action.choice)  # (010)

    def _run_move(
        self, user: BattlePokemon, choice: MoveChoice, *, external: Move | None = None
    ) -> None:
        """``runMove``. 043-5f: ``external`` (Dancer's externalMove): no OverrideAction, no
        PP nor moveUsed, a lockedmove it adds is dropped afterwards (noLock), no dragIn."""
        move = external if external is not None else chosen_move(user, choice)
        no_lock = external is not None and LOCKED_MOVE not in user.timed
        # runMove: count the move action, getTarget, then the BeforeMove checks (a Pokémon that
        # cannot move uses no PP), then PP, then ModifyMove (a defrost move thaws its user;
        # Struggle loses its type).
        user.active_move_actions += 1
        # 026: getTarget gets the queue's action.targetLoc (a random pick for a move without one)
        loc = choice.target if choice.target is not None else user.resolved_loc
        if move.id == RECHARGE_ID:  # 030: no target: getRandomTarget (see _recharge_move)
            self._random_foe_draw(user)
            targeting = Targeting([], spread=False)
        else:
            targeting = resolve_targets(
                self.state, user, move, loc, self.prng, tracked=self._tracked(user)
            )
        chosen = move
        slot = choice.move_index
        encore_boosted: bool | None = None  # (None: from the move used)
        if (
            external is None
            and ENCORE in user.timed
            and slot != STRUGGLE
            and move.id != user.encore_move
        ):
            # 015: encore onOverrideAction, then getRandomTarget for the new move
            slot = next(i for i, s in enumerate(user.moves) if s.move.id == user.encore_move)
            move = user.moves[slot].move
            targeting = random_targeting(self.state, user, move, self.prng)
            # 032: runMove copies the chosen move's pranksterBoosted to the new one (a status
            # move chosen: boosted; a damaging one: a fresh move, not boosted; regf032-2)
            encore_boosted = chosen.category == "Status"
        recharging = MUST_RECHARGE in user.timed
        if not self._before_move(user, move):
            # 015: runMove's BeforeMove failure (030: mustrecharge's onBeforeMove returns null)
            user.move_this_turn_result = None if recharging else False
            user.destiny_bond = False  # 041-4e: destinybond's onMoveAborted
            if user.charge and move.type == "Electric" and move.id != "charge":
                user.charge = False  # 041-4e: charge's onMoveAborted
                self._emit("end", target=user.label, detail="Charge")
            if user.timed.pop(TWO_TURN, None) is not None:
                # 020: twoturnmove onMoveAborted (its onEnd removes the move's volatile)
                user.two_turn_move, user.charge_loc, user.charged = None, None, False
                _clear_vanished(user)  # 026 (041-2)
            if user.hp == 0:  # hurt itself in confusion: runAction's faintMessages
                self._faint_out(user)
                self._check_win(user)
            return
        if move.id != DESTINY_BOND:
            user.destiny_bond = False  # 041-4e: destinybond's onBeforeMove (priority -1)
        if move.id == FOCUS_PUNCH and FOCUS_PUNCH in user.timed and user.counters.get(FOCUS_PUNCH):
            # 041-4e: beforeMoveCallback: lost focus -> cant, no PP, moveThisTurnResult false
            self._emit("cant", actor=user.label, detail="Focus Punch")
            user.move_this_turn_result = False
            return
        pressure_slot: int | None = None
        if slot == STRUGGLE:
            move = replace(move, type="???")  # struggle onModifyMove
            self._emit("activate", target=user.label, detail="move: Struggle")
        elif external is None and not any(
            v in user.timed for v in (TWO_TURN, LOCKED_MOVE, UPROAR, ROLLOUT)
        ):
            if user.moves[slot].pp <= 0:
                # 041-6b: deductPP fails (Spite took the last PP after the choice): cant
                # nopp, clearActiveMove(true), moveThisTurnResult false
                self._emit("cant", actor=user.label, detail="nopp")
                user.move_this_turn_result = False
                self._active_move = None
                return
            user.moves[slot].pp -= 1  # 020, 022: no PP for a locked move (getLockedMove)
            user.moves[slot].used = True  # 041-4e: deductPP
            # 033 (R14): a locked move's sourceEffect is lockedmove (no PP): no Pressure
            pressure_slot = slot
        if external is None:
            user.last_move = move.id  # 015: moveUsed (Struggle too)
            # 022: moveUsed's lastMoveTargetLoc (the queue's random pick for a move without one)
            user.last_move_loc = loc
            self._move_loc = loc  # 020: lastMoveTargetLoc (twoturnmove's targetLoc)
        # (Encore keeps the chosen move's priority: runMove's baseMove.priority = priority)
        move, base_target = self._modify_move(
            user, move, self._move_priority(user, chosen),
            target=_modify_move_target(targeting),
        )  # fmt: skip
        # 012: Mold Breaker's onModifyMove (ignoreAbility): until the move ends, the other
        # Pokémon's breakable abilities do nothing (Battle.suppressingAbility).
        # (041-6b: a move's own ignoreAbility: Sunsteel Strike, Moongeist Beam, Photon Geyser)
        mold = (
            user.ability_id in MOLD_BREAKERS
            or "ignoreAbility" in move.keys
            # 043-5b: Mycelium Might's onModifyMove (a status move)
            or (user.ability_id == "myceliummight" and move.category == "Status")
        )
        suppressed = self._suppress_abilities(user) if mold else []
        if mold:
            self._ignoring_user = user
        self._hit_targets = None  # 041-6f: the active move's hitTargets
        outer_external, self._external_move = self._external_move, external is not None
        try:
            # 015: useMove's moveResult (False on failure, None for NOT_FAIL: Protect)
            user.move_this_turn_result = self._use_move(
                user, move, targeting, base_target, prankster_boosted=encore_boosted,
                pressure_slot=pressure_slot,
            )  # fmt: skip
        finally:
            self._external_move = outer_external
            self._ignoring_user = None
            for pokemon in suppressed:
                pokemon.ability_suppressed = False
        if self._called_result is not None:
            # 025: useMove keeps the called move's moveThisTurnResult (Sleep Talk)
            (user.move_this_turn_result,), self._called_result = self._called_result, None
        # 041-6a: runMove: lastSuccessfulMoveThisTurn = moveDidSomething ? activeMove.id : null
        active = self._active_move
        self._last_successful = (
            (active.id if active is not None else move.id) if user.move_this_turn_result else None
        )
        # 041-6f: runMove's AfterMove gets battle.activeMove (a called move: Metronome's)
        move = active if active is not None else move
        if move.id == BEAK_BLAST:
            user.timed.pop(BEAK_BLAST, None)  # 041-6f: its onAfterMove (removeVolatile, silent)
        if move.id == SPIT_UP and user.stockpile is not None:
            self._end_stockpile(user)  # 041-4d: Spit Up's onAfterMove (singleEvent)
        if move.id == "sparklingaria":
            self._sparkling_aria(user, move)
        self._after_move(user, move)
        if "dance" in move.flags and user.move_this_turn_result and external is None:
            self._dancers(user, move, targeting)  # 043-5f
        if no_lock and LOCKED_MOVE in user.timed:
            del user.timed[LOCKED_MOVE]  # 043-5f: delete volatiles.lockedmove (no onEnd)
            user.locked_move = None
        # runMove's faintMessages: the user knocked out by Spiky Shield with nothing hit, or by
        # Life Orb (013); then the win, when a target fainted with the user standing.
        last, self._win_pending = self._win_pending, None
        if user.hp <= 0 and not user.fainted:
            self._faint_out(user)
            last = user
        if last is not None:
            self._check_win(last)
        if external is not None:
            return  # (runAction's dragIn: the outer action's)
        # 034 (R2): runAction's dragIn, while the move is still the active one (Mold
        # Breaker still ignores Guard Dog: suppressingAbility needs the user active).
        # 040-3: it runs even once the battle is won (Red Card's attacker is dragged out)
        again = [p for p in suppressed if user.position is not None and p.position is not None]
        for pokemon in again:
            pokemon.ability_suppressed = True
        if mold and user.position is not None:
            self._ignoring_user = user  # (the Pokémon dragged in too: _drag_in)
        try:
            self._drag_ins()
        finally:
            for pokemon in again + self._drag_suppressed:
                pokemon.ability_suppressed = False
            self._drag_suppressed = []
            self._ignoring_user = None

    def _dancers(self, user: BattlePokemon, move: Move, targeting: Targeting) -> None:
        """043-5f: runMove's Dancer part: every other active Dancer (hasAbility, not
        semi-invulnerable), slowest storedStats.spe first (then the later effectOrder; no
        shuffle), until the battle is won: ``-activate … ability: Dancer`` and the move as
        an external runMove, at the first target when that is a foe of a dancing ally,
        otherwise at the user."""
        dancers = [
            p for p in self.state.all_active()
            if p is not user and p.ability_id == "dancer" and not vanished(p)
        ]  # fmt: skip
        dancers.sort(key=lambda p: (p.stats["spe"], -p.ability_order))
        first = targeting.targets[0] if targeting.targets else user
        fresh = get_dex().move(move.id)
        assert fresh is not None
        for dancer in dancers:
            # (043 review) faintMessages before each dancer: the user knocked out by Life Orb
            for pokemon in [p for p in self.state.all_active() if p.hp <= 0 and not p.fainted]:
                self._faint_out(pokemon)
                self._check_win(pokemon)
            if self.state.ended:
                break
            if dancer.fainted or dancer.hp <= 0:
                continue
            self._emit("activate", target=dancer.label, detail="ability: Dancer")
            aimed = first if first.side != dancer.side and user.side == dancer.side else user
            place = (aimed.position or 0) + 1
            loc = place if aimed.side != dancer.side else -place
            self._run_move(dancer, MoveChoice(0, loc), external=fresh)

    def _force_switch(
        self, user: BattlePokemon, landed: list[BattlePokemon], move: Move
    ) -> list[BattlePokemon]:
        """034 (R1): ``forceSwitch`` after the move's effects: each target still standing,
        with someone to bring in, runs DragOut; true flags it, false (a status move) shows
        ``-fail`` for the user and the target counts as not hit, null does nothing more."""
        kept = []
        for target in landed:
            if target.hp > 0 and user.hp > 0 and self.state.sides[target.side].bench():
                result = self._drag_out(target)
                if result:
                    target.force_switch = True
                elif result is False and move.category == "Status":
                    # (041 review P2: Dragon Tail's false shows nothing and keeps the target)
                    self._emit("fail", actor=user.label)
                    continue
            kept.append(target)
        return kept

    def _drag_out(self, target: BattlePokemon) -> bool | None:
        """034 (R3): ``runEvent('DragOut')``. Commander's volatiles (priority 2) give false;
        Guard Dog and Suction Cups (priority 1) show ``-activate`` and give null."""
        if target.commanding or target.commanded_by is not None:
            return False
        name = DRAG_OUT_BLOCKERS.get(target.ability_id)
        if name is not None:
            self._emit("activate", target=target.label, detail=f"ability: {name}")
            return None
        if INGRAIN in target.timed:  # 041-4c: ingrain's onDragOut (priority 0)
            self._emit("activate", target=target.label, detail="move: Ingrain")
            return None
        return True

    def _drag_ins(self) -> None:
        """034 (R2): the end of runAction: each flagged Pokémon still standing is dragged out
        (``dragIn``), side by side and position by position."""
        for side_id in SIDE_IDS:
            side = self.state.sides[side_id]
            for position in range(len(side.active)):
                pokemon = side.active[position]
                if pokemon is None or not pokemon.force_switch:
                    continue
                if pokemon.hp > 0:
                    self._drag_in(side, position)
                pokemon.force_switch = False

    def _drag_in(self, side: SideState, position: int) -> None:
        """034 (R2): ``dragIn``: a random Pokémon from the bench (``getRandomSwitchable``),
        DragOut again, then ``switchIn(…, isDrag)``: no BeforeSwitchOut nor Update, the
        outgoing Pokémon's action is cancelled, and runSwitch runs at once (gen 5+)."""
        bench = side.bench()
        if not bench:
            return
        incoming = self.prng.sample(bench)
        old = side.active[position]
        assert old is not None
        if old.hp <= 0 or not self._drag_out(old):
            return
        self._switch_out(old)
        if self._queue is not None:
            self._queue.remove(partial(_acts_for, old))  # cancelAction
        self._switch_in(side, position, incoming, drag=True)
        ignoring = self._ignoring_user
        if ignoring is not None and is_breakable(incoming.base_ability_id):
            # review P3: Mold Breaker's move is still the active one (clearActiveMove comes
            # after dragIn): the incoming Pokémon's breakable ability is ignored (Levitate)
            incoming.ability_suppressed = True
            self._drag_suppressed.append(incoming)
        self._switch_in_abilities([incoming], self._run_switch_sort())

    def _double_shock(self, user: BattlePokemon, spent: str) -> None:
        """041-1g: Double Shock's self onHit: ``setType`` with Electric made ``???`` (false
        when terastallized), then ``-start … typechange`` either way. 041-6f: Burn Up (Fire)."""
        if not _type_locked(user):
            user.base_types = tuple("???" if t == spent else t for t in user.own_types)
            user.type_changed = True
            user.added_type = None  # (041-6f: setType)
            user.apparent_type = user.base_types
        self._emit("start", target=user.label, detail="typechange")

    def _echoed_voice(self) -> None:
        """041-1f: ``addPseudoWeather('echoedvoice')``: start at x1 (duration 2); a restart
        with a duration other than 2 (the next turn) sets 2 and adds 1, up to x5. A start
        runs PseudoWeatherChange (Room Service)."""
        turns = self.state.field.pseudo_weather
        if ECHOED_VOICE not in turns:
            turns[ECHOED_VOICE] = 2
            self.state.field.echoed_voice = 1
            self._pseudo_weather_change()
        elif turns[ECHOED_VOICE] != 2:
            turns[ECHOED_VOICE] = 2
            self.state.field.echoed_voice = min(5, self.state.field.echoed_voice + 1)

    def _round(self) -> None:
        """041-1f: Round's onTry: the first Round left in the queue (any Pokémon) is
        prioritized with sourceEffect Round (its power doubles)."""
        if self._queue is None:
            return
        for action in self._queue:
            if action.kind != "move" or action.pokemon.fainted:
                continue
            assert isinstance(action.choice, MoveChoice)
            if chosen_move(action.pokemon, action.choice).id == "round":
                self._queue.prioritize(action)
                action.round_boosted = True
                return

    def _pledge_wait(self, user: BattlePokemon, move: Move) -> bool:
        """041-5: a Pledge's onPrepareHit: the first queued action of an active ally using
        another Pledge is prioritized with this move as its sourceEffect (``-waiting``)."""
        if self._queue is None:
            return False
        for action in self._queue:
            pokemon = action.pokemon
            if action.kind != "move" or pokemon.position is None or pokemon.fainted:
                continue
            if not isinstance(action.choice, MoveChoice) or pokemon.side != user.side:
                continue
            other = chosen_move(pokemon, action.choice).id
            if other in PLEDGES and other != move.id:
                self._queue.prioritize(action)
                action.pledge_source = move.id
                self._emit("waiting", actor=user.label, target=pokemon.label)
                return True
        return False

    def _instruct(self, user: BattlePokemon, target: BattlePokemon) -> bool:
        """041-6f: Instruct's onHit: the target's lastMove (not failinstruct / charge /
        recharge, no Focus Punch volatile, its slot with PP) as a new move action from
        resolveAction (priority, FractionalPriority, getActionSpeed with lastMoveTargetLoc)
        put first (prioritizeAction, order 3). A lastMove outside the moveset: false
        (not in play without Mimic / Sketch)."""
        if target.last_move is None or self._queue is None:
            return False
        last = get_dex().move(target.last_move)
        index = next((i for i, s in enumerate(target.moves) if s.move.id == target.last_move), None)
        if (
            last is None
            or index is None
            or {"failinstruct", "charge", "recharge"} & last.flags
            or FOCUS_PUNCH in target.timed
            or BEAK_BLAST in target.timed
            or target.moves[index].pp <= 0
        ):
            return False
        self._emit("singleturn", target=target.label, detail="move: Instruct")
        # (the location a request would carry: single targets, the ally, scripted)
        located = last.target in SINGLE_TARGETS or last.target in ALLY_TARGETS
        loc = target.last_move_loc if located or last.target == "scripted" else None
        choice = MoveChoice(index, loc)
        action = self._make_action(target, choice, speed=False)
        action.fractional = self._fractional_priority(target, choice)
        self._action_speed_draws(action)
        action.speed = self._speed(target)
        self._queue.prioritize(action)
        return True

    def _after_you(self, target: BattlePokemon, *, quash: bool = False) -> bool:
        """025 (R7): After You's onHit. ``queue.willMove(target)`` (null when it fainted or has
        no move action left), then ``prioritizeAction`` and ``-activate … move: After You``."""
        if target.fainted or self._queue is None:
            return False
        action = next((a for a in self._queue if a.pokemon is target and a.kind == "move"), None)
        if action is None:
            return False
        if quash:
            # 041-6f: Quash's onHit: action.order = 201 (no sort here; the next resort moves it)
            action.order = QUASH_ORDER
            self._emit("activate", target=target.label, detail="move: Quash")
            return True
        self._queue.prioritize(action)
        self._emit("activate", target=target.label, detail="move: After You")
        return True

    def _revival_blessing(self, user: BattlePokemon) -> None:
        """041-6f: onTryHit: no fainted Pokémon on the side -> -fail (false). Otherwise the
        slot condition (duration 1, silent) and selfSwitch: switchFlag 'revivalblessing',
        kept by runAction's end even with nobody to switch in."""
        assert user.position is not None
        if not revivable(self.state, user.side):
            self._emit("fail", actor=user.label)
            return
        self.state.field.slot_conditions[user.side][user.position].setdefault(
            REVIVAL_BLESSING, False
        )
        if user.hp > 0 and user.commanded_by is None:
            user.switch_flag = REVIVAL_BLESSING
        self._move_succeeded = True
        self._update()  # hitStepMoveHitLoop: eachEvent('Update')
        self._update()  # eachEvent('Update') after faint messages

    def _revive(self, user: BattlePokemon, target: BattlePokemon, *, now: bool = True) -> bool:
        """041-6f: the 'revivalblessing' action (order 6): the target gets up with half its HP
        (-heal … [from] move: Revival Blessing); an active (fainted) one is switched in
        again (instaswitch). True when it was switched in."""
        target.fainted = False
        target.status = None
        target.hp = max(1, target.max_hp // 2)
        # (a fainted one is not active: shown without a position)
        self._emit("heal", target=target.side, value=target.hp, hp=target.hp,
                   team_index=target.team_index,
                   detail="move: revival blessing")  # fmt: skip
        assert user.position is not None
        self.state.field.slot_conditions[user.side][user.position].pop(REVIVAL_BLESSING, None)
        user.switch_flag = None
        if target.position is None:
            return False
        if not now:  # (queue.addChoice pushes it last: no re-sort unless a move is next)
            self._revive_later.append(target)
            return False
        if self._queue is not None:
            # the revivalblessing action's end: a move is next, so updateSpeed and re-sort (the
            # instaswitch pushed last goes first; its own move is still queued here)
            self._update_speed()
            self._queue.resort_if_move_next(self._refresh_speed)
            # switchIn's cancelAction(oldActive): the fainted one is its own oldActive
            self._queue.remove(partial(_acts_for, target))
        self._switch_in(self.state.sides[target.side], target.position, target)
        return True

    def _healing_wish(self, user: BattlePokemon, key: str = "healingwish") -> None:
        """025 (R5): onTryHit: with nothing to switch in (``canSwitch``), ``-fail`` and NOT_FAIL
        (the user stays; spreadMoveHit still returns [false], so the move failed). Otherwise
        the slot condition on the user's position (no onRestart: a second one does nothing),
        then ``selfdestruct: 'ifHit'``: ``faint()`` (HP 0), and the hit loop's faintMessages
        takes the user off the field."""
        assert user.position is not None
        if not self.state.sides[user.side].bench():
            self._emit("fail", actor=user.label)
            return
        self.state.field.slot_conditions[user.side][user.position].setdefault(key, False)
        user.hp = 0
        self._move_succeeded = True
        self._update()  # hitStepMoveHitLoop: eachEvent('Update')
        # faintMessages(checkWin = !user.hp) in the hit loop: the user is gone before the
        # second Update (found in the friends-* pairs)
        self._faint_out(user)
        self._check_win(user)
        self._update()  # eachEvent('Update') after faint messages

    def _modify_move(
        self,
        user: BattlePokemon,
        move: Move,
        priority: int,
        *,
        bounced: bool = False,
        target: BattlePokemon | None = None,
    ) -> tuple[Move, str]:
        """useMoveInner's ModifyType / ModifyMove: the move as used and its target before the
        terrain changed it (``baseTarget``). ``priority``: the action's (runMove's
        ``baseMove.priority``), or the calling move's (025: Sleep Talk's ``activeMove``)."""
        thaw_by_own_move(user, move, self._emit_kw)
        # ModifyType / ModifyMove (007; 040-3c: the user's and the target's Utility Umbrella)
        move = modify_move(
            move,
            self.state.field.active_weather,
            user.item,
            target.item if target is not None else "",
        )
        move = modify_type(move, user.species.name)  # Raging Bull (008)
        move = tera_modify_move(move, user.combatant())  # Tera Blast, Ivy Cudgel (017)
        if move.id == TERA_BLAST and user.terastallized == STELLAR:
            move = replace(move, self_boosts={"atk": -1, "spa": -1})  # onModifyMove (017)
        self._stellar_move = False  # 017: move.stellarBoosted
        for pokemon in self.state.all_active():
            pokemon.shell_resisted = False  # 042-6: Tera Shell (move.hit === 1)
        # 010: the priority getActionSpeed gave the action; the terrain's ModifyType/ModifyMove
        terrain = self.state.field.terrain
        grounded = is_grounded(
            user.types, user.ability_id, user.item, user.pinned, rising="magnetrise" in user.timed
        )
        move = replace(move, priority=priority)
        base_target = move.target
        move = terrain_modify_move(move, terrain, user_grounded=grounded)
        if user.item == PUNCHING_GLOVE and "punch" in move.flags:
            # 040-2: onModifyMovePriority 1, before Unseen Fist (0)
            move = replace(move, flags=move.flags - {"contact"})
        if user.ability_id == LONG_REACH and "contact" in move.flags:
            move = replace(move, flags=move.flags - {"contact"})  # 043-2a: onModifyMove
        if user.ability_id == UNSEEN_FIST and "contact" in move.flags:
            move = replace(move, flags=move.flags - {"protect"})  # onModifyMove (011)
        if user.ability_id == LIQUID_VOICE and "sound" in move.flags:
            move = replace(move, type="Water")  # onModifyType (priority -1, 012)
        if user.ability_id == PIXILATE and pixilate_changes(move, user.terastallized is not None):
            move = replace(move, type="Fairy", type_boosted=True)  # 030 (R1): onModifyType
        if user.ability_id == GALVANIZE and pixilate_changes(move, user.terastallized is not None):
            move = replace(move, type="Electric", type_boosted=True)  # 043-2a
        if (
            move.id == ROLLOUT
            and ROLLOUT not in user.timed
            and user.status != "slp"
            and target is not None
        ):
            # 041-3b: onModifyMove adds rollout (duration 1, hitCount 0; onLockMove)
            user.timed[ROLLOUT] = 1
            user.counters[ROLLOUT] = 0
            if self._calling and target.position is not None:  # 041-6f: move.sourceEffect:
                # lastMoveTargetLoc = getLocOf(target)
                same = target.side == user.side
                user.last_move_loc = -(target.position + 1) if same else target.position + 1
        if is_choice(user.item) and user.choice_lock is None and not bounced:
            # 013: Choice item onModifyMove adds choicelock (031: whose onStart refuses a
            # bounced move)
            user.choice_lock = move.id
        if move.id == "judgment" and user.item.endswith("plate") and user.item in TYPE_BOOSTERS:
            move = replace(move, type=TYPE_BOOSTERS[user.item])  # 041-6f: onModifyType (onPlate)
        if move.id == "aurawheel" and user.species.name == "Morpeko-Hangry":
            move = replace(move, type="Dark")  # 042-3: onModifyType
        if move.id == "revelationdance":
            # 041-6e: onModifyType: the first of getTypes() (??? gives the second)
            types = user.types
            kind = types[1] if types[0] == "???" and len(types) > 1 else types[0]
            move = replace(move, type=kind)
        if move.id == "terastarstorm" and user.species.name == "Terapagos-Stellar":
            # 042-6: onModifyType (Stellar; Physical when terastallized and getStat(atk,
            # false, true) > getStat(spa, …), each running ModifyBoost), onModifyMove
            move = replace(move, type=STELLAR, target="allAdjacentFoes")
            if user.terastallized is not None:
                self._modify_boost(user)
                self._modify_boost(user)
                atk = boosted_stat(user.stats["atk"], user.boosts["atk"])
                if atk > boosted_stat(user.stats["spa"], user.boosts["spa"]):
                    move = replace(move, category="Physical")
        if move.id == "photongeyser":
            # 041-6b: onModifyMove: getStat(atk, false, true) > getStat(spa, ...) (staged, no
            # modifiers; each getStat runs ModifyBoost)
            self._modify_boost(user)
            self._modify_boost(user)
            atk = boosted_stat(user.stats["atk"], user.boosts["atk"])
            if atk > boosted_stat(user.stats["spa"], user.boosts["spa"]):
                move = replace(move, category="Physical")
        if move.id == "shellsidearm" and target is not None:
            # 041-6f: onModifyMove: getStat(stat, false, true) of the user (atk, spa) and the
            # target (def, spd), each running ModifyBoost
            stats = []
            for who, stat in ((user, "atk"), (user, "spa"), (target, "def"), (target, "spd")):
                self._modify_boost(who)
                wonder = WONDER_ROOM in self.state.field.pseudo_weather  # 041-6f
                stats.append(
                    boosted_stat(who.stats[stat], wonder_swapped(who.boosts, wonder)[stat])
                )
            base = (2 * user.level // 5 + 2) * 90
            physical = base * stats[0] // stats[2] // 50
            special = base * stats[1] // stats[3] // 50
            if physical > special or (physical == special and self.prng.random_chance(1, 2)):
                move = replace(move, category="Physical", flags=move.flags | {"contact"})
        source = self._pledge_source
        if move.id in PLEDGES and source in PLEDGES and source != move.id:
            # 041-5: the Pledge's onModifyMove (sourceEffect another Pledge): type, forceSTAB;
            # basePowerCallback 150
            kind, _ = PLEDGE_COMBOS[frozenset({move.id, source})]
            move = replace(move, type=kind, force_stab=True, base_power=150)
        if move.id == PRESENT:
            # 041-6f: onModifyMove: random(10): < 2 heals 1/4 (move.heal, infiltrates), else
            # 40 (< 6), 80 (< 9), 120
            roll = self.prng.random_int(10)
            self._present_heal = roll < 2
            power = 0 if roll < 2 else 40 if roll < 6 else 80 if roll < 9 else 120
            move = replace(move, base_power=power)
        if user.ability_id == "serenegrace" and (move.secondaries or move.self_chance):
            # 042-4: onModifyMove (priority -2): the secondaries' and self's chances x2
            move = replace(
                move,
                secondaries=tuple(
                    replace(s, chance=s.chance * 2) if s.chance else s for s in move.secondaries
                ),
                self_chance=move.self_chance * 2 if move.self_chance else move.self_chance,
            )
        if move.secondaries and self.state.field.has_side(user.side, WATER_PLEDGE):
            # 041-5: the rainbow's onModifyMove doubles the secondaries' chances
            move = replace(
                move,
                secondaries=tuple(
                    replace(s, chance=s.chance * 2) if s.chance else s for s in move.secondaries
                ),
                self_chance=move.self_chance * 2 if move.self_chance else move.self_chance,
            )
        # 041-6f: useMoveInner's lastMoveUsed is the active move its ModifyType changes
        user.last_move_used_type = move.type
        return move, base_target

    def _power_callback_state(self, user: BattlePokemon, move: Move) -> int:
        """041-3b: the side effects of a basePowerCallback (getDamage, once per hit) and the
        value the power is computed from. Fury Cutter: addVolatile('furycutter') (onStart
        multiplier 1; onRestart doubles it up to 4 and sets the duration back to 2): the
        multiplier. Rollout: 30 x 2 ** hits so far (the hit counts unless asleep; the duration
        becomes 2 below 5 hits), x2 with Defense Curl: the power."""
        if move.id == FURY_CUTTER:
            if FURY_CUTTER not in user.timed:
                user.counters[FURY_CUTTER] = 1
            elif user.counters[FURY_CUTTER] < 4:
                user.counters[FURY_CUTTER] <<= 1
            user.timed[FURY_CUTTER] = 2
            return user.counters[FURY_CUTTER]
        if move.id == ROLLOUT:
            power = move.base_power
            hits = user.counters.get(ROLLOUT, 0)
            if ROLLOUT in user.timed and hits:
                power *= 2**hits
            if ROLLOUT in user.timed and user.status != "slp":
                user.counters[ROLLOUT] = hits + 1
                if hits + 1 < 5:
                    user.timed[ROLLOUT] = 2
            return power * 2 if user.defense_curl else power
        if move.id == SPIT_UP:  # 041-4d: stockpile layers x 100
            return user.stockpile[0] * 100 if user.stockpile else 0
        return 0

    def _sleep_talk(self, user: BattlePokemon, move: Move) -> None:
        """025 (R4): Sleep Talk's onHit. One draw from the user's moves without the nosleeptalk
        or charge flag, then ``useMove``: getRandomTarget, ModifyType / ModifyMove, the rest of
        useMoveInner. No PP, lastMove stays Sleep Talk, the move keeps Sleep Talk's priority;
        a multi-hit move goes on while asleep (``isSleepUsable``)."""
        ids = [s.move.id for s in user.moves if not (s.move.flags & SLEEP_TALK_EXCLUDED)]
        if not ids:
            self._emit("fail", actor=user.label)  # (no team has such a move list)
            return
        picked = self.prng.sample(ids)
        called = next(s.move for s in user.moves if s.move.id == picked)
        targeting = self._called_targeting(user, called)  # (041-6f: Metal Burst's ModifyTarget)
        called, base_target = self._modify_move(
            user, called, move.priority,
            target=_modify_move_target(targeting),
        )  # fmt: skip
        # useMoveInner copies the priority and pranksterBoosted (Sleep Talk is a status move)
        # 033 (R14): Pressure takes the PP from Sleep Talk (callerMoveForPressure)
        caller = next(i for i, s in enumerate(user.moves) if s.move.id == SLEEP_TALK)
        self._sleep_usable = True
        try:
            result = self._use_move(
                user, called, targeting, base_target, prankster_boosted=True,
                pressure_slot=caller,
            )  # fmt: skip
        finally:
            self._sleep_usable = False
        self._called_result = (result,)
        self._move_succeeded = True  # onHit returned undefined: Sleep Talk worked

    def _copycat(self, user: BattlePokemon, move: Move) -> bool:
        """041-5: Copycat's onHit. No lastMove: undefined (the move worked, nothing happens);
        a failcopycat move: false; else ``useMove(lastMove.id)`` as Sleep Talk's (getRandomTarget,
        Copycat's priority and pranksterBoosted, Pressure from Copycat). False on failure."""
        last = self._last_move
        if last is None:
            self._move_succeeded = True
            return True
        if "failcopycat" in last.flags:
            return False
        called = get_dex().move(last.id)
        assert called is not None
        targeting = self._called_targeting(user, called)
        caller = next(i for i, s in enumerate(user.moves) if s.move.id == COPYCAT)
        self._calling = True  # (041-6f: from ModifyMove on: Rollout's move.sourceEffect)
        try:
            called, base_target = self._modify_move(
                user, called, move.priority,
                target=_modify_move_target(targeting),
            )  # fmt: skip
            result = self._use_move(
                user, called, targeting, base_target, prankster_boosted=True,
                pressure_slot=caller,
            )  # fmt: skip
        finally:
            self._calling = False
        self._called_result = (result,)
        self._move_succeeded = True
        return True

    def _called_targeting(self, user: BattlePokemon, called: Move) -> Targeting:
        """useMoveInner for a called move (041-5 Copycat, 041-6f Metronome): runEvent
        ('ModifyTarget') first (Metal Burst, Comeuppance: the last damaging foe's slot, also
        from an earlier turn: no getRandomTarget draw), else getRandomTarget."""
        if called.id in METAL_BURSTS and user.damaged_log:
            source, position, _, _ = user.damaged_log[-1]
            at = self.state.at(source.side, position)
            return Targeting([at] if at is not None else [], spread=False)
        return random_targeting(self.state, user, called, self.prng)

    def _metronome(self, user: BattlePokemon, move: Move) -> None:
        """041-6f: Metronome's onHit: ``sample`` of every move with the metronome flag
        (the Unobtainable ones too) sorted by num, then ``useMove`` as Copycat's
        (getRandomTarget, Metronome's priority and pranksterBoosted, Pressure from Metronome)."""
        called = self.prng.sample(_metronome_pool())
        targeting = self._called_targeting(user, called)
        caller = next(i for i, s in enumerate(user.moves) if s.move.id == METRONOME)
        self._calling = True  # (041-6f: from ModifyMove on: Rollout's move.sourceEffect)
        try:
            called, base_target = self._modify_move(
                user, called, move.priority,
                target=_modify_move_target(targeting),
            )  # fmt: skip
            result = self._use_move(
                user, called, targeting, base_target, prankster_boosted=True,
                pressure_slot=caller,
            )  # fmt: skip
        finally:
            self._calling = False
        self._called_result = (result,)
        self._move_succeeded = True

    def _lock_move(self, user: BattlePokemon, move: Move) -> None:
        """022 (R4): ``addVolatile('lockedmove')``: onStart draws trueDuration (2 or 3); when
        the user has it already, onRestart sets the duration back to 2 while turns are left."""
        if user.hp <= 0:
            return
        if LOCKED_MOVE in user.timed:
            if user.locked_turns >= 2:
                user.timed[LOCKED_MOVE] = 2
            return
        user.timed[LOCKED_MOVE] = 2
        user.locked_turns = self.prng.random_range(2, 4)
        user.locked_move = move.id

    def _locked_move_residual(self, pokemon: BattlePokemon) -> bool:
        """lockedmove at the residual (no order): ``duration--`` (ending at 0: onEnd), else
        onResidual: it ends silently while asleep, and trueDuration goes down. True when the
        callback ran."""
        pokemon.timed[LOCKED_MOVE] -= 1
        if pokemon.timed[LOCKED_MOVE] <= 0:
            self._end_locked_move(pokemon)
            return False
        if pokemon.status == "slp":
            del pokemon.timed[LOCKED_MOVE]
            pokemon.locked_move = None
        pokemon.locked_turns -= 1
        return True

    def _end_locked_move(self, pokemon: BattlePokemon) -> None:
        """lockedmove's onEnd: confused by fatigue when it ran its course."""
        del pokemon.timed[LOCKED_MOVE]
        pokemon.locked_move = None
        if pokemon.locked_turns <= 1:
            add_volatile(
                pokemon, "confusion", prng=self.prng, emit=self._emit_kw,
                terrain=self.state.field.terrain,
            )  # fmt: skip

    def _after_move(self, user: BattlePokemon, move: Move) -> None:
        """runMove's ``runEvent('AfterMove', user)``: White Herb's (013) and Eject Pack's (014)
        onAnyAfterMove on every holder with HP (the user's side, then the foes), sorted by
        speed. 022: the user's lockedmove onAfterMove (a volatile: before an item of the same
        speed) ends it when its duration is 1. 041-4e: charge's onAfterMove ends it after an
        Electric move; the user's two volatile handlers tie (a shuffle)."""
        sides = self.state.sides
        holders = [
            p
            for p in sides[user.side].alive_active() + sides[foe_of(user.side)].alive_active()
            if p.held_item in (WHITE_HERB, EJECT_PACK, MIRROR_HERB)  # (041-6f)
            or p.base_ability_id == "opportunist"  # (043-4i)
        ]
        speed_sort(holders, self.prng, _by_speed)
        volatiles = [v for v, on in ((LOCKED_MOVE, LOCKED_MOVE in user.timed),
                                     ("charge", user.charge)) if on]  # fmt: skip
        if len(volatiles) > 1:
            speed_sort(volatiles, self.prng, lambda a, b: 0)
        if volatiles:
            ahead = [p for p in holders if _by_speed(p, user) < 0]
            for pokemon in ahead:
                self._after_move_item(pokemon)
            for volatile in volatiles:
                if volatile == LOCKED_MOVE and user.timed.get(LOCKED_MOVE) == 1:
                    self._end_locked_move(user)
                elif (
                    volatile == "charge"
                    and user.charge
                    and user.hp > 0  # (removeVolatile does nothing at 0 HP)
                    and move.type == "Electric"
                    and move.id != "charge"
                ):
                    user.charge = False
                    self._emit("end", target=user.label, detail="Charge")
            holders = holders[len(ahead) :]
        for pokemon in holders:
            self._after_move_item(pokemon)

    def _after_move_item(self, pokemon: BattlePokemon) -> None:
        self._opportunist(pokemon)  # 043-4i: the ability (subOrder 7) before the item
        if pokemon.item == EJECT_PACK:
            self._eject_pack(pokemon)
        elif pokemon.item == MIRROR_HERB:
            self._mirror_herb(pokemon)
        else:
            self._white_herb(pokemon)

    def _suppress_abilities(self, user: BattlePokemon) -> list[BattlePokemon]:
        suppressed = []
        for pokemon in self.state.all_active():
            if pokemon is not user and is_breakable(pokemon.base_ability_id):
                pokemon.ability_suppressed = True
                suppressed.append(pokemon)
        return suppressed

    # -- 013: held items -------------------------------------------------------------------

    def _use_item(self, pokemon: BattlePokemon) -> bool:
        """``pokemon.useItem()``: ``-enditem``, the item's boosts (Throat Spray, the seeds), then
        the item is gone (AfterUseItem: Unburden)."""
        if pokemon.hp <= 0 or pokemon.position is None or not pokemon.held_item:
            return False
        item = get_dex().item(pokemon.held_item)
        assert item is not None
        self._emit("enditem", target=pokemon.label, detail=item.name)
        if item.boosts:
            apply_boosts(
                pokemon, item.boosts, primary=True, foes_left=self._foes_left(pokemon),
                emit=self._emit_kw, source=pokemon,
            )  # fmt: skip
        pokemon.last_item = pokemon.held_item  # 041-6f
        self._lose_item(pokemon, unburden=True)
        pokemon.used_item_this_turn = True  # 043-5c
        self._symbiosis(pokemon)  # runEvent('AfterUseItem')
        return True

    def _eat_item(
        self,
        pokemon: BattlePokemon,
        on_eat: Callable[[], object] | None = None,
        *,
        force: bool = False,
    ) -> bool:
        """``pokemon.eatItem()``: ``-enditem … [eat]``, the berry's onEat, then the item is
        gone (AfterUseItem: Unburden). 040-4a: Jaboca / Rowap Berry are eaten at 0 HP too."""
        at_zero = pokemon.held_item in RETALIATE_BERRIES
        if (pokemon.hp <= 0 and not at_zero) or pokemon.position is None or not pokemon.held_item:
            return False
        if not force and self._unnerved(pokemon):
            return False  # 043-1: Unnerve / As One's onFoeTryEatItem (not eatItem(true))
        if not force and pokemon.ability_id == "ripen":
            self._emit("activate", target=pokemon.label, detail="ability: Ripen")  # 043-4h
        self._emit("enditem", target=pokemon.label, detail=item_name(pokemon.held_item))
        if on_eat is not None:
            on_eat()
        self._eat_item_event(pokemon, pokemon.held_item)
        pokemon.last_item = pokemon.held_item  # 041-6f
        self._lose_item(pokemon, unburden=True)
        pokemon.ate_berry = True  # 041-4e
        pokemon.used_item_this_turn = True  # 043-5c
        self._symbiosis(pokemon)  # 043-1: runEvent('AfterUseItem')
        return True

    def _eat_item_event(self, pokemon: BattlePokemon, item: str, *, stolen: bool = False) -> None:
        """043-4f: runEvent('EatItem'): Cheek Pouch heals 1/3. 043-4h: Cud Chew keeps a
        berry not eaten by Bug Bite / Pluck (counter 2; 1 when the queue is empty: during
        the residual)."""
        if pokemon.ability_id == "cudchew" and not stolen and item.endswith("berry"):
            pokemon.cud_chew = (item, 1 if self._in_residual else 2)
        if pokemon.ability_id == "cheekpouch":
            self._heal(pokemon, pokemon.max_hp / 3, "ability: cheek pouch")

    def _symbiosis(self, pokemon: BattlePokemon) -> None:
        """043-1: an ally's Symbiosis (onAllyAfterUseItem): not while ``pokemon`` is to
        switch out; the holder's item (takeItem) goes to it (setItem): ``-activate ... ability:
        Symbiosis``."""
        if pokemon.switch_flag or pokemon.hp <= 0 or pokemon.held_item:
            return
        for holder in self.state.sides[pokemon.side].alive_active():
            if holder is pokemon or holder.ability_id != SYMBIOSIS:
                continue
            item = holder.held_item
            if not self._trick_take(holder, item, holder):
                continue
            self._set_item(pokemon, item)
            self._emit("activate", target=holder.label, detail="ability: Symbiosis")
            return

    def _natural_cure_check_show(self, pokemon: BattlePokemon, queue: ActionQueue[_Action]) -> None:
        """043-1: Natural Cure's onCheckShow (a switch action of a statused Pokemon): when the
        switching Pokemon of the side that could have Natural Cure (their species has it and
        another ability) include both holders and non-holders, the holders cure silently."""
        if pokemon.show_cure is not None:
            return
        switching = {id(a.pokemon) for a in queue if isinstance(a.choice, SwitchChoice)}
        cure_list, no_cure = [], 0
        for cur in self.state.sides[pokemon.side].active:
            if cur is None or not cur.status or cur.show_cure:
                continue
            names = cur.species.abilities
            if "Natural Cure" not in names or len(names) < 2:
                continue
            if cur is not pokemon and id(cur) not in switching:
                continue
            if cur.ability_id == NATURAL_CURE:
                cure_list.append(cur)
            else:
                no_cure += 1
        for cur in cure_list:
            cur.show_cure = not (cure_list and no_cure)

    def _take_item(self, pokemon: BattlePokemon, user: BattlePokemon) -> None:
        """Knock Off ``onAfterHit``: ``takeItem()`` (Booster Energy stays with a Paradox
        Pokémon), then the move's ``-enditem`` message."""
        # (takeItem() without a source: the holder is its own source; a plate leaves even
        # when Arceus knocks it off, 044)
        if not can_be_taken(pokemon.held_item, pokemon.species):
            return
        if self._sticky_hold(pokemon, user):
            return
        name = item_name(pokemon.held_item)
        self._lose_item(pokemon, unburden=True)  # Unburden onTakeItem
        self._emit("enditem", target=pokemon.label, detail=name, actor=user.label)

    def _lose_item(self, pokemon: BattlePokemon, *, unburden: bool) -> None:
        pokemon.item = ""
        pokemon.mirror_boosts.clear()  # 040-3b: the item's onEnd / clearEffectState
        if unburden and pokemon.ability_id == UNBURDEN:
            pokemon.unburden = True  # addVolatile('unburden')

    def _heal(self, pokemon: BattlePokemon, amount: float, cause: str) -> bool:
        """``battle.heal``: at least 1, truncated; nothing at full HP."""
        if HEAL_BLOCK in pokemon.timed:
            return False  # 023: healblock onTryHeal
        heal = max(1, int(amount))
        if pokemon.ability_id == "ripen":  # 043-4h: Ripen's onTryHeal (before the HP checks)
            if cause in ("item: leftovers", "item: berry juice"):
                self._emit("activate", target=pokemon.label, detail="ability: Ripen")
            if cause.startswith("item: ") and cause.endswith(" berry"):
                heal *= 2
        healed = min(heal, pokemon.max_hp - pokemon.hp)
        if pokemon.hp <= 0 or healed <= 0:
            return False
        pokemon.hp += healed
        self._emit("heal", target=pokemon.label, value=healed, hp=pokemon.hp, detail=cause)
        return True

    def _damage_event(self, target: BattlePokemon, damage: int, *, by_move: bool) -> int:
        """032 (R2): the holder's item handlers of spreadDamage's runEvent('Damage') (not for
        directDamage or Struggle's recoil): Focus Band draws randomChance(1, 10) first, for
        every damage, then leaves 1 HP from a move's (confusion's counts as a move's)."""
        focus_band = target.item == FOCUS_BAND and self.prng.random_chance(1, 10)
        if focus_band and damage >= target.hp and by_move:
            self._emit("activate", target=target.label, detail="item: Focus Band")
            return target.hp - 1
        return damage

    def _confusion_damage_event(self, pokemon: BattlePokemon, damage: int) -> int:
        """043 review: runEvent('Damage') for a confusion self-hit (its effect is a Move):
        Sturdy's onDamage at full HP (priority -30; 044), Focus Sash's (-40), then Focus
        Band's."""
        if pokemon.ability_id == STURDY and pokemon.hp == pokemon.max_hp and damage >= pokemon.hp:
            self._emit("ability", target=pokemon.label, detail="Sturdy")
            damage = pokemon.hp - 1
        if (
            pokemon.item == FOCUS_SASH
            and pokemon.hp == pokemon.max_hp
            and damage >= pokemon.hp
            and self._use_item(pokemon)
        ):
            damage = pokemon.hp - 1
        return self._damage_event(pokemon, damage, by_move=True)

    def _pledge_condition(
        self,
        user: BattlePokemon,
        move: Move,
        targets: list[BattlePokemon],
        dealt: dict[int, int],
        subbed: set[int],
    ) -> None:
        """041-5: a combined Pledge's sideCondition on the target's side (runMoveEffects, a
        target that took the hit) or the rainbow's self.sideCondition (selfDrops: behind a
        substitute too)."""
        assert self._pledge_source is not None
        _, condition = PLEDGE_COMBOS[frozenset({move.id, self._pledge_source})]
        field_state = self.state.field
        if condition == WATER_PLEDGE:
            if any(id(t) in dealt or id(t) in subbed for t in targets):
                add_side_condition(field_state, user.side, condition, emit=self._emit_kw)
            return
        for target in targets:
            if id(target) in dealt:
                add_side_condition(field_state, target.side, condition, emit=self._emit_kw)

    def _magic_guard(self, pokemon: BattlePokemon, source: BattlePokemon | None = None) -> bool:
        """043-3c: Magic Guard's onDamage: false for any damage whose effect is not a
        move (before Focus Band's roll); an Ability's shows ``-activate`` on its source."""
        if pokemon.ability_id != "magicguard":
            return False
        if source is not None:
            name = get_dex().ability(source.ability_id).name  # type: ignore[union-attr]
            self._emit("activate", target=source.label, detail=f"ability: {name}")
        return True

    def _chip(
        self,
        pokemon: BattlePokemon,
        amount: float,
        cause: str,
        source: BattlePokemon | None = None,
    ) -> int:
        """``battle.damage`` from an effect (not a move): at least 1, truncated. ``source``:
        an Ability's holder (043-3c: Magic Guard's ``-activate``)."""
        if pokemon.hp <= 0:
            return 0
        if self._magic_guard(pokemon, source):
            return 0
        dealt = max(1, int(amount))
        dealt = min(self._damage_event(pokemon, dealt, by_move=False), pokemon.hp)
        pokemon.hp -= dealt
        self._emit("damage", target=pokemon.label, value=dealt, hp=pokemon.hp, detail=cause)
        return dealt

    def _item_residual(self, pokemon: BattlePokemon, item: str) -> None:
        """Leftovers / Black Sludge (order 5), Flame / Toxic Orb (28), White Herb (29)."""
        if pokemon.item != item:
            return
        if item == LEFTOVERS or (item == BLACK_SLUDGE and "Poison" in pokemon.types):
            self._heal(pokemon, pokemon.max_hp / 16, f"item: {item_name(item).lower()}")
        elif item == BLACK_SLUDGE:
            self._chip(pokemon, pokemon.max_hp / 8, "item: black sludge")
        elif item in (FLAME_ORB, TOXIC_ORB):
            self._set_status(pokemon, "brn" if item == FLAME_ORB else "tox", pokemon,
                             status_move=False)  # fmt: skip
        elif item == WHITE_HERB:
            self._white_herb(pokemon)
        elif item == EJECT_PACK:
            self._eject_pack(pokemon)
        elif item == MIRROR_HERB:
            self._mirror_herb(pokemon)
        elif item == STICKY_BARB:
            self._chip(pokemon, pokemon.max_hp / 8, "item: sticky barb")  # 040-4b
        elif item == MICLE_BERRY and self._berry_low(pokemon):
            # 040-3b: onEat: addVolatile('micleberry') (duration 2, no message)
            self._eat_item(pokemon, lambda: pokemon.timed.__setitem__(MICLE_BERRY, 2))

    def _micle(self, user: BattlePokemon, move: Move, accuracy: int | None) -> int | None:
        """040-3b: the micleberry volatile's onSourceAccuracy (runEvent('Accuracy'), not for
        an OHKO move): ``-enditem … Micle Berry``, removeVolatile, a number x4915/4096."""
        if MICLE_BERRY not in user.timed or OHKO in move.keys:
            return accuracy
        self._emit("enditem", target=user.label, detail="Micle Berry")
        del user.timed[MICLE_BERRY]
        return None if accuracy is None else modify(accuracy, MICLE_MODIFIER, 4096)

    def _eject_pack(self, pokemon: BattlePokemon) -> None:
        """Eject Pack (014): useItem once a stat was lowered. onUseItem: not without a Pokémon
        to bring in, nor while a Pokémon on the field already has ``switchFlag === true``;
        onUse sets ``switchFlag = true``."""
        if pokemon.item != EJECT_PACK or not pokemon.eject_pending:
            return
        if pokemon.hp <= 0 or pokemon.position is None:
            return
        if not self.state.sides[pokemon.side].bench():
            return
        if pokemon.commanding or pokemon.commanded_by is not None:
            return  # 028
        if any(p.switch_flag is True for p in self.state.all_active()):
            return
        if self._use_item(pokemon):
            pokemon.eject_pending = False
            pokemon.switch_flag = True

    def _white_herb(self, pokemon: BattlePokemon) -> None:
        """White Herb: when a stat is lowered, useItem, then the lowered stats go back to 0."""
        if pokemon.item != WHITE_HERB:
            return
        lowered = [name for name, stage in pokemon.boosts.items() if stage < 0]
        if lowered and self._use_item(pokemon):
            for name in lowered:
                pokemon.boosts[name] = 0
            self._emit("clearnegativeboost", target=pokemon.label)

    def _modify_move_event(self, user: BattlePokemon, move: Move) -> bool:
        """useMoveInner's runEvent('ModifyMove'): the user's volatiles with onModifyMove
        (throatchop, 023: healblock) tie (same holder, subOrder 2) and are shuffled. A chosen
        move met them at BeforeMove (priority 6) already; a called one (Sleep Talk) did not
        (I-001, old bug from 021/023): a sound move (a heal move) stops with ``cant``. True
        when the move stops (the event returns false)."""
        handlers = [v for v in user.timed if v in (THROAT_CHOP, HEAL_BLOCK)]
        speed_sort(handlers, self.prng, lambda a, b: 0)
        for handler in handlers:
            if handler == THROAT_CHOP and "sound" in move.flags:
                self._emit("cant", actor=user.label, detail="move: Throat Chop")
                return True
            if handler == HEAL_BLOCK and "heal" in move.flags:
                self._emit("cant", actor=user.label, detail="move: Heal Block")
                return True
        return False

    def _use_move(
        self,
        user: BattlePokemon,
        move: Move,
        targeting: Targeting,
        base_target: str,
        prankster_boosted: bool | None = None,
        pressure_slot: int | None = None,
    ) -> bool | None:
        """useMoveInner from the target change on: the move line, TryMove, the hit steps.
        ``pressure_slot`` (033): the move slot Pressure takes PP from (None: no Pressure, as for
        a locked move, Struggle, or a bounced move).

        Returns the move's result (015, ``moveThisTurnResult``): True when it did something,
        None when every target was stopped by a NOT_FAIL effect (Protect, the guards), False
        otherwise."""
        changed = move.target != base_target
        # 033 (T011, old bug from 012/029): Sheer Force's onModifyMove sets move.hasSheerForce
        # once; a gas holder knocked out later does not take the secondaries back
        outer_sheer, self._sheer_force = self._sheer_force, has_sheer_force(user.ability_id, move)
        try:
            return self._use_move_inner(
                user, move, targeting, base_target, prankster_boosted, pressure_slot, changed
            )
        finally:
            self._sheer_force = outer_sheer

    def _negated(self, user: BattlePokemon) -> bool:
        """``move.hasSheerForce && pokemon.hasAbility('sheerforce')`` (033): the snapshot, and
        the ability now."""
        return self._sheer_force and user.ability_id == SHEER_FORCE

    def _use_move_inner(
        self,
        user: BattlePokemon,
        move: Move,
        targeting: Targeting,
        base_target: str,
        prankster_boosted: bool | None,
        pressure_slot: int | None,
        changed: bool,
    ) -> bool | None:
        curse_random = False
        self._active_move = move  # 041-5: setActiveMove
        if move.id == CURSE:
            # 032 (R15): onModifyMove: a non-Ghost user's nonGhostTarget (self: getRandomTarget
            # gives the user, no draw); a Ghost aiming at its ally: randomNormal (two draws)
            if "Ghost" not in user.types:
                move = replace(move, target="self")
                targeting = Targeting([user], spread=False)
            elif targeting.targets and targeting.targets[0].side == user.side:
                move = replace(move, target="randomNormal")
                curse_random = True
        if curse_random:
            self._random_foe_draw(user)
        if changed:  # useMoveInner: getRandomTarget after the move's ModifyMove
            self._random_foe_draw(user)
        if self._modify_move_event(user, move):
            # the move is false: ``baseTarget !== move.target`` holds, and getRandomTarget of
            # no move (the empty move) picks a random foe; then useMoveInner returns false
            self._random_foe_draw(user)
            return False
        if curse_random:
            targeting = random_targeting(self.state, user, move, self.prng)
        if changed:  # ... and after runEvent('ModifyMove')
            self._random_foe_draw(user)
            foes = self.state.sides[foe_of(user.side)].alive_active()
            targeting = Targeting(foes, spread=len(foes) > 1)
        if move.id in FUTURE_MOVES and not targeting.targets:
            # 041-4b: getTarget's last resort with no foe standing: foe.active[0] (fainted);
            # getMoveTargets keeps a fainted target for a futuremove
            foe = self.state.sides[foe_of(user.side)].active[0]
            if foe is not None:
                targeting = Targeting([foe], spread=False)
        if move.id in METAL_BURSTS and user.damaged_log:
            # 041-4a: onModifyTarget: the Pokemon at the last damaging foe's slot (also from
            # an earlier turn); getMoveTargets picks a random foe when it fainted (one draw)
            source, position, _, _ = user.damaged_log[-1]
            attacker = self.state.at(source.side, position)
            if attacker is None or attacker.fainted:
                attacker = self._random_foe_draw(user)
            if attacker is not None:  # 041-6f: then getMoveTargets' RedirectTarget (Follow Me)
                attacker = redirect(self.state, user, move, attacker)
            targeting = Targeting([attacker] if attacker else [], spread=False)
        first = targeting.targets[0].label if targeting.targets else None
        if move.target == "allies":
            first = user.label  # 015: the move line names the user
        self._emit("move", actor=user.label, target=first, detail=move.name)
        targeting = self._ability_redirect(user, move, targeting)  # getMoveTargets (012)
        if (
            move.id in REFLECT_CATEGORY
            and move.id in user.timed
            and user.counter_hit is not None
            and not redirecting_foes(self.state, user)
        ):
            # 041-4a: the volatile's onRedirectTarget (priority -1, after Follow Me's)
            side, position, _ = user.counter_hit
            attacker = self.state.at(side, position)
            if attacker is not None and not attacker.fainted:
                targeting = Targeting([attacker], spread=False)
            else:
                targeting = Targeting([], spread=False)
        if pressure_slot is not None:
            self._pressure(user, move, targeting.targets, pressure_slot)
        if move.id == "darkvoid" and user.species.base_species != "Darkrai" and not self._bounced:
            self._emit("fail", actor=user.label)  # 041-6f: onTry: null
            return None
        if move.id in SPENT_TYPE and SPENT_TYPE[move.id] not in user.types:
            self._emit("fail", actor=user.label)  # 041-1g: onTryMove: null
            return None
        if "charge" in move.flags and not self._charge(user, move, targeting):
            return None  # 020: onTryMove returned null (charging)
        if (
            move.id == "pollenpuff"
            and HEAL_BLOCK in user.timed
            and targeting.targets
            and targeting.targets[0].side == user.side
        ):
            self._emit("cant", actor=user.label, detail="move: Heal Block")  # 023: onTryMove
            return False
        if move.id in DAMP_MOVES and self._damp(user):
            return False  # 043-3b: runEvent('TryMove') before the selfdestruct faint
        if move.id in SELF_KO_MOVES:
            user.hp = 0  # 041-1c: useMoveInner's selfdestruct 'always': faint() (HP 0)
        if move.id == ECHOED_VOICE:
            # 041-1f: onTryMove (singleEvent TryMove: before the no-target -fail and before
            # runEvent('TryMove'), review P3)
            self._echoed_voice()
        if not targeting.targets and move.target != "foeSide":
            # 020: a hazard needs no foe on the field (tryMoveHit on the side)
            self._emit("fail", actor=user.label)
            return False
        if self._priority_blocked(user, move, targeting.targets):
            return False  # TryMove (011): after the move line and the PP
        if user.metronome is not None:
            self._metronome_item(user, move)  # 042-1: the volatile's onTryMove (-2)
        if move.id == "round":
            self._round()  # 041-1f: onTry
        if move.id == "hyperspacefury" and user.species.name != "Hoopa-Unbound":
            self._emit("fail", actor=user.label)  # 042-5: onTry (null)
            return None
        if move.id == "aurawheel" and user.species.base_species != "Morpeko":
            self._emit("fail", actor=user.label)  # 042-3: onTry (null)
            return None
        if move.id in ("fakeout", "firstimpression") and user.active_move_actions > 1:
            self._emit("fail", actor=user.label)  # fakeout onTry (support.HAND_PORTED_MOVES)
            return False
        if move.id in REFLECT_CATEGORY and (move.id not in user.timed or user.counter_hit is None):
            self._emit("fail", actor=user.label)  # 041-4a: onTry (no volatile, slot null)
            return False
        if move.id == DESTINY_BOND and user.destiny_bond:
            user.destiny_bond = False  # 041-4e: onPrepareHit: !removeVolatile -> -fail
            self._emit("fail", actor=user.label)
            return False
        if move.id == LAST_RESORT and not _last_resort_ok(user):
            self._emit("fail", actor=user.label)  # 041-4e: onTry
            return False
        if move.id == "stuffcheeks" and not _holds_berry(user):
            self._emit("fail", actor=user.label)  # 041-6f: onTry
            return False
        if move.id == "belch" and not user.ate_berry:
            self._emit("fail", actor=user.label)  # 041-4e: onTry
            return False
        if (move.id in (SPIT_UP, SWALLOW) and user.stockpile is None) or (
            move.id == STOCKPILE and user.stockpile is not None and user.stockpile[0] >= 3
        ):
            self._emit("fail", actor=user.label)  # 041-4d: onTry
            return False
        if move.id in FUTURE_MOVES:  # 041-4b: onTry (NOT_FAIL: no hit now)
            return self._future_sight(user, targeting.targets[0], move.id)
        if move.id in METAL_BURSTS and (
            not user.damaged_log or user.damaged_log[-1][3] != self.state.turn
        ):
            self._emit("fail", actor=user.label)  # 041-4a: onTry (!lastDamagedBy?.thisTurn)
            return False
        if move.id == "snore" and not _asleep(user):
            self._emit("fail", actor=user.label)  # 041-3d: onTry (043-3c: or Comatose)
            return False
        if move.id in ATTACK_FIRST_MOVES and not self._foe_will_attack(targeting.targets[0]):
            self._emit("fail", actor=user.label)  # suckerpunch / thunderclap onTry (015)
            return False
        if move.id == POLTERGEIST and not targeting.targets[0].held_item:
            self._emit("fail", actor=user.label)  # 033 (R8): onTry
            return False
        if move.id == UPPER_HAND and not self._foe_will_attack(
            targeting.targets[0], with_priority=True
        ):
            self._emit("fail", actor=user.label)  # upperhand onTry (021 R7)
            return False
        if move.id == SLEEP_TALK and not _asleep(user):
            self._emit("fail", actor=user.label)  # sleeptalk onTry (025; 043-3c: Comatose)
            return False
        if move.id == "steelroller" and self.state.field.terrain is None:
            self._emit("fail", actor=user.label)  # steelroller onTry (010)
            return False
        if move.target in ("all", "allySide", "foeSide", "allyTeam"):
            self._protean(user, move)  # 043-5c: tryMoveHit's PrepareHit
            return self._run_field_move(user, move)
        if move.id in PLEDGES and self._pledge_wait(user, move):
            return False  # 041-5: onPrepareHit null (no -fail)
        if move.id == FLING:
            flung = self._fling(user, move)  # 032 (R8): onPrepareHit
            if flung is None:
                self._emit("fail", actor=user.label)
                return False
            move = flung
        # PrepareHit (009): Protect and its variants need a later action and the stall check
        # (no draw when nothing acts later); Ally Switch its own counter.
        if is_stalling(move) and not (self._will_act() and stall_check(user, self.prng)):
            self._emit("fail", actor=user.label)
            return False
        if move.id == "allyswitch" and not ally_switch_check(user, self.prng):
            self._emit("fail", actor=user.label)
            return False
        self._protean(user, move)  # 043-5c: runEvent('PrepareHit')

        targets = targeting.targets
        self._not_fail_blocks = 0
        self._sure_hit = False
        self._smart = targeting.smart
        aimed = len(targets)
        targets = self._invulnerability(user, move, targets)  # 026 (R8)
        if move.target not in USER_TARGETS:
            targets = self._try_hit(user, move, targets)  # hitStepTryHitEvent (009)
        # 030: hitStepTypeImmunity's runImmunity(move, !smartTarget): silent for every target
        # while it is on; trySpreadMoveHit turns it off after a step with a failure
        quiet = self._smart

        dex = get_dex()
        # hitStepTypeImmunity: status moves ignore type immunity unless they say otherwise.
        checks_type = move.category != "Status" or move.ignore_immunity is False
        hit: list[BattlePokemon] = []
        if prankster_boosted is None:  # (a called move keeps the caller's, 025)
            prankster_boosted = move.category == "Status"
        prankster = user.ability_id == PRANKSTER and prankster_boosted
        for target in targets:
            if checks_type and type_immune(move, user.combatant(), target.combatant()):
                self._smart = False
                if not quiet:
                    self._emit("immune", target=target.label)
            elif (
                "powder" in move.flags
                and target is not user
                and dex.effect_immune("powder", target.types)
            ):
                self._emit("immune", target=target.label)  # hitStepTryImmunity
            elif move.id == ENDEAVOR and not user.hp < target.hp:
                self._emit("immune", target=target.label)  # 023: onTryImmunity
            elif move.id == "attract" and not _opposite_genders(target, user):
                self._emit("immune", target=target.label)  # 041-6f: onTryImmunity
            elif move.id == "dreameater" and not _asleep(target):
                self._emit("immune", target=target.label)  # 041-6b: onTryImmunity
            elif move.id == LEECH_SEED and "Grass" in target.types:
                self._emit("immune", target=target.label)  # 041-4c: onTryImmunity
            elif move.id == "worryseed" and target.base_ability_id in ("truant", "insomnia"):
                self._emit("immune", target=target.label)  # 041-3h: onTryImmunity
            elif prankster and target.side != user.side and "Dark" in target.types:
                self._emit("immune", target=target.label)  # Prankster vs Dark (gen 7+, 011)
            else:
                hit.append(target)
        self._accuracy_last = hit[-1] if hit else None  # 032: activeTarget (the last target)
        always_hits = move.id == "toxic" and "Poison" in user.types
        if move.target == "self" and move.category == "Status":
            always_hits = True  # 032: hitStepAccuracy (Clangorous Soul's accuracy 100)
        numeric = move.accuracy is not None and not self._sure_hit
        if always_hits or not numeric:
            for target in hit:
                if OHKO not in move.keys:
                    # 032 review: ModifyAccuracy runs even for accuracy true (its handlers
                    # are still sorted: a tie draws)
                    self._accuracy_modifier(user, move, target)
                if numeric:
                    # 028: the stages are still looked up (ModifyBoost) before alwaysHit
                    self._accuracy_boost_draws(user, move, target)
                if not always_hits:
                    self._micle(user, move, None)  # 040-3b: runEvent('Accuracy') (true)
        else:
            assert move.accuracy is not None  # (numeric)
            landed = []
            for target in hit:
                if OHKO in move.keys:
                    accuracy = self._ohko_accuracy(user, move, target)
                    if accuracy is None:
                        self._emit("immune", target=target.label)  # -immune … [ohko]
                        continue
                    # 023: glaiverush onAccuracy (true: no draw)
                    sure = target.glaive_rush or _locked_on(user, target)  # (041-6f)
                    if sure or self.prng.random_chance(accuracy, 100):
                        landed.append(target)
                    else:
                        self._emit("miss", actor=user.label, target=target.label)
                    continue
                modifier = self._accuracy_modifier(user, move, target)  # 032: ModifyAccuracy
                self._accuracy_boost_draws(user, move, target)  # 028
                # ModifyBoost: Unaware (012); Mind's Eye ignores evasion
                accuracy_stage = 0 if target.ability_id == UNAWARE else user.boosts["accuracy"]
                evasion = target.boosts["evasion"]
                if (
                    user.ability_id in (UNAWARE, MINDS_EYE, KEEN_EYE, "illuminate")
                    or move.id in IGNORES_DEFENSIVE
                ):
                    evasion = 0  # (015: Sacred Sword's ignoreEvasion)
                stage = max(-6, min(6, accuracy_stage)) - evasion
                accuracy = modify(_wonder_skin(move, target), modifier, 4096)  # (before the stages)
                accuracy = boosted_accuracy(accuracy, stage)
                sure = self._accuracy_true(target, move, user)
                micled = self._micle(user, move, None if sure else accuracy)  # 040-3b
                if micled is not None:
                    accuracy = micled
                # 023: glaiverush onAccuracy (true: no draw); 034 (R5): minimize's
                if sure or self.prng.random_chance(accuracy, 100):
                    landed.append(target)
                else:
                    if self._smart:
                        self._smart = False  # 030: the first miss is silent
                    else:
                        self._emit("miss", actor=user.label, target=target.label)
                    if user.item == BLUNDER_POLICY and self._use_item(user):
                        # 040-2: hitStepAccuracy (not an OHKO move): boost({spe: 2}, pokemon)
                        apply_boosts(
                            user, {"spe": 2}, primary=True, foes_left=self._foes_left(user),
                            emit=self._emit_kw, source=user,
                        )  # fmt: skip
            hit = landed
        if breaks_protect(move):
            self._break_protect(move, hit)  # hitStepBreakProtect (Feint)

        self._move_succeeded = False  # useMoveInner's moveResult
        self._total_damage = 0
        if move.category == "Status":
            self._run_status_move(user, move, hit)
        else:
            self._run_hits(user, move, hit, spread=targeting.spread)
            if move.self_boost and self._move_succeeded and not self.state.ended:
                self._boost(user, move.self_boost, user)  # 023: selfBoost (Scale Shot)
            if (
                "selfSwitch" in move.keys
                and self._move_succeeded
                and user.hp > 0
                and user.commanded_by is None  # 028: not while commanded
                and user not in self._eject_cancelled  # 040-3: Eject Button's source.switchFlag
            ):
                user.switch_flag = move.id  # 014: runMoveEffects (U-turn, Volt Switch, ...)
        self._eject_cancelled.clear()
        if self._move_succeeded and not self._negated(user):
            # 041-1d: the move's onAfterMoveSecondarySelf (singleEvent, first): the target
            # (the last of getMoveTargets') has fainted or has no HP
            if (
                move.id == "fellstinger"
                and user.hp > 0
                and targeting.targets
                and targeting.targets[-1].hp <= 0
            ):
                self._boost(user, {"atk": 3}, user)
            self._after_move_secondary_self(user, move)
        if self._move_succeeded:
            return True
        if move.category == "Status" and hit and not _has_hit_effect(move):
            return True  # spreadMoveHit: no effect to fail (Splash) -> didSomething is true
        if move.id == STEEL_BEAM:  # 033 (R9): onMoveFail (after a miss or a block)
            self._steel_beam_cost(user)
        if move.id in CRASH_MOVES and user.hp > 0:  # 041-1c: onMoveFail
            self._crash(user, move)
        # trySpreadMoveHit: no target left and no step returned false -> null
        return None if aimed and self._not_fail_blocks == aimed else False

    def _after_move_secondary_self(self, user: BattlePokemon, move: Move) -> None:
        """``runEvent('AfterMoveSecondarySelf', user)`` (013): Life Orb's recoil (not for status
        moves), Throat Spray after a sound move. 028: before it, the move's own handler
        (singleEvent): Order Up."""
        if move.id == ORDER_UP:
            self._order_up(user)
        if (
            move.id == "relicsong"
            and user.species.base_species == "Meloetta"
            and user.transform_base is None
        ):
            # 042-4: onAfterMoveSecondarySelf (not transformed): formeChange, not for good
            name = "Meloetta" if user.species.name == "Meloetta-Pirouette" else "Meloetta-Pirouette"
            forme = get_dex().species(name)
            assert forme is not None
            user.set_species(forme)
            self._emit("formechange", target=user.label, detail=forme.name)
        if user.ability_id == "magician":
            self._magician(user, move)  # 042-5: the ability (subOrder 7) before the item
        if user.item == LIFE_ORB and move.category != "Status":
            self._chip(user, user.max_hp / 10, "item: life orb")
        elif user.item == SHELL_BELL and self._total_damage and not user.force_switch:
            # 040-4b: move.totalDamage / 8
            self._heal(user, self._total_damage / 8, "item: shell bell")
        elif user.item == THROAT_SPRAY and "sound" in move.flags:
            self._use_item(user)

    def _accuracy_modifier(self, user: BattlePokemon, move: Move, target: BattlePokemon) -> int:
        """032 (R1): runEvent('ModifyAccuracy', target, user): the target's onModifyAccuracy
        (Snow Cloak and Sand Veil -1, Bright Powder -2) and the user's onSourceModifyAccuracy
        (Wide Lens, Zoom Lens -2), sorted by priority, speed and subOrder (ability 7, item 8),
        ties shuffled, collected also while ignored; their chainModify gives one 4096-based
        modifier (026: Snow Cloak)."""
        weather = self.state.field.active_weather
        handlers: list[tuple[int, int, int, int | None]] = []  # priority, speed, subOrder, mod
        for ability, needs in ((SNOW_CLOAK, SNOW), (SAND_VEIL, SAND)):
            if target.base_ability_id == ability:
                applies = target.ability_id == ability and weather == needs
                handlers.append((-1, target.cached_speed, 7, 3277 if applies else None))
        if target.item in TARGET_ACCURACY_ITEMS:
            priority, mod = TARGET_ACCURACY_ITEMS[target.item]
            handlers.append((priority, target.cached_speed, 8, mod))
        numeric_acc = move.accuracy is not None and not self._sure_hit
        if user.base_ability_id == "compoundeyes":  # 043-2b: onSourceModifyAccuracy (-1)
            applies = user.ability_id == "compoundeyes" and numeric_acc
            handlers.append((-1, user.cached_speed, 7, 5325 if applies else None))
        if target.base_ability_id == "tangledfeet":  # 043-2b: onModifyAccuracy (-1)
            applies = (
                target.ability_id == "tangledfeet" and numeric_acc and bool(target.confusion_turns)
            )
            handlers.append((-1, target.cached_speed, 7, 2048 if applies else None))
        if user.base_ability_id == "hustle":  # 043-2a: onSourceModifyAccuracy (-1)
            numeric = move.accuracy is not None and not self._sure_hit
            applies = user.ability_id == "hustle" and move.category == "Physical" and numeric
            handlers.append((-1, user.cached_speed, 7, 3277 if applies else None))
        if user.item in SOURCE_ACCURACY_ITEMS:
            priority, mod = SOURCE_ACCURACY_ITEMS[user.item]
            if user.item == ZOOM_LENS and self._will_move(target):
                mod = 0  # !queue.willMove(target): only after the target moved
            handlers.append((priority, user.cached_speed, 8, mod or None))
        if GRAVITY in self.state.field.pseudo_weather:
            # 041-4e: Gravity's onModifyAccuracy (a field handler: speed 0, subOrder 5),
            # x6840/4096 on a numeric accuracy
            numeric = move.accuracy is not None and not self._sure_hit
            handlers.append((0, 0, 5, 6840 if numeric else None))
        speed_sort(handlers, self.prng, _by_handler_order)
        modifier = 4096
        for *_, handler_mod in handlers:
            if handler_mod is not None:
                modifier = chain_modify(modifier, handler_mod, 4096)
        return modifier

    def _accuracy_boost_draws(self, user: BattlePokemon, move: Move, target: BattlePokemon) -> None:
        """028 (R5): hitStepAccuracy's ModifyBoost events: the user's (no supported move has
        ignoreAccuracy), then the target's unless the move ignores evasion (Mind's Eye's
        onModifyMove, Sacred Sword)."""
        self._modify_boost(user)
        if (
            user.ability_id not in (MINDS_EYE, KEEN_EYE, "illuminate")
            and move.id not in IGNORES_DEFENSIVE
        ):
            self._modify_boost(target)

    def _order_up(self, user: BattlePokemon) -> None:
        """028 (R4): Order Up's onAfterMoveSecondarySelf. A commanded user raises one stat by
        its Tatsugiri's form (even a fainted one): Droopy Def, Stretchy Spe, else Atk
        (``boost(…, pokemon, pokemon)``, the move's effect: a stuck stage is shown)."""
        tatsugiri = user.commanded_by
        if tatsugiri is None or tatsugiri.species.base_species != "Tatsugiri":
            return
        name = tatsugiri.species.name
        stat = "def" if name.endswith("-Droopy") else "spe" if name.endswith("-Stretchy") else "atk"
        apply_boosts(
            user, {stat: 1}, primary=True, foes_left=self._foes_left(user), emit=self._emit_kw,
            source=user,
        )  # fmt: skip

    # -- 009: protection, redirection and helping ----------------------------------------

    def _will_act(self) -> bool:
        """``queue.willAct()``: a move or switch action is still queued this turn (gen 9 keeps
        the actions of Pokémon that fainted)."""
        return self._queue is not None and bool(self._queue)

    def _will_move(self, pokemon: BattlePokemon) -> bool:
        """``queue.willMove(pokemon)``."""
        if pokemon.fainted or self._queue is None:
            return False
        return any(a.pokemon is pokemon and a.kind == "move" for a in self._queue)

    def _foe_will_attack(self, target: BattlePokemon, *, with_priority: bool = False) -> bool:
        """Sucker Punch's ``onTry`` (015): the target's queued move action (``willMove``) is a
        damaging move. It looks at the chosen move, before Encore's OverrideAction.
        ``with_priority``: Upper Hand's (021), also with a priority above 0.1 (the priority
        getActionSpeed last wrote to the move: Prankster, Grassy Glide)."""
        if target.fainted or self._queue is None:
            return False
        if not with_priority and MUST_RECHARGE in target.timed:
            return False  # 030 (review P2): suckerpunch / thunderclap check mustrecharge too
        for action in self._queue:
            if action.pokemon is target and isinstance(action.choice, MoveChoice):
                if with_priority and action.priority <= 0:
                    return False
                return chosen_move(target, action.choice).category != "Status"
        return False

    def _invulnerability(
        self, user: BattlePokemon, move: Move, targets: list[BattlePokemon]
    ) -> list[BattlePokemon]:
        """026 (R8): hitStepInvulnerabilityEvent, the first hit step (left to right, no draws):
        a target vanished by Phantom Force (``onInvulnerability: false``) is missed, except by
        Helping Hand and (gen 8+) a Poison type's Toxic."""
        if move.id == "helpinghand":
            return targets
        poison_toxic = move.id == "toxic" and "Poison" in user.types
        kept = []
        for target in targets:
            # 028: a commanding Tatsugiri is missed, even by a Poison type's Toxic
            state = vanished(target)
            if target.commanding or (
                not poison_toxic
                and state
                and move.id not in HITS_VANISHED.get(state, ())
                and not _locked_on(user, target)  # 041-6f: onSourceInvulnerability 0
            ):
                if self._smart:
                    self._smart = False  # 030: the first failure is silent
                else:
                    self._emit("miss", actor=user.label, target=target.label)
            else:
                kept.append(target)
        return kept

    def _try_hit(
        self, user: BattlePokemon, move: Move, targets: list[BattlePokemon]
    ) -> list[BattlePokemon]:
        """``runEvent('TryHit', targets)``: handlers left to right by priority (no draws):
        Wide Guard / Quick Guard (priority 4), then Protect and its variants (3). A blocked
        target drops out with only ``-activate`` (NOT_FAIL)."""
        blocked: set[int] = set()
        terrain = self.state.field.terrain
        for target in targets:
            for guard in GUARDS:
                if guard in self.state.field.sides[target.side] and guard_blocks(guard, move):
                    self._emit("activate", target=target.label, detail=GUARD_NAMES[guard])
                    blocked.add(id(target))
                    self._not_fail_blocks += 1  # 015: NOT_FAIL
                    break
            else:
                # 010: Psychic Terrain (also priority 4; field handlers after side ones)
                grounded = is_grounded(
                    target.types,
                    target.ability_id,
                    target.item,
                    target.pinned,
                    rising="magnetrise" in target.timed,
                )
                from_ally = target.side == user.side
                if blocks_priority(terrain, move, target_grounded=grounded, from_ally=from_ally):
                    self._emit("activate", target=target.label, detail="move: Psychic Terrain")
                    blocked.add(id(target))
        for target in targets:
            if id(target) in blocked:
                continue
            volatile = protection_of(target)
            if volatile is None or not protects_against(volatile, move):
                continue
            if self._smart:
                self._smart = False  # 030: the protect effects' onTryHit, silent for smartTarget
            else:
                self._emit("activate", target=target.label, detail="move: Protect")
            blocked.add(id(target))
            self._not_fail_blocks += 1  # 015: NOT_FAIL
            if self._makes_contact(move, user):
                self._contact_effect(volatile, user, target)
        for target in targets:  # 012: Overcoat (priority 1); 032: Sap Sipper (1)
            if id(target) in blocked or target is user:
                continue
            if target.ability_id == SAP_SIPPER and move.type == "Grass":
                blocked.add(id(target))
                if not apply_boosts(
                    target, {"atk": 1}, primary=False, foes_left=self._foes_left(target),
                    emit=self._emit_kw, source=user, ability="Sap Sipper",
                ):  # fmt: skip
                    self._emit("immune", target=target.label)
                continue
            if target.ability_id != OVERCOAT:
                continue
            if "powder" in move.flags and not get_dex().effect_immune("powder", target.types):
                self._emit("immune", target=target.label)
                blocked.add(id(target))
        for target in targets:  # 031 (R1): Magic Bounce (priority 1)
            if id(target) in blocked or target is user or not self._reflects(target, move):
                continue
            blocked.add(id(target))  # onTryHit's null: false, not NOT_FAIL (no -fail)
            self._bounce(target, move, user)
        # priority 0, per target its ability, then its item: Good as Gold (011), the absorbing
        # abilities (012), Safety Goggles (013)
        for target in targets:
            if id(target) in blocked or target is user:
                continue
            if self._ability_try_hit(user, move, target):
                blocked.add(id(target))
            elif (
                target.item == SAFETY_GOGGLES
                and "powder" in move.flags
                and not get_dex().effect_immune("powder", target.types)
            ):
                self._emit("activate", target=target.label, detail="item: Safety Goggles")
                blocked.add(id(target))
        return [t for t in targets if id(t) not in blocked]

    def _reflects(
        self, holder: BattlePokemon, move: Move, target: BattlePokemon | None = None
    ) -> bool:
        """031 (R1): Magic Bounce's condition: a reflectable move that has not bounced yet, the
        event's target not vanished (isSemiInvulnerable: the holder for onTryHit, the first foe
        for onAllyTryHitSide; Mold Breaker and Neutralizing Gas empty ``ability_id``)."""
        return (
            holder.ability_id == MAGIC_BOUNCE
            and "reflectable" in move.flags
            and not self._bounced
            and not vanished(target or holder)
        )

    def _bounce(self, holder: BattlePokemon, move: Move, source: BattlePokemon) -> None:
        """031 (R3): ``useMove(getActiveMove(move.id), holder, {target: source})`` with
        hasBounced and no pranksterBoosted. The original move's priority, no PP, no lastMove,
        no choicelock; ``[from] ability: Magic Bounce``. useMove writes the holder's
        moveThisTurnResult. The running move's state is kept around the nested move."""
        fresh = get_dex().move(move.id)
        assert fresh is not None
        saved = (self._not_fail_blocks, self._sure_hit, self._smart, self._move_succeeded,
                 self._stellar_move, self._called_result)  # fmt: skip
        self._bounced = True
        try:
            called, base_target = self._modify_move(holder, fresh, move.priority, bounced=True)
            targeting = bounce_targeting(self.state, holder, called, source)
            holder.move_this_turn_result = self._use_move(
                holder, called, targeting, base_target, prankster_boosted=False
            )
        finally:
            self._bounced = False
            (self._not_fail_blocks, self._sure_hit, self._smart, self._move_succeeded,
             self._stellar_move, self._called_result) = saved  # fmt: skip

    def _ability_try_hit(self, user: BattlePokemon, move: Move, target: BattlePokemon) -> bool:
        """The target's ability ``onTryHit`` (priority 0): True when it stops the move."""
        ability = target.ability_id
        if (  # 043-1: onTryHit: null
            ability == TELEPATHY
            and target is not user
            and target.side == user.side
            and move.category != "Status"
        ):
            self._emit("activate", target=target.label, detail="ability: Telepathy")
            return True
        if ability == OBLIVIOUS and move.id in ("taunt", "attract"):
            self._emit("immune", target=target.label)  # [from] ability: Oblivious (015)
            return True
        if (ability == BULLETPROOF and "bullet" in move.flags) or (
            ability == SOUNDPROOF and "sound" in move.flags
        ):
            self._emit("immune", target=target.label)  # 032 (R11)
            return True
        if ability == STURDY and OHKO in move.keys:
            self._emit("immune", target=target.label)  # [from] ability: Sturdy (026 R5)
            return True
        if ability == GOOD_AS_GOLD:
            if move.category != "Status":
                return False
            self._emit("immune", target=target.label)
            return True
        if ability == "flashfire":
            if move.type != "Fire":
                return False
            self._sure_hit = True  # 027: move.accuracy = true (no roll for the other targets)
            if target.flash_fire:
                self._emit("immune", target=target.label)
            else:
                target.flash_fire = True  # addVolatile('flashfire')
                self._emit("start", target=target.label, detail="ability: Flash Fire")
            return True
        if ability == "windrider" and "wind" in move.flags:
            # 043-4d: Wind Rider's onTryHit: boost({atk: 1}, target, target), else -immune
            if not apply_boosts(
                target, {"atk": 1}, primary=False, foes_left=self._foes_left(target),
                emit=self._emit_kw, source=target, ability="Wind Rider",
            ):  # fmt: skip
                self._emit("immune", target=target.label)
            return True
        absorber = ABSORBERS.get(ability)
        if absorber is None or move.type != absorber[0]:
            return False
        _, effect, name = absorber
        if effect == "heal":
            healed = min(target.max_hp // 4, target.max_hp - target.hp)
            if healed > 0 and HEAL_BLOCK not in target.timed:  # 023: onTryHeal
                target.hp += healed
                self._emit("heal", target=target.label, value=healed, hp=target.hp,
                           detail=f"ability: {name.lower()}")  # fmt: skip
                return True
        elif apply_boosts(  # (043-4b: Motor Drive; 043-4c: Well-Baked Body +2)
            target, {effect: 2 if ability == "wellbakedbody" else 1}, primary=False,
            foes_left=self._foes_left(target),
            emit=self._emit_kw, source=user, ability=name,
        ):  # fmt: skip
            return True
        self._emit("immune", target=target.label)
        return True

    def _ability_redirect(self, user: BattlePokemon, move: Move, targeting: Targeting) -> Targeting:
        """``priorityEvent('RedirectTarget')`` in getMoveTargets (after the move line): with no
        Follow Me / Rage Powder in front of it, a Storm Drain / Lightning Rod holder draws in a
        single-target move of its type (also an ally's), faster first, then the one that
        switched in earlier (``compareRedirectOrder``, no draw)."""
        if move.target not in SINGLE_TARGETS and move.target != "randomNormal":
            return targeting
        if targeting.spread:
            return targeting
        if is_charging(user, move, effective_weather(self.state.field.active_weather, user.item)):
            return targeting  # 021: isCharging skips RedirectTarget (Electro Shot, Lightning Rod)
        if "tracksTarget" in move.keys or user.ability_id in TRACKERS:
            return targeting  # 041-6a: Snipe Shot (getMoveTargets: !move.tracksTarget; 043-2b)
        if not targeting.targets and self._move_loc == -((user.position or 0) + 1):
            return targeting  # getTarget gave null (its own location): -fail before this
        # 020: with no target left (the foes fainted), the event still runs on the fainted
        # target, so an ally's Lightning Rod / Storm Drain draws the move in
        if redirecting_foes(self.state, user):
            # handled at getTarget (009); it would win (priority 1). 022: a Rage Powder that
            # does not affect the user (a Grass type) returns nothing, so the abilities act
            return targeting
        holders = [
            p for p in self.state.all_active()
            if p is not user and not p.fainted
            and REDIRECT_ABILITIES.get(p.ability_id, ("", ""))[0] == move.type
        ]  # fmt: skip
        if not holders:
            return targeting
        holders.sort(key=lambda p: (-p.cached_speed, p.ability_order))
        holder = holders[0]
        if not targeting.targets or holder is not targeting.targets[0]:
            self._emit("activate", target=holder.label,
                       detail=f"ability: {REDIRECT_ABILITIES[holder.ability_id][1]}")  # fmt: skip
        return Targeting([holder], spread=False)

    def _makes_contact(
        self,
        move: Move,
        user: BattlePokemon,
        target: BattlePokemon | None = None,
        announce: str | None = None,
    ) -> bool:
        """040-3: ``checkMoveMakesContact``: Protective Pads on the user removes the contact
        (``announcePads``: ``-activate`` the target's effect, then the user's item)."""
        if "contact" not in move.flags:
            return False
        if user.item == PROTECTIVE_PADS:
            if announce is not None and target is not None:
                self._emit("activate", target=target.label, detail=announce)
                self._emit("activate", target=user.label, detail="item: Protective Pads")
            return False
        return True

    def _contact_effect(self, volatile: str, user: BattlePokemon, holder: BattlePokemon) -> None:
        """Spiky Shield, Baneful Bunker, Silk Trap, Burning Bulwark on a contact move."""
        effect = contact_effect(volatile)
        if effect is None or user.hp <= 0:
            return
        if effect == "damage":
            if self._magic_guard(user):
                return
            dealt = self._damage_event(user, max(1, user.max_hp // 8), by_move=False)
            dealt = min(dealt, user.hp)
            user.hp -= dealt
            self._emit("damage", target=user.label, value=dealt, hp=user.hp, detail="spiky shield")
        elif effect == "spe":
            apply_boosts(
                user, {"spe": -1}, primary=True, foes_left=self._foes_left(user),
                emit=self._emit_kw, source=holder,
            )  # fmt: skip
        else:
            self._set_status(user, effect, holder, status_move=False)

    def _ohko_accuracy(self, user: BattlePokemon, move: Move, target: BattlePokemon) -> int | None:
        """026 (R3): hitStepAccuracy for an OHKO move: 30 (Sheer Cold 20 for a user that is not
        Ice) plus the level difference; None (``-immune … [ohko]``, no draw) against a higher
        level or, for Sheer Cold, an Ice target. No stages, no ModifyAccuracy."""
        accuracy = 20 if move.id == SHEER_COLD and "Ice" not in user.types else 30
        if user.level < target.level or (move.id == SHEER_COLD and "Ice" in target.types):
            return None
        return accuracy + user.level - target.level

    def _break_protect(self, move: Move, targets: list[BattlePokemon]) -> None:
        """``hitStepBreakProtect``: remove the target's protection and its side's guards."""
        for target in targets:
            broke = False
            for volatile in BREAKABLE:
                if target.timed.pop(volatile, None) is not None:
                    broke = True
            for guard in GUARDS:
                if guard in self.state.field.sides[target.side]:
                    end_side_condition(self.state.field, target.side, guard, self._emit_kw)
                    broke = True
            if broke:
                # Feint: -activate|target|move: Feint; others add [broken] (not compared)
                self._emit("activate", target=target.label, detail=f"move: {move.name}")
                target.timed.pop(STALL, None)
                target.counters.pop(STALL, None)

    def _self_effect(self, user: BattlePokemon, move: Move) -> None:
        """A one-turn volatile on the user (``-singleturn``), then Protect's ``onHit``
        (``addVolatile('stall')``); or Ally Switch's swap."""
        if move.id == "allyswitch":
            self._ally_switch(user)
            return
        volatile = move.volatile_status
        assert volatile is not None
        add_timed(user, volatile)
        self._emit("singleturn", target=user.label, detail=SINGLE_TURN_NAMES[volatile])
        if volatile in REDIRECTORS:
            self._effect_order += 1
            user.counters["redirect_order"] = self._effect_order
        if is_stalling(move):
            add_stall(user)

    def _ally_switch(self, user: BattlePokemon) -> None:
        side = self.state.sides[user.side]
        assert user.position is not None
        new_position = 1 - user.position
        ally = side.active[new_position]
        if ally is None or ally.fainted:
            self._emit("fail", actor=user.label)  # -fail|user|move: Ally Switch
            return
        self._emit("swap", actor=user.label, value=new_position)
        old_position = user.position
        side.active[old_position], side.active[new_position] = ally, user
        ally.position, user.position = old_position, new_position
        if not side.order:
            side.order = list(side.brought)
        i, j = side.order.index(user), side.order.index(ally)
        side.order[i], side.order[j] = side.order[j], side.order[i]
        for pokemon in (ally, user):  # 025: runEvent('Swap', target), then the user
            for key in WISHES:  # (041-6d: each slot condition)
                self._healing_wish_swap(pokemon, run_event=True, key=key)

    def _has_source_volatile(self, pokemon: BattlePokemon, volatile: str) -> bool:
        if volatile == SYRUP_BOMB:
            return SYRUP_BOMB in pokemon.timed and pokemon.syrup_source is not None
        return pokemon.attract_source is not None

    def _helping_hand(self, user: BattlePokemon, target: BattlePokemon) -> bool:
        """Helping Hand ``onTryHit``, then its volatile on the ally."""
        if not target.newly_switched and not self._will_move(target):
            self._emit("fail", actor=user.label)
            return False
        if add_timed(target, "helpinghand"):
            target.counters["helpinghand"] = 1  # onStart: multiplier 1.5
        else:
            # 041-6f: onRestart (a second one through Instruct): multiplier *= 1.5
            target.counters["helpinghand"] = target.counters.get("helpinghand", 1) + 1
        self._emit("singleturn", target=target.label, detail="Helping Hand")
        return True

    def _disable_before_move(self, user: BattlePokemon, move: Move) -> bool:
        """disable ``onBeforeMove`` (priority 7, 023): the disabled move fails with ``cant``."""
        if DISABLE not in user.timed or move.id != user.disabled_move:
            return True
        self._emit("cant", actor=user.label, detail="Disable")
        return False

    def _priority_six_before_move(
        self, user: BattlePokemon, move: Move, handlers: list[str]
    ) -> bool:
        """BeforeMove priority 6: throatchop (021) and healblock (023), in the order
        ``_before_move`` sorted them."""
        for handler in handlers:
            if handler == THROAT_CHOP and not self._throat_chop_before_move(user, move):
                return False
            if handler == HEAL_BLOCK and "heal" in move.flags:
                self._emit("cant", actor=user.label, detail="move: Heal Block")
                return False
        return True

    def _throat_chop_before_move(self, user: BattlePokemon, move: Move) -> bool:
        """throatchop ``onBeforeMove`` (priority 6, 021 R5): a sound move fails with ``cant``."""
        if THROAT_CHOP not in user.timed or "sound" not in move.flags:
            return True
        self._emit("cant", actor=user.label, detail="move: Throat Chop")
        return False

    def _taunt_before_move(self, user: BattlePokemon, move: Move) -> bool:
        """taunt ``onBeforeMove`` (priority 5, 015): a status move fails with ``cant``."""
        if TAUNT not in user.timed or move.category != "Status":
            return True
        self._emit("cant", actor=user.label, detail="move: Taunt")
        return False

    def _imprison_before_move(self, user: BattlePokemon, move: Move) -> bool:
        """imprison ``onFoeBeforeMove`` (priority 4, 022 R2): a move a foe with the imprison
        volatile knows fails with ``cant`` (not Struggle)."""
        if move.id == "struggle":
            return True
        foe = self.state.sides[foe_of(user.side)]
        if not any(
            p is not None and p.hp > 0 and p.imprison and any(s.move.id == move.id for s in p.moves)
            for p in foe.active
        ):
            return True
        self._emit("cant", actor=user.label, detail="move: Imprison")
        return False

    def _before_move(self, user: BattlePokemon, move: Move) -> bool:
        """``runEvent('BeforeMove')``: handlers by onBeforeMovePriority (slp/frz 10, flinch 8,
        throatchop 6 (021), taunt 5, imprison 4 (022), confusion 3, par 1, choicelock 0); the
        first that stops the Pokémon ends the checks. 022: the handlers are speed-sorted first,
        so two foes' imprison (onFoeBeforeMove, each with its holder's speed) tie and draw a
        shuffle at the same speed, whatever the move. 023: throatchop and healblock (priority 6,
        the user's volatiles, in the order they were added) tie too; sorted before the
        imprisoners (priority 4), whichever handler stops the Pokémon."""
        priority_six = [v for v in user.timed if v in (THROAT_CHOP, HEAL_BLOCK)]
        speed_sort(priority_six, self.prng, lambda a, b: 0)
        imprisoners = [
            p.cached_speed
            for p in self.state.sides[foe_of(user.side)].active
            if p is not None and p.hp > 0 and p.imprison
        ]
        speed_sort(imprisoners, self.prng, lambda a, b: b - a)
        user.glaive_rush = False  # 023: glaiverush onBeforeMove (priority 100)
        if move.id == CHILLY_RECEPTION and CHILLY_RECEPTION in user.timed:
            # 041-6d: chillyreception's onBeforeMove (priority 100)
            self._emit("prepare", target=user.label, detail="Chilly Reception")
        return (
            self._recharge_before_move(user)
            and sleep_or_freeze(user, move, self.prng, self._emit_kw)
            and self._truant_before_move(user)
            and self._flinch_before_move(user)
            and self._disable_before_move(user, move)
            and self._priority_six_before_move(user, move, priority_six)
            and self._gravity_before_move(user, move)
            and self._taunt_before_move(user, move)
            and self._imprison_before_move(user, move)
            and confusion_before_move(
                user,
                self.prng,
                self._emit_kw,
                lambda: self._modify_boost(user),
                lambda dealt: self._confusion_damage_event(user, dealt),
                wonder_room=WONDER_ROOM in self.state.field.pseudo_weather,
            )
            and self._attract_before_move(user)
            and full_paralysis(user, self.prng, self._emit_kw)
            and self._choice_lock_before_move(user, move)
        )

    def _truant_before_move(self, user: BattlePokemon) -> bool:
        """043-5c: Truant's onBeforeMove (priority 9): the truant volatile removed: ``cant …
        ability: Truant``; otherwise it is added."""
        if user.ability_id != "truant":
            return True
        if user.truant:
            user.truant = False
            self._emit("cant", actor=user.label, detail="ability: Truant")
            return False
        user.truant = True
        return True

    def _gravity_before_move(self, user: BattlePokemon, move: Move) -> bool:
        """041-4e: Gravity's onBeforeMove (priority 6): ``cant … move: Gravity``."""
        if GRAVITY in self.state.field.pseudo_weather and "gravity" in move.flags:
            self._emit("cant", actor=user.label, detail="move: Gravity")
            return False
        return True

    def _gravity_start(self) -> None:
        """041-4e: Gravity's onFieldStart: every active Pokemon flying (Fly, Bounce) comes
        down (its move cancelled, twoturnmove removed) with ``-activate … move: Gravity``."""
        self._set_gravity(True)
        for pokemon in self.state.all_active():
            rose = pokemon.timed.pop(MAGNET_RISE, None) is not None  # 041-6f (no onEnd)
            if rose and "fly" not in pokemon.timed and "bounce" not in pokemon.timed:
                self._emit("activate", target=pokemon.label, detail="move: Gravity")
                continue
            if pokemon.timed.pop("fly", None) is None and pokemon.timed.pop("bounce", None) is None:
                continue
            if self._queue is not None:
                self._queue.remove(partial(_queued_move_of, pokemon))
            if pokemon.timed.pop(TWO_TURN, None) is not None:
                pokemon.two_turn_move, pokemon.charge_loc, pokemon.charged = None, None, False
            _clear_vanished(pokemon)
            self._emit("activate", target=pokemon.label, detail="move: Gravity")

    def _set_gravity(self, on: bool) -> None:
        for side in self.state.sides.values():
            for pokemon in side.team:
                pokemon.gravity = on

    def _recharge_before_move(self, user: BattlePokemon) -> bool:
        """030 (R7): mustrecharge ``onBeforeMove`` (priority 11, before sleep): ``cant …
        recharge``, the volatile ends, null."""
        if user.timed.pop(MUST_RECHARGE, None) is None:
            return True
        self._emit("cant", actor=user.label, detail="recharge")
        return False

    def _choice_lock_before_move(self, user: BattlePokemon, move: Move) -> bool:
        """choicelock ``onBeforeMove`` (022): the lock ends when the item is no longer a Choice
        item (given away by Trick). 041-5: another move (a locked move Copycat called while
        locked into Copycat): the move line, ``-fail``, and the move stops."""
        if user.choice_lock is not None and not is_choice(user.held_item):
            user.choice_lock = None
        if (
            user.choice_lock is not None
            and user.item  # 041-6f: not while ignoringItem
            and move.id not in (user.choice_lock, "struggle")
        ):
            self._emit("move", actor=user.label, target=None, detail=move.name)
            self._emit("fail", actor=user.label)
            return False
        return True

    def _run_hits(
        self, user: BattlePokemon, move: Move, targets: list[BattlePokemon], *, spread: bool
    ) -> None:
        """Showdown ``hitStepMoveHitLoop``: one or more hits, then faints, recoil and the win."""
        if not targets:
            return
        hits = 1
        beat_up: list[int] = []
        if move.id == BEAT_UP:
            # 033 (R11): onModifyMove: the user and every party member (side.pokemon order,
            # the bench too) that has not fainted and has no status; multihit is their number
            beat_up = [
                5 + p.set_base_atk // 10
                for p in self.state.sides[user.side].order
                if p is user or (not p.fainted and p.status is None)
            ]
            move = replace(move, multihit=(len(beat_up), len(beat_up)))
        if move.multihit is not None:
            low, high = move.multihit
            if low != high and user.ability_id == "skilllink":
                hits = high  # 043-2a: Skill Link's onModifyMove (no draw)
            elif (low, high) == (2, 5):  # 35/35/15/15%
                hits = self.prng.sample([2] * 7 + [3] * 7 + [4] * 3 + [5] * 3)
                if hits < 4 and user.item == LOADED_DICE:
                    hits = 5 - self.prng.random_int(2)  # 013
            elif low != high:
                hits = self.prng.random_range(low, high + 1)
            else:
                hits = low
            if hits == 10 and user.item == LOADED_DICE:
                hits -= self.prng.random_int(7)  # 033 (R10): Population Bomb with Loaded Dice
        # 033 (R10): multiaccuracy (Loaded Dice's onModifyMove deletes it)
        multiaccuracy = (  # (043-2a: Skill Link's onModifyMove deletes it too)
            "multiaccuracy" in move.keys and user.item != LOADED_DICE
            and user.ability_id != "skilllink"
        )  # fmt: skip
        total = 0
        self._total_damage = 0  # 040-4b: move.totalDamage (Shell Bell)
        total_by_target: dict[int, int] = {}
        self_dropped = False
        landed = 0
        last_hit: dict[int, int] = {}
        subbed: set[int] = set()
        down_before = user.hp == 0
        # 030 (R9): smartTarget still on with two targets: hit n on the n-th target only
        smart = self._smart and len(targets) > 1
        all_targets = targets
        for n in range(hits):
            if all(t.hp <= 0 for t in all_targets):
                break
            # 043-5i: put to sleep mid-move (Effect Spore): no more hits, unless sleep-usable
            if n > 0 and user.status == "slp" and not self._sleep_usable:
                break
            if smart:
                targets = [all_targets[n]]
            if multiaccuracy and n > 0 and not self._multi_accuracy(user, move, targets[0]):
                break
            landed += 1
            if move.id == TRIPLE_AXEL:  # 033 (R10): basePowerCallback 20 * move.hit
                move = replace(move, base_power=20 * (n + 1))
            if move.id == "triplekick":  # 041-1a: 10 * move.hit
                move = replace(move, base_power=10 * (n + 1))
            if beat_up:  # 033 (R11): basePowerCallback: 5 + baseStats.atk / 10 of allies.shift()
                move = replace(move, base_power=beat_up[n])
            if move.id == UPROAR:  # 033 (R13): the move's TryHit in spreadMoveHit
                self._uproar_wake(targets[0])
            if move.id == POLTERGEIST:  # 033 (R8): the move's TryHit in spreadMoveHit
                # (the item's name follows in Showdown's line; the compared log drops it)
                self._emit("activate", target=targets[0].label, detail="move: Poltergeist")
            if breaks_screens(move):
                # spreadMoveHit: the move's TryHit (single-target), after the accuracy and
                # immunity checks and before the damage (008)
                self._break_screens(targets[0].side)
            combined = move.id in PLEDGES and move.force_stab
            if combined:
                self._emit("combine")  # 041-5: basePowerCallback (getDamage)
            dealt_by_target, hit_subbed = self._one_hit(user, move, targets, spread=spread)
            if smart:  # moveDamage collects each target's hit
                last_hit = {**last_hit, **dealt_by_target}
                subbed = subbed | hit_subbed
            else:
                last_hit, subbed = dealt_by_target, hit_subbed
            if dealt_by_target:
                self._move_succeeded = True
            total += sum(dealt_by_target.values())
            self._total_damage = total
            if move.id == "steelroller" and dealt_by_target:
                self._clear_terrain()  # onHit (runMoveEffects, 010)
            if move.volatile_status == PARTIALLY_TRAPPED:  # 024 R1: runMoveEffects
                for target in targets:
                    if id(target) in dealt_by_target:
                        add_partially_trapped(
                            target, user, move.id, move.name, prng=self.prng, emit=self._emit_kw
                        )
            if combined:
                self._pledge_condition(user, move, targets, dealt_by_target, hit_subbed)
            if move.id == "jawlock":  # 041-6f: onHit: the user, then the target
                for target in targets:
                    # (addVolatile's linkedStatus: nothing when either has no HP)
                    if id(target) in dealt_by_target and target.hp > 0 and user.hp > 0:
                        self._trap(target, user)
                        self._trap(user, target)
            if move.id == SMACK_DOWN:  # 041-2: runMoveEffects' volatileStatus
                for target in targets:
                    if id(target) in dealt_by_target and target.hp > 0:
                        self._smack_down(target)
            if move.id in ("bugbite", "pluck", "incinerate"):  # 041-3c: onHit
                for target in targets:
                    if id(target) in dealt_by_target:
                        self._steal_berry(user, target, move)
            if move.id == CLEAR_SMOG:  # onHit (runMoveEffects, 021 R6)
                for target in targets:
                    if id(target) in dealt_by_target:
                        target.reset_boosts()
                        self._emit("clearboost", target=target.label)
            for target in targets:  # 040-4a: runMoveEffects' runEvent('Hit')
                if (
                    id(target) in dealt_by_target
                    and BEAK_BLAST in target.timed
                    and self._makes_contact(move, user)
                ):
                    # 041-6f: beakblast's onHit (a volatile, before the item's): trySetStatus
                    self._set_status(user, "brn", target, status_move=False)
                if (
                    id(target) in dealt_by_target
                    and target.ability_id == "angerpoint"
                    and target.hp > 0
                    and id(target) in self._crit_hits
                    and target.boosts["atk"] < 6  # (at +6 the boost changes nothing: no line)
                ):
                    # 043-4e: Anger Point's onHit: boost({atk: 12}) shows -setboost
                    target.boosts["atk"] = 6
                    target.stats_raised_this_turn = True
                    self._emit("setboost", target=target.label, detail="atk", value=6)
                if (
                    id(target) in dealt_by_target
                    and target.item == ENIGMA_BERRY
                    and self._type_mods.get(id(target), 0) > 0
                ):
                    self._enigma_berry(target)
                elif (
                    id(target) in dealt_by_target
                    and target.item == STICKY_BARB
                    and target is not user
                    and not user.held_item
                    and self._makes_contact(move, user)
                    and can_be_taken(target.held_item, target.species, user.species)
                    and not self._sticky_hold(target, user)
                ):
                    # 040-4b: Sticky Barb's onHit: takeItem, source.setItem (no message)
                    self._lose_item(target, unburden=True)
                    user.item = STICKY_BARB
            # spreadMoveHit step 4: self drops (once per move unless it is multi-hit)
            # (041-6e: Sheer Force deletes move.self too: Diamond Storm)
            if move.self_boosts and not self_dropped and not self._sheer_force:
                roll = self.prng.random_int(100)
                if move.self_chance is None or roll < move.self_chance:
                    self._boost(user, move.self_boosts, user)
                if move.multihit is None:
                    self_dropped = True
            if move.id == GLAIVE_RUSH and (dealt_by_target or subbed) and user.hp > 0:
                user.glaive_rush = True  # 023: self.volatileStatus (-singlemove [silent])
            hit_any = dealt_by_target or subbed
            if (
                move.id in RECHARGE_MOVES
                and hit_any
                and user.hp > 0
                and MUST_RECHARGE not in user.timed
            ):
                # 030 (R7): selfDrops' self.volatileStatus for a target not false (a substitute
                # is null: it counts); onStart: -mustrecharge
                user.timed[MUST_RECHARGE] = 2
                self._emit("mustrecharge", target=user.label)
            if move.id in SPENT_TYPE and hit_any and user.hp > 0 and not self_dropped:
                self._double_shock(user, SPENT_TYPE[move.id])  # 041-1g: self.onHit
                self_dropped = True
            if move.id in LOCKING_MOVES and not self_dropped:
                self._lock_move(user, move)  # 022: self.volatileStatus 'lockedmove'
                self_dropped = True
            if move.id == UPROAR and not self_dropped:
                self_dropped = True  # 033 (R13): self.volatileStatus 'uproar' (no onRestart)
                if user.hp > 0 and UPROAR not in user.timed:
                    user.timed[UPROAR] = 3
                    self._emit("start", target=user.label, detail="Uproar")
            # step 5: secondary effects, one roll per effect per target (Sheer Force removed
            # them: no rolls, 012)
            sheer_force = self._sheer_force  # 033: move.secondaries deleted at ModifyMove
            for target in targets:
                secondaries = () if sheer_force else move.secondaries
                if (
                    (user.item in (KINGS_ROCK, RAZOR_FANG) or user.ability_id == "stench")  # 043-3b
                    and move.category != "Status"
                    and not any(s.volatile_status == "flinch" for s in secondaries)
                ):
                    # 032 (R2): onModifyMove (priority -1, after Sheer Force's): +10% flinch
                    secondaries = (*secondaries, KINGS_ROCK_FLINCH)
                behind_substitute = id(target) in subbed  # 016: a null target, rolls only
                cloaked = target.item == COVERT_CLOAK or target.ability_id == "shielddust"
                if cloaked and not behind_substitute:  # (043-3b: Shield Dust, the same)
                    # onModifySecondaries: only self effects (013)
                    secondaries = tuple(s for s in secondaries if s.self_boosts)
                for secondary in secondaries:
                    roll = self.prng.random_int(100)
                    if secondary.chance is not None and roll >= secondary.chance:
                        continue
                    if behind_substitute:
                        if secondary.self_boosts:
                            self._boost(user, secondary.self_boosts, user)
                        continue
                    if move.id == "eeriespell":
                        self._eerie_spell(target)  # 041-6e: the secondary's onHit
                    if secondary.status:
                        self._set_status(
                            target, secondary.status, user, status_move=False, by_move=True
                        )
                    if secondary.boosts:
                        self._boost(target, secondary.boosts, user)
                    if secondary.self_boosts:
                        self._boost(user, secondary.self_boosts, user)
                    blocked = (
                        secondary.volatile_status in (YAWN, HEAL_BLOCK)
                        and secondary.volatile_status not in target.timed
                        and target.hp > 0
                        and self._volatile_veil(target, secondary.volatile_status, from_move=True)
                    )  # 032 (R13): Psychic Noise's Heal Block and Aroma Veil
                    if secondary.volatile_status and not blocked:
                        add_volatile(
                            target, secondary.volatile_status, prng=self.prng,
                            emit=self._emit_kw, terrain=self.state.field.terrain,
                            min_confusion=3 if move.id == "axekick" else 2, source=user,
                        )  # fmt: skip
                    if move.id == THROAT_CHOP and target.hp > 0 and THROAT_CHOP not in target.timed:
                        # 021 (R5): the secondary's onHit: addVolatile('throatchop')
                        target.timed[THROAT_CHOP] = 2
                        self._emit("start", target=target.label, detail="Throat Chop")
                    if move.id in SAMPLED_STATUSES:
                        # 030 (R4): the secondary's onHit: trySetStatus(sample(...)), silent
                        # (033: Tri Attack)
                        status = self.prng.sample(SAMPLED_STATUSES[move.id])
                        self._set_status(target, status, user, status_move=False, by_move=True)
                    if move.id == BURNING_JEALOUSY and target.stats_raised_this_turn:
                        # 027 (R6): the secondary's onHit: trySetStatus('brn')
                        self._set_status(target, "brn", user, status_move=False)
                    if move.id == "spiritshackle" and user.position is not None:
                        self._trap(user, target)  # 041-3g: the secondary (source.isActive)
                    if move.id == ALLURING_VOICE and target.stats_raised_this_turn:
                        # 031 (R5): the secondary's onHit: addVolatile('confusion')
                        add_volatile(
                            target, "confusion", prng=self.prng, emit=self._emit_kw,
                            terrain=self.state.field.terrain, source=user,
                        )  # fmt: skip
            # runEvent('DamagingHit'): left to right by order (Rocky Helmet 2, then the rest),
            # then by target; no draws
            if FORCE_SWITCH in move.keys:  # 041-1d: spreadMoveHit's forceSwitch (Dragon Tail)
                self._force_switch(user, [t for t in targets if id(t) in dealt_by_target], move)
            for target in targets:  # 032 (R12): Rough Skin (order 1)
                hit = id(target) in dealt_by_target
                if (
                    hit
                    and target.ability_id == ROUGH_SKIN
                    and self._makes_contact(move, user, target, announce="ability: Rough Skin")
                ):
                    self._chip(user, user.max_hp / 8, "ability: rough skin", target)
                elif (
                    hit
                    and target.ability_id == AFTERMATH
                    and target.hp <= 0
                    and self._makes_contact(move, user, target, announce="ability: Aftermath")
                    and not self._damp_on_field()
                ):
                    self._chip(user, user.max_hp / 4, "ability: aftermath", target)  # 043-3b
                elif hit and (
                    target.ability_id == "electromorphosis"
                    or (target.ability_id == "windpower" and "wind" in move.flags)
                ):
                    self._add_charge(target)  # 043-4d: onDamagingHit (order 1)
            for target in targets:
                hit = id(target) in dealt_by_target
                if hit and target.item == ROCKY_HELMET and self._makes_contact(move, user):
                    self._chip(user, user.max_hp / 6, "item: rocky helmet")
            for target in targets:
                if id(target) not in dealt_by_target:
                    continue
                hit_by_fire = move.type == "Fire" and dealt_by_target.get(id(target))
                if hit_by_fire and target.status == "frz":
                    cure(target, self._emit_kw)  # frz onDamagingHit
                self._damaging_hit(user, move, target, dealt_by_target[id(target)])
                self._counter_hit(user, move, target, dealt_by_target[id(target)])
                if target.item == AIR_BALLOON:
                    self._pop_balloon(target)  # 032 (R4): the item's onDamagingHit
                elif target.item == WEAKNESS_POLICY and self._type_mods.get(id(target), 0) > 0:
                    self._use_item(target)  # 032 (R7): getMoveHitData(move).typeMod > 0
                elif HIT_BOOST_ITEMS.get(target.item) == move.type:
                    self._use_item(target)  # 040-2: Absorb Bulb, Cell Battery, ...
                elif (
                    RETALIATE_BERRIES.get(target.item) == move.category
                    and user.hp > 0
                    and user.position is not None
                    and user.ability_id != "magicguard"
                ):
                    # 040-4a: Jaboca / Rowap Berry's onDamagingHit (043-4h: Ripen: 1/4)
                    name = "jaboca berry" if move.category == "Physical" else "rowap berry"
                    if self._eat_item(target):
                        ripe = 4 if target.ability_id == "ripen" else 8
                        self._chip(user, user.max_hp / ripe, f"item: {name}")
            if user.ability_id == TOXIC_CHAIN:
                # 032 (R12): the user's onSourceDamagingHit, after the targets' handlers
                for target in targets:
                    if id(target) not in dealt_by_target:
                        continue
                    if target.ability_id == "shielddust" or target.item == COVERT_CLOAK:
                        continue
                    if self.prng.random_chance(3, 10):
                        self._set_status(target, "tox", user, status_move=False)
            elif user.ability_id == "poisontouch":
                # 043-3b: onSourceDamagingHit, as Toxic Chain; checkMoveMakesContact(move,
                # target, source): the hit Pokemon's Protective Pads stop it
                for target in targets:
                    if id(target) not in dealt_by_target:
                        continue
                    if target.ability_id == "shielddust" or target.item == COVERT_CLOAK:
                        continue
                    if self._makes_contact(move, target) and self.prng.random_chance(3, 10):
                        self._set_status(target, "psn", user, status_move=False)
            if move.id == "knockoff" and user.hp > 0:
                for target in targets:  # onAfterHit (013)
                    if id(target) in dealt_by_target:
                        self._take_item(target, user)
            if move.id in (THIEF, "covet"):  # (041-3c: Covet's onAfterHit is Thief's)
                for target in targets:  # 032 (R9): onAfterHit
                    if id(target) in dealt_by_target:
                        self._thief(user, target, covet=move.id == "covet")
            if move.id == "icespinner" and user.hp > 0 and dealt_by_target:
                # onAfterHit (010): after DamagingHit (Rocky Helmet), for a damaged target
                self._clear_terrain()
            if move.id in SPINNERS and user.hp > 0 and not sheer_force:
                for target in targets:  # 020: onAfterHit, once per damaged target
                    if id(target) in dealt_by_target:
                        self._spin_away(user, move)
            if move.id in HAZARD_SETTERS and user.hp > 0 and not sheer_force:
                for target in targets:  # 041-6e: onAfterHit, once per damaged target
                    if id(target) in dealt_by_target:
                        add_hazard(self.state.field, foe_of(user.side),
                                   HAZARD_SETTERS[move.id], emit=self._emit_kw)  # fmt: skip
            for target in targets:
                total_by_target[id(target)] = total_by_target.get(
                    id(target), 0
                ) + dealt_by_target.get(id(target), 0)
            self._update()  # hitStepMoveHitLoop: eachEvent('Update') per hit
            if user.hp <= 0 and len(all_targets) == 1:
                break
        targets = all_targets
        self._hit_targets = list(targets)  # 041-6f: move.hitTargets
        for target in targets:  # 041-1e: gotAttacked with move.totalDamage-like sums
            if target is not user and total_by_target.get(id(target), 0) > 0:
                target.damaged_by.add(id(user))
                if target.side != user.side and user.position is not None:
                    # 041-4a: gotAttacked(move, moveDamage[i]): the last hit's damage. (A hit
                    # on a substitute leaves a null target: no gotAttacked; scenario
                    # r-metal-burst-substitute, the 041-4 review's P2 checked against Showdown)
                    dealt = last_hit.get(id(target), 0)
                    target.damaged_log.append((user, user.position, dealt, self.state.turn))
        for target in targets:  # 023: timesAttacked (the last hit's result was a number)
            if target is not user and (id(target) in last_hit or id(target) in subbed):
                target.times_attacked += 1 if smart else landed
        # faintQueue holds the user before its targets when it went down first: 023 Final
        # Gambit (in damageCallback), or before the hits (Spiky Shield, a 009 bug fixed in 023)
        gambit = (move.id == FINAL_GAMBIT or down_before) and user.hp == 0 and not user.fainted
        batch = []  # 043-1: this faintMessages' queue (AfterFaint)
        if gambit:
            self._faint_out(user)
            batch.append(user)
        last_fainted = None
        for target in targets:
            if target.hp == 0 and not target.fainted:
                last_fainted = target
                self._faint_out(target)
                batch.append(target)
        ended = False
        if gambit:
            ended = self._check_win(last_fainted or user)
        elif user.hp == 0 and not user.fainted:
            # 013: knocked out during the hits (Rocky Helmet; 041-4e: Destiny Bond, whose
            # faint() grows the queue): it faints after the targets,
            # and faintMessages(checkWin = !user.hp) decides the win here (the hit count
            # still follows the win line).
            self._faint_out(user)
            batch.append(user)
            ended = self._check_win(user)
        if batch and not ended:
            self._after_faint(len(batch), batch[-1], self._last_faint_source)
        if move.multihit is not None and not is_smart(move):  # (030: a boolean smartTarget)
            # A fainted Pokémon is no longer active: Showdown names it by side only.
            first = targets[0]
            label = first.side if first.fainted else first.label
            self._emit("hitcount", target=label, value=landed)
        if OHKO in move.keys and targets[0].hp == 0:
            self._emit("ohko")  # 026 (R4; not in the compared log)
        # faintMessages(..., checkWin = !user.hp): while the user stands, the win is decided
        # only after its recoil (applyRecoilDamage), at the end of runMove.
        if (
            total
            and user.hp > 0
            and (choice_is_struggle(move) or move.recoil or move.id in (STEEL_BEAM, CHLOROBLAST))
        ):
            self._recoil(user, move, total)
        if last_fainted is not None and user.hp > 0:
            self._win_pending = last_fainted  # decided at the end of runMove (013)
        # A user knocked out by its recoil faints only in runMove's final faintMessages: it is
        # still sorted (at 0 HP) by the Update below.
        self._update()  # eachEvent('Update') after faint messages
        if not self._negated(user):
            # 016: the last hit's substitutes are null targets (targetsCopy; 030: smartTarget
            # copies the targets again)
            hit_targets = targets if smart else [t for t in targets if id(t) not in subbed]
            self._after_move_secondary(user, move, hit_targets, total_by_target)

    def _boost(
        self, target: BattlePokemon, changes: Mapping[str, int], source: BattlePokemon
    ) -> None:
        """A secondary or self stat change (silent when nothing changes); ``source``: the
        move's user."""
        apply_boosts(
            target, changes, primary=False, foes_left=self._foes_left(target),
            emit=self._emit_kw, source=source,
        )  # fmt: skip

    def _one_hit(
        self, user: BattlePokemon, move: Move, targets: list[BattlePokemon], *, spread: bool
    ) -> tuple[dict[int, int], set[int]]:
        """One hit of spreadMoveHit: step 0 (the substitutes, 016), then getSpreadDamage and
        spreadDamage. Returns the damage dealt per target (by id) and the targets whose
        substitute took the hit (HIT_SUBSTITUTE: no longer targets of this hit)."""
        subbed: set[int] = set()
        for target in targets:
            if target.hp > 0:
                self._normal_gem(user, move, target)  # 042-1: TryPrimaryHit (before the sub)
                if (  # 043-6f: Gulp Missile's onSourceTryPrimaryHit (Surf)
                    move.id == "surf"
                    and user.ability_id == "gulpmissile"
                    and user.species.name == "Cramorant"
                ):
                    self._gulp(user)
            if target.hp > 0 and self._hits_substitute(user, move, target):
                self._hit_substitute(user, move, target, spread=spread)
                subbed.add(id(target))
        results = []
        for target in targets:
            if target.hp <= 0 or id(target) in subbed:
                continue
            if move.id == "pollenpuff" and target.side == user.side:
                # 015: onTryHit sets basePower 0 (getDamage: no draws), onHit heals
                # floor(baseMaxhp / 2); NOT_FAIL at full HP
                if HEAL_BLOCK in target.timed and target.hp != target.max_hp:
                    # 023: healblock onTryHeal names the user
                    self._emit("cant", actor=user.label, detail="move: Heal Block")
                if self._heal(target, target.max_hp // 2, ""):
                    self._move_succeeded = True
                else:
                    self._not_fail_blocks += 1
                continue
            if move.id == PRESENT and self._present_heal:
                self._present_heal_hit(target)
                continue
            result = self._calc_hit(user, move, target, spread=spread)
            self._type_mods[id(target)] = result.type_mod  # (032: Weakness Policy)
            if result.crit:
                self._crit_hits.add(id(target))
            else:
                self._crit_hits.discard(id(target))
            if not result.immune and resist_berry(target.item, move.type, result.type_mod):
                name = item_name(target.item)  # onSourceModifyDamage: eatItem, then [weaken]
                if self._eat_item(target):
                    self._emit("enditem", target=target.label, detail=name)
            results.append((target, result.damage))
        dealt_by_target: dict[int, int] = {}
        for target, damage in results:
            busting = (  # 043-6e: Disguise / Ice Face's onDamage (priority 1): 0
                target.ability_id == "disguise" and target.species.name == "Mimikyu"
            ) or (
                target.ability_id == "iceface" and target.species.name == "Eiscue"
                and move.category == "Physical"
            )  # fmt: skip
            if busting:
                name = "Disguise" if target.ability_id == "disguise" else "Ice Face"
                self._emit("activate", target=target.label, detail=f"ability: {name}")
                target.disguise_busted = True
                damage = 0
            elif "endure" in target.timed and damage >= target.hp:
                self._emit("activate", target=target.label, detail="move: Endure")
                damage = target.hp - 1  # endure onDamage (priority -10)
            if move.id in ("falseswipe", "holdback") and damage >= target.hp:  # (041-6f)
                damage = target.hp - 1  # 041-1d: the move's onDamage (priority -20)
            if target.ability_id == STURDY and target.hp == target.max_hp and damage >= target.hp:
                self._emit("ability", target=target.label, detail="Sturdy")
                damage = target.hp - 1  # sturdy onDamage (priority -30, 012)
            full = target.hp == target.max_hp
            if (
                target.item == FOCUS_SASH
                and full
                and damage >= target.hp
                and self._use_item(target)
            ):
                damage = target.hp - 1  # focussash onDamage (priority -40, 013)
            damage = self._damage_event(target, damage, by_move=True)  # 032: Focus Band (-40)
            if target.ability_id in _HALF_HP_BOOSTS:  # berserk onDamage (013: before its berry)
                negated = self._negated(user)
                target.checked_berserk = bool(move.multihit or negated)
            dealt = min(damage, target.hp)
            target.hp -= dealt
            dealt_by_target[id(target)] = dealt
            if target.hp == 0:  # 041-4e: faint(source, effect)
                target.faint_source = None if "futuremove" in move.flags else user
            if FOCUS_PUNCH in target.timed and move.category != "Status":
                target.counters[FOCUS_PUNCH] = 1  # 041-4e: focuspunch's onHit (lostFocus)
            self._emit("damage", target=target.label, value=dealt, hp=target.hp)
            if move.drain and dealt and user.hp > 0 and HEAL_BLOCK not in user.timed:
                amount = max(1, _round(dealt * move.drain[0] / move.drain[1]))
                amount = self._big_root(user, amount)
                healed = min(amount, user.max_hp - user.hp)
                if self._oozed(user, target, amount):
                    pass  # 043-3b: Liquid Ooze's onSourceTryHeal (also at full HP)
                elif healed > 0:  # heal() does nothing at full HP
                    user.hp += healed
                    self._emit("heal", target=user.label, value=healed, hp=user.hp, detail="drain")
        return dealt_by_target, subbed

    def _calc_hit(
        self,
        user: BattlePokemon,
        move: Move,
        target: BattlePokemon,
        *,
        spread: bool,
        active_target: BattlePokemon | None = None,
    ) -> DamageResult:
        """``getDamage``: the damage roll and its messages (modifyDamage). ``active_target``
        (032): Showdown's activeTarget when it is not ``target`` (a substitute's hit): Unaware
        ignores the user's stages when that Pokémon has it, and the target's only when the
        target is that Pokémon."""
        sides = self.state.field.sides
        if OHKO in move.keys:  # 026 (R4): after the immunity, maxhp (no crit, no roll)
            if type_immune(move, user.combatant(), target.combatant()):
                return DamageResult(damage=0, crit=False, type_mod=0, immune=True)
            return DamageResult(target.max_hp, crit=False, type_mod=0, immune=False)
        if move.id in FIXED_DAMAGE_MOVES:  # 023: getDamage's damageCallback (033: damage)
            if type_immune(move, user.combatant(), target.combatant()):
                return DamageResult(damage=0, crit=False, type_mod=0, immune=True)
            if move.id in (NIGHT_SHADE, "seismictoss"):  # 033 (R1): move.damage "level"
                return DamageResult(user.level, crit=False, type_mod=0, immune=False)
            if move.id in (RUINATION, SUPER_FANG):  # 024 R8, 033: half the HP, at least 1
                return DamageResult(max(1, target.hp // 2), crit=False, type_mod=0, immune=False)
            if move.id == ENDEAVOR:
                return DamageResult(target.hp - user.hp, crit=False, type_mod=0, immune=False)
            if move.id in REFLECT_CATEGORY:  # 041-4a: damage || 1
                dealt = user.counter_hit[2] if user.counter_hit else 0
                return DamageResult(dealt or 1, crit=False, type_mod=0, immune=False)
            if move.id in METAL_BURSTS:  # 041-4a: lastDamagedBy.damage * 1.5 || 1
                last = user.damaged_log[-1] if user.damaged_log else None
                dealt = int(last[2] * 1.5) if last else 0
                return DamageResult(dealt or 1, crit=False, type_mod=0, immune=False)
            dealt, user.hp = user.hp, 0  # pokemon.faint(): queued before the target
            return DamageResult(dealt, crit=False, type_mod=0, immune=False)
        if user.focus_energy:  # 017: onModifyCritRatio
            move = replace(move, crit_ratio=move.crit_ratio + 2)
        if user.dragon_cheer:  # 041-3a: +2 on a Dragon type when it started, otherwise +1
            move = replace(move, crit_ratio=move.crit_ratio + user.dragon_cheer)
        if user.ability_id == "superluck":  # 043-2b: onModifyCritRatio +1 (an ability: first)
            move = replace(move, crit_ratio=move.crit_ratio + 1)
        if user.item in (SCOPE_LENS, RAZOR_CLAW):  # 032 (R2), 040-4b: onModifyCritRatio
            move = replace(move, crit_ratio=move.crit_ratio + 1)
        if user.ability_id == "merciless" and target.status in ("psn", "tox"):
            move = replace(move, crit_ratio=5)  # 043-2b: return 5
        callback_state = self._power_callback_state(user, move)  # 041-3b
        attacker = replace(  # 023: Last Respects
            user.combatant(self.state.field),
            callback_state=callback_state,
            charge=user.charge,  # 041-4e
            gem="gem" in user.timed,  # 042-1
            ally_abilities=self._ally_abilities(user),  # 043-1
            fallen=user.fallen,
            side_fainted=self.state.sides[user.side].total_fainted,
            fainted_last_turn=self.state.sides[user.side].fainted_last_turn,
            echoed_voice=self.state.field.echoed_voice,
            round_boosted=self._round_boosted,
            last_successful=self._last_successful,
            gravity=GRAVITY in self.state.field.pseudo_weather,
            damaged_by_target=id(target) in user.damaged_by,
            last_to_move=not any(  # 043-2a: Analytic's queue.willMove
                self._will_move(p) for p in self.state.all_active() if p is not user
            ),
        )
        defender = replace(  # 023: Payback (basePowerCallback: newlySwitched, willMove)
            target.combatant(self.state.field),
            acted=not target.newly_switched and not self._will_move(target),
            vanished=vanished(target),  # 041-2: Fly and Bounce's onSourceBasePower
        )
        if self._tera_shell(user, target, move):
            defender = replace(defender, shell=True)  # 042-6
        if active_target is None and self._disguise_holds(user, move, target):
            defender = replace(defender, disguised=True)  # 043-6e
        if active_target is not None and active_target is not target:
            attacker = replace(attacker, stages_ignored=active_target.ability_id == UNAWARE
                               and active_target is not user)  # fmt: skip
            defender = replace(defender, stages_ignored=False)
        result = calc_damage(
            attacker, defender, move,
            spread=spread, prng=self.prng,
            weather=self.state.field.active_weather,
            screens=frozenset(sides[target.side]).intersection(SCREENS),
            screens_on_field=sum(s in sides[side] for side in SIDE_IDS for s in SCREENS),
            helping_hand=user.counters.get("helpinghand", 1) if "helpinghand" in user.timed else 0,
            terrain=self.state.field.terrain,
            ruin=self._ruin_abilities(),
            damage_handlers=self._damage_handlers(user, target, move),
            stellar_move=self._stellar_move,
            ruin_speeds=self._ruin_speeds(),
            modify_boost=lambda: self._modify_boost(user),
            modify_spe=(partial(self._modify_spe, target), partial(self._modify_spe, user)),
            attack_handlers=self._attack_handlers(user, target, move),
        )  # fmt: skip
        if result.fickle:  # 041-6b: Fickle Beam's onBasePower (before the crit message)
            self._emit("activate", target=user.label, detail="move: Fickle Beam")
        if result.stellar:  # 017: stellarBoostedTypes.push(type), move.stellarBoosted
            if user.species.name != "Terapagos-Stellar":  # (042-6)
                user.stellar_boosted.append(move.type)
            self._stellar_move = True
        if result.type_mod > 0:
            self._emit("supereffective", target=target.label)
        elif result.type_mod < 0:
            self._emit("resisted", target=target.label)
        if result.crit:
            self._emit("crit", target=target.label)
        return result

    def _present_heal_hit(self, target: BattlePokemon) -> None:
        """041-6f: Present's heal: getDamage gives nothing (basePower 0: no draws), then
        runMoveEffects' move.heal: ``-fail … heal`` at full HP (false), else pokemon.heal
        (no TryHeal: Heal Block does not stop it) of Math.round(baseMaxhp / 4)."""
        if target.hp >= target.max_hp:
            self._emit("fail", actor=target.label, detail="heal")
            return
        healed = min(int(target.max_hp / 4 + 0.5), target.max_hp - target.hp)
        target.hp += healed
        self._emit("heal", target=target.label, value=healed, hp=target.hp, detail="")
        self._move_succeeded = True
        if FOCUS_PUNCH in target.timed:
            target.counters[FOCUS_PUNCH] = 1  # runEvent('Hit'): focuspunch's onHit (lostFocus)

    def _hits_substitute(self, user: BattlePokemon, move: Move, target: BattlePokemon) -> bool:
        """016: the substitute's onTryPrimaryHit applies: not the user itself, not a
        ``bypasssub`` move, not ``infiltrates`` (Pollen Puff on an ally)."""
        return (
            target.substitute_hp > 0
            and target is not user
            and "bypasssub" not in move.flags
            and user.ability_id != INFILTRATOR  # 043-1: move.infiltrates
            and not (move.id == "pollenpuff" and target.side == user.side)
            and not (move.id == PRESENT and self._present_heal)  # 041-6f: infiltrates
        )

    def _hit_substitute(
        self, user: BattlePokemon, move: Move, target: BattlePokemon, *, spread: bool
    ) -> None:
        """016: the substitute's onTryPrimaryHit (research R2): getDamage, capped at the
        substitute's HP; recoil and drain at once; AfterSubDamage. (032: tryPrimaryHitEvent
        leaves activeTarget as the accuracy step's last target.)"""
        result = self._calc_hit(
            user, move, target, spread=spread, active_target=self._accuracy_last
        )
        damage = min(result.damage, target.substitute_hp)
        target.substitute_hp -= damage
        self._move_succeeded = True
        if target.substitute_hp <= 0:
            target.substitute_hp = 0
            self._emit("end", target=target.label, detail="Substitute")
        else:
            self._emit("activate", target=target.label, detail="move: Substitute")
        if (
            damage
            and user.hp > 0
            and (choice_is_struggle(move) or move.recoil or move.id in (STEEL_BEAM, CHLOROBLAST))
        ):
            self._recoil(user, move, damage)  # applyRecoilDamage (033: mindBlownRecoil too)
        if move.drain and damage:
            amount = self._big_root(user, math.ceil(damage * move.drain[0] / move.drain[1]))
            if not self._oozed(user, target, amount):  # 043-3b
                self._heal(user, amount, "drain")
        if (move.id == "icespinner" and user.hp > 0) or move.id == "steelroller":
            self._clear_terrain()  # onAfterSubDamage (010)
        if move.id in SPINNERS and user.hp > 0 and not self._sheer_force:
            self._spin_away(user, move)  # 020: onAfterSubDamage (each removal checks the hp)
        if move.id in HAZARD_SETTERS and user.hp > 0 and not self._sheer_force:
            # 041-6e: onAfterSubDamage
            add_hazard(self.state.field, foe_of(user.side), HAZARD_SETTERS[move.id],
                       emit=self._emit_kw)  # fmt: skip
        if target.item == AIR_BALLOON:
            # 032 (R4): runEvent('AfterSubDamage') after the move's singleEvent
            self._pop_balloon(target)

    def _pop_balloon(self, pokemon: BattlePokemon) -> None:
        """032 (R4): Air Balloon pops: ``-enditem``, no item, AfterUseItem (Unburden)."""
        self._emit("enditem", target=pokemon.label, detail="Air Balloon")
        self._lose_item(pokemon, unburden=True)

    def _recoil(self, user: BattlePokemon, move: Move, damage: int) -> None:
        """``applyRecoilDamage``: Struggle's 1/4 max HP, or the move's share of ``damage``."""
        if choice_is_struggle(move):
            recoil = max(1, _round(user.max_hp / 4))  # struggleRecoil
        elif move.id == STEEL_BEAM:
            self._steel_beam_cost(user)  # 033 (R9): mindBlownRecoil
            return
        elif user.ability_id == ROCK_HEAD:
            return  # 043-2a: onDamage null for the 'recoil' effect (before Focus Band)
        elif self._magic_guard(user):
            return
        elif move.id == CHLOROBLAST:  # 041-6b: Math.round(maxhp / 2), effect 'recoil'
            recoil = self._damage_event(user, _round(user.max_hp / 2), by_move=False)
        else:
            assert move.recoil is not None
            recoil = max(1, _round(damage * move.recoil[0] / move.recoil[1]))
            recoil = self._damage_event(user, recoil, by_move=False)  # (not Struggle's)
        recoil = min(recoil, user.hp)
        user.hp -= recoil
        self._direct_damage = choice_is_struggle(move)  # 023: Struggle's is directDamage
        self._emit("damage", target=user.label, value=recoil, hp=user.hp, detail="recoil")
        self._direct_damage = False

    def _multi_accuracy(self, user: BattlePokemon, move: Move, target: BattlePokemon) -> bool:
        """033 (R10): hitStepMoveHitLoop's check before each hit after the first: the user's
        accuracy stage and the target's evasion stage multiply the accuracy unrounded (each
        after its ModifyBoost), then ModifyAccuracy, the Accuracy event and randomChance."""
        assert move.accuracy is not None
        accuracy: float = move.accuracy
        self._modify_boost(user)
        stage = 0 if target.ability_id == UNAWARE else max(-6, min(6, user.boosts["accuracy"]))
        accuracy = (
            accuracy * _ACCURACY_TABLE[stage] if stage >= 0 else accuracy / _ACCURACY_TABLE[-stage]
        )
        if (
            user.ability_id not in (MINDS_EYE, KEEN_EYE, "illuminate")
            and move.id not in IGNORES_DEFENSIVE
        ):
            self._modify_boost(target)
            evasion = 0 if user.ability_id == UNAWARE else max(-6, min(6, target.boosts["evasion"]))
            if evasion > 0:
                accuracy /= _ACCURACY_TABLE[evasion]
            elif evasion < 0:
                accuracy *= _ACCURACY_TABLE[-evasion]
        modifier = self._accuracy_modifier(user, move, target)
        if modifier != 4096 and accuracy == int(accuracy):
            # runEvent applies event.modifier to a whole non-negative number only (033 review)
            accuracy = modify(int(accuracy), modifier, 4096)
        if self._accuracy_true(target, move, user):
            return True  # 023: glaiverush onAccuracy (034: minimize's)
        if accuracy == int(accuracy):
            accuracy = int(accuracy)  # (a whole number, as JavaScript shows it)
        return self.prng.random_chance(accuracy, 100)  # type: ignore[arg-type]

    def _normal_gem(self, user: BattlePokemon, move: Move, target: BattlePokemon) -> None:
        """042-1: Normal Gem's onSourceTryPrimaryHit: a Normal move (not Status, not a
        Pledge) on another Pokemon: useItem (``-enditem … [from] gem``, also at 0 HP),
        then the gem volatile (duration 1, onBasePower x5325/4096)."""
        if (
            user.item != "normalgem"
            or target is user
            or move.category == "Status"
            or "pledgecombo" in move.flags
            or move.type != "Normal"
            or user.position is None
        ):
            return
        self._emit("enditem", target=user.label, detail="Normal Gem")  # ([from] gem: not compared)
        user.last_item = user.held_item
        self._lose_item(user, unburden=True)
        self._effect_order += 1
        user.timed["gem"] = 1

    def _metronome_item(self, user: BattlePokemon, move: Move) -> None:
        """042-1: the metronome volatile's onTryMove (priority -2): gone without the item
        (hasItem: ignoringItem too); a move that calls another is not counted; the same
        move after a successful one, or a charging move's turns, count up."""
        if user.item != METRONOME_ITEM:
            user.metronome = None
            return
        if move.id in CALLING_MOVES:
            return
        assert user.metronome is not None
        last, count = user.metronome
        if last == move.id and user.move_last_turn_result:
            count += 1
        elif "twoturnmove" in user.timed:
            count = 1 if last != move.id else count + 1
        else:
            count = 0
        user.metronome = (move.id, count)

    def _crash(self, user: BattlePokemon, move: Move) -> None:
        """041-1c: High Jump Kick's ``damage(baseMaxhp / 2, source, source, move)``."""
        if self._magic_guard(user):  # (the effect is the High Jump Kick condition)
            return
        cost = self._damage_event(user, max(1, user.max_hp // 2), by_move=False)
        cost = min(cost, user.hp)
        user.hp -= cost
        self._emit("damage", target=user.label, value=cost, hp=user.hp, detail=move.id)

    def _steel_beam_cost(self, user: BattlePokemon) -> None:
        """033 (R9): Steel Beam's ``damage(round(maxhp / 2), source, source, Steel Beam)``,
        from applyRecoilDamage after a hit and from onMoveFail otherwise."""
        if user.hp <= 0 or self._magic_guard(user):
            return
        cost = self._damage_event(user, _round(user.max_hp / 2), by_move=False)
        cost = min(cost, user.hp)
        user.hp -= cost
        self._emit("damage", target=user.label, value=cost, hp=user.hp, detail="steelbeam")

    def _damage_handlers(
        self, user: BattlePokemon, target: BattlePokemon, move: Move
    ) -> list[DamageHandler]:
        """The Pokémon handlers of ``runEvent('ModifyDamage', user, target)``, in the order
        findEventHandlers collects them: the user's Life Orb (013); every Friend Guard (012,
        ``onAny``; its holder's allies), the user's side first; the target's Multiscale (012),
        then its resist berry (013). Ignored ones (Mold Breaker) are still sorted."""
        handlers = []
        if user.metronome is not None:  # 042-1: the volatile (a Condition: subOrder 2)
            count = min(user.metronome[1], 5)
            handlers.append(DamageHandler(user.cached_speed, 2, (METRONOME_BOOSTS[count], 4096)))
        if user.ability_id == TINTED_LENS:  # 043-2a: the user's ability, before its item
            lens = (2, 1) if type_mod(move, target.combatant()) < 0 else None
            handlers.append(DamageHandler(user.cached_speed, 7, lens))
        if user.ability_id == SNIPER:
            handlers.append(DamageHandler(user.cached_speed, 7, (3, 2), crit_only=True))
        if user.item == LIFE_ORB:
            handlers.append(DamageHandler(user.cached_speed, 8, LIFE_ORB_MODIFIER))
        if user.item == EXPERT_BELT:  # 040-2: getMoveHitData(move).typeMod > 0
            belt = EXPERT_BELT_MODIFIER if type_mod(move, target.combatant()) > 0 else None
            handlers.append(DamageHandler(user.cached_speed, 8, belt))
        foe_side = foe_of(user.side)
        sides = self.state.sides
        for pokemon in sides[user.side].alive_active() + sides[foe_side].alive_active():
            if pokemon.base_ability_id != FRIEND_GUARD or pokemon.hp == 0:
                # I-001 (old bug from 012): allies() / foes() leave out a Pokémon at 0 HP
                # (knocked out by an earlier hit of the move, not fainted yet)
                continue
            applies = (
                pokemon.ability_id == FRIEND_GUARD
                and pokemon is not target
                and pokemon.side == target.side
            )
            handlers.append(
                DamageHandler(pokemon.cached_speed, 7, FRIEND_GUARD_MODIFIER if applies else None)
            )
        if target.ability_id == PUNK_ROCK:  # 043-2a: onSourceModifyDamage x0.5 (sound)
            rock = (1, 2) if "sound" in move.flags else None
            handlers.append(DamageHandler(target.cached_speed, 7, rock))
        if target.glaive_rush:  # 023: onSourceModifyDamage x2
            handlers.append(DamageHandler(target.cached_speed, 2, GLAIVE_RUSH_MODIFIER))
        if target.minimized:  # 034 (R5): onSourceModifyDamage x2 for a move with the flag
            applies = MINIMIZE_FLAG in move.flags
            handlers.append(
                DamageHandler(target.cached_speed, 2, GLAIVE_RUSH_MODIFIER if applies else None)
            )
        state = vanished(target)
        if state in ("dig", "dive"):  # 041-2: onSourceModifyDamage x2 (Earthquake, Surf)
            applies = move.id in HITS_VANISHED[state]
            handlers.append(DamageHandler(target.cached_speed, 2, (2, 1) if applies else None))
        ability = target.base_ability_id
        on = target.ability_id == ability  # (collected also while ignored)
        if ability in FILTERS:  # 043-2b
            applies = on and type_mod(move, target.combatant()) > 0
            handlers.append(DamageHandler(target.cached_speed, 7, (3, 4) if applies else None))
        elif ability == "icescales":
            applies = on and move.category == "Special"
            handlers.append(DamageHandler(target.cached_speed, 7, (1, 2) if applies else None))
        elif ability == "shadowshield":
            applies = on and target.hp >= target.max_hp
            handlers.append(DamageHandler(target.cached_speed, 7, (1, 2) if applies else None))
        elif ability == "fluffy":
            fire, contact = move.type == "Fire", "contact" in move.flags
            mod = (2, 1) if fire and not contact else (1, 2) if contact and not fire else None
            handlers.append(DamageHandler(target.cached_speed, 7, mod if on else None))
        if target.base_ability_id == MULTISCALE:
            applies = target.ability_id == MULTISCALE and target.hp >= target.max_hp
            handlers.append(
                DamageHandler(target.cached_speed, 7, MULTISCALE_MODIFIER if applies else None)
            )
        if target.item in RESIST_BERRIES:
            effectiveness = type_mod(move, target.combatant())  # 021: Freeze-Dry
            applies = resist_berry(target.item, move.type, effectiveness)
            if self._hits_substitute(user, move, target):
                applies = False  # hitSub: the berry's handler returns (016)
            modifier = RESIST_BERRY_MODIFIER if applies else None
            handlers.append(DamageHandler(target.cached_speed, 8, modifier))
            if applies and target.ability_id == "ripen":
                # 043-4h: Ripen's berryWeaken (onSourceModifyDamagePriority -1: after the rest)
                handlers.append(DamageHandler(-1, 99, (1, 2)))
        return handlers

    @staticmethod
    def _accuracy_true(target: BattlePokemon, move: Move, user: BattlePokemon) -> bool:
        """``runEvent('Accuracy')`` gives true: glaiverush (023) and minimize (034, R5: a move
        with the minimize flag) ``onAccuracy``; the user's lockon on it (041-6f)."""
        return (
            target.glaive_rush
            or (target.minimized and MINIMIZE_FLAG in move.flags)
            or _locked_on(user, target)
            or NO_GUARD in (user.ability_id, target.ability_id)  # 043-2b: onAnyAccuracy
        )

    def _counter_hit(
        self, user: BattlePokemon, move: Move, target: BattlePokemon, dealt: int
    ) -> None:
        """041-4a: the counter / mirrorcoat volatile's onDamagingHit: a foe's physical /
        special hit sets the slot and twice the damage (the last hit wins)."""
        if user.side == target.side or not dealt:
            return
        for volatile, category in REFLECT_CATEGORY.items():
            if volatile in target.timed and move.category == category:
                assert user.position is not None
                target.counter_hit = (user.side, user.position, 2 * dealt)

    def _before_turn_move(self, action: _Action) -> None:
        """041-4a: runAction's beforeTurnMove: getTarget (a fainted foe at the location picks
        another, one draw), then the move's beforeTurnCallback adds its volatile (duration 1,
        onStart: slot null, damage 0)."""
        pokemon = action.pokemon
        assert isinstance(action.choice, MoveChoice)
        if action.loc is not None:
            foe = self.state.at(foe_of(pokemon.side), action.loc - 1)
            if (foe is None or foe.fainted) and self._random_foe_draw(pokemon) is None:
                return  # no target: runAction returns false
        elif self._random_foe_draw(pokemon) is None:
            return
        move_id = chosen_move(pokemon, action.choice).id
        if move_id in pokemon.timed:
            return  # addVolatile: already there (no onRestart)
        pokemon.timed[move_id] = 1
        pokemon.counter_hit = None

    def _anticipates(self, pokemon: BattlePokemon) -> bool:
        """043-5a: Anticipation: a foe's damaging move it is weak to (not immune), or OHKO."""
        dex = get_dex()
        for foe in self.state.sides[foe_of(pokemon.side)].alive_active():
            for slot in foe.moves:
                move = slot.move
                if move.category == "Status":
                    continue
                types = tuple(pokemon.types)
                weak = not dex.is_immune(move.type, types) and dex.type_mod(move.type, types) > 0
                if weak or OHKO in move.keys:
                    return True
        return False

    def _forewarn(self, pokemon: BattlePokemon) -> None:
        """043-5a: Forewarn's onStart: the foes' moves with the highest power (OHKO 150,
        Counter / Metal Burst / Mirror Coat 120, a damaging move without one 80), one of
        them sampled: ``-activate … ability: Forewarn``."""
        warn: list[tuple[str, BattlePokemon]] = []
        best = 1
        for foe in self.state.sides[foe_of(pokemon.side)].alive_active():
            for slot in foe.moves:
                move = slot.move
                bp = move.base_power
                if OHKO in move.keys:
                    bp = 150
                if move.id in ("counter", "metalburst", "mirrorcoat"):
                    bp = 120
                if bp == 1 or (not bp and move.category != "Status"):
                    bp = 80
                if bp > best:
                    warn, best = [(move.name, foe)], bp
                elif bp == best:
                    warn.append((move.name, foe))
        if warn:
            name, _ = self.prng.sample(warn)
            self._emit("activate", target=pokemon.label, detail="ability: Forewarn", value=name)

    def _sticky_hold(self, pokemon: BattlePokemon, source: BattlePokemon | None) -> bool:
        """043-5a: Sticky Hold's onTakeItem: another Pokemon cannot take it (-activate)."""
        if pokemon.ability_id != "stickyhold" or pokemon.hp <= 0 or pokemon.item == STICKY_BARB:
            return False
        if source is None or source is pokemon:
            return False
        self._emit("activate", target=pokemon.label, detail="ability: Sticky Hold")
        return True

    def _ability_trapped(self, pokemon: BattlePokemon) -> bool:
        """043-5b: the foes' onFoeTrapPokemon (Shadow Tag: not another Shadow Tag; Arena
        Trap: grounded; Magnet Pull: Steel), each a tryTrap (a Ghost is immune), and Shed
        Shell's handler (priority -10) frees it. Holders of the same speed are shuffled."""
        holders = [
            p for p in self.state.sides[foe_of(pokemon.side)].alive_active()
            if p.ability_id in ("shadowtag", "arenatrap", "magnetpull")
        ]  # fmt: skip
        if len(holders) > 1:
            speed_sort(holders, self.prng, _by_speed)
        trapped = False
        for holder in holders:
            ability = holder.ability_id
            if ability == "shadowtag":
                caught = pokemon.ability_id != "shadowtag"
            elif ability == "arenatrap":
                caught = GRAVITY in self.state.field.pseudo_weather or is_grounded(
                    pokemon.types, pokemon.ability_id, pokemon.item, pokemon.pinned,
                    rising="magnetrise" in pokemon.timed,
                )  # fmt: skip
            else:
                caught = "Steel" in pokemon.types
            if caught and "Ghost" not in pokemon.types:
                trapped = True
        return trapped and pokemon.item != SHED_SHELL

    def _protean(self, user: BattlePokemon, move: Move) -> None:
        """043-5c: Protean / Libero's onPrepareHit: once per switch-in, not for a move that
        calls another or a future move; setType (false when terastallized), then
        ``-start … typechange``."""
        if user.ability_id not in ("protean", "libero") or user.protean_used:
            return
        if "futuremove" in move.flags or "callsMove" in move.keys:
            return
        if move.type == "???" or tuple(user.types) == (move.type,):
            return
        if user.terastallized is not None:
            return
        user.base_types = (move.type,)
        user.type_changed = True
        user.added_type = None
        user.apparent_type = user.base_types
        user.protean_used = True
        self._emit("start", target=user.label, detail="typechange")

    def _add_charge(self, pokemon: BattlePokemon) -> None:
        """043-4d: addVolatile('charge') (Electromorphosis, Wind Power)."""
        add_volatile(
            pokemon, "charge", prng=self.prng, emit=self._emit_kw,
            terrain=self.state.field.terrain, source=pokemon,
        )  # fmt: skip

    def _tailwind_start(self, side_id: str) -> None:
        """043-4d: runEvent('SideConditionStart') for Tailwind: Wind Power's charge, Wind
        Rider's Attack +1 (the holders by speed)."""
        holders = [
            p for p in self.state.sides[side_id].alive_active()
            if p.ability_id in ("windpower", "windrider") and p.hp > 0
        ]  # fmt: skip
        speed_sort(holders, self.prng, _by_speed)
        for p in holders:
            if p.ability_id == "windpower":
                self._add_charge(p)
            else:
                apply_boosts(
                    p, {"atk": 1}, primary=False, foes_left=self._foes_left(p),
                    emit=self._emit_kw, source=p, ability="Wind Rider",
                )  # fmt: skip

    def _flinch_before_move(self, user: BattlePokemon) -> bool:
        """flinch's onBeforeMove, then runEvent('Flinch'): 043-4b Steadfast's Speed +1."""
        if flinch_before_move(user, self._emit_kw):
            return True
        if user.ability_id == "steadfast":
            apply_boosts(
                user, {"spe": 1}, primary=False, foes_left=self._foes_left(user),
                emit=self._emit_kw, source=user, ability="Steadfast",
            )  # fmt: skip
        return False

    def _damaging_hit(
        self, user: BattlePokemon, move: Move, target: BattlePokemon, dealt: int
    ) -> None:
        """The target's ability ``onDamagingHit`` (012), after its status's (frz)."""
        ability = target.ability_id
        boost = ON_HIT_BOOSTS.get(ability)
        if boost is not None and (boost[1] is None or move.type in boost[1]):
            apply_boosts(
                target, {boost[0]: boost[3]}, primary=False, foes_left=self._foes_left(target),
                emit=self._emit_kw, source=user, ability=boost[2],
            )  # fmt: skip
        elif ability == WEAK_ARMOR and move.category == "Physical":
            apply_boosts(
                target,
                {"def": -1, "spe": 2},
                primary=False,
                foes_left=self._foes_left(target),
                emit=self._emit_kw,
                source=target,
                ability="Weak Armor",
            )  # fmt: skip  (032 R12: boost(..., target, target))
        elif (
            ability == FLAME_BODY
            and self._makes_contact(move, user)
            and self.prng.random_chance(3, 10)
        ):
            self._set_status(user, "brn", target, status_move=False)
        elif ability in CONTACT_STATUS and self._makes_contact(move, user):
            if self.prng.random_chance(3, 10):  # 043-3a: Static, Poison Point
                self._set_status(user, CONTACT_STATUS[ability], target, status_move=False)
        elif ability == "cutecharm" and self._makes_contact(move, user):
            if self.prng.random_chance(3, 10):  # 043-3b: addVolatile('attract', holder)
                self._add_attract(user, target, from_move=False)
        elif ability == EFFECT_SPORE and self._makes_contact(move, user):
            powder_immune = (
                get_dex().effect_immune("powder", user.types)
                or user.ability_id == OVERCOAT
                or user.item == SAFETY_GOGGLES
            )  # runStatusImmunity('powder')
            if not powder_immune:
                r = self.prng.random_int(100)  # 043-3a: Effect Spore
                status = "slp" if r < 11 else "par" if r < 21 else "psn" if r < 30 else None
                if status is not None:
                    self._set_status(user, status, target, status_move=False)
        elif ability == "gulpmissile":  # 043-6f: the attacker hit back (a live, active one)
            name = target.species.name
            if (
                user.hp > 0
                and is_active(user)
                and not vanished(target)
                and name in ("Cramorant-Gulping", "Cramorant-Gorging")
            ):
                self._chip(user, user.max_hp / 4, "ability: gulp missile", source=target)
                if name == "Cramorant-Gulping":
                    apply_boosts(
                        user, {"def": -1}, primary=False, foes_left=self._foes_left(target),
                        emit=self._emit_kw, source=target, ability="Gulp Missile",
                    )  # fmt: skip
                else:
                    self._set_status(user, "par", target, status_move=False)
                self._temporary_forme(target, "Cramorant")
        elif ability == "cursedbody":  # 043-5a: randomChance(3, 10): disable the attacker
            if (
                DISABLE not in user.timed
                and "futuremove" not in move.flags
                and move.id != "struggle"
                and self.prng.random_chance(3, 10)
            ):
                self._disable(user, from_move=False, acting=not self._external_move)
        elif ability == "lingeringaroma":  # 043-5c: contact: the attacker's ability
            yours = get_dex().ability(user.base_ability_id)
            if (
                not (yours and yours.cant_suppress)
                and user.base_ability_id != "lingeringaroma"
                and self._makes_contact(
                    move,
                    user,
                    target,
                    announce="ability: Lingering Aroma" if user.side != target.side else None,
                )
            ):
                self._set_ability(user, "Lingering Aroma", target, None, activate=target)
        elif ability == "sandspit":  # 043-4d: setWeather('sandstorm')
            if set_weather(self.state.field, SAND, emit=self._emit_kw,
                           duration=_weather_duration(target, SAND)):  # fmt: skip
                self._weather_change()
        elif ability == "seedsower":  # 043-4d: setTerrain('grassyterrain')
            duration = 8 if target.item == TERRAIN_EXTENDER else None
            if set_terrain(self.state.field, GRASSY, emit=self._emit_kw, duration=duration):
                self._terrain_change()
        elif ability in ("gooey", "tanglinghair") and self._makes_contact(
            move, user, target, announce=f"ability: {_TANGLERS[ability]}"
        ):
            # 043-4d: -ability, then boost({spe: -1}, source, target, null, isSecondary)
            self._emit("ability", target=target.label, detail=_TANGLERS[ability])
            apply_boosts(
                user, {"spe": -1}, primary=False, foes_left=self._foes_left(user),
                emit=self._emit_kw, source=target, ability=_TANGLERS[ability],
            )  # fmt: skip
        elif ability == ILLUSION and target.illusion is not None:
            self._illusion_end(target)  # 034 (R6): onDamagingHit
        elif ability == TOXIC_DEBRIS and move.category == "Physical":
            # 020 (R5): a layer of Toxic Spikes on the attacker's side (an ally's move: its foes')
            side = foe_of(user.side) if user.side == target.side else user.side
            if self.state.field.hazards[side].get(TOXIC_SPIKES, 0) < 2:
                self._emit("activate", target=target.label, detail="ability: Toxic Debris")
                add_hazard(self.state.field, side, TOXIC_SPIKES, emit=self._emit_kw)

    def _charge(self, user: BattlePokemon, move: Move, targeting: Targeting) -> bool:
        """020 (R6): Meteor Beam's onTryMove. True: the move goes on (its second turn, or Power
        Herb). Otherwise ``-prepare``, SpA +1, ``runEvent('ChargeMove')`` and twoturnmove.
        021 (R8): Electro Shot in the rain fires at once (``-anim``; Power Herb is kept).
        026 (R1): Solar Beam / Solar Blade: no boost; in the sun they fire at once."""
        if user.charged:  # removeVolatile(move.id)
            user.charged = False
            _clear_vanished(user)  # 026 (R7): visible again (041-2: Dig, Fly, ...)
            return True
        if (  # 043-6f: Dive's onTryMove: Gulp Missile (not transformed)
            move.id == "dive"
            and user.ability_id == "gulpmissile"
            and user.species.name == "Cramorant"
            and user.transform_base is None
        ):
            self._gulp(user)
        self._emit("prepare", target=user.label, detail=move.name)
        if move.id in SPA_CHARGERS:  # (026: Solar Beam / Solar Blade raise nothing)
            apply_boosts(user, {"spa": 1}, primary=True, foes_left=self._foes_left(user),
                         emit=self._emit_kw, source=user)  # fmt: skip
        if fires_at_once(move, effective_weather(self.state.field.active_weather, user.item)):
            return True  # (the -anim line is not compared)
        if user.item == POWER_HERB and self._use_item(user):
            return True  # onChargeMove returns false
        if TWO_TURN not in user.timed:  # addVolatile('twoturnmove', defender)
            user.timed[TWO_TURN] = 2
            user.two_turn_move = move.id
            user.charge_loc = self._move_loc
            if self._calling and move.target != "self":
                # 041-5: a called move (Copycat; effect.sourceEffect): the defender's location
                # (a fainted one: a sample of the foes, fainted ones too)
                defender = targeting.targets[0] if targeting.targets else None
                if defender is None or defender.fainted:
                    foes = [f for f in self.state.sides[foe_of(user.side)].active if f is not None]
                    defender = self.prng.sample(foes) if foes else None
                if defender is not None and defender.position is not None:
                    loc = defender.position + 1
                    user.charge_loc = -loc if defender.side == user.side else loc
            user.charged = True
            if move.id in SEMI_INVULNERABLE:
                # 026 (R7): twoturnmove's onStart adds the move's volatile (duration 2, so it
                # joins the residual sort after twoturnmove): semi-invulnerable (041-2: Dig,
                # Fly, Dive, Bounce, Shadow Force)
                user.timed[move.id] = 2
        return False

    def _smack_down(self, pokemon: BattlePokemon) -> None:
        """041-2: the smackdown condition's onStart / onRestart. Fly and Bounce end (their move
        is cancelled, twoturnmove removed); otherwise it applies to a Flying type or Levitate,
        not with an Iron Ball, Ingrain (041-4c) or Gravity (041-4e) (Magnet Rise and Telekinesis
        are unsupported)."""
        sky = vanished(pokemon) in ("fly", "bounce")
        if sky:
            _clear_vanished(pokemon)
            if self._queue is not None:  # cancelMove
                self._queue.remove(lambda a: a.pokemon is pokemon and a.kind == "move")
            if pokemon.timed.pop(TWO_TURN, None) is not None:
                pokemon.two_turn_move, pokemon.charge_loc, pokemon.charged = None, None, False
        if pokemon.smacked_down:  # onRestart
            if sky:
                self._emit("start", target=pokemon.label, detail="Smack Down")
            return
        applies = "Flying" in pokemon.types or pokemon.ability_id == "levitate"
        if pokemon.item == "ironball" or "ingrain" in pokemon.timed or pokemon.gravity:
            applies = False
        if pokemon.timed.pop(MAGNET_RISE, None) is not None:
            applies = True  # 041-6f: magnetrise deleted (no onEnd)
        if not (applies or sky):
            return
        pokemon.smacked_down = True
        self._emit("start", target=pokemon.label, detail="Smack Down")

    def _spin_away(self, user: BattlePokemon, move: Move) -> None:
        """020 (R4): Rapid Spin / Mortal Spin ``onAfterHit``: the hazards on the user's side,
        ``-sideend … [from] move: …``, then partial trapping (024). 041-4c: Leech Seed first
        (``-end … Leech Seed [from] move: …``)."""
        if LEECH_SEED in user.timed:
            del user.timed[LEECH_SEED]
            user.leech_slot = None
            self._emit("end", target=user.label, detail="Leech Seed")
        for hazard in REMOVE_ORDER:
            if user.hp > 0 and remove_hazard(self.state.field, user.side, hazard):
                self._emit("sideend", actor=user.side, detail=HAZARDS[hazard].name)
        if user.hp > 0 and PARTIALLY_TRAPPED in user.timed:
            self._end_partially_trapped(user)  # 024 R6: removeVolatile (onEnd)

    def _defog(self, user: BattlePokemon, target: BattlePokemon) -> bool:
        """020 (R4): Defog's onHit. Evasion -1 (not through a substitute); the target side's
        screens end with their own message and its hazards with Defog's; then the user side's
        hazards; then the terrain (not counted as a success)."""
        success = False
        if not target.substitute_hp or user.ability_id == INFILTRATOR:  # (043-1)
            success = apply_boosts(
                target, {"evasion": -1}, primary=True, foes_left=self._foes_left(target),
                emit=self._emit_kw, source=user,
            )  # fmt: skip
        field_state = self.state.field
        for screen in DEFOG_SCREENS:  # (Safeguard and Mist are unsupported)
            if field_state.has_side(target.side, screen):
                end_side_condition(field_state, target.side, screen, self._emit_kw)
        for side in (target.side, user.side):
            for hazard in REMOVE_ORDER:
                if remove_hazard(field_state, side, hazard):
                    self._emit("sideend", actor=side, detail=HAZARDS[hazard].name)
                    success = True
        self._clear_terrain()
        return success

    def _tidy_up(self, user: BattlePokemon) -> bool:
        """020 (R4): Tidy Up's onHit. Every substitute (getAllActive order), both sides'
        hazards (the user's first, no [from]), ``-activate`` if anything went, then Atk and Spe
        +1 (a self effect)."""
        success = False
        for pokemon in self.state.all_active():
            if pokemon.substitute_hp > 0:
                pokemon.substitute_hp = 0
                self._emit("end", target=pokemon.label, detail="Substitute")
                success = True
        for side in (user.side, foe_of(user.side)):
            for hazard in REMOVE_ORDER:
                if remove_hazard(self.state.field, side, hazard):
                    self._emit("sideend", actor=side, detail=HAZARDS[hazard].name)
                    success = True
        if success:
            self._emit("activate", target=user.label, detail="move: Tidy Up")
        boosted = apply_boosts(
            user, {"atk": 1, "spe": 1}, primary=False, foes_left=self._foes_left(user),
            emit=self._emit_kw, source=user,
        )  # fmt: skip
        return boosted or success

    def _after_move_secondary(
        self, user: BattlePokemon, move: Move, targets: list[BattlePokemon], dealt: dict[int, int]
    ) -> None:
        """``runEvent('AfterMoveSecondary', targets)``: frz's thaw (moves that thaw) and
        Berserk (012), speed-sorted (ties shuffled). Sheer Force skips it."""
        handlers: list[tuple[BattlePokemon, str]] = []
        for target in targets:
            if target.status == "frz":
                handlers.append((target, "frz"))
            if target.base_ability_id in _HALF_HP_BOOSTS and not target.fainted:
                handlers.append((target, target.base_ability_id))  # (043-4i: Anger Shell)
            if target.held_item in HIT_BERRIES:  # (041-6f: sorted while ignored)
                handlers.append((target, "item"))  # 040-2: Kee / Maranga Berry
            if target.held_item in (EJECT_BUTTON, RED_CARD):
                handlers.append((target, target.held_item))  # 040-3
            if target.base_ability_id == "pickpocket":
                handlers.append((target, "pickpocket"))  # 043-5a
        speed_sort(handlers, self.prng, _by_after_secondary)
        for target, kind in handlers:
            if kind == "frz":
                if move.thaws_target and target.status == "frz":
                    cure(target, self._emit_kw)  # frz onAfterMoveSecondary
                continue
            if kind == EJECT_BUTTON:
                self._eject_button(user, move, target)
                continue
            if kind == RED_CARD:
                self._red_card(user, move, target)
                continue
            if kind == "pickpocket":
                self._pickpocket(user, move, target)
                continue
            if kind == "item":
                berry = HIT_BERRIES.get(target.item)
                if berry is not None and move.category == berry[0]:
                    self._eat_item(target, partial(self._berry_boost, target, berry[1]))
                continue
            damage = dealt.get(id(target), 0)
            if target.ability_id == kind:
                target.checked_berserk = True
            if target.ability_id != kind or target is user or target.hp <= 0 or not damage:
                continue
            half = target.max_hp / 2
            if target.hp <= half < target.hp + damage:
                boosts, name = _HALF_HP_BOOSTS[kind]
                apply_boosts(
                    target, dict(boosts), primary=False, foes_left=self._foes_left(target),
                    emit=self._emit_kw, source=target, ability=name,
                )  # fmt: skip

    def _pickpocket(self, source: BattlePokemon, move: Move, target: BattlePokemon) -> None:
        """043-5a: Pickpocket's onAfterMoveSecondary: a contact move's user loses its item
        to the holder (takeItem, setItem; back to the user when setItem fails)."""
        if target.ability_id != "pickpocket" or source is target or "contact" not in move.flags:
            return
        if target.held_item or target.switch_flag or source.switch_flag:
            return
        item = source.held_item
        if not self._trick_take(source, item, target):
            return
        if target.hp <= 0 or target.position is None:
            source.item = item  # setItem failed: source.item = yourItem.id
            return
        self._set_item(target, item)
        self._emit("enditem", target=source.label, detail=item_name(item))
        self._emit("item", target=target.label, detail=item_name(item))

    def _eject_button(self, source: BattlePokemon, move: Move, target: BattlePokemon) -> None:
        """040-3: Eject Button's onAfterMoveSecondary: the holder hit by another Pokémon's
        damaging move switches out (``switchFlag``; the attacker's own switch is cancelled)."""
        if target.item != EJECT_BUTTON or source is target or target.hp <= 0:
            return
        if move.category == "Status" or "futuremove" in move.flags:
            return
        if not self.state.sides[target.side].bench() or target.force_switch:
            return
        if target.commanding or target.commanded_by is not None:
            return
        if any(p.switch_flag is True for p in self.state.all_active()):
            return
        if self._use_item(target):
            target.switch_flag = True
            source.switch_flag = None
            self._eject_cancelled.append(source)

    def _red_card(self, source: BattlePokemon, move: Move, target: BattlePokemon) -> None:
        """040-3: Red Card's onAfterMoveSecondary: ``useItem(source)`` (``-enditem … [of]``),
        then DragOut on the attacker: dragged out at the end of the action."""
        if target.item != RED_CARD or source is target or source.hp <= 0 or target.hp <= 0:
            return
        if move.category == "Status":
            return
        if source.position is None or not self.state.sides[source.side].bench():
            return
        if source.force_switch or target.force_switch:
            return
        if target.position is None:
            return
        self._emit("enditem", target=target.label, detail="Red Card", actor=source.label)
        self._lose_item(target, unburden=True)
        if self._drag_out(source):
            source.force_switch = True

    def _run_status_move(self, user: BattlePokemon, move: Move, hit: list[BattlePokemon]) -> None:
        """A status move (``runMoveEffects``): stat stages (004), then a status condition (003)
        or confusion (005). A failed status reports itself; when nothing else happened, a
        failed volatile status makes the move fail (``combineResults``)."""
        landed = []
        if move.id in ONE_TURN_MOVES:
            # 009: Protect and its variants, Endure, Follow Me, Rage Powder, Ally Switch,
            # Helping Hand (its onTryHit runs in spreadMoveHit)
            if move.id == "helpinghand":
                if not hit or not self._helping_hand(user, hit[0]):
                    return
            else:
                self._self_effect(user, move)
            self._move_succeeded = True
            self._update()  # hitStepMoveHitLoop: eachEvent('Update')
            self._update()  # eachEvent('Update') after faint messages
            return
        if move.id in WISHES:
            self._healing_wish(user, move.id)  # 025 (R5), 041-6d
            return
        if move.id == REVIVAL_BLESSING:
            self._revival_blessing(user)  # 041-6f
            return
        if move.id == "instruct":  # 041-6f: onHit; false -> -fail (runMoveEffects)
            if hit and self._instruct(user, hit[0]):
                self._move_succeeded = True
                self._update()  # hitStepMoveHitLoop: eachEvent('Update')
                self._update()  # eachEvent('Update') after faint messages
            elif hit:
                self._emit("fail", actor=user.label)
            return
        if move.id in (AFTER_YOU, "quash"):  # 025 (R7): onHit; false -> -fail (runMoveEffects)
            if hit and self._after_you(hit[0], quash=move.id == "quash"):
                self._move_succeeded = True
                self._update()  # hitStepMoveHitLoop: eachEvent('Update')
                self._update()  # eachEvent('Update') after faint messages
            elif hit:  # 041-6f: missed everyone (Quash, After You): no -fail
                self._emit("fail", actor=user.label)
            return
        if move.id == "rest":
            self._rest(user)  # 041-3d
            return
        if move.id == STOCKPILE:  # 041-4d: the volatile's onStart / onRestart
            self._stockpile(user)
            self._move_succeeded = True
            self._update()  # hitStepMoveHitLoop: eachEvent('Update')
            self._update()  # eachEvent('Update') after faint messages
            return
        if move.id == SWALLOW:  # 041-4d: onHit
            layers = user.stockpile[0] if user.stockpile else 1
            amount = modify(user.max_hp, (1024, 2048, 4096)[layers - 1], 4096)
            if not self._heal(user, amount, ""):
                self._emit("fail", actor=user.label, detail="heal")
            if user.stockpile is not None:
                self._end_stockpile(user)
            self._move_succeeded = True  # (NOT_FAIL when nothing was healed)
            self._update()  # hitStepMoveHitLoop: eachEvent('Update')
            self._update()  # eachEvent('Update') after faint messages
            return
        if move.id == WISH:  # 041-4b: the slotCondition; false -> -fail
            if self._wish(user):
                self._move_succeeded = True
                self._update()  # hitStepMoveHitLoop: eachEvent('Update')
                self._update()  # eachEvent('Update') after faint messages
            else:
                self._emit("fail", actor=user.label)
            return
        if move.id in ("splash", "celebrate"):
            # 041-3a: onTryHit's -nothing / -activate (NOT_FAIL: the move does not fail)
            if move.id == "celebrate":
                self._emit("activate", target=user.label, detail="move: Celebrate")
            self._move_succeeded = True
            self._update()  # hitStepMoveHitLoop: eachEvent('Update')
            self._update()  # eachEvent('Update') after faint messages
            return
        if move.id == SLEEP_TALK:
            self._sleep_talk(user, move)  # 025: onHit (target self, no other effect)
            self._update()  # hitStepMoveHitLoop: eachEvent('Update')
            self._update()  # eachEvent('Update') after faint messages
            return
        if move.id == METRONOME:
            self._metronome(user, move)  # 041-6f: onHit
            self._update()  # hitStepMoveHitLoop: eachEvent('Update')
            self._update()  # eachEvent('Update') after faint messages
            return
        if move.id == COPYCAT:
            if self._copycat(user, move):  # 041-5: onHit
                self._update()  # hitStepMoveHitLoop: eachEvent('Update')
                self._update()  # eachEvent('Update') after faint messages
            else:
                # onHit false: the hit loop breaks before its Updates (moves041-31)
                self._emit("fail", actor=user.label)
            return
        if (
            (move.id == "teleport" and not self.state.sides[user.side].bench())
            or (move.id == FILLET_AWAY and (user.hp * 2 <= user.max_hp or user.max_hp == 1))
            or (move.id == "noretreat" and user.no_retreat)
            or (move.id == MAGNET_RISE and (user.smacked_down or "ingrain" in user.timed))
        ):
            self._emit("fail", actor=user.label)  # 041-6d: onTry false
            return
        if move.id == CLANGOROUS_SOUL and (user.hp * 100 <= user.max_hp * 33 or user.max_hp == 1):
            self._emit("fail", actor=user.label)  # 032 (R15): onTry
            return
        if move.id == CURSE and "Ghost" in user.types and hit and CURSE in hit[0].timed:
            self._emit("fail", actor=user.label)  # 032 (R15): onTryHit false
            return
        if move.id == YAWN and hit and hit[0].status is not None:
            self._emit("fail", actor=user.label)  # 025 R1: the move's onTryHit (like Disable's)
            return
        if move.id == LOCK_ON and hit and LOCK_ON in user.timed:
            self._emit("fail", actor=user.label)  # 041-6f: onTryHit false
            return
        if move.id == DISABLE and hit and hit[0].last_move in (None, "struggle"):
            # 023: the move's onTryHit, a singleEvent at the start of spreadMoveHit (after
            # accuracy, before the substitute): false -> -fail, the move fails
            self._emit("fail", actor=user.label)
            return
        did_anything: bool | None = None  # None: no effect gave a result (Showdown null)
        switches = False
        # 016: spreadMoveHit step 0, every target first: onTryPrimaryHit's getDamage gives
        # nothing -> -fail (the user), null; the hit loop still goes on, so the move counts
        # as used (research U3)
        behind = [t for t in hit if self._hits_substitute(user, move, t)]
        for _ in behind:
            self._emit("fail", actor=user.label)
        blocked_by_substitute = bool(behind)
        for target in hit:
            did: bool | None = None
            if target in behind:
                continue
            if move.id == PARTING_SHOT:
                # 014: onHit boosts; no switch when nothing dropped (Mirror Armor still switches).
                # Eject Pack's onAfterBoost does nothing while Parting Shot is the active move.
                ejects = {id(p): p.eject_pending for p in self.state.all_active()}
                dropped = apply_boosts(
                    target, PARTING_SHOT_DROPS, primary=True, foes_left=self._foes_left(target),
                    emit=self._emit_kw, source=user,
                )  # fmt: skip
                for p in self.state.all_active():
                    p.eject_pending = ejects.get(id(p), p.eject_pending)
                switches = switches or dropped or target.ability_id == MIRROR_ARMOR
                did = True
            if move.id == HEAL_PULSE:
                # 030 (R5): onHit heals ceil(baseMaxhp / 2); otherwise -fail target heal and
                # NOT_FAIL (probe: the move still succeeds)
                if not self._heal(target, -(-target.max_hp // 2), ""):
                    self._emit("fail", actor=target.label)
                did = True
            if move.id in WEATHER_HEALS or move.id in (FLORAL_HEALING, "shoreup"):
                # 032 (R14): onHit heals; otherwise -fail target heal and NOT_FAIL
                if not self._heal(target, self._heal_amount(move, target), ""):
                    self._emit("fail", actor=target.label)
                did = True
            if move.id == BELLY_DRUM:
                did = self._belly_drum(target)
            if move.id in (CLANGOROUS_SOUL, FILLET_AWAY):
                # 032 (R15): onTryHit's boost (null when nothing rose), then onHit's
                # directDamage(maxhp * 33 / 100) (041-6d: Fillet Away's maxhp / 2)
                assert move.boosts is not None
                if not apply_boosts(
                    target, move.boosts, primary=True, foes_left=self._foes_left(target),
                    emit=self._emit_kw, source=user,
                ):  # fmt: skip
                    continue
                share = 33 / 100 if move.id == CLANGOROUS_SOUL else 1 / 2
                self._direct_cost(target, target.max_hp * share)
                did = True
            if move.id == "teleport":
                did = True  # 041-6d: selfSwitch (canSwitch was checked by onTry)
                switches = True
            if move.id == CURSE:
                did = self._curse(user, target)
            if move.id in HEALING_MOVES:
                did = self._heal_move(user, move, target)
                if move.id == ROOST and did:
                    self._roost(target)  # selfDrops: only when the heal worked
            if move.id == DEFOG:
                did = self._defog(user, target)
            if move.id == TIDY_UP:
                did = self._tidy_up(user)
            if move.id == PAIN_SPLIT:
                did = self._pain_split(user, target)
            if move.id == STRENGTH_SAP:
                did = self._strength_sap(user, target)
            if move.id == DISABLE:
                did = self._disable(target)
            if move.id == "spite":
                did = self._spite(target)  # 041-3f
            if move.id in ("block", "meanlook"):
                did = self._trap(user, target)  # 041-3g
            if move.id in ABILITY_MOVES:
                did = self._ability_move(user, target, move)  # 041-3h
            if move.id == TRANSFORM:
                did = self._transform(user, target)  # 041-6f
            if move.id == CORROSIVE_GAS:
                did = self._corrosive_gas(user, target)  # 041-6f
            if move.id == DOODLE:
                if not self._doodle(user, target, move):
                    continue  # 041-6f: NOT_FAIL
                did = True
            if move.id == LOCK_ON:  # 041-6f: onHit: source.addVolatile('lockon', target)
                user.timed[LOCK_ON] = 2
                user.lock_on_target = target
                self._emit("activate", target=user.label, detail="move: Lock-On")
                did = True
            if move.id == "psychup":
                did = self._psych_up(user, target)  # 041-3f
            if move.id in SWAP_SPLIT_MOVES:
                did = self._swap_split(user, target, move.id)  # 041-6c
            if move.id in (TRICK, "switcheroo"):  # (041-3c: Switcheroo's onHit is Trick's)
                did = self._trick(user, target)
            if move.id == SKILL_SWAP:
                did = self._skill_swap(user, target)
            if move.id == SUBSTITUTE:
                did = self._substitute(target)
            if move.id == SHED_TAIL:
                did = self._shed_tail(target)
                switches = switches or bool(did)
            if move.id == BATON_PASS:
                # 034 (R4): onHit: nobody to switch to or commanded -> -fail and NOT_FAIL
                if not self.state.sides[target.side].bench() or target.commanded_by is not None:
                    self._emit("fail", actor=target.label)
                    continue
                did = True
                switches = True
            if FORCE_SWITCH in move.keys:
                # 034 (R1): runMoveEffects' hitResult = !!canSwitch(target.side)
                did = bool(self.state.sides[target.side].bench())
            if move.boosts and move.id not in (CLANGOROUS_SOUL, FILLET_AWAY):
                boosted = apply_boosts(
                    target,
                    move.boosts,
                    primary=True,
                    foes_left=self._foes_left(target),
                    emit=self._emit_kw,
                    source=user,
                )
                did = True if boosted else None  # boost() returns null when nothing changed
            if move.status is not None:
                if not self._set_status(target, move.status, user, status_move=True, by_move=True):
                    continue  # (combines with null)
                did = True
            if move.volatile_status is not None and move.volatile_status in MOVE_LOCKS:
                did = self._add_move_lock(target, move.volatile_status)
            elif (
                move.volatile_status in (YAWN, HEAL_BLOCK, "torment")
                and move.volatile_status not in target.timed
                and not (move.volatile_status == "torment" and target.torment)
                and target.hp > 0
                and self._volatile_veil(target, move.volatile_status, from_move=True)
            ):
                pass  # 032 (R13): TryAddVolatile's null combines as no result
            elif move.volatile_status == "attract":
                did = self._add_attract(target, user, from_move=True)  # 041-6f
            elif move.volatile_status == "noretreat":
                # 041-6d: onTry deletes volatileStatus while trapped (Mean Look, Block)
                if target.trapper is None and not target.no_retreat:
                    target.no_retreat = True
                    self._emit("start", target=target.label, detail="move: No Retreat")
                    did = True
            elif move.volatile_status == "tarshot":
                # 041-6c: tarshot's onStart is false when terastallized; addVolatile is
                # false (no message) when it is there already
                if target.terastallized is None and not target.tar_shot and target.hp > 0:
                    target.tar_shot = True
                    self._emit("start", target=target.label, detail="Tar Shot")
                    did = True
                else:
                    did = bool(did)
            elif move.volatile_status is not None and move.id not in (
                SUBSTITUTE,
                SHED_TAIL,
                DISABLE,
                CURSE,
                "gastroacid",  # 041-3h: _ability_move
            ):
                added = add_volatile(
                    target, move.volatile_status, prng=self.prng, emit=self._emit_kw,
                    terrain=self.state.field.terrain, from_status_move=True, source=user,
                )  # fmt: skip
                if added is not None:  # null (Misty Terrain) combines as no result
                    did = bool(did or added)
            if move.volatile_status == "confusion" and target.ability_id == "owntempo":
                self._emit("immune", target=target.label)  # Own Tempo onHit (runEvent 'Hit')
            if did:
                landed.append(target)
            if did is not None:
                did_anything = bool(did_anything or did)
        if did_anything is False:
            self._emit("fail", actor=user.label)
        if FORCE_SWITCH in move.keys:
            landed = self._force_switch(user, landed, move)
        if move.id == MEMENTO and len(hit) > len(behind):
            user.hp = 0  # 041-4e: selfdestruct 'ifHit' (faint(); the hit loop's faintMessages)
            landed = landed or [user]
        if switches and user.hp > 0 and user.commanded_by is None:  # (028: not while commanded)
            user.switch_flag = move.id  # runMoveEffects: selfSwitch (014)
        if landed or blocked_by_substitute:
            self._move_succeeded = True
            self._update()  # hitStepMoveHitLoop: eachEvent('Update')
            if user.hp == 0 and not user.fainted:
                # I-001 (old bug from 032): a Ghost's Curse knocked its user out; the hit
                # loop's faintMessages(checkWin = !user.hp) comes before the next Update
                self._faint_out(user)
                self._check_win(user)
            self._update()  # eachEvent('Update') after faint messages

    def _heal_bell(self, user: BattlePokemon) -> bool:
        """041-3f: Heal Bell's onHit: ``-activate``, then each of the side's Pokemon
        (side.pokemon order) is cured; another one with Soundproof or Good as Gold shows
        ``-immune``. False when nobody was cured."""
        for ally in self.state.sides[user.side].alive_active():
            if ally.ability_id == SOUNDPROOF:  # onAllyTryHitSide: a sound move (no effect)
                self._emit("immune", target=ally.label)
        self._emit("activate", target=user.label, detail="move: Heal Bell")
        cured = False
        for ally in self.state.sides[user.side].order:
            # (review P2: a benched Pokemon's ability does nothing: ignoringAbility, !isActive)
            if (
                ally is not user
                and ally.position is not None
                and ally.ability_id in ("soundproof", "goodasgold")
            ):
                self._emit("immune", target=ally.label)
                continue
            if ally.hp > 0 and ally.status is not None:
                cure(ally, self._emit_kw)
                cured = True
        if not cured:
            self._emit("fail", actor=user.label)
        return cured

    def _ability_move(self, user: BattlePokemon, target: BattlePokemon, move: Move) -> bool | None:
        """041-3h: Soak, Gastro Acid, Role Play, Entrainment, Worry Seed, Simple Beam (their
        onTryHit's false gives -fail; null is no result)."""
        dex = get_dex()

        def cant_suppress(pokemon: BattlePokemon) -> bool:
            data = dex.ability(pokemon.base_ability_id)
            return data is not None and data.cant_suppress

        mine, yours = user.base_ability_id, target.base_ability_id
        if move.id == "soak":
            if target.types == ("Water",) or _type_locked(target):
                self._emit("fail", actor=target.label)  # onHit: -fail target, null
                return None
            target.base_types = ("Water",)
            target.type_changed = True
            target.added_type = None  # (041-6f: setType)
            target.apparent_type = target.base_types
            self._emit("start", target=target.label, detail="typechange")
            return True
        if move.id == "gastroacid":
            if cant_suppress(target):
                return False
            if target.item == ABILITY_SHIELD:
                self._emit("block", target=target.label, detail="item: Ability Shield")
                return None
            if target.gastro_acid or target.hp <= 0:
                return False
            target.gastro_acid = True  # onStart: -endability (not compared), then End
            self._ability_end(target, called_back=True)
            return True
        if move.id == "roleplay":
            data = dex.ability(yours)
            if mine == yours or (data is not None and data.fail_role_play) or cant_suppress(user):
                return False
            return self._set_ability(user, target.ability, target, move)
        if move.id == "entrainment":
            data = dex.ability(mine)
            if (
                mine == yours
                or cant_suppress(target)
                or yours == "truant"
                or (data is not None and data.no_entrain)
            ):
                return False
            return self._set_ability(target, user.ability, user, move)
        if move.id == "simplebeam" and (cant_suppress(target) or yours in ("simple", "truant")):
            return False
        if move.id == "worryseed" and cant_suppress(target):
            return False
        new = "Simple" if move.id == "simplebeam" else "Insomnia"
        did = self._set_ability(target, new, user, move)
        if did and move.id == "worryseed" and target.status == "slp":
            cure(target, self._emit_kw)
        return did

    def _transform(self, user: BattlePokemon, target: BattlePokemon) -> bool:
        """041-6f: ``transformInto(target)``: false on a fainted target, either one disguised
        (Illusion) or transformed, a target behind a substitute, Ogerpon / Terapagos with a
        Terastallized one, or a Stellar user. Otherwise the target's species, types (getTypes
        without the added type and Tera; addedType too), apparentType, stored stats (not HP),
        moves (pp = maxpp = min(5, move.pp)), boosts, focusenergy / dragoncheer and
        timesAttacked; ``-transform``; setAbility(isTransform): no message, its End, and
        its Start only when the ability changes."""
        tera_formes = ("Ogerpon", "Terapagos")
        if (
            target.fainted
            or user.illusion is not None
            or target.illusion is not None
            or target.substitute_hp > 0
            or target.transform_base is not None
            or user.transform_base is not None
            or (
                target.species.base_species in tera_formes
                and (user.terastallized is not None or target.terastallized is not None)
            )
            or user.terastallized == STELLAR
        ):
            return False
        own_stats = user.saved_stats if user.saved_stats is not None else user.stats
        base_moves = list(user.moves)
        if user.mimicked is not None:  # (review P3: baseMoveSlots still has Mimic)
            index, slot = user.mimicked
            base_moves[index] = slot
        user.transform_base = (user.species, user.base_types, own_stats, base_moves)
        user.saved_stats = None
        user.species = target.species
        user.base_types = target.base_types
        user.type_changed = True
        user.added_type = target.added_type
        user.apparent_type = target.apparent_type
        user.stats = {k: (v if k == "hp" else target.stats[k]) for k, v in user.stats.items()}
        # setSpecies(species, isTransform): the stats from the target's base stats and the
        # user's set, then speed = storedStats.spe, before transformInto copies the stats
        own = user.pokemon_set
        nature = get_dex().nature(own.nature) if own is not None else None
        if own is not None and nature is not None:
            spread = calc_stats(target.species.base_stats, own.ivs, own.evs, own.level, nature)
            user.cached_speed = spread["spe"]
        else:
            user.cached_speed = user.stats["spe"]
        user.moves = [MoveSlot(s.move, min(5, s.move.pp), min(5, s.move.pp)) for s in target.moves]
        user.mimicked = None
        user.boosts = dict(target.boosts)
        user.focus_energy = target.focus_energy
        user.dragon_cheer = target.dragon_cheer
        user.times_attacked = target.times_attacked
        self._emit("transform", actor=user.label, target=target.label)
        if user.terastallized is not None:
            user.apparent_type = (user.terastallized,)
        old = user.base_ability_id
        ignoring = user.ability_suppressed
        user.ability_suppressed = False
        self._ability_end(user, called_back=True)
        user.ability = target.ability
        self._ability_order += 1
        user.ability_order = self._ability_order
        if user.base_ability_id != old:
            self._ability_start(user)
        user.ability_suppressed = ignoring and is_breakable(user.base_ability_id)
        return True

    def _corrosive_gas(self, user: BattlePokemon, target: BattlePokemon) -> bool:
        """041-6f: Corrosive Gas's onHit: takeItem (the held item, as Knock Off), then `-enditem `
        [from] move: Corrosive Gas`; nothing taken: `-fail` on the target (onHit undefined)."""
        item = target.held_item
        if self._trick_take(target, item, user):
            self._emit("enditem", target=target.label, detail=item_name(item), actor=user.label)
        else:
            self._emit("fail", actor=target.label)
        return True

    def _doodle(self, user: BattlePokemon, target: BattlePokemon, move: Move) -> bool | None:
        """041-6f: Doodle's onHit: unless the target's ability is failroleplay, each of the
        user's side (alliesAndSelf: position order, with HP) without that ability or a
        cantsuppress one gets it (setAbility). Nothing done: ``-fail`` (when no setAbility was
        null) and NOT_FAIL."""
        dex = get_dex()
        data = dex.ability(target.base_ability_id)
        success: bool | None = False
        if not (data is not None and data.fail_role_play):
            for pokemon in self.state.sides[user.side].active:
                if pokemon is None or pokemon.hp <= 0:
                    continue
                own = dex.ability(pokemon.base_ability_id)
                if pokemon.base_ability_id == target.base_ability_id or (
                    own is not None and own.cant_suppress
                ):
                    continue
                did = self._set_ability(pokemon, target.ability, user, move)
                if did:
                    success = True
                elif not success and did is None:
                    success = None
        if success is False:
            self._emit("fail", actor=user.label)
        return success

    def _set_ability(
        self,
        pokemon: BattlePokemon,
        ability: str,
        source: BattlePokemon,
        move: Move | None,
        *,
        activate: BattlePokemon | None = None,
    ) -> bool | None:
        """041-3h: ``pokemon.setAbility(ability, source)`` from a move: false at 0 HP or when
        either ability is cantsuppress; runEvent('SetAbility') (Ability Shield: ``-block``,
        null); the old ability's End, the new one (a new abilityState), ``-ability … [from]
        move: X``, its Start."""
        dex = get_dex()
        new = dex.ability(to_id(ability))
        old = dex.ability(pokemon.base_ability_id)
        if pokemon.hp <= 0 or (new and new.cant_suppress) or (old and old.cant_suppress):
            return False
        if pokemon.item == ABILITY_SHIELD:
            self._emit("block", target=pokemon.label, detail="item: Ability Shield")
            return None
        ignoring = pokemon.ability_suppressed
        pokemon.ability_suppressed = False
        self._ability_end(pokemon, called_back=True)
        pokemon.ability = new.name if new else ability
        self._ability_order += 1
        pokemon.ability_order = self._ability_order
        if activate is not None:  # 043-5c: Mummy / Lingering Aroma: -activate on the holder
            self._emit("activate", target=activate.label, detail=f"ability: {pokemon.ability}")
        else:
            self._emit("ability", target=pokemon.label, detail=pokemon.ability)
        self._ability_start(pokemon)
        pokemon.ability_suppressed = ignoring and is_breakable(pokemon.base_ability_id)
        return True

    def _trap(self, user: BattlePokemon, target: BattlePokemon) -> bool:
        """041-3g: ``addVolatile('trapped', source)``: false when it has it already or is a
        Ghost (runStatusImmunity, silent); onStart ``-activate … trapped``."""
        if target.hp <= 0 or target.trapper is not None or "Ghost" in target.types:
            return False
        target.trapper = user
        self._emit("activate", target=target.label, detail="trapped")
        return True

    def _eerie_spell(self, target: BattlePokemon) -> None:
        """041-6e: Eerie Spell's secondary onHit: deductPP(lastMove, 3) on a target with HP;
        ``-activate … move: Eerie Spell`` when some PP came off."""
        if target.hp <= 0:
            return
        slot = next((s for s in target.moves if s.move.id == target.last_move), None)
        if slot is None or slot.pp <= 0:
            return
        slot.pp -= min(3, slot.pp)
        self._emit("activate", target=target.label, detail="move: Eerie Spell")

    def _spite(self, target: BattlePokemon) -> bool:
        """041-3f: Spite's onHit: deductPP(lastMove, 4); false without a last move or when
        no PP came off; ``-activate … move: Spite``."""
        slot = next((s for s in target.moves if s.move.id == target.last_move), None)
        if slot is None or slot.pp <= 0:
            return False
        deducted = min(4, slot.pp)
        slot.pp -= deducted
        self._emit("activate", target=target.label, detail="move: Spite")
        return True

    def _mimic(self, user: BattlePokemon, target: BattlePokemon, move_id: str) -> bool:
        """041-6f: Mimic / Sketch's onHit: the target's lastMove (not failmimic / nosketch, not
        known) in the move's slot with pp = maxpp = move.pp (no PP Ups). Mimic's slot goes
        back to the base slot at clearVolatile; Sketch's is for good."""
        copied = get_dex().move(target.last_move) if target.last_move is not None else None
        flag = "failmimic" if move_id == "mimic" else "nosketch"
        if (
            copied is None
            or flag in copied.flags
            or any(s.move.id == copied.id for s in user.moves)
        ):
            return False
        index = next((i for i, s in enumerate(user.moves) if s.move.id == move_id), None)
        if index is None:
            return False
        if move_id == "mimic":
            user.mimicked = (index, user.moves[index])
        user.moves[index] = MoveSlot(copied, copied.pp, copied.pp)
        if move_id == "mimic":
            self._emit(
                "start", target=user.label, detail="Mimic"
            )  # (the move name is not compared)
        else:
            self._emit("activate", target=user.label, detail="move: Sketch")
        return True

    def _swap_split(self, user: BattlePokemon, target: BattlePokemon, move_id: str) -> bool:
        """041-6c: the onHit of the moves that trade stages or stored stats, set a type, or
        raise stages (-swapboost / -invertboost are not compared)."""
        if move_id in SWAPPED_STAGES:
            for stat in SWAPPED_STAGES[move_id]:
                user.boosts[stat], target.boosts[stat] = target.boosts[stat], user.boosts[stat]
            return True
        if move_id == "topsyturvy":
            if not any(target.boosts.values()):
                return False
            target.boosts = {k: -v for k, v in target.boosts.items()}
            return True
        if move_id in SPLIT_STATS:
            for pokemon in (user, target):
                if pokemon.saved_stats is None:
                    pokemon.saved_stats = pokemon.stats
            if move_id == "speedswap":
                mine, yours = user.stats["spe"], target.stats["spe"]
                user.stats = {**user.stats, "spe": yours}
                target.stats = {**target.stats, "spe": mine}
            else:
                for stat in SPLIT_STATS[move_id]:
                    value = (user.stats[stat] + target.stats[stat]) // 2
                    user.stats = {**user.stats, stat: value}
                    target.stats = {**target.stats, stat: value}
            copied = get_dex().move(move_id)
            assert copied is not None
            self._emit("activate", target=user.label, detail=f"move: {copied.name}")
            return True
        if move_id == "forestscurse":
            # 041-6f: onHit: false with Grass or when terastallized (addType)
            if "Grass" in target.types or target.terastallized is not None:
                return False
            target.added_type = "Grass"
            self._emit("start", target=target.label, detail="typeadd")
            return True
        if move_id in ("mimic", "sketch"):
            return self._mimic(user, target, move_id)
        if move_id == "acupressure":
            # 041-6f: onHit: sample a stat (boosts order) below +6, then +2
            stats = [s for s in BOOST_IDS if target.boosts[s] < 6]
            if not stats:
                return False
            self._boost(target, {self.prng.sample(stats): 2}, user)
            return True
        if move_id == "conversion2":
            # 041-6f: onHit: a type (dex order) the user does not have that resists or is
            # immune to the type of the target's lastMoveUsed, sampled; setType
            kind = target.last_move_used_type
            if kind is None:
                return False
            dex = get_dex()
            options = [t for t in dex.type_names() if t not in user.types and dex.resists(t, kind)]
            if not options:
                return False
            chosen = self.prng.sample(options)
            if _type_locked(user):
                return False
            user.base_types = (chosen,)
            user.type_changed = True
            user.added_type = None
            user.apparent_type = user.base_types
            self._emit("start", target=user.label, detail="typechange")
            return True
        if move_id == "conversion":
            # 041-6f: onHit: the type of moveSlots[0]; false if the user has it already
            kind = target.moves[0].move.type
            if kind in target.types or _type_locked(target):
                return False
            target.base_types = (kind,)
            target.type_changed = True
            target.added_type = None  # (041-6f: setType)
            target.apparent_type = target.base_types
            self._emit("start", target=target.label, detail="typechange")
            return True
        if move_id == "magicpowder":
            if target.types == ("Psychic",) or _type_locked(target):
                return False  # (setType false when terastallized)
            target.base_types = ("Psychic",)
            target.type_changed = True
            target.added_type = None  # (041-6f: setType)
            target.apparent_type = target.base_types
            self._emit("start", target=target.label, detail="typechange")
            return True
        if move_id == "reflecttype":
            if _type_locked(user):
                return False
            types = tuple(t for t in target.own_types if t != "???")
            if not types:
                if not target.added_type:
                    return False
                types = ("Normal",)  # (041-6f: then the target's addedType)
            self._emit("start", target=user.label, detail="typechange")
            old = user.apparent_type
            user.base_types = types
            user.type_changed = True
            user.added_type = target.added_type  # (041-6f: reflecttype copies it)
            # knownType: only from an ally; otherwise the apparent type stays
            user.apparent_type = types if target.side == user.side else old
            return True
        if move_id == "stuffcheeks":
            # 041-6f: onHit: boost def +2 (null when nothing rose), then eatItem(true)
            raised = apply_boosts(
                target, {"def": 2}, primary=True, foes_left=self._foes_left(target),
                emit=self._emit_kw, source=user,
            )  # fmt: skip
            if not raised:
                return False
            item = target.item
            self._eat_item(target, lambda: self._berry_on_eat(target, item))
            return True
        if move_id == "recycle":
            # 041-6f: onHit: false with an item or no lastItem; -item, setItem
            if target.held_item or not target.last_item:
                return False
            item, target.last_item = target.last_item, ""
            self._emit("item", target=target.label, detail=item_name(item))
            self._set_item(target, item)
            return True
        if move_id == "takeheart":  # (the last one)
            raised = apply_boosts(
                target, {"spa": 1, "spd": 1}, primary=True, foes_left=self._foes_left(target),
                emit=self._emit_kw, source=user,
            )  # fmt: skip
            cured = target.status is not None
            if cured:
                cure(target, self._emit_kw)
            return cured or bool(raised)
        return False

    def _psych_up(self, user: BattlePokemon, target: BattlePokemon) -> bool:
        """041-3f: Psych Up's onHit: copy the stages; remove, then copy Dragon Cheer (its
        value) and Focus Energy (``-start``), then ``-copyboost`` (043-1: also Costar)."""
        user.boosts = dict(target.boosts)
        user.dragon_cheer, user.focus_energy = 0, False
        if target.dragon_cheer:
            user.dragon_cheer = target.dragon_cheer
            self._emit("start", target=user.label, detail="move: Dragon Cheer")
        if target.focus_energy:
            user.focus_energy = True
            self._emit("start", target=user.label, detail="move: Focus Energy")
        self._emit("copyboost", target=user.label, actor=target.label)
        return True

    def _disable(
        self, target: BattlePokemon, *, from_move: bool = True, acting: bool = False
    ) -> bool | None:
        """023 (R17): ``addVolatile('disable')``: fails when it has it already (no onRestart)
        or when its last move has no PP left; 5 turns, one less when it is still to move."""
        if DISABLE in target.timed:
            return False
        if self._volatile_veil(target, DISABLE, from_move=from_move):
            return None  # 032 (R13): Aroma Veil
        slot = next((s for s in target.moves if s.move.id == target.last_move), None)
        if slot is not None and slot.pp <= 0:
            return False
        # (043-5h: or it is the activePokemon of a move that is not external: Cursed Body)
        target.timed[DISABLE] = 4 if self._will_move(target) or acting else 5
        target.disabled_move = target.last_move
        self._emit("start", target=target.label, detail="Disable")
        return True

    def _strength_sap(self, user: BattlePokemon, target: BattlePokemon) -> bool:
        """023 (R15): Strength Sap's onHit. Fails at -6 Attack; otherwise the target's Attack
        with its stage (getStat unmodified) is measured, lowered by 1, and the user heals by
        it; it worked if either happened."""
        if target.boosts["atk"] == -6:
            return False
        attack = boosted_stat(target.stats["atk"], target.boosts["atk"])
        lowered = apply_boosts(
            target, {"atk": -1}, primary=True, foes_left=self._foes_left(target),
            emit=self._emit_kw, source=user,
        )  # fmt: skip
        amount = self._big_root(user, attack)
        if self._oozed(user, target, amount):  # 043-3b: heal() gives 0
            return lowered
        return self._heal(user, amount, "") or lowered

    def _oozed(self, healer: BattlePokemon, source: BattlePokemon, amount: float) -> bool:
        """043-3b: Liquid Ooze's onSourceTryHeal (drain, Leech Seed, Strength Sap; after Big
        Root's): the healer takes the amount as damage instead, and heal() gives 0."""
        if source.ability_id != LIQUID_OOZE or HEAL_BLOCK in healer.timed:
            return False
        self._chip(healer, amount, "ability: liquid ooze", source)
        return True

    def _big_root(self, pokemon: BattlePokemon, amount: int) -> int:
        """040-4b: Big Root's onTryHeal (drain, Strength Sap): chainModify 5324/4096."""
        if pokemon.item != BIG_ROOT:
            return amount
        return modify(amount, BIG_ROOT_MODIFIER, 4096)

    def _pain_split(self, user: BattlePokemon, target: BattlePokemon) -> bool:
        """021 (R4): Pain Split's onHit. Both HPs become their average (``sethp``: at least 1,
        at most the max HP); the target's line first (``[silent]``), then the user's."""
        average = (target.hp + user.hp) // 2 or 1
        for pokemon in (target, user):
            pokemon.hp = min(max(1, average), pokemon.max_hp)
            self._emit("sethp", target=pokemon.label, hp=pokemon.hp, detail="Pain Split")
        return True

    def _roost(self, pokemon: BattlePokemon) -> None:
        """022 (R7): the roost volatile (duration 1, ends silently at the residual). Its onStart
        fails while terastallized (only a ``-hint``); ``BattlePokemon.types`` drops Flying."""
        if pokemon.terastallized is not None:
            return
        pokemon.timed[ROOST] = 1
        self._emit("singleturn", target=pokemon.label, detail="move: Roost")

    def _trick(self, user: BattlePokemon, target: BattlePokemon) -> bool:
        """022 (R6): Trick's onHit. ``takeItem`` from the target, then from the user (each
        refused by the item's TakeItem: Booster Energy on a Paradox Pokémon, Ogerpon's mask);
        it fails, giving the taken items back, when one is refused, when neither has an item,
        or when an item cannot go to its receiver (the same TakeItem, with the receiver).
        Otherwise ``-activate``, then setItem and ``-item`` (or ``-enditem … [silent]``) for
        the target, then for the user."""
        yours, mine = target.held_item, user.held_item
        your_taken = self._trick_take(target, yours, user)
        my_taken = self._trick_take(user, mine, user)
        if (
            (yours and not your_taken)
            or (mine and not my_taken)
            or (not yours and not mine)
            or (mine and not can_be_taken(mine, target.species, user.species))
            or (yours and not can_be_taken(yours, user.species, target.species))
        ):
            target.item, user.item = yours, mine  # (the itemState stays cleared)
            return False
        self._emit("activate", target=user.label, detail="move: Trick")
        for receiver, given, lost in ((target, mine, yours), (user, yours, mine)):
            if given:
                self._set_item(receiver, given)
                self._emit("item", target=receiver.label, detail=item_name(given))
            else:
                self._emit("enditem", target=receiver.label, detail=item_name(lost))
        return True

    def _skill_swap(self, user: BattlePokemon, target: BattlePokemon) -> bool | None:
        """027 (R2, R3): ``battle.skillSwap``. It fails when either has fainted or has a
        failskillswap ability. 029 (R5): then runEvent('SetAbility') for the target, then the
        user: Ability Shield's onSetAbility shows ``-block`` and gives null (no ``-fail``; the
        move's result is false). Then ``-activate`` (the abilities named only against a foe),
        the user's End, the target's End, a new abilityState each, the target's Start, the
        user's Start."""
        if user.hp <= 0 or target.hp <= 0 or user.fainted or target.fainted:
            return False
        mine, yours = user.base_ability_id, target.base_ability_id
        if fails_skill_swap(mine) or fails_skill_swap(yours):
            return False
        for pokemon in (target, user):
            if pokemon.item == ABILITY_SHIELD:
                self._emit("block", target=pokemon.label, detail="item: Ability Shield")
                return None
        self._emit("activate", target=user.label, detail="Skill Swap")
        # Mold Breaker's ignoreAbility suppresses breakable handlers in runEvent only, not
        # End / Start; for the rest of the move it ignores the target's new ability if that
        # is breakable (the user is never ignored in gen 9)
        ignoring = target.ability_suppressed
        target.ability_suppressed = False
        self._ability_end(user)
        self._ability_end(target)
        user.ability, target.ability = target.ability, user.ability
        for pokemon in (user, target):
            self._ability_order += 1
            pokemon.ability_order = self._ability_order
        self._ability_start(target)
        self._ability_start(user)
        target.ability_suppressed = ignoring and is_breakable(target.base_ability_id)
        return True

    def _fling(self, user: BattlePokemon, move: Move) -> Move | None:
        """032 (R8): Fling's onPrepareHit. None (``-fail``) without an item, with one its
        TakeItem keeps, or one that cannot be flung. The power is the item's fling.basePower;
        its status / volatileStatus becomes a secondary (after King's Rock's 10%, which its
        onModifyMove added first); then addVolatile('fling') (the item goes at the next
        Update). Berries and fling.effect items (White Herb, Mental Herb) are refused before
        the battle (support), so they are not flung here."""
        item = get_dex().item(user.item) if user.item else None
        if user.ability_id == "klutz":
            item = None  # 043-5d: ignoringItem(isFling): Klutz, whatever the item
        if item is None or item.fling is None or not can_be_taken(item.id, user.species):
            return None
        if item.is_berry or item.fling.get("effect"):
            raise EngineError(f"Fling with {item.name} is not supported")
        secondaries = move.secondaries
        flincher = user.item in (KINGS_ROCK, RAZOR_FANG) or user.ability_id == "stench"  # (043-3b)
        if flincher and not any(s.volatile_status == "flinch" for s in secondaries):
            secondaries = (*secondaries, KINGS_ROCK_FLINCH)
        status = item.fling.get("status")
        volatile = item.fling.get("volatileStatus")
        if isinstance(status, str):
            secondaries = (*secondaries, Secondary(None, status, frozenset({"status"})))
        elif isinstance(volatile, str):
            keys = frozenset({"volatileStatus"})
            secondaries = (*secondaries, Secondary(None, None, keys, volatile_status=volatile))
        power = item.fling["basePower"]
        assert isinstance(power, int)
        if user not in self._flinging:
            self._flinging.append(user)
        return replace(move, base_power=power, secondaries=secondaries)

    def _fling_end(self, pokemon: BattlePokemon) -> None:
        """032 (R8): the fling volatile's onUpdate: setItem(''), ``-enditem … [from] move:
        Fling``, AfterUseItem (Unburden), removeVolatile."""
        self._flinging.remove(pokemon)
        name = item_name(pokemon.held_item)
        pokemon.last_item = pokemon.held_item  # 041-6f
        self._lose_item(pokemon, unburden=True)
        self._emit("enditem", target=pokemon.label, detail=name)

    def _magician(self, user: BattlePokemon, move: Move) -> None:
        """042-5: Magician's onAfterMoveSecondarySelf: with no item (nor a gem), after a
        damaging move (not Fling, not with switchFlag true), the hit targets sorted by speed
        (ties shuffled); the first other one whose item it can take gives it
        (``-item … [from] ability: Magician``)."""
        hit = self._hit_targets
        if (
            not hit
            or user.switch_flag is True
            or user.held_item
            or "gem" in user.timed
            or move.id == "fling"
            or move.category == "Status"
        ):
            return
        targets = list(hit)
        speed_sort(targets, self.prng, _by_speed)
        for target in targets:
            if target is user:
                continue
            item = target.held_item
            if not self._trick_take(target, item, user):
                continue
            if not can_be_taken(item, user.species, target.species) or user.hp <= 0:
                target.item = item  # setItem failed: pokemon.item = yourItem.id
                continue
            self._set_item(user, item)
            self._emit("item", target=user.label, detail=item_name(item))
            return

    def _thief(self, user: BattlePokemon, target: BattlePokemon, *, covet: bool = False) -> None:
        """032 (R9): Thief's onAfterHit. With no item of its own, the user takes the target's
        (takeItem, then the item's TakeItem with the user and setItem):
        ``-enditem … [silent]`` and ``-item … [from] move: Thief``."""
        if user.held_item or target.position is None:
            return
        item = target.held_item
        if not self._trick_take(target, item, user):
            return
        if not can_be_taken(item, user.species, target.species) or user.hp <= 0:
            # (setItem fails for a user with no HP: Rough Skin, Rocky Helmet; items032-2)
            target.item = item  # (the itemState stays cleared)
            return
        self._set_item(user, item)
        if not covet:  # 041-3c: Covet shows only the -item line
            self._emit("enditem", target=target.label, detail=item_name(item))
        self._emit("item", target=user.label, detail=item_name(item))

    def _trick_take(self, pokemon: BattlePokemon, item: str, source: BattlePokemon) -> bool:
        """``pokemon.takeItem()``: runEvent('TakeItem') (the item's onTakeItem, Unburden), then
        the item's End with a cleared itemState (Eject Pack forgets a lowered stat)."""
        if not item or not can_be_taken(item, pokemon.species, source.species):
            return False
        if self._sticky_hold(pokemon, source):
            return False
        self._lose_item(pokemon, unburden=True)
        pokemon.item_started = False
        pokemon.eject_pending = False
        return True

    def _set_item(self, pokemon: BattlePokemon, item: str) -> None:
        """``pokemon.setItem()`` (022): a new itemState, then the item's Start (a Choice item
        ends the choicelock; the seeds, White Herb and Booster Energy as on switching in)."""
        pokemon.item = item
        pokemon.item_started = False
        pokemon.eject_pending = False
        pokemon.mirror_boosts.clear()
        if is_choice(item):
            pokemon.choice_lock = None
        self._item_start(pokemon)

    def _veil_holder(self, target: BattlePokemon, ability: str) -> BattlePokemon | None:
        """032 (R13): the first of the target and its ally (alliesAndSelf) with this ability
        (an ``onAlly…`` handler; Mold Breaker and the gas empty ``ability_id``)."""
        side = self.state.sides[target.side]
        # alliesAndSelf: HP left (043-3c; Sweet / Aroma Veil since the 043 review)
        holders = [p for p in side.alive_active() if p.ability_id == ability and p.hp > 0]
        holders.sort(key=lambda p: -p.cached_speed)
        return holders[0] if holders else None

    def _volatile_veil(self, target: BattlePokemon, volatile: str, *, from_move: bool) -> bool:
        """032 (R13): runEvent('TryAddVolatile'): Sweet Veil against Yawn, Aroma Veil against
        its volatiles (``-block`` only from a move), Purifying Salt against Yawn (``-immune``).
        True: null (stopped)."""
        sun = effective_weather(self.state.field.active_weather, target.item) == SUN
        sleepless = target.ability_id in ("insomnia", "vitalspirit") or (
            target.ability_id == LEAF_GUARD and sun
        )  # 043-3a: their onTryAddVolatile (yawn): -immune, null
        shielded = (  # 043-6d: Shields Down's onTryAddVolatile (yawn) in the Meteor forme
            target.ability_id == "shieldsdown" and target.species.name == "Minior-Meteor"
            and target.transform_base is None
        )  # fmt: skip
        if volatile == YAWN and (target.ability_id == PURIFYING_SALT or sleepless or shielded):
            self._emit("immune", target=target.label)
            return True
        if volatile == YAWN and "Grass" in target.types:
            veil = self._veil_holder(target, FLOWER_VEIL)  # 043-3c: onAllyTryAddVolatile
            if veil is not None:
                self._emit("block", target=target.label, detail="ability: Flower Veil",
                           actor=veil.label)  # fmt: skip
                return True
        name = {YAWN: SWEET_VEIL}.get(volatile)
        if name is None and volatile in AROMA_VEIL_BLOCKS:
            name = AROMA_VEIL
        holder = self._veil_holder(target, name) if name else None
        if holder is None:
            return False
        if name == SWEET_VEIL or from_move:
            detail = "ability: Sweet Veil" if name == SWEET_VEIL else "ability: Aroma Veil"
            self._emit("block", target=target.label, detail=detail, actor=holder.label)
        return True

    def _add_move_lock(self, target: BattlePokemon, volatile: str) -> bool | None:
        """015: ``addVolatile('taunt')``: duration 3, one more when the target already moved
        this turn (Taunt: only after its first turn on the field); False if it has it; None
        (null) when Aroma Veil stops it (032)."""
        if target.hp <= 0 or volatile in target.timed:
            return False
        if self._volatile_veil(target, volatile, from_move=True):
            return None
        if volatile == ENCORE:
            # onStart: no lastMove, failencore (Encore, Struggle), not its move, no PP
            slot = next((s for s in target.moves if s.move.id == target.last_move), None)
            if slot is None or "failencore" in slot.move.flags or slot.pp <= 0:
                return False
            target.encore_move = slot.move.id
        duration = 3
        if (target.active_turns or volatile != TAUNT) and not self._will_move(target):
            duration += 1
        target.timed[volatile] = duration
        self._emit("start", target=target.label, detail=MOVE_LOCK_NAMES[volatile])
        return True

    def _end_move_lock(self, pokemon: BattlePokemon, volatile: str) -> None:
        """``removeVolatile``: the condition's onEnd message (Taunt, Encore; 023: Disable,
        Heal Block)."""
        if pokemon.timed.pop(volatile, None) is not None:
            self._emit("end", target=pokemon.label, detail=VOLATILE_END_NAMES[volatile])
            if volatile == ENCORE:
                pokemon.encore_move = None
            if volatile == DISABLE:
                pokemon.disabled_move = None

    def _substitute(self, user: BattlePokemon) -> bool | None:
        """016: Substitute (research R1). onTryHit: ``-fail`` with a substitute up or at 1/4
        max HP or less; the volatile's onStart (``-start``, hp floor(maxhp / 4)), then onHit's
        ``directDamage(maxhp / 4)``. Its NOT_FAIL still fails the move: spreadMoveHit returns
        ``[false]`` for any falsy TryHit (017: Stomping Tantrum doubles the next turn)."""
        if user.substitute_hp or user.hp <= user.max_hp / 4 or user.max_hp == 1:
            self._emit("fail", actor=user.label)
            return None
        user.substitute_hp = user.max_hp // 4
        self._emit("start", target=user.label, detail="Substitute")
        if PARTIALLY_TRAPPED in user.timed:
            self._end_partially_trapped(user)  # 024: onStart, -end … [partiallytrapped] [silent]
        user.hp -= max(1, user.max_hp // 4)
        self._direct_damage = True  # 023: directDamage (no hurtThisTurn)
        self._emit("damage", target=user.label, value=max(1, user.max_hp // 4), hp=user.hp)
        self._direct_damage = False
        return True

    def _shed_tail(self, user: BattlePokemon) -> bool | None:
        """030 (R8): Shed Tail. onTryHit's NOT_FAIL (``-fail``): nobody to switch to or
        commanded, a substitute up, or at ceil(maxhp / 2) HP or less. Then the substitute's
        onStart (``-start … Substitute [from] move: Shed Tail``, hp floor(maxhp / 4)), onHit's
        ``directDamage(ceil(maxhp / 2))``, and selfSwitch 'shedtail' (the replacement copies
        the substitute only, ``replace``)."""
        can_switch = bool(self.state.sides[user.side].bench()) and user.commanded_by is None
        if not can_switch or user.substitute_hp or user.hp <= -(-user.max_hp // 2):
            self._emit("fail", actor=user.label)
            return None
        user.substitute_hp = user.max_hp // 4
        self._emit("start", target=user.label, detail="Substitute")
        if PARTIALLY_TRAPPED in user.timed:
            self._end_partially_trapped(user)  # 024: the substitute's onStart
        cost = -(-user.max_hp // 2)
        user.hp -= cost
        self._direct_damage = True  # 023: directDamage (no hurtThisTurn)
        self._emit("damage", target=user.label, value=cost, hp=user.hp)
        self._direct_damage = False
        return True

    def _direct_cost(self, pokemon: BattlePokemon, amount: float) -> None:
        """``directDamage``: at least 1, truncated, at most the HP left (no hurtThisTurn)."""
        cost = min(pokemon.hp, max(1, int(amount)))
        pokemon.hp -= cost
        self._direct_damage = True
        self._emit("damage", target=pokemon.label, value=cost, hp=pokemon.hp)
        self._direct_damage = False

    def _belly_drum(self, target: BattlePokemon) -> bool:
        """032 (R15): Belly Drum's onHit. Fails at half HP or less, at +6 Attack or with 1 max
        HP; otherwise ``directDamage(maxhp / 2)`` and ``boost({atk: 12})``, shown as
        ``-setboost … atk 6 [from] move: Belly Drum``."""
        if target.hp * 2 <= target.max_hp or target.boosts["atk"] >= 6 or target.max_hp == 1:
            return False
        self._direct_cost(target, target.max_hp / 2)
        target.boosts["atk"] = 6
        self._emit("setboost", target=target.label, detail="atk", value=6)
        target.stats_raised_this_turn = True  # 027: boost's success
        return True

    def _curse(self, user: BattlePokemon, target: BattlePokemon) -> bool:
        """032 (R15): Curse. A Ghost user: the curse volatile (no duration; ``-start … Curse``),
        then onHit's ``directDamage(source.maxhp / 2)`` to the user. Otherwise onTryHit's
        ``move.self``: Spe -1, Atk +1, Def +1 (a self effect: a stuck stage is silent)."""
        if "Ghost" in user.types:
            target.timed[CURSE] = 0
            self._emit("start", target=target.label, detail="Curse")
            self._direct_cost(user, user.max_hp / 2)
            return True
        self.prng.random_int(100)  # spreadMoveHit's self drops: the secondaryRoll
        apply_boosts(
            user, CURSE_SELF_BOOSTS, primary=False, foes_left=self._foes_left(user),
            emit=self._emit_kw, source=user,
        )  # fmt: skip
        return True

    def _heal_amount(self, move: Move, target: BattlePokemon) -> int:
        """032 (R14): Moonlight / Morning Sun ``modify(maxhp, factor)`` by the effective
        weather (2/3 as 0.667 in the sun, 1/4 in the rain, sandstorm and snow, else 1/2);
        Floral Healing ``modify(baseMaxhp, 0.667)`` on Grassy Terrain, else ``ceil(1/2)``."""
        if move.id == "shoreup":  # 041-1d: isWeather('sandstorm'): 0.667, else 0.5
            return modify(target.max_hp, 0.667 if self.state.field.active_weather == SAND else 0.5)
        if move.id == FLORAL_HEALING:
            if self.state.field.terrain == GRASSY:
                return modify(target.max_hp, 0.667)
            return -(-target.max_hp // 2)
        weather = effective_weather(self.state.field.active_weather, target.item)  # (040-3c)
        if weather == SUN:
            return modify(target.max_hp, 0.667)
        if weather in (RAIN, SAND, SNOW):
            return modify(target.max_hp, 1, 4)
        return modify(target.max_hp, 1, 2)

    def _heal_move(self, user: BattlePokemon, move: Move, target: BattlePokemon) -> bool | None:
        """015: Recover's ``heal: [1, 2]`` (spreadMoveHit: ``-fail target heal`` at full HP,
        Math.round), Lunar Blessing's onHit (``modify(maxhp, 0.25)`` and cureStatus). None:
        failed with its own message (didAnything null)."""
        if move.id in ("lunarblessing", "junglehealing"):
            healed = self._heal(target, modify(target.max_hp, 1, 4), "")
            cured = target.status is not None
            cure(target, self._emit_kw)
            return healed or cured
        if target.hp >= target.max_hp:
            self._emit("fail", actor=target.label)
            return None
        if HEAL_BLOCK in target.timed:
            # 030: battle.heal's TryHeal fails (Life Dew's heal-blocked ally): -fail source
            self._emit("fail", actor=user.label)
            return None
        num, den = HEALING_MOVES[move.id]
        return self._heal(target, int(target.max_hp * num / den + 0.5), "")

    def _run_field_move(self, user: BattlePokemon, move: Move) -> bool:
        """``tryMoveHit`` (target ``all``/``allySide``/``foeSide``): no accuracy check, no hit
        loop (so no Update events); the condition is added, and the move fails if nothing
        happened."""
        if move.id == PERISH_SONG:
            return self._perish_song(user, move)
        if move.id == "healbell":
            return self._heal_bell(user)  # 041-3f
        if move.id == "teatime":
            return self._teatime(user, move)  # 041-6f
        if move.id == "courtchange":
            return self._court_change(user)  # 041-6f
        if move.id == "magneticflux":
            # 041-6f: onHitSide: the side's Pokemon with Plus / Minus (unsupported: none
            # yet) get Def / SpD +1; false (-fail) when none or nothing rose
            did = False
            for ally in self.state.sides[user.side].alive_active():
                if ally.ability_id in ("plus", "minus"):
                    did = bool(apply_boosts(
                        ally, {"def": 1, "spd": 1}, primary=True,
                        foes_left=self._foes_left(ally), emit=self._emit_kw, source=user,
                    )) or did  # fmt: skip
            if not did:
                self._emit("fail", actor=user.label)
            return did
        if move.id == "happyhour":
            return True  # 041-3a: its onTryHit is not run for a side move (no -activate)
        if move.id == HAZE:  # 023 (R16): onHitField
            self._emit("clearallboost")
            for pokemon in self.state.all_active():
                pokemon.reset_boosts()
            return True
        if move.target == "foeSide":
            # 031 (R2): runEvent('TryHitSide', the first foe (foes(true): fainted ones too)):
            # Magic Bounce's onAllyTryHitSide on that foe and its allies with HP, sorted by
            # unmodified Speed (resolvePriority: getStat('spe', true, true)), ties shuffled, the
            # handlers of ignored abilities too. The first that bounces stops the event; the
            # vanished check is on the first foe (review P2, P3)
            foe_side = self.state.sides[foe_of(user.side)]
            first = next((p for p in foe_side.active if p is not None), None)
            holders = [p for p in foe_side.alive_active()
                       if p.hp > 0 and p.base_ability_id == MAGIC_BOUNCE]  # fmt: skip
            speed_sort(holders, self.prng, lambda a, b: b.stats["spe"] - a.stats["spe"])
            for holder in holders:
                if first is not None and self._reflects(holder, move, first):
                    self._bounce(holder, move, user)
                    return False
        field_state = self.state.field
        if move.side_condition in HAZARDS:  # 020: on the foes' side, a layer more
            ok = add_hazard(field_state, foe_of(user.side), move.side_condition,
                            emit=self._emit_kw)  # fmt: skip
            if not ok:
                self._emit("fail", actor=user.label)
            return ok
        if move.id == "auroraveil" and field_state.weather != SNOW:
            self._emit("fail", actor=user.label)  # onTry: only in the snow
            return False
        if move.side_condition in GUARDS:
            # 009: onTry needs a later action; onHitSide adds stall even when it fails.
            if not self._will_act():
                self._emit("fail", actor=user.label)
                return False
            if add_side_condition(field_state, user.side, move.side_condition, emit=self._emit_kw):
                self._emit(
                    "singleturn", target=user.label, detail=SINGLE_TURN_NAMES[move.side_condition]
                )
            # onHitSide returns undefined: no -fail even when the side already had it
            add_stall(user)
            return True
        elif move.weather is not None:
            ok = set_weather(field_state, move.weather, emit=self._emit_kw,
                             duration=_weather_duration(user, move.weather))  # fmt: skip
            if ok:
                self._weather_change()
            if (
                "selfSwitch" in move.keys
                and self.state.sides[user.side].bench()
                and user.commanded_by is None
            ):
                # 041-6d: Chilly Reception: runMoveEffects' selfSwitch succeeds with canSwitch
                user.switch_flag = move.id
                ok = True
        elif move.terrain is not None:
            duration = 8 if user.item == TERRAIN_EXTENDER else None  # (040-4b)
            ok = set_terrain(field_state, move.terrain, emit=self._emit_kw, duration=duration)
            if ok:
                self._terrain_change()  # eachEvent('TerrainChange') (010)
        elif move.pseudo_weather is not None:
            started = move.pseudo_weather not in field_state.pseudo_weather
            ok = add_pseudo_weather(
                field_state, move.pseudo_weather, source=user.label, emit=self._emit_kw
            )
            if ok and started and move.pseudo_weather == GRAVITY:
                self._gravity_start()
            if ok and started:
                self._pseudo_weather_change()
        else:
            assert move.side_condition is not None
            clay = move.side_condition in SCREENS and user.item == LIGHT_CLAY
            ok = add_side_condition(
                field_state, user.side, move.side_condition, emit=self._emit_kw,
                duration=8 if clay else None,
            )  # fmt: skip
            if ok and move.side_condition == TAILWIND:
                self._tailwind_start(user.side)
        if not ok:
            self._emit("fail", actor=user.label)
        return ok

    def _break_screens(self, side_id: str) -> None:
        """``removeSideCondition`` of Reflect, Light Screen and Aurora Veil, in that order."""
        for screen in SCREENS:
            if screen in self.state.field.sides[side_id]:
                end_side_condition(self.state.field, side_id, screen, self._emit_kw)

    def _foes_left(self, pokemon: BattlePokemon) -> bool:
        """``side.foePokemonLeft()``: the Pokémon's opponents still have Pokémon."""
        return self.state.sides[foe_of(pokemon.side)].pokemon_left() > 0

    def _emit_kw(self, kind: EventKind, **fields: object) -> None:
        self._emit(kind, **fields)
        value = fields.get("value")
        if kind == "boost" and isinstance(value, int) and value > 0 and not self._mirroring:
            self._mirror_record(str(fields["target"]), str(fields["detail"]), value)

    def _mirror_record(self, label: str, stat: str, amount: int) -> None:
        """040-3b: Mirror Herb's onFoeAfterBoost (the target's foes with HP; not for a Mirror
        Herb's own boost): the raised stages add up in effectState.boosts."""
        target = next((p for p in self.state.all_active() if p.label == label), None)
        if target is None:
            return
        for foe in self.state.sides[foe_of(target.side)].alive_active():
            if foe.item == MIRROR_HERB:
                foe.mirror_boosts[stat] = foe.mirror_boosts.get(stat, 0) + amount
            if foe.ability_id == "opportunist":  # 043-4i: onFoeAfterBoost (the same)
                foe.opportunist[stat] = foe.opportunist.get(stat, 0) + amount

    def _mirror_herb(self, pokemon: BattlePokemon) -> None:
        """040-3b: Mirror Herb when ready: useItem, then onUse's ``boost(boosts, pokemon)``."""
        if pokemon.item != MIRROR_HERB or not pokemon.mirror_boosts:
            return
        boosts = dict(pokemon.mirror_boosts)
        if not self._use_item(pokemon):
            return
        self._mirroring = True
        try:
            apply_boosts(
                pokemon, boosts, primary=True, foes_left=self._foes_left(pokemon),
                emit=self._emit_kw, source=pokemon,
            )  # fmt: skip
        finally:
            self._mirroring = False

    def _opportunist(self, pokemon: BattlePokemon) -> None:
        """043-4i: Opportunist's onAny handlers (SwitchIn -3, AfterTerastallization,
        AfterMove, Residual 29): ``boost(effectState.boosts)``, then they are gone."""
        if pokemon.ability_id != "opportunist" or not pokemon.opportunist:
            return
        boosts = dict(pokemon.opportunist)
        pokemon.opportunist.clear()
        self._mirroring = True
        try:
            apply_boosts(
                pokemon, boosts, primary=False, foes_left=self._foes_left(pokemon),
                emit=self._emit_kw, source=pokemon, ability="Opportunist",
            )  # fmt: skip
        finally:
            self._mirroring = False

    def _after_terastallization(self) -> None:
        """040-3b: runEvent('AfterTerastallization'): Mirror Herb's onAny handler on every
        holder with HP, speed-sorted."""
        holders = [
            p for p in self.state.all_active()
            if (p.held_item == MIRROR_HERB or p.base_ability_id == "opportunist") and p.hp > 0
        ]  # fmt: skip
        speed_sort(holders, self.prng, _by_speed)
        for pokemon in holders:
            self._opportunist(pokemon)  # (043-4i: the ability, subOrder 7, first)
            self._mirror_herb(pokemon)

    def _set_status(
        self,
        target: BattlePokemon,
        status: str,
        user: BattlePokemon,
        *,
        status_move: bool,
        rest: bool = False,
        by_move: bool = False,
        from_hazard: bool = False,
    ) -> bool | None:
        veil = self._veil_holder(target, SWEET_VEIL)
        flower = None
        if "Grass" in target.types and user is not target and not rest:
            flower = self._veil_holder(target, FLOWER_VEIL)  # 043-3c: onAllySetStatus
        applied = try_set_status(
            target, status, user=user, status_move=status_move, prng=self.prng,
            emit=self._emit_kw,
            weather=effective_weather(self.state.field.active_weather, target.item),
            terrain=self.state.field.terrain,
            sweet_veil=veil.label if veil else None, uproar=self._in_uproar(),
            uproar_first=self._uproar_first(veil), rest=rest,
            flower_veil=flower.label if flower else None,
            flower_veil_shown=status_move and by_move,
        )  # fmt: skip
        if applied:
            self._effect_order += 1
            target.status_order = self._effect_order
            if (
                by_move
                and user is not target
                and user.ability_id == "poisonpuppeteer"
                and user.species.base_species == "Pecharunt"
                and status in ("psn", "tox")
            ):  # 043-3b: Poison Puppeteer's onAnyAfterSetStatus (before Lum Berry's, -1)
                pass_confusion = True
            else:
                pass_confusion = False
            if (
                target.ability_id == "synchronize"
                and user is not target
                and not from_hazard
                and status not in ("slp", "frz")
            ):
                # 043-3b: Synchronize's onAfterSetStatus: the source gets it (a status effect)
                self._emit("activate", target=target.label, detail="ability: Synchronize")
                self._set_status(user, status, target, status_move=True)
            if pass_confusion:
                add_volatile(
                    target, "confusion", prng=self.prng, emit=self._emit_kw,
                    terrain=self.state.field.terrain, source=user,
                )  # fmt: skip
            if target.item == LUM_BERRY:
                self._lum_berry(target)  # 032 (R5): runEvent('AfterSetStatus')
        return applied

    def _pressure(
        self, user: BattlePokemon, move: Move, targets: list[BattlePokemon], slot: int
    ) -> None:
        """033 (R14): useMoveInner's pressureTargets: runEvent('DeductPP') on each, Pressure's
        onDeductPP gives 1 unless the holder is the user's ally; the sum comes off the slot
        (deductPP: not below 0). foeSide moves have none, mustpressure moves all the foes; the
        field moves (all) count the foes, allySide the allies only."""
        foes = self.state.sides[foe_of(user.side)].alive_active()
        if "mustpressure" in move.flags or move.target == "all":
            holders = foes
        elif move.target in ("foeSide", "allySide", "allyTeam"):
            holders = []
        else:
            holders = targets
        extra = sum(1 for p in holders if p.side != user.side and p.ability_id == PRESSURE)
        if extra:
            user.moves[slot].pp = max(0, user.moves[slot].pp - extra)

    def _in_uproar(self) -> bool:
        """033 (R13): an active Pokémon with HP has the uproar volatile (onAnySetStatus)."""
        # (042-4: an uproar holder at HP 0 before its faint no longer counts: runEvent skips it)
        return any(
            UPROAR in p.timed and p.hp > 0
            for s in SIDE_IDS
            for p in self.state.sides[s].alive_active()
        )

    def _uproar_first(self, veil: BattlePokemon | None) -> bool:
        """033 (review P3): runEvent('SetStatus') sorts the fastest uproar holder's
        onAnySetStatus (subOrder 2) before Sweet Veil's onAllySetStatus (ability, 7) unless the
        veil's holder is faster."""
        holders = [
            p.cached_speed
            for s in SIDE_IDS
            for p in self.state.sides[s].alive_active()
            if UPROAR in p.timed
        ]
        return veil is None or (bool(holders) and max(holders) >= veil.cached_speed)

    def _uproar_wake(self, target: BattlePokemon) -> None:
        """033 (R13): Uproar's onTryHit: each sleeping active Pokémon wakes, the target's side
        and the other side by position in turn (``-curestatus … slp [msg]``)."""
        own = self.state.sides[target.side].active
        foe = self.state.sides[foe_of(target.side)].active
        for i in range(len(own)):
            for p in (own[i], foe[i] if i < len(foe) else None):
                if p is not None and p.status == "slp":
                    cure(p, self._emit_kw)

    def _uproar_residual(self, pokemon: BattlePokemon) -> bool:
        """033 (R13): uproar at the residual (order 28, subOrder 1): ``duration--`` (at 0 its
        onEnd: ``-end … Uproar``); onResidual: Throat Chop removes it (``-end``), after Struggle
        it is deleted silently (still ``[upkeep]``), else ``-start … Uproar [upkeep]``."""
        pokemon.timed[UPROAR] -= 1
        ended = pokemon.timed[UPROAR] <= 0
        if ended or THROAT_CHOP in pokemon.timed:
            del pokemon.timed[UPROAR]
            self._emit("end", target=pokemon.label, detail="Uproar")
            return not ended  # fieldEvent: no faintMessages after a duration's end
        if pokemon.last_move == "struggle":
            del pokemon.timed[UPROAR]
        self._emit("start", target=pokemon.label, detail="Uproar")  # [upkeep]
        return True

    # -- replacements ---------------------------------------------------------------------

    def replace(
        self,
        choices1: Sequence[SwitchChoice | PassChoice],
        choices2: Sequence[SwitchChoice | PassChoice],
    ) -> None:
        if not self.awaiting_replacements:
            raise IllegalChoiceError("no replacement is needed")
        flag_request, self.state.flag_request = self.state.flag_request, False
        resume = self._after_request if flag_request else "next_turn"
        switches: list[tuple[BattlePokemon, SwitchChoice]] = []
        revivals: list[tuple[BattlePokemon, BattlePokemon]] = []  # 041-6f
        for side_id, choices in zip(SIDE_IDS, (choices1, choices2), strict=True):
            self.state.flag_request = flag_request  # (legality uses the same request)
            legal = is_legal_replacement(self.state, side_id, list(choices))
            self.state.flag_request = False
            if not legal:
                raise IllegalChoiceError(f"{side_id}: illegal replacement {choices}")
            side = self.state.sides[side_id]
            for position, choice in enumerate(choices):
                if isinstance(choice, SwitchChoice):
                    outgoing = side.active[position]
                    assert outgoing is not None
                    if reviving(self.state, outgoing) and outgoing.switch_flag:
                        revivals.append((outgoing, side.team[choice.team_index]))
                        continue
                    switches.append((outgoing, choice))
        # commitChoices: updateSpeed, then each action's getActionSpeed (028: both draw)
        self._update_speed()
        actions = [self._make_action(outgoing, choice) for outgoing, choice in switches]
        # Replacements are 'instaswitch' actions (order 3): every switch-in happens before the
        # runSwitch actions, which then run as one batch. runAction skips eachEvent('Update')
        # while another instaswitch is next (verified with the draw trace).
        queue = ActionQueue(actions, self.prng)
        pending: list[BattlePokemon] = []
        while queue:
            action = queue.pop()
            assert isinstance(action.choice, SwitchChoice)
            side = self.state.sides[action.pokemon.side]
            incoming = side.team[action.choice.team_index]
            assert action.pokemon.position is not None
            # 030 (R8): switchIn's copyVolatileFrom(oldActive, 'shedtail'): the substitute (its
            # hp left) and nothing else, not the boosts
            passed = 0
            if action.pokemon.hp > 0:
                if action.pokemon.switch_flag == SHED_TAIL:
                    passed = action.pokemon.substitute_hp
                elif action.pokemon.switch_flag == BATON_PASS:
                    copy_volatiles(action.pokemon, incoming)  # 034 (R4): copyVolatileFrom
                self._switch_out(action.pokemon)  # 014: switched out by its flag
                if self._queue is not None:
                    self._queue.remove(partial(_acts_for, action.pokemon))  # cancelAction
            self._switch_in(side, action.pokemon.position, incoming)
            if passed:
                incoming.substitute_hp = passed
            self._insert_run_switch(pending, incoming)
            if not queue:
                # eachEvent('Update'): runSwitch is next (041-6f: or a revivalblessing action)
                self._update(run_switch_next=not revivals)
        upcoming = self._queue.peek() if resume == "turn" and self._queue is not None else None
        now = resume != "turn" or (upcoming is not None and upcoming.kind == "move")
        for user, target in revivals:  # 041-6f: order 6, after the instaswitches
            if self._revive(user, target, now=now):
                self._insert_run_switch(pending, target)
                self._update(run_switch_next=True)  # (the instaswitch's runAction)
            else:
                self._update(run_switch_next=bool(pending))  # runAction's end
        self._switch_in_abilities(pending, self._run_switch_sort())
        if resume == "turn":
            # 014: the end of the runSwitch action, then the rest of the turn's queue
            assert self._queue is not None
            if self._after_action(self._queue):
                return
            self._continue_turn()
            return
        # 020: the queue is empty after these runSwitch actions, so runAction's checkFainted
        # flags a Pokémon the hazards knocked out, and its replacement is asked for before the
        # next turn (R8). The fainted positions and the switch flags (Eject Pack) go into one
        # request: switchFlag is set on both, so it is not a flag-only request.
        self._check_fainted()
        self._update()  # eachEvent('Update') after runSwitch
        if self.state.ended:
            return
        if self._fainted_to_replace():
            self._switch_requested()  # (drops flags with nobody to bring in; BeforeSwitchOut)
            return  # replace() again, then the next turn
        if self._flag_request_after_switch_in():
            return
        self._next_turn()

    def _fainted_to_replace(self) -> bool:
        """020: a fainted active Pokémon with someone on the bench to replace it."""
        return any(
            p is not None and p.fainted and need
            for s in SIDE_IDS
            for p, need in zip(self.state.sides[s].active, self.needs_replacement(s), strict=True)
        )


TAUNT = "taunt"
# 015: the volatiles that limit the moves (residual order); Mental Herb cures them in this order
ENCORE = "encore"
MOVE_LOCKS: Mapping[str, int] = {TAUNT: 15, ENCORE: 16}
# mentalherb's list, in its order (attract and torment are not supported; 023: disable, healblock)
MENTAL_HERB_CURES = (TAUNT, ENCORE, DISABLE, HEAL_BLOCK)
LOCKING_MOVES = frozenset({"outrage", "thrash", "petaldance", "ragingfury"})  # 022, 041
MOVE_LOCK_NAMES: Mapping[str, str] = {TAUNT: "move: Taunt", ENCORE: "Encore"}
VOLATILE_END_NAMES: Mapping[str, str] = {
    **MOVE_LOCK_NAMES,
    DISABLE: "Disable",
    HEAL_BLOCK: "move: Heal Block",
}
OBLIVIOUS = "oblivious"
ATTACK_FIRST_MOVES = frozenset({"suckerpunch", "thunderclap"})  # 015: onTry (R1)
UPPER_HAND = "upperhand"  # 021: onTry (R7)
SUBSTITUTE = "substitute"  # 016
SPINNERS = frozenset({"rapidspin", "mortalspin"})  # 020
POWER_HERB = "powerherb"
DEFOG = "defog"
TIDY_UP = "tidyup"
PAIN_SPLIT = "painsplit"  # 021
TRICK = "trick"  # 022
SKILL_SWAP = "skillswap"  # 027
SLEEP_TALK = "sleeptalk"  # 025
COPYCAT = "copycat"  # 041-5
METRONOME = "metronome"  # 041-6f
CORROSIVE_GAS = "corrosivegas"  # 041-6f
HEALING_WISH = "healingwish"  # 025
LUNAR_DANCE = "lunardance"  # 041-6d
WISHES = (HEALING_WISH, LUNAR_DANCE)
DOODLE = "doodle"  # 041-6f
TRANSFORM = "transform"  # 041-6f
SPA_CHARGERS = frozenset({"meteorbeam", "electroshot"})  # 020, 021: SpA +1 when charging
OHKO = "ohko"  # 026: the move key (Sheer Cold: "Ice")
PHANTOM_FORCE = "phantomforce"  # 026: the move and its volatile (semi-invulnerable)
# 041-2: the two-turn moves whose volatile makes the user semi-invulnerable, and the moves
# each one lets through (onInvulnerability)
SMACK_DOWN = "smackdown"  # 041-2
FURY_CUTTER = "furycutter"  # 041-3b
SEMI_INVULNERABLE = frozenset({PHANTOM_FORCE, "shadowforce", "dig", "fly", "dive", "bounce"})
_SKY = frozenset({"gust", "twister", "skyuppercut", "thunder", "hurricane", "smackdown",
                  "thousandarrows"})  # fmt: skip
HITS_VANISHED = {
    "dig": frozenset({"earthquake", "magnitude"}),
    "dive": frozenset({"surf", "whirlpool"}),
    "fly": _SKY,
    "bounce": _SKY,
}


def vanished(pokemon: BattlePokemon) -> str:
    """041-2: ``isSemiInvulnerable``: the semi-invulnerable volatile it has, or ""."""
    return next((v for v in pokemon.timed if v in SEMI_INVULNERABLE), "")


def _clear_vanished(pokemon: BattlePokemon) -> None:
    for v in SEMI_INVULNERABLE:
        pokemon.timed.pop(v, None)


ORDER_UP = "orderup"  # 028
# 026: getTarget gives null for the user's own location with these targets
SELF_LOC_NULL_TARGETS = frozenset({"adjacentAlly", "any", "normal"})
SHEER_COLD = "sheercold"
AFTER_YOU = "afteryou"  # 025
DESTINY_KNOT = "destinyknot"  # 041-6f
QUASH_ORDER = 201  # 041-6f: Quash
SLEEP_TALK_EXCLUDED = frozenset({"nosleeptalk", "charge"})
ROOST = "roost"  # 022: the move and its volatile (duration 1)
ROOST_RESIDUAL_ORDER = 25
ENDEAVOR = "endeavor"  # 023
RUINATION = "ruination"  # 024
NIGHT_SHADE = "nightshade"  # 033 (R1)
SUPER_FANG = "superfang"  # 033 (R1)
FIXED_DAMAGE_MOVES = frozenset(
    {
        "endeavor",
        "finalgambit",
        RUINATION,
        NIGHT_SHADE,
        SUPER_FANG,
        "seismictoss",
        "counter",
        "mirrorcoat",
        "metalburst",
        "comeuppance",  # 041-6f
    }  # 041-4a
)
TRI_ATTACK = "triattack"  # 033 (R7)
POLTERGEIST = "poltergeist"  # 033 (R8)
TRIPLE_AXEL = "tripleaxel"  # 033 (R10)
BEAT_UP = "beatup"  # 033 (R11)
_ACCURACY_TABLE = (1, 4 / 3, 5 / 3, 2, 7 / 3, 8 / 3, 3)  # 033 (R10): multiaccuracy's boostTable
STEEL_BEAM = "steelbeam"  # 033 (R9): mindBlownRecoil
CHLOROBLAST = "chloroblast"  # 041-6b: chloroblastRecoil
HAZARD_SETTERS = {"stoneaxe": "stealthrock", "ceaselessedge": "spikes"}  # 041-6e
FILLET_AWAY = "filletaway"  # 041-6d
CHILLY_RECEPTION = "chillyreception"  # 041-6d
LOCK_ON = "lockon"  # 041-6f
PRESENT = "present"  # 041-6f
# 041-6c
SWAPPED_STAGES = {"guardswap": ("def", "spd"), "powerswap": ("atk", "spa"),
                  "heartswap": BOOST_IDS}  # fmt: skip
SPLIT_STATS = {"powersplit": ("atk", "spa"), "guardsplit": ("def", "spd"), "speedswap": ("spe",)}
SWAP_SPLIT_MOVES = frozenset({*SWAPPED_STAGES, *SPLIT_STATS, "topsyturvy", "magicpowder",
                              "reflecttype", "takeheart", "conversion",
                              "forestscurse", "stuffcheeks", "recycle",
                              "conversion2", "acupressure", "mimic", "sketch"})  # fmt: skip
DOUBLE_SHOCK = "doubleshock"  # 041-1g
SPENT_TYPE = {DOUBLE_SHOCK: "Electric", "burnup": "Fire"}  # 041-6f: Burn Up
SELF_KO_MOVES = frozenset({"selfdestruct", "explosion", "mistyexplosion"})  # 041-1c
CRASH_MOVES = frozenset({"highjumpkick", "supercellslam", "axekick"})  # 041-1c: hasCrashDamage
MOODY = "moody"
HUNGER_SWITCH = "hungerswitch"  # 042-3
TERA_SHIFT = "terashift"  # 042-6
STRENGTH_SAP = "strengthsap"
HAZE = "haze"
GLAIVE_RUSH = "glaiverush"
GLAIVE_RUSH_MODIFIER = (8192, 4096)
MOODY_RESIDUAL = (28, 2)  # onResidualOrder, onResidualSubOrder
FINAL_GAMBIT = "finalgambit"
BURNING_JEALOUSY = "burningjealousy"  # 027
ALLURING_VOICE = "alluringvoice"  # 031
NO_ABILITY = "noability"  # 031: Trace looks for it
DIRE_CLAW = "direclaw"  # 030
GIGA_IMPACT = "gigaimpact"  # 030
# 030 (041-1a: Hyper Beam and the others): self.volatileStatus mustrecharge
RECHARGE_MOVES = frozenset(
    {
        GIGA_IMPACT,
        "hyperbeam",
        "blastburn",
        "hydrocannon",
        "frenzyplant",
        "rockwrecker",
        "prismaticlaser",
        "roaroftime",
    }
)
SHED_TAIL = "shedtail"  # 030
FORCE_SWITCH = "forceSwitch"  # 034: the move key of Roar and Whirlwind
BATON_PASS = "batonpass"  # 034
MINIMIZE_FLAG = "minimize"  # 034: Stomp, Body Slam, Heavy Slam, ... (move.flags)
DIRE_CLAW_STATUSES = ("psn", "par", "slp")
# 030, 033: a secondary's onHit trySetStatus(sample(...))
SAMPLED_STATUSES = {DIRE_CLAW: DIRE_CLAW_STATUSES, TRI_ATTACK: ("brn", "par", "frz")}
THROAT_CHOP_RESIDUAL_ORDER = 22  # 021: throatchop onResidualOrder
UPROAR_RESIDUAL = (28, 1)  # 033 (R13): uproar onResidualOrder, onResidualSubOrder
SLOW_START_RESIDUAL = (28, 2)  # 033 (R12): slowstart onResidualOrder, onResidualSubOrder
HEAL_BLOCK_RESIDUAL_ORDER = 20  # 023
DISABLE_RESIDUAL_ORDER = 17  # 023
PERISH_SONG = "perishsong"  # 022: the volatile (duration 4)
PERISH_SONG_RESIDUAL_ORDER = 24
CLEAR_SMOG = "clearsmog"  # 021
DEFOG_SCREENS = ("reflect", "lightscreen", "auroraveil")
HEALING_MOVES: Mapping[str, tuple[int, int]] = {
    "recover": (1, 2),  # heal: [1, 2]
    "lunarblessing": (1, 4),  # onHit: modify(maxhp, 0.25)
    "junglehealing": (1, 4),  # 041-6d: the same onHit
    "roost": (1, 2),  # 022: heal: [1, 2], then self.volatileStatus
    "lifedew": (1, 4),  # 030 (R6): heal: [1, 4] (target allies)
    "slackoff": (1, 2),  # 032 (R14): heal: [1, 2]
    "softboiled": (1, 2),  # 041-1a
    "milkdrink": (1, 2),
}
WEATHER_HEALS = frozenset({"moonlight", "morningsun", "synthesis"})  # 032 (R14), 041
FLORAL_HEALING = "floralhealing"  # 032 (R14)
BELLY_DRUM = "bellydrum"  # 032 (R15)
CLANGOROUS_SOUL = "clangoroussoul"
CURSE = "curse"  # the move and its volatile (no duration)
CURSE_RESIDUAL_ORDER = 12
_HEAL_VOLATILE_ORDER = {AQUA_RING: 6, INGRAIN: 7, LEECH_SEED: 8}  # 041-4c: onResidualOrder
CURSE_SELF_BOOSTS = {"spe": -1, "atk": 1, "def": 1}
HEAL_PULSE = "healpulse"  # 030 (R5)


@cache
def _metronome_pool() -> list[Move]:
    """041-6f: Metronome's moves (flags.metronome, isNonstandard only Unobtainable), by num."""
    return sorted((m for m in get_dex().all_moves() if "metronome" in m.flags), key=lambda m: m.num)


def _has_hit_effect(move: Move) -> bool:
    """The status move does something on hit (stat stages, a status, a volatile, Parting
    Shot); one without (Splash) succeeds on reaching its target."""
    return (
        bool(move.boosts)
        or FORCE_SWITCH in move.keys  # 034 (T011): Roar with no one to bring in is false
        or move.status is not None
        or move.volatile_status is not None
        or move.id
        in (
            PARTING_SHOT,
            DEFOG,
            TIDY_UP,
            PAIN_SPLIT,
            TRICK,
            "switcheroo",
            SKILL_SWAP,
            HEALING_WISH,
            LUNAR_DANCE,
            "teleport",
            AFTER_YOU,
            HEAL_PULSE,
            *HEALING_MOVES,
            *WEATHER_HEALS,
            FLORAL_HEALING,
            BELLY_DRUM,
            "spite",  # 041-3f
            "psychup",
            "block",  # 041-3g
            "meanlook",
            *ABILITY_MOVES,  # 041-3h
            *SWAP_SPLIT_MOVES,  # 041-6f (from 041-6c: a false onHit fails the move)
            COPYCAT,  # 041-6f (from 041-5)
            REVIVAL_BLESSING,  # 041-6f
            TRANSFORM,  # 041-6f
            "instruct",  # 041-6f
        )
    )


def _acts_for(pokemon: BattlePokemon, action: _Action) -> bool:
    return action.pokemon is pokemon


def _display_name(pokemon: BattlePokemon) -> str:
    """Showdown ``getDetails``: Greninja-Bond and Rockruff-Dusk are shown as the base species."""
    name = pokemon.species.name
    return name.split("-")[0] if name in ("Greninja-Bond", "Rockruff-Dusk") else name


def _round(x: float) -> int:
    """JavaScript ``Math.round`` for non-negative values (halves round up)."""
    return int(x + 0.5)


def _faint(pokemon: BattlePokemon) -> None:
    """The Pokémon faints. Its status stays until ``_check_fainted`` at the end of the turn;
    clearVolatile -> setSpecies resets its cached speed to the plain stat."""
    pokemon.fainted = True
    pokemon.cached_speed = pokemon.stats["spe"]
    pokemon.reset_boosts()
    clear_volatiles(pokemon)


def chosen_move(pokemon: BattlePokemon, choice: MoveChoice) -> Move:
    """The move a choice uses (Struggle when ``move_index`` is ``STRUGGLE``; 030: Recharge)."""
    if choice.move_index == STRUGGLE:
        struggle = get_dex().move("struggle")
        assert struggle is not None
        return struggle
    if choice.move_index == RECHARGE:
        return _recharge_move()
    if choice.move_index == LOCKED_EXTERNAL:  # 041-5: a locked move Copycat called
        locked = get_dex().move(locked_move_id(pokemon) or pokemon.queued_external or "")
        assert locked is not None
        return locked
    return pokemon.moves[choice.move_index].move


RECHARGE_ID = "recharge"


@cache
def _recharge_move() -> Move:
    """030: Showdown's Recharge (``dex.moves.get('recharge')``: a move that does not exist): no
    category (``undefined``: not a Status move, so Prankster does not boost it; review P2),
    priority 0, no flags and no target. With no target, every getTarget is a getRandomTarget
    (randomFoe, one draw: resolveAction, getActionSpeed, runMove), as for a spread move.
    mustrecharge's onBeforeMove always stops it."""
    splash = get_dex().move("splash")
    assert splash is not None
    return replace(
        splash,
        id=RECHARGE_ID,
        name="Recharge",
        name_ja="",
        category="",
        flags=frozenset(),
        target="",
    )


def choice_is_struggle(move: Move) -> bool:
    return move.id == "struggle"


def _by_priority_then_speed(a: tuple[int, int], b: tuple[int, int]) -> int:
    return (b[0] - a[0]) or (b[1] - a[1])


_WEATHER = "weather"  # the residual handler of whichever weather is up
_TERRAIN = "terrain"  # 010: the residual handler of whichever terrain is up
_GRASSY_HEAL = "grassyheal"  # 010: Grassy Terrain's onResidual on one Pokémon
_FIRE_SEA = "firesea"  # 041-5: the sea of fire's onResidual (order 5, subOrder 1)
_ITEM = "item:"  # 013: a held item's onResidual ("item:leftovers")
PARTING_SHOT = "partingshot"  # 014
PARTING_SHOT_DROPS = {"atk": -1, "spa": -1}
# 013: onSwitchInPriority of the items with an onStart (White Herb has none)
METRONOME_ITEM = "metronome"  # 042-1
SWITCH_IN_ITEMS = {BOOSTER_ENERGY: -2, WHITE_HERB: 0, AIR_BALLOON: 0, ROOM_SERVICE: -1,
                   **dict.fromkeys(SEEDS, -1), METRONOME_ITEM: 0}  # fmt: skip
# 042-1: the moves with callsMove (the Metronome item's onTryMove skips them)
CALLING_MOVES = frozenset({"assist", "copycat", "mefirst", "metronome", "mirrormove",
                           "naturepower", "sleeptalk"})  # fmt: skip
METRONOME_BOOSTS = (4096, 4915, 5734, 6553, 7372, 8192)  # 042-1: onModifyDamage
# onResidualOrder, onResidualSubOrder (White Herb has none: an Item's subOrder is 8)
ITEM_RESIDUAL_ORDER = {
    LEFTOVERS: (5, 4),
    BLACK_SLUDGE: (5, 4),
    FLAME_ORB: (28, 3),
    TOXIC_ORB: (28, 3),
    WHITE_HERB: (29, 8),
    EJECT_PACK: (29, 8),
    MICLE_BERRY: (1 << 32, 8),
    MIRROR_HERB: (29, 8),
    STICKY_BARB: (28, 3),  # 040-4b
}  # fmt: skip  (040-3b: no order, last)


@dataclass(slots=True)
class _Residual:
    """A residual handler: a field or side condition (``pokemon`` None), a Pokémon's status,
    or one of its volatile statuses."""

    pokemon: BattlePokemon | None
    effect: str  # "weather", a field/side condition, a status, "flinch" or a timed volatile
    side: str | None = None  # the side of a side condition


_NO_ORDER = 1 << 32  # comparePriority: a handler without an order (flinch) sorts last
_CONDITION_SUB_ORDER = 2  # resolvePriority subOrder: Status 0, Condition (volatiles) 2


def _by_residual(a: _Residual, b: _Residual) -> int:
    """comparePriority for residual handlers: order, then speed (field and side handlers have
    none: 0), then subOrder. Showdown sets effectOrder only for SwitchIn/RedirectTarget
    handlers, so equal handlers tie (shuffled)."""
    return (
        (_residual_order(a) - _residual_order(b))
        or (_handler_speed(b) - _handler_speed(a))
        or (_sub_order(a) - _sub_order(b))
    )


def _weather_duration(source: BattlePokemon, weather: str) -> int | None:
    """The weather's durationCallback: 8 turns when its setter holds the weather's rock."""
    return 8 if WEATHER_ROCKS.get(source.item) == weather else None


def _wonder_skin(move: Move, target: BattlePokemon) -> int:
    """043-3b: Wonder Skin's onModifyAccuracy (priority 10, first): a status move's numeric
    accuracy becomes 50 (the other handlers' modifiers apply to it)."""
    assert move.accuracy is not None
    if target.ability_id == "wonderskin" and move.category == "Status":
        return 50
    return move.accuracy


def _locked_on(user: BattlePokemon, target: BattlePokemon) -> bool:
    """041-6f: the user's lockon volatile names the target (effectState.source)."""
    return LOCK_ON in user.timed and user.lock_on_target is target


def _residual_order(handler: _Residual) -> int:
    if handler.effect.startswith(_SLOT):
        return _SLOT_RESIDUAL[handler.effect.removeprefix(_SLOT)]
    if handler.effect == _WEATHER:
        return WEATHER_RESIDUAL_ORDER
    if handler.effect == _TERRAIN:
        return TERRAIN_RESIDUAL_ORDER[0]
    if handler.effect == _GRASSY_HEAL:
        return GRASSY_HEAL_ORDER[0]
    if handler.effect == _FIRE_SEA:
        return 5
    if handler.effect.startswith(_ITEM):
        return ITEM_RESIDUAL_ORDER[handler.effect.removeprefix(_ITEM)][0]
    if handler.pokemon is None:
        return FIELD_RESIDUAL_ORDER[handler.effect][0]
    if handler.effect in RESIDUAL_ORDER:
        return residual_order(handler.pokemon)
    if handler.effect == THROAT_CHOP:
        return THROAT_CHOP_RESIDUAL_ORDER
    if handler.effect == UPROAR:
        return UPROAR_RESIDUAL[0]
    if handler.effect == SLOW_START:
        return SLOW_START_RESIDUAL[0]
    if handler.effect == HEAL_BLOCK:
        return HEAL_BLOCK_RESIDUAL_ORDER
    if handler.effect == DISABLE:
        return DISABLE_RESIDUAL_ORDER
    if handler.effect == PERISH_SONG:
        return PERISH_SONG_RESIDUAL_ORDER
    if handler.effect == MOODY:
        return MOODY_RESIDUAL[0]
    if handler.effect in (HUNGER_SWITCH, "opportunist", "shieldsdown"):
        return 29  # 042-3, 043-4i
    if handler.effect in (HEALER, HYDRATION, SHED_SKIN):
        return 5  # 043-1, 043-3a
    if handler.effect in (BAD_DREAMS, SPEED_BOOST, "harvest", "cudchew", "pickup"):
        return 28  # 043-3b, 043-4b
    if handler.effect == ROOST:
        return ROOST_RESIDUAL_ORDER
    if handler.effect == PARTIALLY_TRAPPED:
        return PARTIALLY_TRAPPED_RESIDUAL_ORDER
    if handler.effect == YAWN:
        return YAWN_RESIDUAL_ORDER
    if handler.effect == CURSE:
        return CURSE_RESIDUAL_ORDER
    if handler.effect == SALT_CURE:
        return SALT_CURE_RESIDUAL_ORDER
    if handler.effect == MAGNET_RISE:
        return MAGNET_RISE_RESIDUAL_ORDER  # 041-6f
    if handler.effect == SYRUP_BOMB:
        return SYRUP_BOMB_RESIDUAL_ORDER  # 041-6f
    if handler.effect in _HEAL_VOLATILE_ORDER:  # 041-4c
        return _HEAL_VOLATILE_ORDER[handler.effect]
    return MOVE_LOCKS.get(handler.effect, _NO_ORDER)


def _handler_speed(handler: _Residual) -> int:
    return handler.pokemon.cached_speed if handler.pokemon is not None else 0


def _sub_order(handler: _Residual) -> int:
    if handler.effect.startswith(_SLOT):
        return 3  # 041-4b: a slot condition
    if handler.effect == _WEATHER:
        return 0
    if handler.effect == _TERRAIN:
        return TERRAIN_RESIDUAL_ORDER[1]
    if handler.effect == _GRASSY_HEAL:
        return GRASSY_HEAL_ORDER[1]
    if handler.effect == _FIRE_SEA:
        return 1
    if handler.effect.startswith(_ITEM):
        return ITEM_RESIDUAL_ORDER[handler.effect.removeprefix(_ITEM)][1]
    if handler.pokemon is None:
        return FIELD_RESIDUAL_ORDER[handler.effect][1]
    if handler.effect == MOODY:
        return MOODY_RESIDUAL[1]
    if handler.effect in (HUNGER_SWITCH, "opportunist", "shieldsdown"):
        return 7  # 042-3: an Ability
    if handler.effect in (HEALER, HYDRATION, SHED_SKIN):
        return 3  # 043-1, 043-3a
    if handler.effect in (BAD_DREAMS, SPEED_BOOST, "harvest", "cudchew", "pickup"):
        return 2  # 043-3b, 043-4b
    if handler.effect == SLOW_START:
        return SLOW_START_RESIDUAL[1]
    if handler.effect == UPROAR:
        return UPROAR_RESIDUAL[1]
    return 0 if handler.effect in RESIDUAL_ORDER else _CONDITION_SUB_ORDER


def _by_after_secondary(a: tuple[BattlePokemon, str], b: tuple[BattlePokemon, str]) -> int:
    """AfterMoveSecondary handlers: priority (Eject Button 2), speed, then subOrder (status 0,
    ability 7, item 8)."""
    priority = {EJECT_BUTTON: 2}
    order = {"frz": 0, "item": 8, EJECT_BUTTON: 8, RED_CARD: 8}
    return (
        (priority.get(b[1], 0) - priority.get(a[1], 0))
        or (b[0].cached_speed - a[0].cached_speed)
        or (order.get(a[1], 7) - order.get(b[1], 7))
    )


def _modify_move_target(targeting: Targeting) -> BattlePokemon | None:
    """useMoveInner's ModifyMove target: getTarget's (a spread move: its random foe)."""
    if targeting.chosen is not None:
        return targeting.chosen
    return targeting.targets[0] if targeting.targets and not targeting.spread else None


FLING = "fling"  # 032 (R8)
THIEF = "thief"  # 032 (R9)
KINGS_ROCK_FLINCH = Secondary(10, None, frozenset({"chance", "volatileStatus"}),
                              volatile_status="flinch")  # fmt: skip


def _by_handler_order(
    a: tuple[int, int, int, int | None], b: tuple[int, int, int, int | None]
) -> int:
    """032: event handlers as (priority, speed, subOrder, ...): higher priority, faster, then
    lower subOrder first (Battle.comparePriority)."""
    return (b[0] - a[0]) or (b[1] - a[1]) or (a[2] - b[2])


def _by_speed(a: BattlePokemon, b: BattlePokemon) -> int:
    """Showdown sorts Pokémon by ``pokemon.speed`` (the cached value), fastest first."""
    return b.cached_speed - a.cached_speed


_WEATHER_LOCKS = {"cloudnine": "Cloud Nine", "airlock": "Air Lock"}  # 043-4g


def _suppresses_weather(pokemon: BattlePokemon) -> bool:
    """043-4g: suppressWeather and not ignoringAbility() (Mold Breaker does not count)."""
    return (
        to_id(pokemon.ability) in _WEATHER_LOCKS
        and not pokemon.neutralized
        and not pokemon.gastro_acid
    )


# 013 Berserk; 043-4i Anger Shell (the same onDamage / onTryEatItem / onAfterMoveSecondary)
_HALF_HP_BOOSTS: dict[str, tuple[dict[str, int], str]] = {
    BERSERK: ({"spa": 1}, "Berserk"),
    "angershell": ({"atk": 1, "spa": 1, "spe": 1, "def": -1, "spd": -1}, "Anger Shell"),
}


_TANGLERS = {"gooey": "Gooey", "tanglinghair": "Tangling Hair"}  # 043-4d


def _asleep(pokemon: BattlePokemon) -> bool:
    """043-3c: ``status === 'slp' || hasAbility('comatose')``."""
    return pokemon.status == "slp" or pokemon.ability_id == COMATOSE


def _opposite_genders(target: BattlePokemon, source: BattlePokemon) -> bool:
    """041-6f: Attract's gender check (M and F; genderless never)."""
    return {target.gender, source.gender} == {"M", "F"}


def _queued_move_of(pokemon: BattlePokemon, action: _Action) -> bool:
    return action.pokemon is pokemon and action.kind == "move"
