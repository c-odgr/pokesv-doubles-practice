"""Random teams within what the engine supports (for tests, cross-checks and baselines)."""

from __future__ import annotations

import random
from collections.abc import Sequence
from dataclasses import replace
from functools import cache

from pokesv_sim.dex import STAT_IDS, get_dex, to_id
from pokesv_sim.support import (
    HAND_PORTED_ABILITIES,
    PIVOT_MOVES,
    species_supported,
    supported_items,
    supported_moves,
)
from pokesv_sim.team import PokemonSet, Team


def random_team(
    rng: random.Random,
    size: int = 6,
    *,
    status_moves: bool = False,
    stage_moves: bool = False,
    volatile_moves: bool = False,
    fake_out: bool = False,
    speed_control: bool = False,
    weather: bool = False,
    screens: bool = False,
    aurora_veil: bool = False,
    doubles_moves: bool = False,
    support_moves: bool = False,
    terrain: bool = False,
    pivot_moves: bool = False,
    parting_shot: bool = False,
    required_moves: Sequence[str] | None = None,
    abilities: bool = False,
    ability_pool: frozenset[str] | None = None,
    move_pool: frozenset[str] | None = None,
    items: bool = False,
    item_pool: frozenset[str] | None = None,
) -> Team:
    """A legal team within the engine's support: learnable supported moves, 'No Ability', no
    item unless asked.

    ``status_moves``: every member knows a move that can inflict a status condition (003).
    ``stage_moves``: every member knows a 004 move (stat stages, recoil, drain, multi-hit, crit).
    ``volatile_moves``: every member knows a 005 move (flinch, confusion, Fake Out).
    ``fake_out``: every member knows Fake Out.
    ``speed_control``: every member knows Trick Room or Tailwind (006).
    ``weather``: every member knows a weather move and, when it can, a move the weather changes
    (Fire, Water, Thunder, Weather Ball, ...) (007).
    ``screens``: every member knows Reflect, Light Screen or Aurora Veil; one that knows Aurora
    Veil also knows Snowscape when it can; both also learn a screen breaker when they can (008).
    ``aurora_veil``: like ``screens``, with Aurora Veil for every member (only a dozen learn it).
    ``doubles_moves``: every member knows a 009 move; each also learns a protection move and
    a supporting move (Follow Me, Helping Hand, Wide Guard, ...) when it can (009).
    ``support_moves``: like ``doubles_moves``, from the members that learn a supporting move
    other than Helping Hand and Feint.
    ``terrain``: every member knows a terrain move and, when it can, a move the terrain changes
    (Terrain Pulse, Expanding Force, Grassy Glide, Steel Roller, ...) (010).
    ``pivot_moves``: every member knows U-turn, Volt Switch, Flip Turn or Parting Shot (014).
    ``parting_shot``: every member knows Parting Shot (014).
    ``required_moves``: member i is a species that learns ``required_moves[i]`` (a name) and
    knows it (015: spreads rare moves over the members; ``size`` is its length).
    ``abilities``: every member has one of its abilities that 011 supports (otherwise
    'No Ability'); ``ability_pool``: only these ability ids.
    ``move_pool``: the move ids to choose from (default: every supported move).
    ``items``: every member holds a supported item, a different one each (013);
    ``item_pool``: only these item ids. The items are drawn after the members, so the
    members are the same as without them.
    """
    dex = get_dex()
    pool = _supported_pool(move_pool if move_pool is not None else supported_moves())
    candidates = sorted(pool)
    required = (
        _inflicts_status
        if status_moves
        else _uses_004
        if stage_moves
        else uses_volatile
        if volatile_moves
        else _is_fake_out
        if fake_out
        else _controls_speed
        if speed_control
        else _sets_weather
        if weather
        else _sets_terrain
        if terrain
        else _pivots
        if pivot_moves
        else _is_parting_shot
        if parting_shot
        else _supports
        if support_moves
        else _is_009
        if doubles_moves
        else _knows_aurora_veil
        if aurora_veil
        else _sets_screen
        if screens
        else None
    )
    if required is not None:
        candidates = [s for s in candidates if any(required(m) for m in pool[s])]
    allowed = frozenset(ability_pool if ability_pool is not None else HAND_PORTED_ABILITIES)
    if abilities:
        candidates = [s for s in candidates if _supported_abilities(s, allowed)]
    members = []
    if required_moves is not None:
        chosen: list[str] = []
        for name in required_moves:
            chosen.append(
                rng.choice([s for s in candidates if name in pool[s] and s not in chosen])
            )
    else:
        chosen = rng.sample(candidates, size)
    for k, species_id in enumerate(chosen):
        moves = rng.sample(pool[species_id], min(4, len(pool[species_id])))
        if required_moves is not None and required_moves[k] not in moves:
            moves[0] = required_moves[k]
        if required is not None and not any(required(m) for m in moves):
            moves[0] = rng.choice([m for m in pool[species_id] if required(m)])
            moves = list(dict.fromkeys(moves))
        if weather and not any(_weather_changes(m) for m in moves):
            favoured = [m for m in pool[species_id] if _weather_changes(m) and m not in moves]
            free = [i for i, m in enumerate(moves) if not _sets_weather(m)]
            if favoured and free:
                moves[free[0]] = rng.choice(favoured)
        if terrain and not any(m in _TERRAIN_DEPENDENT for m in moves):
            favoured = [m for m in pool[species_id] if m in _TERRAIN_DEPENDENT]
            free = [i for i, m in enumerate(moves) if not _sets_terrain(m)]
            if favoured and free:
                moves[free[0]] = rng.choice(favoured)
        if screens or aurora_veil:
            _add_screen_partners(rng, moves, pool[species_id])
        if doubles_moves or support_moves:
            _add_009_moves(rng, moves, pool[species_id])
        evs = dict.fromkeys(STAT_IDS, 0)
        budget = 510
        for stat in rng.sample(STAT_IDS, len(STAT_IDS)):
            evs[stat] = min(budget, rng.randrange(0, 253, 4))
            budget -= evs[stat]
        nature = rng.choice(_NATURES)
        species = dex.species(species_id)
        assert species is not None
        ability = (
            rng.choice(_supported_abilities(species_id, allowed)) if abilities else "No Ability"
        )
        members.append(
            PokemonSet(
                species=species.name,
                moves=tuple(moves),
                ability=ability,
                nature=nature,
                evs=evs,
            )
        )
    if items:
        names = [_item_name(i) for i in sorted(item_pool or supported_items())]
        held = rng.sample(names, len(members))
        members = [replace(m, item=item) for m, item in zip(members, held, strict=True)]
    return Team(tuple(members))


def _item_name(item_id: str) -> str:
    item = get_dex().item(item_id)
    assert item is not None
    return item.name


_NATURES = ["Adamant", "Modest", "Jolly", "Timid", "Bold", "Calm", "Serious", "Brave", "Quiet"]


@cache
def _supported_abilities(species_id: str, allowed: frozenset[str]) -> list[str]:
    """The species' abilities among ``allowed`` (ids), as names."""
    species = get_dex().species(species_id)
    assert species is not None
    return [a for a in species.abilities if to_id(a) in allowed]


@cache
def _supported_pool(moves: frozenset[str]) -> dict[str, list[str]]:
    """Species id -> the given moves it can learn (supported species with at least one)."""
    dex = get_dex()
    pool = {}
    for species in dex.all_species():
        if not species_supported(species.id):
            continue
        learnable = sorted(m for m in dex.learnable(species.id) if m in moves)
        if learnable:
            pool[species.id] = [_move_name(m) for m in learnable]
    return pool


def _move_name(move_id: str) -> str:
    move = get_dex().move(move_id)
    assert move is not None
    return move.name


def _inflicts_status(move_name: str) -> bool:
    move = get_dex().move(move_name)
    assert move is not None
    return move.status is not None or any(sec.status for sec in move.secondaries)


def _uses_004(move_name: str) -> bool:
    move = get_dex().move(move_name)
    assert move is not None
    return bool(
        move.boosts
        or move.self_boosts
        or move.recoil
        or move.drain
        or move.multihit
        or move.will_crit
        or move.crit_ratio > 1
        or any(sec.boosts or sec.self_boosts for sec in move.secondaries)
    )


def uses_volatile(move_name: str) -> bool:
    """A 005 move: it can flinch or confuse (Fake Out included)."""
    move = get_dex().move(move_name)
    assert move is not None
    return move.volatile_status is not None or any(sec.volatile_status for sec in move.secondaries)


def _pivots(move_name: str) -> bool:
    return to_id(move_name) in PIVOT_MOVES


def _is_parting_shot(move_name: str) -> bool:
    return move_name == "Parting Shot"


def _is_fake_out(move_name: str) -> bool:
    return move_name == "Fake Out"


def _controls_speed(move_name: str) -> bool:
    return move_name in ("Trick Room", "Tailwind")


def _sets_screen(move_name: str) -> bool:
    return move_name in ("Reflect", "Light Screen", "Aurora Veil")


def _knows_aurora_veil(move_name: str) -> bool:
    return move_name == "Aurora Veil"


_SCREEN_BREAKERS = ("Brick Break", "Psychic Fangs", "Raging Bull")


def _add_screen_partners(rng: random.Random, moves: list[str], learnable: list[str]) -> None:
    """Snowscape for an Aurora Veil user, and a screen breaker when it can learn one, each in a
    slot that does not hold a screen (008)."""
    wanted = []
    if "Aurora Veil" in moves and "Snowscape" in learnable:
        wanted.append("Snowscape")
    breakers = [m for m in learnable if m in _SCREEN_BREAKERS]
    if breakers and not any(m in _SCREEN_BREAKERS for m in moves):
        wanted.append(rng.choice(breakers))
    for move in wanted:
        if move in moves:
            continue
        free = [i for i, m in enumerate(moves) if not _sets_screen(m) and m not in wanted]
        if free:
            moves[free[0]] = move
        elif len(moves) < 4:
            moves.append(move)


_PROTECTS = ("Protect", "Detect", "Spiky Shield", "Baneful Bunker", "Silk Trap",
             "Burning Bulwark", "Endure")  # fmt: skip
_SUPPORTS = ("Wide Guard", "Quick Guard", "Follow Me", "Rage Powder", "Helping Hand", "Coaching",
             "Aromatic Mist", "Ally Switch", "Feint")  # fmt: skip


def _is_009(move_name: str) -> bool:
    return move_name in _PROTECTS or move_name in _SUPPORTS


_COMMON = ("Protect", "Endure", "Helping Hand", "Feint")


def _supports(move_name: str) -> bool:
    """A supporting move that few Pokémon learn (Follow Me, Wide Guard, Ally Switch, ...)."""
    return move_name in _SUPPORTS and move_name not in _COMMON


def _add_009_moves(rng: random.Random, moves: list[str], learnable: list[str]) -> None:
    """A protection move and a supporting move, each when the member can learn one and does not
    know one yet, in a slot that holds no 009 move (009)."""
    for group in (_PROTECTS, _SUPPORTS):
        if any(m in group for m in moves):
            continue
        options = [m for m in learnable if m in group]
        # Protect, Endure and Helping Hand are learnable by most: favour the others.
        rarer = [m for m in options if m not in _COMMON]
        if rarer and rng.random() < 0.6:
            options = rarer
        if not options:
            continue
        move = rng.choice(options)
        free = [i for i, m in enumerate(moves) if not _is_009(m)]
        if free:
            moves[free[0]] = move
        elif len(moves) < 4:
            moves.append(move)


_TERRAINS = ("Electric Terrain", "Grassy Terrain", "Psychic Terrain", "Misty Terrain")
_TERRAIN_DEPENDENT = ("Terrain Pulse", "Expanding Force", "Rising Voltage", "Grassy Glide",
                      "Psyblade", "Steel Roller", "Ice Spinner")  # fmt: skip


def _sets_terrain(move_name: str) -> bool:
    return move_name in _TERRAINS


def _sets_weather(move_name: str) -> bool:
    return move_name in ("Sunny Day", "Rain Dance", "Sandstorm", "Snowscape")


_WEATHER_DEPENDENT = ("Thunder", "Hurricane", "Blizzard", "Bleakwind Storm", "Wildbolt Storm",
                      "Sandsear Storm", "Weather Ball", "Hydro Steam")  # fmt: skip


def _weather_changes(move_name: str) -> bool:
    """A damaging move the weather changes: Fire and Water moves, and the 007 moves."""
    if move_name in _WEATHER_DEPENDENT:
        return True
    move = get_dex().move(move_name)
    return move is not None and move.category != "Status" and move.type in ("Fire", "Water")
