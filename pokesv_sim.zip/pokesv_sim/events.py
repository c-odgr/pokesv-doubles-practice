"""Battle events: the ordered record of everything that happened in a battle."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Literal

EventKind = Literal[
    "preview",  # a side chose its Pokémon (detail: chosen species, leads first)
    "switch",  # a Pokémon entered a position (value: its HP)
    "drag",  # 034: a Pokémon was dragged in by Roar / Whirlwind (fields as for "switch")
    "replace",  # 034: Illusion ended (target: the position, detail: the true species)
    "turn",  # a new turn begins (value: turn number)
    "move",  # actor used a move (detail: move name; target: chosen target position)
    "fail",  # the move failed (e.g. no target left)
    "combine",  # 041-5: a combined Pledge (no fields)
    "waiting",  # 041-5: actor waits for its ally (target) with another Pledge
    "immune",  # target is unaffected by the move's type
    "miss",  # the move missed target
    "crit",  # a critical hit on target
    "supereffective",
    "resisted",
    "damage",  # target lost HP (value: damage dealt, hp: HP left; detail: cause if not a move)
    "status",  # target got a status condition (detail: "brn", "par", ...)
    "curestatus",  # target's status ended (detail: which)
    "cant",  # actor could not move (detail: "par", "slp", "frz", "flinch")
    "start",  # target got a volatile status (detail: "confusion")
    "end",  # target's volatile status ended (detail: "confusion")
    "activate",  # target's volatile status takes effect (detail: "confusion")
    "fieldstart",  # a field condition started (actor: who set it; detail: "Trick Room")
    "fieldend",  # a field condition ended (detail: its name)
    "sidestart",  # a side condition started (actor: the side; detail: "Tailwind")
    "sideend",  # a side condition ended (actor: the side; detail: its name)
    "weather",  # the weather started (detail: "RainDance", ...) or ended (detail: "none")
    "weatherupkeep",  # the weather goes on at the end of a turn (detail: its name)
    "boost",  # target's stat stage rose (detail: stat, value: stages; 0 if it could not)
    "unboost",  # target's stat stage fell (detail: stat, value: stages)
    "heal",  # target recovered HP (value: amount, hp: HP after; detail: cause)
    "hitcount",  # a multi-hit move hit target value times
    "singleturn",  # target got a one-turn effect (detail: "Protect", "move: Follow Me", ...)
    "swap",  # actor moved to position value (Ally Switch)
    "ability",  # target's ability is announced (detail: its name, e.g. "Intimidate") (011)
    "enditem",  # target lost its item (detail: the item name) (013)
    "clearnegativeboost",  # target's lowered stats were restored (White Herb) (013)
    "terastallize",  # target terastallized (detail: the Tera Type) (017)
    "formechange",  # 042-3: a forme change not for good (detail: the species name)
    "copyboost",  # 043-1: Costar (target copies actor's stages)
    "detailschange",  # target changed forme for good (detail: the new species name) (017)
    "prepare",  # target starts charging a two-turn move (detail: its name) (020)
    "sethp",  # target's HP was set (hp: HP after; Pain Split) (021)
    "clearboost",  # target's stat stages were all reset (Clear Smog) (021)
    "swapsideconditions",  # Court Change swapped the side conditions (041-6f)
    "transform",  # actor transformed into target (041-6f)
    "clearallboost",  # every active Pokemon's stat stages were reset (Haze) (023)
    "item",  # target got an item (detail: the item name; Trick) (022)
    "fieldactivate",  # a move acted on the whole field (detail: "move: Perish Song") (022)
    "block",  # target's item stopped an effect (detail: "item: Ability Shield") (029)
    "ohko",  # an OHKO move knocked its target out (026; not in the compared log)
    "mustrecharge",  # target must recharge next turn (Giga Impact, 030)
    "setboost",  # target's stage set to value (Belly Drum, 032)
    "faint",
    "win",  # detail: winning side
    "tie",
    "aborted",  # the battle needed something the engine does not support yet (detail: what)
]


@dataclass(frozen=True, slots=True)
class Event:
    kind: EventKind
    turn: int
    actor: str | None = None  # position such as "p1a", or a side id for preview/win
    target: str | None = None
    value: int | None = None
    hp: int | None = None
    detail: str | None = None
    team_index: int | None = None  # for "switch": the Pokémon's index in its side's team

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}
