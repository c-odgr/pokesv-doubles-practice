"""035 (plan R3, US5-2..4): what the log's hits and move order say about the foe's sets.

A turn's log is cut into hits: a ``move`` line, then the outcome lines up to the next ``move``.
A hit is used only when the view at the next decision still describes its conditions: no stat
stage, weather, terrain or side condition changed during the turn, nothing was eaten or lost by
the two Pokémon, no switch at their positions, not a multi-hit move. What cannot be read safely
is skipped: a missed observation costs little; a wrong one would rule out the truth.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

from pokesv_sim.dex import Move, get_dex
from pokesv_sim.events import Event

UNSAFE_TURN = frozenset({
    "boost", "unboost", "clearboost", "clearallboost", "clearnegativeboost", "setboost",
    "weather", "fieldstart", "fieldend", "sidestart", "sideend", "swap", "detailschange",
    "replace", "item", "sethp",
})  # fmt: skip
OUTCOME = frozenset({"damage", "immune", "miss", "activate", "crit", "supereffective", "resisted"})


@dataclass(frozen=True, slots=True)
class Hit:
    attacker: str  # position label
    target: str
    move: Move
    crit: bool
    spread: bool
    helping_hand: bool
    damage: int | None  # HP lost (the side's own Pokémon); None for a foe target
    hp_before: int | None  # HP before (own) or the shown percentage (foe); None if not known
    hp_after: int  # HP after (own) or the shown percentage (foe)
    turn: int


@dataclass(frozen=True, slots=True)
class Order:
    first: str  # position labels: ``first`` used its move before ``second``
    second: str
    first_move: Move
    second_move: Move
    turn: int


def _turns(log: Sequence[Event]) -> dict[int, list[Event]]:
    out: dict[int, list[Event]] = {}
    for e in log:
        out.setdefault(e.turn, []).append(e)
    return out


def track_hp(e: Event, hp: dict[str, int]) -> int | None:
    """Keep ``hp`` (position label -> HP as the log shows it) up to date; return the value
    before ``e`` for a damage line."""
    label = e.actor if e.kind in ("switch", "drag") else e.target
    if label is None:
        return None
    before = hp.get(label)
    if e.kind in ("switch", "drag"):
        shown = e.hp if e.hp is not None else e.value
        if shown is not None:
            hp[label] = shown
    elif e.kind in ("damage", "heal", "sethp") and e.hp is not None:
        hp[label] = e.hp
    return before


def hits_and_orders(
    log: Sequence[Event], hp: dict[str, int] | None = None
) -> tuple[list[Hit], list[Order]]:
    """The hits and move orders of the log that can be read safely (see the module doc).
    ``hp``: the HP shown at each position before the log (updated as the log is read)."""
    dex = get_dex()
    hp = {} if hp is None else hp
    before: dict[int, int | None] = {}
    for e in log:
        before[id(e)] = track_hp(e, hp)
    hits: list[Hit] = []
    orders: list[Order] = []
    for turn, events in sorted(_turns(log).items()):
        if any(e.kind in UNSAFE_TURN for e in events):
            continue
        touched = {e.target for e in events if e.kind in ("enditem", "switch", "drag")}
        touched |= {e.actor for e in events if e.kind in ("switch", "drag")}
        helped = {e.target for e in events if e.kind == "singleturn" and e.detail == "Helping Hand"}
        moves = [i for i, e in enumerate(events) if e.kind == "move"]
        used: list[tuple[str, Move]] = []
        for n, start in enumerate(moves):
            head = events[start]
            end = moves[n + 1] if n + 1 < len(moves) else len(events)
            body = events[start + 1 : end]
            move = dex.move(head.detail or "")
            actor = head.actor
            if move is None or actor is None:
                continue
            used.append((actor, move))
            if move.category == "Status" or move.multihit is not None or actor in touched:
                continue
            labels = {
                e.target for e in body if e.kind in OUTCOME and e.target and e.target != actor
            }
            crits = {e.target for e in body if e.kind == "crit"}
            if any(e.kind == "activate" and e.detail == "move: Substitute" for e in body):
                continue
            for e in body:
                if e.kind != "damage" or e.detail is not None or e.target in touched:
                    continue
                if e.hp is None or e.target is None:
                    continue
                hits.append(
                    Hit(
                        attacker=actor,
                        target=e.target,
                        move=move,
                        crit=e.target in crits,
                        spread=len(labels) > 1,
                        helping_hand=actor in helped,
                        damage=e.value,
                        hp_before=before.get(id(e)),
                        hp_after=e.hp,
                        turn=turn,
                    )
                )
        if any(e.kind in ("cant", "activate") and e.detail and "Quick" in e.detail for e in events):
            continue  # Quick Claw / Quick Draw move out of turn
        for i, (a, ma) in enumerate(used):
            if a in touched:
                continue
            for b, mb in used[i + 1 :]:
                if b in touched:
                    continue
                if (
                    a[:2] != b[:2]
                    and ma.priority == mb.priority
                    and _fixed(ma)
                    and _fixed(mb)
                    and "Status" not in (ma.category, mb.category)
                ):
                    orders.append(Order(a, b, ma, mb, turn))
    return hits, orders


def _fixed(move: Move) -> bool:
    """A move whose priority is the move's own (Grassy Glide gains one in Grassy Terrain;
    Triage raises draining moves)."""
    return move.id != "grassyglide" and "heal" not in move.flags
