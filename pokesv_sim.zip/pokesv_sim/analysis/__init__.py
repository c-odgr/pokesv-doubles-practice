"""Analysis on top of the engine: many battles, summaries, comparisons with Showdown."""
