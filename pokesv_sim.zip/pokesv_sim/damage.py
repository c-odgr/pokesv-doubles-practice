"""Damage calculation (Showdown ``BattleActions.getDamage`` / ``modifyDamage``, Gen 9).

Covers what 001 supports: level, attacking/defending stat, base power, spread modifier, critical
hit, random factor, STAB and type effectiveness; burns (003), stat stages (004) and the weather
(007, passed as the weather id), abilities (011, 012). Items are added by 013 at the points
marked in ``_modify``.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace

from pokesv_sim.abilities import (
    BOOSTER_MODIFIER,
    CRIT_BLOCKERS,
    HALVING_ABILITIES,
    RUIN,
    RUIN_MODIFIER,
    WATER_BUBBLE,
    attack_modifier,
    base_power_modifiers,
    ignores_ghost_immunity,
    ruin_modifier,
)
from pokesv_sim.boosts import boosted_stat
from pokesv_sim.dex import Move, get_dex
from pokesv_sim.items import (
    ASSAULT_VEST,
    CHOICE_STAT,
    EVIOLITE,
    LIFE_ORB,
    LIFE_ORB_MODIFIER,
    MASK_MODIFIER,
    OGERPON_MASKS,
    RESIST_BERRY_MODIFIER,
    TYPE_BOOSTER_MODIFIER,
    legend_orb,
    resist_berry,
    soul_dew,
    type_booster,
)
from pokesv_sim.order import speed_sort
from pokesv_sim.prng import Prng
from pokesv_sim.screens import SCREEN_MODIFIER, reduces
from pokesv_sim.terrain import base_power_callback as terrain_base_power_callback
from pokesv_sim.terrain import base_power_modifier as terrain_base_power
from pokesv_sim.terrain import is_grounded, move_base_power_modifier
from pokesv_sim.weather import (
    SOLAR_MOVES,
    SOLAR_WEAK_WEATHER,
    boosts_defense,
    damage_modifier,
    effective_weather,
)

# Gen 7+ critical hit chances by crit ratio (index 1 = 1/24, the default).
_CRIT_MULT = (0, 24, 8, 2, 1)
_SPREAD_MODIFIER = 0.75


@dataclass(frozen=True, slots=True)
class Combatant:
    """What damage depends on: level, current types and stats."""

    level: int
    types: tuple[str, ...]
    stats: Mapping[str, int]
    burned: bool = False
    boosts: Mapping[str, int] | None = None  # stat stages (004)
    ability: str = ""  # ability id (011); "" while Mold Breaker ignores it (012)
    booster: str | None = None  # the stat Protosynthesis / Quark Drive raises (011)
    statused: bool = False  # has a status condition (Guts, 012)
    flash_fire: bool = False  # Flash Fire has started (012)
    full_hp: bool = True  # at full HP (Multiscale, 012)
    # 017: its own types (``types`` is the Tera Type once terastallized), the Tera Type it
    # terastallized into (None: not terastallized) and the types Stellar has already boosted
    base_types: tuple[str, ...] = ()
    tera: str | None = None
    stellar_boosted: frozenset[str] = frozenset()
    shell: bool = False  # 042-6: Tera Shell makes this hit not very effective
    disguised: bool = False  # 043-6e: Disguise / Ice Face: no crit, effectiveness 0
    pikachu: bool = False  # review: Light Ball's baseSpecies.baseSpecies (not a Transform)
    species: str = ""  # the species name (Ogerpon's masks and Ivy Cudgel, 017)
    item: str = ""  # held item id (013)
    nfe: bool = False  # not fully evolved (Eviolite, 013)
    item_takeable: bool = False  # Knock Off can take the item (013)
    # 015: the move callbacks' inputs
    status: str | None = None  # the status condition (Facade: not while asleep)
    hp: int = 0  # current and max HP (Eruption; max_hp 0: not given, full power)
    # 032: Unaware's onAnyModifyBoost by Showdown's activeTarget (None: from the abilities):
    # whether this Pokémon's stages are ignored in this calculation (a substitute's
    # TryPrimaryHit keeps the accuracy step's last target as activeTarget)
    stages_ignored: bool | None = None
    max_hp: int = 0
    weight_hg: int = 0  # species weight in hectograms (Heavy Slam, Heat Crash)
    speed: int = 0  # getStat('spe'): with its stage and modifiers (Gyro Ball, 021)
    failed_last_turn: bool = False  # moveLastTurnResult === false (Stomping Tantrum)
    # 023: hurtThisTurn (Assurance), not newly switched in and done moving this turn
    # (Payback), side.totalFainted (Last Respects), timesAttacked (Rage Fist)
    hurt_this_turn: bool = False
    acted: bool = False
    side_fainted: int = 0
    smacked_down: bool = False  # 041-2: the smackdown volatile (isGrounded)
    rising: bool = False  # 041-6f: the magnetrise volatile (isGrounded)
    vanished: str = ""  # 041-2: the semi-invulnerable volatile (Fly: Gust x2)
    echoed_voice: int = 1  # 041-1f: the field's Echoed Voice multiplier
    callback_state: int = 0  # 041-3b: Fury Cutter's multiplier, Rollout's power
    charge: bool = False  # 041-4e: the charge volatile
    round_boosted: bool = False  # 041-1f: Round called forward by another Round
    last_successful: str | None = None  # 041-6a: battle.lastSuccessfulMoveThisTurn
    tar_shot: bool = False  # 041-6c: the tarshot volatile (Fire +1 on the first type)
    gravity: bool = False  # 041-6b: the gravity pseudo-weather (Grav Apple)
    wonder_room: bool = False  # 041-6f: `stats` has Def and SpD swapped
    holds_item: bool | None = None  # 041-6f: Acrobatics reads pokemon.item (not ignoringItem)
    stats_lowered: bool = False  # 041-1e: Lash Out
    fainted_last_turn: bool = False  # 041-1e: Retaliate (side.faintedLastTurn)
    damaged_by_target: bool = False  # 041-1e: Avalanche (attackedBy this turn)
    times_attacked: int = 0
    slow_start: bool = False  # 033 (R12): Slow Start's counter is running
    fresh: bool = False  # 043-2a: activeTurns 0 (Stakeout)
    last_to_move: bool = False  # 043-2a: no other active Pokemon will move (Analytic)
    gender: str = ""  # 043-2a: "M" / "F" / "" (Rivalry)
    gem: bool = False  # 042-1: the gem volatile (Normal Gem used this turn)
    # 043-1: the abilities of its allies on the field (not suppressed), Supreme Overlord's
    # effectState.fallen
    ally_abilities: frozenset[str] = frozenset()
    fallen: int = 0


@dataclass(frozen=True, slots=True)
class DamageHandler:
    """One ``runEvent('ModifyDamage')`` handler: its holder's speed and subOrder (side
    conditions 4, abilities 7) and its modifier when it applies to this hit (None otherwise:
    it is still sorted)."""

    speed: int
    sub_order: int
    modifier: tuple[int, int] | None
    crit_only: bool = False  # 043-2a: Sniper (it applies only to a critical hit)


def _by_handler(a: DamageHandler, b: DamageHandler) -> int:
    return (b.speed - a.speed) or (a.sub_order - b.sub_order)


@dataclass(frozen=True, slots=True)
class DamageResult:
    damage: int
    crit: bool
    type_mod: int  # +1 per weakness, -1 per resistance
    immune: bool
    stellar: bool = False  # 017: Stellar boosted this hit (move.stellarBoosted)
    fickle: bool = False  # 041-6b: Fickle Beam's randomChance(3, 10) came up


def trunc(value: float, bits: int = 0) -> int:
    """Showdown ``Dex.trunc``: ``num >>> 0``, optionally modulo ``2 ** bits``."""
    n = int(value) & 0xFFFFFFFF
    return n % (1 << bits) if bits else n


def modify(value: int, numerator: float, denominator: float = 1) -> int:
    """Apply a modifier the way the games do (4096-based, exact halves round down)."""
    modifier = trunc(numerator * 4096 / denominator)
    return trunc((trunc(value * modifier) + 2048 - 1) / 4096)


HELPING_HAND = (3, 2)  # helpinghand onBasePower (priority 10): chainModify(1.5) (009)


def chain_modify(modifier: int, numerator: int, denominator: int = 1) -> int:
    """``Battle.chainModify``: combine a 4096-based modifier with the next one."""
    next_mod = trunc(numerator * 4096 / denominator)
    return (modifier * next_mod + 2048) >> 12


def base_power(
    move: Move,
    *,
    helping_hand: int = 0,
    terrain: str | None = None,
    attacker_types: tuple[str, ...] = (),
    defender_types: tuple[str, ...] = (),
    attacker_ability: str = "",
    defender_ability: str = "",
    attacker_item: str = "",
    defender_item_takeable: bool = False,
    defender_item: str = "",
    callback_power: int | None = None,
    attacker_status: str | None = None,
    attacker_species: str = "",
    weather: str | None = None,
    own_mods: tuple[tuple[int, int], ...] = (),
    smacked: tuple[bool, bool] = (False, False),  # 041-2: Smack Down (attacker, defender)
    rising: tuple[bool, bool] = (False, False),  # 041-6f: Magnet Rise (attacker, defender)
    vanished: bool = False,  # 041-2: the defender is semi-invulnerable (Dig)
    charge: bool = False,  # 041-4e
    gem: bool = False,  # 042-1
    ally_abilities: frozenset[str] = frozenset(),  # 043-1
    fallen: int = 0,
    genders: tuple[str, str] = ("", ""),  # 043-2a: Rivalry (attacker, defender)
    last_to_move: bool = False,  # 043-2a: Analytic
) -> int:
    """The base power after ``basePowerCallback`` and ``runEvent('BasePower')`` (after the
    critical hit roll): the handlers by priority, Technician (30), Sheer Force (21), Sharpness
    (19, 012), Helping Hand (10, 009), the terrain (6) and the move's own (0, 010), chained,
    then applied once."""
    attacker_grounded = is_grounded(
        attacker_types, attacker_ability, attacker_item, smacked[0], rising=rising[0]
    )
    defender_grounded = is_grounded(
        defender_types, defender_ability, defender_item, smacked[1], rising=rising[1]
    )
    if callback_power is not None:
        power = callback_power  # 015: the move's basePowerCallback
    else:
        power = terrain_base_power_callback(terrain, move, defender_grounded=defender_grounded)
    modifiers = base_power_modifiers(
        attacker_ability, move, power, attacker_item, ally_abilities=ally_abilities, fallen=fallen,
        status=attacker_status, weather=weather, genders=genders, last_to_move=last_to_move,
    )  # fmt: skip
    if defender_ability == "dryskin" and move.type == "Fire":
        modifiers.append((5120, 4096))  # 043-4c: Dry Skin's onSourceBasePower (priority 17)
    if (
        type_booster(attacker_item, move)
        or soul_dew(attacker_item, attacker_species, move)
        or legend_orb(attacker_item, attacker_species, move)  # 040-3b
    ):
        modifiers.append(TYPE_BOOSTER_MODIFIER)  # priority 15 (013; Soul Dew, 030)
    if attacker_item in OGERPON_MASKS and attacker_species.startswith(OGERPON_MASKS[attacker_item]):
        modifiers.append(MASK_MODIFIER)  # priority 15 (017)
    if gem:
        modifiers.append((5325, 4096))  # 042-1: the gem volatile's onBasePower (priority 14)
    # 041-6f: chainModify(1.5 ** n) is chainModify(1.5) n times (6144 * 6144 / 4096 = 9216)
    modifiers.extend([HELPING_HAND] * int(helping_hand))
    if charge and move.type == "Electric":
        modifiers.append((2, 1))  # 041-4e: charge's onBasePower (priority 9)
    field_mod = terrain_base_power(
        terrain,
        move,
        attacker_grounded=attacker_grounded,
        # 041-2 review P2: Grassy / Misty's onBasePower: !defender.isSemiInvulnerable()
        defender_grounded=defender_grounded and not vanished,
    )
    if field_mod is not None:
        modifiers.append(field_mod)
    own_mod = move_base_power_modifier(terrain, move, attacker_grounded=attacker_grounded)
    if own_mod is not None:
        modifiers.append(own_mod)
    if move.id == "knockoff" and defender_item_takeable:
        modifiers.append((3, 2))  # Knock Off onBasePower (013)
    if move.id == FACADE and attacker_status not in (None, "slp"):
        modifiers.append((2, 1))  # Facade onBasePower (015)
    modifiers.extend(own_mods)  # 041-1b: Venoshock, Brine
    if move.id in SOLAR_MOVES and effective_weather(weather, attacker_item) in SOLAR_WEAK_WEATHER:
        modifiers.append((1, 2))  # Solar Beam / Solar Blade onBasePower (026 R2)
    if not modifiers:
        return power
    modifier = 4096
    for numerator, denominator in modifiers:
        modifier = chain_modify(modifier, numerator, denominator)
    # I-001 (old bug from 010): no clamp here; a 0 makes getDamage return 0 (``if (!basePower)
    # return 0``), as Misty Terrain's 0.5 on a power of 1
    return modify(power, modifier, 4096)


FACADE = "facade"
# 015: Heavy Slam / Heat Crash: (weight ratio, power), else 40
_WEIGHT_POWERS = ((5, 120), (4, 100), (3, 80), (2, 60))
# 015: overrideOffensiveStat (the attacker's stat used as its attack)
OFFENSIVE_STAT_OVERRIDES: Mapping[str, str] = {"bodypress": "def"}
# 021: overrideDefensiveStat (the defender's stat, its stage and its Modify event)
DEFENSIVE_STAT_OVERRIDES: Mapping[str, str] = {
    "psyshock": "def", "psystrike": "def", "secretsword": "def",  # (041-6a)
}  # fmt: skip
# 015: ignoreDefensive (and ignoreEvasion); 033: Darkest Lariat
IGNORES_DEFENSIVE = frozenset({"sacredsword", "darkestlariat"})
FOUL_PLAY = "foulplay"  # 033 (R4): overrideOffensivePokemon "target"
# 033 (R2): basePowerCallback by the target's HP fraction (Hard Press 100, Crush Grip 120)
_HP_FRACTION_POWERS: Mapping[str, int] = {"hardpress": 100, "crushgrip": 120}
# 021: Grass Knot / Low Kick: (target weight in hg, power), else 20
_TARGET_WEIGHT_POWERS = ((2000, 120), (1000, 100), (500, 80), (250, 60), (100, 40))


def move_base_power(move: Move, attacker: Combatant, defender: Combatant) -> int | None:
    """The move's own ``basePowerCallback`` (015; getDamage, before the critical hit roll and
    ``clampIntRange(basePower, 1)``), or None when it has none of these."""
    if move.id == "furycutter":  # 041-3b: clampIntRange(40 x multiplier, 1, 160)
        return min(160, move.base_power * max(1, attacker.callback_state))
    if move.id == "rollout":  # 041-3b
        return attacker.callback_state or move.base_power
    if move.id == "spitup":  # 041-4d: layers x 100
        return attacker.callback_state
    if move.id in ("stompingtantrum", "temperflare"):  # (041-1a: Temper Flare)
        return move.base_power * 2 if attacker.failed_last_turn else move.base_power
    if move.id in ("heavyslam", "heatcrash"):
        mine, theirs = max(1, attacker.weight_hg), max(1, defender.weight_hg)  # getWeight
        return next((p for k, p in _WEIGHT_POWERS if mine >= theirs * k), 40)
    if move.id in ("grassknot", "lowkick"):  # 021
        weight = max(1, defender.weight_hg)
        return next((p for w, p in _TARGET_WEIGHT_POWERS if weight >= w), 20)
    if move.id == "gyroball":  # 021: getStat('spe') of the target, then of the user
        if not attacker.speed:
            return 1  # not finite
        return min(150, 25 * defender.speed // attacker.speed + 1)
    if move.id in ("eruption", "dragonenergy", "waterspout"):  # 021, 041-1a: the same callback
        if not attacker.max_hp:
            return move.base_power
        return max(1, move.base_power * attacker.hp // attacker.max_hp)
    if move.id in ("infernalparade", "hex"):  # 041-6b, 023 (043-3c: or Comatose)
        statused = defender.status or defender.ability == "comatose"
        return move.base_power * 2 if statused else move.base_power
    if move.id == "assurance":  # 023
        return move.base_power * 2 if defender.hurt_this_turn else move.base_power
    if move.id == "payback":  # 023
        return move.base_power * 2 if defender.acted else move.base_power
    if move.id == "lastrespects":  # 023
        return 50 + 50 * attacker.side_fainted
    if move.id == "ragefist":  # 023
        return min(350, 50 + 50 * attacker.times_attacked)
    if move.id == "echoedvoice":  # 041-1f
        return move.base_power * attacker.echoed_voice
    if move.id == "round":  # 041-1f: move.sourceEffect === 'round'
        return move.base_power * 2 if attacker.round_boosted else move.base_power
    if move.id == "avalanche":  # 041-1e: damaged by the target this turn
        return move.base_power * 2 if attacker.damaged_by_target else move.base_power
    if move.id == "acrobatics":
        held = attacker.item if attacker.holds_item is None else attacker.holds_item
        return move.base_power if held else move.base_power * 2
    if move.id in _HP_FRACTION_POWERS and defender.max_hp:  # 033 (R2)
        percent = 100 * (defender.hp * 4096 // defender.max_hp)
        return (_HP_FRACTION_POWERS[move.id] * percent + 2047) // 4096 // 100 or 1
    if move.id in ("storedpower", "powertrip"):  # 032 (R15), 041-1a: 20 + 20 x positiveBoosts
        return move.base_power + 20 * sum(v for v in (attacker.boosts or {}).values() if v > 0)
    if move.id in ("reversal", "flail") and attacker.max_hp:  # 041-1b
        ratio = max(attacker.hp * 48 // attacker.max_hp, 1)
        return next(p for r, p in _REVERSAL_POWERS if ratio < r)
    if move.id == "electroball":  # 041-1b: floor(spe / target spe), not finite: 0
        ratio = attacker.speed // defender.speed if defender.speed else 0
        return (40, 60, 80, 120, 150)[min(ratio, 4)]
    if move.id == TERA_BLAST and attacker.tera == STELLAR:
        return 100  # 017
    return None


_REVERSAL_POWERS = ((2, 200), (5, 150), (10, 100), (17, 80), (33, 40), (10**9, 20))


def move_on_base_power(
    move: Move, attacker: Combatant, defender: Combatant
) -> tuple[tuple[int, int], ...]:
    """041-1b: the move's own onBasePower (priority 0, chainModify(2)). 041-1e: Lash Out,
    Retaliate."""
    if move.id in ("gust", "twister") and defender.vanished in ("fly", "bounce"):
        return ((2, 1),)  # 041-2: Fly and Bounce's onSourceBasePower
    if move.id == "lashout" and attacker.stats_lowered:
        return ((2, 1),)
    if move.id == "retaliate" and attacker.fainted_last_turn:
        return ((2, 1),)
    if move.id == "venoshock" and defender.status in ("psn", "tox"):
        return ((2, 1),)
    if move.id == "brine" and defender.max_hp and defender.hp * 2 <= defender.max_hp:
        return ((2, 1),)
    if move.id in FUSION_PARTNER and attacker.last_successful == FUSION_PARTNER[move.id]:
        return ((2, 1),)  # 041-6a: Fusion Bolt / Flare after the other
    if move.id in ("collisioncourse", "electrodrift") and type_mod(move, defender) > 0:
        return ((5461, 4096),)  # 041-6b: target.runEffectiveness(move) > 0
    if move.id == "gravapple" and attacker.gravity:
        return ((3, 2),)  # 041-6b
    if move.id == "barbbarrage" and defender.status in ("psn", "tox"):
        return ((2, 1),)  # 041-6b
    return ()


# 017: Terastallization (specs/017-terastal research R3, R4)
STELLAR = "Stellar"
TERA_BLAST = "terablast"
IVY_CUDGEL = "ivycudgel"
_IVY_CUDGEL_TYPES = {
    "Ogerpon-Wellspring": "Water",
    "Ogerpon-Hearthflame": "Fire",
    "Ogerpon-Cornerstone": "Rock",
}
STELLAR_MODIFIER = (4915, 4096)  # a Stellar boost of a type the user does not have


def tera_modify_move(move: Move, attacker: Combatant) -> Move:
    """Tera Blast's onModifyType / onModifyMove (the Tera Type; Physical when Atk > SpA with
    stages but no modifiers) and Ivy Cudgel's onModifyType (the masked formes)."""
    if move.id == TERA_BLAST and attacker.tera is not None:
        boosts = attacker.boosts or {}
        atk = boosted_stat(attacker.stats["atk"], boosts.get("atk", 0))
        spa = boosted_stat(attacker.stats["spa"], boosts.get("spa", 0))
        category = "Physical" if atk > spa else move.category
        return replace(move, type=attacker.tera, category=category)
    if move.id == IVY_CUDGEL:
        forme = attacker.species.removesuffix("-Tera")
        if forme in _IVY_CUDGEL_TYPES:
            return replace(move, type=_IVY_CUDGEL_TYPES[forme])
    return move


def tera_power(power: int, move: Move, attacker: Combatant) -> int:
    """getDamage after BasePower: a terastallized Pokémon's weak moves of its Tera Type (for
    Stellar: of a type not boosted yet) get 60, unless they have priority, hit several times or
    get their power from a callback with a base power of 0 or 150."""
    if attacker.tera is None or power >= 60:
        return power
    if attacker.tera == STELLAR:
        if move.type in attacker.stellar_boosted:
            return power
    elif move.type not in attacker.types:
        return power
    dex_move = get_dex().move(move.id)
    assert dex_move is not None
    if dex_move.priority > 0 or dex_move.multihit:
        return power
    if move.base_power in (0, 150) and move_base_power(move, attacker, attacker) is not None:
        return power  # (Heavy Slam, Eruption; their callbacks do not use the defender here)
    if move.id == "beatup":
        return power  # 033 (R11): basePower 0 with a callback (each hit's power is set apart)
    return 60


def tera_type_mod(move: Move, defender: Combatant) -> int | None:
    """runEffectiveness: a Stellar move is super effective on a terastallized target."""
    if move.type == STELLAR:
        return 1 if defender.tera is not None else 0
    return None


def _stab(attacker: Combatant, move: Move, stellar_move: bool) -> tuple[tuple[int, int], bool]:
    """modifyDamage's STAB: (modifier, whether Stellar boosted this hit). Stellar boosts each
    type once (and every hit of the move that did); ModifySTAB (Adaptability) is skipped."""
    if move.type == "???":
        return (1, 1), False  # typeless (Struggle): no STAB, no Stellar boost
    own = attacker.base_types or attacker.types
    is_stab = move.force_stab or move.type in attacker.types or move.type in own
    stab: tuple[int, int] = (3, 2) if is_stab else (1, 1)
    if attacker.tera == STELLAR:
        if move.type not in attacker.stellar_boosted or stellar_move:
            return ((2, 1) if is_stab else STELLAR_MODIFIER), True
        return stab, False
    if attacker.tera == move.type and move.type in own:
        stab = (2, 1)
    if attacker.ability == "adaptability" and move.type in attacker.types:
        stab = (9, 4) if stab == (2, 1) else (2, 1)  # onModifySTAB (012)
    return stab, False


def _chained(value: int, modifiers: list[tuple[int, int]]) -> int:
    """``runEvent`` with ``chainModify`` handlers: combine them, then modify once."""
    if not modifiers:
        return value
    modifier = 4096
    for numerator, denominator in modifiers:
        modifier = chain_modify(modifier, numerator, denominator)
    return modify(value, modifier, 4096)


def type_immune(move: Move, attacker: Combatant, defender: Combatant) -> bool:
    """``runImmunity`` of the move's type: Scrappy's (011) and Mind's Eye's (012) Normal and
    Fighting moves hit Ghosts; a Ground move hits only a grounded target (``isGrounded``:
    Levitate 011, Iron Ball and Air Balloon 032)."""
    if defender.item == "ringtarget":
        # 040-4b: Ring Target's onNegateImmunity false: no type immunity; a Ground move uses
        # isGrounded(negateImmunity): its Flying type does not count (Levitate still does)
        if move.type != "Ground":
            return False
        types = tuple(t for t in defender.types if t != "Flying")
        return not is_grounded(
            types, defender.ability, defender.item, defender.smacked_down, rising=defender.rising
        )
    if move.type == "Ground":
        return not is_grounded(
            defender.types,
            defender.ability,
            defender.item,
            defender.smacked_down,
            rising=defender.rising,
        )
    types = defender.types
    if ignores_ghost_immunity(attacker.ability) and move.type in ("Normal", "Fighting"):
        types = tuple(t for t in types if t != "Ghost")
    return get_dex().is_immune(move.type, types)


def _base_damage(
    attacker: Combatant,
    defender: Combatant,
    move: Move,
    crit: bool,
    weather: str | None,
    power: int | None = None,
    ruin: frozenset[str] = frozenset(),
    terrain: str | None = None,
) -> int:
    physical = move.category == "Physical"
    attack_stat, defense_stat = ("atk", "def") if physical else ("spa", "spd")
    defense_stat = DEFENSIVE_STAT_OVERRIDES.get(move.id, defense_stat)  # Psyshock (021)
    # Body Press (015): the stat and its stage come from Defense, but getDamage then runs
    # 'ModifyAtk' (the attack modifiers below), not 'ModifyDef'
    stat_used = OFFENSIVE_STAT_OVERRIDES.get(move.id, attack_stat)
    if attacker.wonder_room and stat_used in ("def", "spd") and stat_used != attack_stat:
        stat_used = "spd" if stat_used == "def" else "def"  # 041-6f: Wonder Room's onModifyMove
    # Foul Play (033 R4): the target's stat and stage (calculateStat on the target; its
    # ModifyBoost is the user's, so Unaware works as usual), then the user's ModifyAtk
    offense = defender if move.id == FOUL_PLAY else attacker
    atk_stage = (offense.boosts or {}).get(stat_used, 0)
    def_stage = (defender.boosts or {}).get(defense_stat, 0)
    if move.id in IGNORES_DEFENSIVE:
        def_stage = 0  # ignoreDefensive (015)
    if crit:  # a critical hit ignores the attacker's drops and the defender's raises
        atk_stage, def_stage = max(atk_stage, 0), min(def_stage, 0)
    # ModifyBoost (012): Unaware ignores the other side's stages
    def_ignored = defender.stages_ignored
    atk_ignored = attacker.stages_ignored
    if def_ignored if def_ignored is not None else attacker.ability == "unaware":
        def_stage = 0
    if atk_ignored if atk_ignored is not None else defender.ability == "unaware":
        atk_stage = 0
    attack = boosted_stat(offense.stats[stat_used], atk_stage)
    if attacker.ability == "hustle" and attack_stat == "atk":
        attack = modify(attack, 3, 2)  # 043-2a: Hustle returns this.modify(atk, 1.5) (not chained)
    defense = boosted_stat(defender.stats[defense_stat], def_stage)
    # runEvent('ModifyAtk'/'ModifySpA'): priority 5, the volatiles (Protosynthesis/Quark Drive,
    # Flash Fire) then the abilities (Guts, Dragon's Maw, Transistor, 012); then Ruin (0).
    attack_mods = []
    halved = move.type in HALVING_ABILITIES.get(defender.ability, ())
    if halved and attack_stat == "atk":
        attack_mods.append((1, 2))  # 032: Thick Fat / Heatproof / Purifying Salt (Atk: 6)
    if attacker.booster == attack_stat:
        attack_mods.append(BOOSTER_MODIFIER)
    if attacker.flash_fire and move.type == "Fire":
        attack_mods.append((3, 2))
    own = attack_modifier(
        attacker.ability, move, statused=attacker.statused, hp=attacker.hp,
        max_hp=attacker.max_hp, weather=effective_weather(weather, attacker.item),
        terrain=terrain, ally_abilities=attacker.ally_abilities, target_fresh=defender.fresh,
    )  # fmt: skip
    if own is not None:
        attack_mods.append(own)
    if attacker.slow_start and attack_stat == "atk":
        attack_mods.append((1, 2))  # 033 (R12): Slow Start onModifyAtk (priority 5)
    if defender.ability == WATER_BUBBLE and move.type == "Fire":
        attack_mods.append((1, 2))  # 030: Water Bubble onSourceModifyAtk/SpA (priority 5)
    if halved and attack_stat == "spa":
        attack_mods.append((1, 2))  # 032: (SpA: 5)
    if CHOICE_STAT.get(attacker.item) == attack_stat:
        attack_mods.append((3, 2))  # Choice Band / Specs (priority 1, 013)
    if attacker.item == "lightball" and attacker.pikachu:
        attack_mods.append((2, 1))  # 042-1: Light Ball onModifyAtk/SpA (priority 1)
    if attacker.ability == WATER_BUBBLE and move.type == "Water":
        attack_mods.append((2, 1))  # 030: Water Bubble onModifyAtk/SpA (priority 0)
    if ruin_modifier(attack_stat, ruin, attacker.ability):
        attack_mods.append(RUIN_MODIFIER)
    attack = _chained(attack, attack_mods)
    if boosts_defense(weather, defender.types, defense_stat):
        # snowscape onModifyDef / sandstorm onModifySpD (priority 10) return this.modify(x, 1.5):
        # applied at once, before the chained modifiers (025; chained since 007)
        defense = modify(defense, 3, 2)
    defense = _chained(defense, _defense_mods(defender, defense_stat, ruin, terrain))
    level_factor = trunc(2 * attacker.level / 5 + 2)
    if power is None:
        power = move.base_power
    return trunc(trunc(trunc(level_factor * power * attack) / defense) / 50)


def _defense_mods(
    holder: Combatant, stat: str, ruin: frozenset[str], terrain: str | None = None
) -> list[tuple[int, int]]:
    """runEvent('ModifyDef'/'ModifySpD'), crits included, chained: Protosynthesis/Quark
    Drive (6), Eviolite (2), Assault Vest (1, 013), Ruin (0). (The weather, priority 10,
    modifies the stat at once before these; see ``_base_damage``.)"""
    mods = []
    if holder.booster == stat:
        mods.append(BOOSTER_MODIFIER)
    if stat == "def":  # 043-2b: onModifyDef (6): Fur Coat x2, Marvel Scale, Grass Pelt x1.5
        if holder.ability == "furcoat":
            mods.append((2, 1))
        elif (holder.ability == "marvelscale" and holder.statused) or (
            holder.ability == "grasspelt" and terrain == "grassyterrain"
        ):
            mods.append((3, 2))
    if holder.item == EVIOLITE and holder.nfe:
        mods.append((3, 2))
    if holder.item == ASSAULT_VEST and stat == "spd":
        mods.append((3, 2))
    if ruin_modifier(stat, ruin, holder.ability):
        mods.append(RUIN_MODIFIER)
    return mods


def _modify(
    base: int,
    attacker: Combatant,
    move: Move,
    type_mod: int,
    *,
    crit: bool,
    spread: bool,
    roll: int,
    weather: str | None,
    final_mods: Sequence[tuple[int, int]] = (),
    stellar_move: bool = False,
    defender_item: str = "",
) -> int:
    """``modifyDamage`` for one random roll (``roll`` = Showdown's ``random(16)``, 0 is max).
    ``final_mods``: the ModifyDamage modifiers in handler order (screens, Multiscale, Friend
    Guard)."""
    damage = base + 2
    if spread:
        damage = modify(damage, _SPREAD_MODIFIER)
    # 040-3c: the defender's effective weather (Hydro Steam: the attacker's sun first)
    own = effective_weather(weather, attacker.item)
    weather_mod = damage_modifier(effective_weather(weather, defender_item), move, own)
    if weather_mod != 1.0:
        damage = modify(damage, weather_mod)
    if crit:
        damage = trunc(damage * 1.5)
    damage = trunc(trunc(damage * (100 - roll)) / 100)
    stab, _ = _stab(attacker, move, stellar_move)  # 017: Terastallization; Adaptability (012)
    if stab != (1, 1):
        damage = modify(damage, *stab)
    if type_mod > 0:
        damage *= 2**type_mod
    for _ in range(-type_mod):
        damage = trunc(damage / 2)
    if (
        attacker.burned
        and move.category == "Physical"
        and attacker.ability != "guts"
        and move.id != FACADE  # gen 6+ (015)
    ):
        damage = modify(damage, 0.5)
    if final_mods:  # ModifyDamage: screens (008), Multiscale, Friend Guard (012)
        damage = _chained(damage, list(final_mods))
    # (other final modifiers such as Life Orb: 012)
    if not damage:
        return 1
    return trunc(damage, 16)


def damage_rolls(
    attacker: Combatant,
    defender: Combatant,
    move: Move,
    *,
    crit: bool = False,
    spread: bool = False,
    weather: str | None = None,
    screens: frozenset[str] = frozenset(),
    helping_hand: int = 0,
    terrain: str | None = None,
    ruin: frozenset[str] = frozenset(),
    friend_guard: bool = False,
) -> list[int]:
    """The 16 possible damage values, lowest first. Empty when the defender is immune.
    ``screens``: the screens on the defender's side; ``ruin``: the Ruin abilities on the field;
    ``friend_guard``: the defender's ally has Friend Guard."""
    move = tera_modify_move(move, attacker)  # 017 (the battle does it at ModifyType)
    if type_immune(move, attacker, defender):
        return []
    crit = crit and defender.ability not in CRIT_BLOCKERS and not defender.disguised  # (027)
    type_mod = _type_mod(move, defender)
    power = base_power(
        move, helping_hand=helping_hand, terrain=terrain, attacker_types=attacker.types,
        defender_types=defender.types, attacker_ability=attacker.ability,
        defender_ability=defender.ability, attacker_item=attacker.item,
        defender_item_takeable=defender.item_takeable, defender_item=defender.item,
        smacked=(attacker.smacked_down, defender.smacked_down),
        rising=(attacker.rising, defender.rising),
        vanished=bool(defender.vanished),
        charge=attacker.charge, gem=attacker.gem,
        ally_abilities=attacker.ally_abilities, fallen=attacker.fallen,
        genders=(attacker.gender, defender.gender), last_to_move=attacker.last_to_move,
        callback_power=move_base_power(move, attacker, defender), attacker_status=attacker.status,
        attacker_species=attacker.species, weather=weather,
        own_mods=move_on_base_power(move, attacker, defender),
    )  # fmt: skip
    if not power:
        return [0] * 16  # getDamage: ``if (!basePower) return 0`` (I-001)
    power = tera_power(power, move, attacker)
    base = _base_damage(attacker, defender, move, crit, weather, power, ruin, terrain)
    pokemon_handlers = []  # in the battle's collection order (Battle._damage_handlers)
    if attacker.item == LIFE_ORB:
        pokemon_handlers.append(DamageHandler(1, 8, LIFE_ORB_MODIFIER))  # 013
    if friend_guard:
        pokemon_handlers.append(DamageHandler(1, 7, FRIEND_GUARD_MODIFIER))
    if defender.ability == "multiscale" and defender.full_hp:
        pokemon_handlers.append(DamageHandler(1, 7, MULTISCALE_MODIFIER))
    if resist_berry(defender.item, move.type, type_mod):
        pokemon_handlers.append(DamageHandler(1, 8, RESIST_BERRY_MODIFIER))  # 013
    handlers = _damage_handlers(
        defender, move, crit, screens, 1 if screens else 0, pokemon_handlers,
        infiltrates=attacker.ability == "infiltrator",
    )  # fmt: skip
    final_mods = [
        h.modifier for h in handlers if h.modifier is not None and (crit or not h.crit_only)
    ]
    if defender.ability == "ripen" and resist_berry(defender.item, move.type, type_mod):
        final_mods.append((1, 2))  # 043-4h: Ripen's berryWeaken (priority -1: last)
    return [
        _modify(
            base,
            attacker,
            move,
            type_mod,
            crit=crit,
            spread=spread,
            roll=roll,
            weather=weather,
            final_mods=final_mods,
            defender_item=defender.item,
        )
        for roll in range(15, -1, -1)
    ]


FRIEND_GUARD_MODIFIER = (3, 4)
MULTISCALE_MODIFIER = (1, 2)


def _damage_handlers(
    defender: Combatant,
    move: Move,
    crit: bool,
    screens: frozenset[str],
    screens_on_field: int,
    abilities: Sequence[DamageHandler] | None = None,
    *,
    infiltrates: bool = False,
) -> list[DamageHandler]:
    """The ModifyDamage handlers before sorting: ``abilities`` (Friend Guard, Multiscale, given
    by the battle with their holders' speeds; otherwise the defender's Multiscale), then every
    screen on the field (speed 0, subOrder 4; the defender side's one applies)."""
    handlers = list(abilities or ())
    if abilities is None and defender.ability == "multiscale" and defender.full_hp:
        handlers.append(DamageHandler(1, 7, MULTISCALE_MODIFIER))
    # (043-1: Infiltrator's move.infiltrates: the screens are sorted but do not apply)
    screen_mod = SCREEN_MODIFIER if reduces(screens, move, crit) and not infiltrates else None
    for i in range(screens_on_field):
        handlers.append(DamageHandler(0, 4, screen_mod if i == 0 else None))
    return handlers


def calc_damage(
    attacker: Combatant,
    defender: Combatant,
    move: Move,
    *,
    spread: bool,
    prng: Prng,
    weather: str | None = None,
    screens: frozenset[str] = frozenset(),
    screens_on_field: int = 0,
    helping_hand: int = 0,
    terrain: str | None = None,
    ruin: frozenset[str] = frozenset(),
    damage_handlers: Sequence[DamageHandler] | None = None,
    stellar_move: bool = False,
    ruin_speeds: Mapping[str, Sequence[int]] | None = None,
    modify_boost: Callable[[], None] | None = None,
    modify_spe: tuple[Callable[[], None], Callable[[], None]] | None = None,  # 041-5
    attack_handlers: Sequence[tuple[int, int]] = (),
) -> DamageResult:
    """Damage for one hit in battle, drawing the critical hit and the random roll from ``prng``.

    Draw order follows Showdown: immunity (no draw), critical hit, the random factor, then the
    shuffle of the ModifyDamage handlers that tie (008: screens; 012: Friend Guard and
    Multiscale with the same speed). ``screens``: the screens on the defender's side;
    ``screens_on_field``: on both sides; ``damage_handlers``: the ability handlers (None:
    the defender's own Multiscale); ``stellar_move``: Stellar already boosted this move (017);
    ``ruin_speeds``: the speeds of each Ruin ability's holders on the field (018: holders of the
    same ability with the same speed tie in ModifyAtk/Def/SpA/SpD and are shuffled).
    ``modify_boost``: runs ``runEvent('ModifyBoost')``'s draws (028: two Unaware at the same
    speed), once per getStat / calculateStat. ``attack_handlers``: (priority, holder speed) of
    the other abilities' ModifyAtk/SpA handlers in this hit's event (030: the user's own, the
    target's onSource ones; they tie with each other and with Ruin's).
    """
    if type_immune(move, attacker, defender):
        return DamageResult(damage=0, crit=False, type_mod=0, immune=True)
    if modify_boost is not None and move.id in ("gyroball", "electroball"):
        # basePowerCallback's getStat('spe'): Gyro Ball the target's, then the user's;
        # Electro Ball the user's first (041-5: each ModifyBoost, then ModifySpe)
        first, second = (1, 0) if move.id == "electroball" else (0, 1)
        modify_boost()
        if modify_spe is not None:
            modify_spe[first]()
        modify_boost()
        if modify_spe is not None:
            modify_spe[second]()
    if move.will_crit:
        crit = True  # willCrit: no roll
    else:
        ratio = min(move.crit_ratio, 4)
        crit = bool(ratio) and prng.random_chance(1, _CRIT_MULT[ratio])
    if crit and (defender.ability in CRIT_BLOCKERS or defender.disguised):  # (043-2b, 043-6e)
        crit = False  # 027: runEvent('CriticalHit'): Shell Armor's onCriticalHit false
    type_mod = _type_mod(move, defender)
    # 041-6b: Fickle Beam's onBasePower draws (after the crit roll, in the BasePower event)
    fickle = move.id == "ficklebeam" and prng.random_chance(3, 10)
    power = base_power(
        move, helping_hand=helping_hand, terrain=terrain, attacker_types=attacker.types,
        defender_types=defender.types, attacker_ability=attacker.ability,
        defender_ability=defender.ability, attacker_item=attacker.item,
        defender_item_takeable=defender.item_takeable, defender_item=defender.item,
        smacked=(attacker.smacked_down, defender.smacked_down),
        rising=(attacker.rising, defender.rising),
        vanished=bool(defender.vanished),
        charge=attacker.charge, gem=attacker.gem,
        ally_abilities=attacker.ally_abilities, fallen=attacker.fallen,
        genders=(attacker.gender, defender.gender), last_to_move=attacker.last_to_move,
        callback_power=move_base_power(move, attacker, defender), attacker_status=attacker.status,
        attacker_species=attacker.species, weather=weather,
        own_mods=move_on_base_power(move, attacker, defender) + (((2, 1),) if fickle else ()),
    )  # fmt: skip  # after the crit roll (009, 010)
    if not power:  # getDamage: ``if (!basePower) return 0``: no random factor (I-001)
        return DamageResult(damage=0, crit=crit, type_mod=type_mod, immune=False, fickle=fickle)
    power = tera_power(power, move, attacker)  # 017
    base = _base_damage(attacker, defender, move, crit, weather, power, ruin, terrain)
    if modify_boost is not None:
        modify_boost()  # calculateStat: the attack, then the defense (before ModifyAtk/Def)
        modify_boost()
    _shuffle_ruin_ties(move, ruin_speeds or {}, prng, attack_handlers)
    roll = prng.random_int(16)
    handlers = _damage_handlers(
        defender, move, crit, screens, screens_on_field, damage_handlers,
        infiltrates=attacker.ability == "infiltrator",  # 043-1
    )  # fmt: skip
    speed_sort(handlers, prng, _by_handler)
    final_mods = [
        h.modifier for h in handlers if h.modifier is not None and (crit or not h.crit_only)
    ]
    damage = _modify(
        base, attacker, move, type_mod, crit=crit, spread=spread, roll=roll, weather=weather,
        final_mods=final_mods,
        stellar_move=stellar_move, defender_item=defender.item,
    )  # fmt: skip
    _, stellar = _stab(attacker, move, stellar_move)
    return DamageResult(damage=damage, crit=crit, type_mod=type_mod, immune=False,
                        stellar=stellar, fickle=fickle)  # fmt: skip


def _shuffle_ruin_ties(
    move: Move,
    ruin_speeds: Mapping[str, Sequence[int]],
    prng: Prng,
    attack_handlers: Sequence[tuple[int, int]] = (),
) -> None:
    """018: ``runEvent('ModifyAtk')`` then ``('ModifyDef')`` (SpA / SpD for special moves) sort
    their handlers. The Ruin abilities' ``onAny`` handlers (priority 0) of holders with the same
    speed tie, and Showdown shuffles them; the result is the same either way (one Ruin applies
    once, never to its own holders), but the shuffle draws. 030: the attack event's other
    ability handlers (``attack_handlers``, (priority, speed)) are sorted with them."""
    physical = move.category == "Physical"
    attack_stat, defense_stat = ("atk", "def") if physical else ("spa", "spd")
    defense_stat = DEFENSIVE_STAT_OVERRIDES.get(move.id, defense_stat)  # Psyshock (021)
    for stat in (attack_stat, defense_stat):
        handlers = [(0, s) for ruin, holders in sorted(ruin_speeds.items())
                    if RUIN.get(ruin) == stat for s in holders]  # fmt: skip
        if stat == attack_stat:
            handlers.extend(attack_handlers)
        if len(handlers) > 1:
            speed_sort(handlers, prng, lambda a, b: (b[0] - a[0]) or (b[1] - a[1]))


FREEZE_DRY = "freezedry"
FLYING_PRESS = "flyingpress"  # 041-6a
FUSION_PARTNER = {"fusionbolt": "fusionflare", "fusionflare": "fusionbolt"}  # 041-6a


def type_mod(move: Move, defender: Combatant) -> int:
    """``runEffectiveness``: the sum over the defender's types (017: Stellar on a terastallized
    target). 021: Freeze-Dry's onEffectiveness makes its Water part super effective."""
    if defender.shell:
        return -1  # 042-6: Tera Shell (runEffectiveness)
    if defender.disguised:
        return 0  # 043-6e: Disguise / Ice Face's onEffectiveness
    tera = tera_type_mod(move, defender)
    if tera is not None:
        return tera
    if move.type == "Ground" and defender.item == "ironball" and "Flying" in defender.types:
        # 032 (R3): Iron Ball's onEffectiveness checks target.hasType('Flying'), not the type
        # it is given, so every type's part is 0 (neutral even on Corviknight's Steel)
        return 0
    dex = get_dex()
    return (
        sum(
            1 if move.id == FREEZE_DRY and t == "Water" else dex.type_mod(move.type, (t,))
            for t in defender.types
        )
        + (  # 041-6a: Flying Press's onEffectiveness, per type
            sum(dex.type_mod("Flying", (t,)) for t in defender.types)
            if move.id == FLYING_PRESS
            else 0
        )
        + (1 if defender.tar_shot and move.type == "Fire" else 0)
    )  # 041-6c


_type_mod = type_mod
