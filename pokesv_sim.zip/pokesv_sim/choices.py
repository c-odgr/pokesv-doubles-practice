"""Choices a player can make, and the lists of legal choices.

Target locations follow Showdown: ``1``/``2`` are the foe's left/right positions and ``-1``/``-2``
the user's own side. Spread moves take no target.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, replace

from pokesv_sim.dex import Move
from pokesv_sim.items import ASSAULT_VEST
from pokesv_sim.state import (
    ACTIVE_PER_SIDE,
    PREVIEW_PICK,
    BattlePokemon,
    BattleState,
    SideState,
    foe_of,
)

SINGLE_TARGETS = frozenset({"normal", "any", "adjacentFoe"})
ALLY_OR_SELF = "adjacentAllyOrSelf"  # 041-6f
ALLY_TARGETS = frozenset({"adjacentAlly"})  # 009: Helping Hand, Coaching (never a draw)
# Showdown getRandomTarget returns the user for these (no random draw): the move affects the
# user, the whole field (Trick Room) or the user's side (Tailwind).
USER_TARGETS = frozenset({"self", "all", "allySide", "allyTeam"})  # (allyTeam: 041-3f)
STRUGGLE = -1  # MoveChoice.move_index for Struggle (offered only when no move has PP left)
RECHARGE = -2  # 030: MoveChoice.move_index for Recharge (the turn after Giga Impact)
# 041-5: MoveChoice.move_index for a locked move the Pokemon does not know (Copycat called a
# two-turn or rampage move: getLockedMove gives its id, runMove uses it with no PP)
LOCKED_EXTERNAL = -3
MUST_RECHARGE = "mustrecharge"  # 030: the volatile (duration 2)


@dataclass(frozen=True, slots=True)
class MoveChoice:
    move_index: int  # index into the Pokémon's moves
    target: int | None = None  # target location, None for spread moves
    terastallize: bool = False  # 017: terastallize before moving (once per battle and side)


@dataclass(frozen=True, slots=True)
class SwitchChoice:
    team_index: int  # index into the side's full team


@dataclass(frozen=True, slots=True)
class PassChoice:
    """No action for this position (empty or fainted, nothing to switch in)."""


type Choice = MoveChoice | SwitchChoice | PassChoice


@dataclass(frozen=True, slots=True)
class Preview:
    """Team indices brought to battle, leads first (at most four)."""

    order: tuple[int, ...]


def preview_options(side: SideState) -> int:
    """How many Pokémon must be brought."""
    return min(PREVIEW_PICK, len(side.team))


def is_legal_preview(side: SideState, preview: Preview) -> bool:
    order = preview.order
    return (
        len(order) == preview_options(side)
        and len(set(order)) == len(order)
        and all(0 <= i < len(side.team) for i in order)
    )


def request_target(pokemon: BattlePokemon, move: Move) -> str:
    """The request's target (Pokemon.getMoves): Curse's ``nonGhostTarget`` (self) for a user
    that is not a Ghost type (032 R15)."""
    if move.id == "curse" and "Ghost" not in pokemon.types:
        return "self"
    if move.id == "terastarstorm" and pokemon.species.name == "Terapagos-Stellar":
        return "allAdjacentFoes"  # 042-6
    return move.target


def move_targets(target_type: str, position: int) -> list[int | None]:
    """Target locations a move can be aimed at from ``position`` (doubles, all adjacent)."""
    ally = -(1 - position) - 1  # the other own position
    if target_type in SINGLE_TARGETS:
        return [1, 2, ally]
    if target_type in ALLY_TARGETS:
        return [ally]
    if target_type == ALLY_OR_SELF:  # 041-6f: Acupressure (the user's own location too)
        return [-position - 1, ally]
    return [None]


TWO_TURN = "twoturnmove"  # 020
LOCKED_MOVE = "lockedmove"  # 022: Outrage
UPROAR = "uproar"  # 033 (R13): the move's volatile (duration 3, onLockMove)
ROLLOUT = "rollout"  # 041-3b: the move's volatile (duration 1 or 2, onLockMove)
THROAT_CHOP = "throatchop"  # 021: the volatile (duration 2)
HEAL_BLOCK = "healblock"  # 023: the volatile (duration 2 from Psychic Noise)
DISABLE = "disable"  # 023: the volatile (duration 5)


def locked_slot(pokemon: BattlePokemon) -> int | None:
    """020: ``getLockedMove`` (twoturnmove's onLockMove; 022: lockedmove's): the slot of the
    move the Pokémon must use (its request: that move only, no target, trapped, no
    Terastallization). 030: mustrecharge's onLockMove gives Recharge (``RECHARGE``)."""
    if MUST_RECHARGE in pokemon.timed:
        return RECHARGE
    if TWO_TURN in pokemon.timed:
        locked = pokemon.two_turn_move
    elif LOCKED_MOVE in pokemon.timed:
        locked = pokemon.locked_move
    elif UPROAR in pokemon.timed:
        locked = UPROAR  # 033 (R13): uproar's onLockMove
    elif ROLLOUT in pokemon.timed:
        locked = ROLLOUT  # 041-3b: rollout's onLockMove
    else:
        return None
    return next((i for i, s in enumerate(pokemon.moves) if s.move.id == locked), LOCKED_EXTERNAL)


def locked_move_id(pokemon: BattlePokemon) -> str | None:
    """041-5: the id ``getLockedMove`` gives (None for Recharge or no lock)."""
    if MUST_RECHARGE in pokemon.timed:
        return None
    if TWO_TURN in pokemon.timed:
        return pokemon.two_turn_move
    if LOCKED_MOVE in pokemon.timed:
        return pokemon.locked_move
    if UPROAR in pokemon.timed:
        return UPROAR
    if ROLLOUT in pokemon.timed:
        return ROLLOUT
    return None


def hidden_disabled(state: BattleState, pokemon: BattlePokemon) -> frozenset[str]:
    """022: the moves disabled but hidden (``disableMove(id, true)``): Imprison's
    onFoeDisableMove disables every move an active foe with the imprison volatile knows
    (``foes()``: those with HP left)."""
    foe = state.sides[foe_of(pokemon.side)]
    return frozenset(
        s.move.id
        for p in foe.active
        if p is not None and p.hp > 0 and p.imprison
        for s in p.moves
        if s.move.id != "struggle"
    )


def _is_last_active(side: SideState, position: int) -> bool:
    """``isLastActive``: no unfainted Pokémon in a later position of the side."""
    return all(p is None or p.fainted for p in side.active[position + 1 :])


def legal_move_choices(
    state: BattleState, side_id: str, *, strict: bool = False
) -> list[list[MoveChoice | SwitchChoice]]:
    """Per active position: every legal move (with target) and switch. Empty for no action.

    022: a move disabled but hidden (Imprison) is shown as usable to the last Pokémon of the
    side to choose (Showdown ``getMoves(lockedMove, restrictData)``), and refused when chosen
    (``chooseMove``): ``strict`` leaves those moves out, as the updated request does."""
    side = state.sides[side_id]
    result: list[list[MoveChoice | SwitchChoice]] = []
    for pos in range(ACTIVE_PER_SIDE):
        pokemon = side.active[pos]
        if pokemon is None or pokemon.fainted or pokemon.commanding:
            result.append([])  # 028: a commanding Tatsugiri passes (Side.choosePass)
            continue
        options: list[MoveChoice | SwitchChoice] = []
        locked = locked_slot(pokemon)
        if locked is not None:
            result.append([MoveChoice(locked, None)])  # (aimed where it was charged)
            continue
        hidden = hidden_disabled(state, pokemon)
        if hidden and not strict and _is_last_active(side, pos):
            hidden = frozenset()
        for i, slot in enumerate(pokemon.moves):
            if slot.pp <= 0 or _disabled(pokemon, slot.move) or slot.move.id in hidden:
                continue
            for target in move_targets(request_target(pokemon, slot.move), pos):
                options.append(MoveChoice(i, target))
        if not options:
            options.append(MoveChoice(STRUGGLE, None))  # Struggle picks its target at random
        # 024: the request's trapped (partiallytrapped). 043-5b: a 'hidden' trap (a foe's
        # ability) on the last Pokemon to choose is maybeTrapped: switching is offered and
        # refused when chosen (``strict`` leaves it out, as the updated request does)
        offered = pokemon.trap_hidden and not strict and _is_last_active(side, pos)
        if not pokemon.trapped or offered:
            options.extend(SwitchChoice(p.team_index) for p in side.bench())
        result.append(options)
    return result


def _disabled(pokemon: BattlePokemon, move: Move) -> bool:
    """``DisableMove`` (013): a Choice item locks the first move it used (choicelock), Assault
    Vest and Taunt (015) disable status moves, Throat Chop (021) sound moves, and a
    cantusetwice move (022, Blood Moon) is disabled right after its use. Struggle is
    offered when nothing is left."""
    move_id, category = move.id, move.category
    if "cantusetwice" in move.flags and pokemon.last_move == move_id:
        return True  # 022: Blood Moon (nextTurn disables it after the DisableMove event)
    if THROAT_CHOP in pokemon.timed and "sound" in move.flags:
        return True  # 021: throatchop onDisableMove
    if HEAL_BLOCK in pokemon.timed and "heal" in move.flags:
        return True  # 023: healblock onDisableMove
    if DISABLE in pokemon.timed and move.id == pokemon.disabled_move:
        return True  # 023: disable onDisableMove
    if pokemon.gravity and "gravity" in move.flags:
        return True  # 041-4e: Gravity's onDisableMove
    if move_id == "belch" and not pokemon.ate_berry:
        return True  # 041-4e: Belch's onDisableMove
    if move_id == "stuffcheeks" and not _holds_berry(pokemon):
        return True  # 041-6f: Stuff Cheeks' onDisableMove
    if pokemon.torment and move_id == pokemon.last_move and move_id != "struggle":
        return True  # 041-3g: torment onDisableMove
    # (041-6f: choicelock's onDisableMove does nothing while ignoringItem)
    if pokemon.choice_lock is not None and pokemon.item and move_id != pokemon.choice_lock:
        return True
    if "taunt" in pokemon.timed and category == "Status" and move_id != "mefirst":
        return True  # 015: taunt onDisableMove
    encore = pokemon.encore_move
    if "encore" in pokemon.timed and encore is not None and move_id != encore:
        # encore onDisableMove (only while the Pokémon has the move)
        return any(s.move.id == encore for s in pokemon.moves)
    return pokemon.item == ASSAULT_VEST and category == "Status" and move_id != "mefirst"


REVIVAL_BLESSING = "revivalblessing"  # 041-6f: the move and its slot condition


def reviving(state: BattleState, pokemon: BattlePokemon | None) -> bool:
    """041-6f: the position has the revivalblessing slot condition (pokemon.reviving)."""
    return (
        pokemon is not None
        and pokemon.position is not None
        and REVIVAL_BLESSING in state.field.slot_conditions[pokemon.side][pokemon.position]
    )


def revivable(state: BattleState, side_id: str) -> list[BattlePokemon]:
    """041-6f: the side's fainted Pokémon, in side.pokemon order."""
    side = state.sides[side_id]
    return [p for p in (side.order or side.brought) if p.fainted]


def needs_replacement(state: BattleState, side_id: str) -> list[bool]:
    """Per position: whether a Pokémon must be chosen to switch in. Showdown's
    ``forceSwitch``: the switch flags (014: U-turn, Eject Pack) and, at the end of the turn,
    the empty or fainted positions."""
    side = state.sides[side_id]
    available = len(side.bench())
    flags = []
    for pos in range(ACTIVE_PER_SIDE):
        pokemon = side.active[pos]
        empty = (pokemon is None or pokemon.fainted) and not state.flag_request
        flagged = pokemon is not None and not pokemon.fainted and bool(pokemon.switch_flag)
        if flagged and reviving(state, pokemon):
            flags.append(bool(revivable(state, side_id)))  # 041-6f: a fainted one to pick
            continue
        flags.append((empty or flagged) and available > 0)
    return flags


def is_legal_turn(state: BattleState, side_id: str, choices: Sequence[Choice]) -> bool:
    """A full set of choices for one turn: one per position, no Pokémon switched in twice."""
    legal = legal_move_choices(state, side_id, strict=True)  # 022: hidden moves are refused
    if len(choices) != ACTIVE_PER_SIDE:
        return False
    switching = [c.team_index for c in choices if isinstance(c, SwitchChoice)]
    if len(switching) != len(set(switching)):
        return False
    # Struggle's flag is dropped (Showdown chooseMove returns before the terastallize checks)
    tera = [
        c
        for c in choices
        if isinstance(c, MoveChoice) and c.terastallize and c.move_index != STRUGGLE
    ]
    if tera and (len(tera) > 1 or not state.sides[side_id].can_terastallize()):
        return False  # 017: "You can only Terastallize once per battle."
    active = state.sides[side_id].active
    for pokemon, options, choice in zip(active, legal, choices, strict=True):
        if not options:
            if not isinstance(choice, PassChoice):
                return False
        elif isinstance(choice, MoveChoice) and choice.terastallize:
            if replace(choice, terastallize=False) not in options:
                return False
            if pokemon is not None and locked_slot(pokemon) is not None:
                return False  # 020: a locked move's request has no canTerastallize
        elif choice not in options:
            return False
    return True


def is_legal_replacement(
    state: BattleState, side_id: str, choices: Sequence[SwitchChoice | PassChoice]
) -> bool:
    side = state.sides[side_id]
    need = needs_replacement(state, side_id)
    if len(choices) != ACTIVE_PER_SIDE:
        return False
    bench = {p.team_index for p in side.bench()}
    fainted = {p.team_index for p in revivable(state, side_id)}
    revives = [p is not None and bool(p.switch_flag) and reviving(state, p) for p in side.active]
    chosen = [c.team_index for c in choices if isinstance(c, SwitchChoice)]
    if len(chosen) != len(set(chosen)):
        return False
    for must, revive, choice in zip(need, revives, choices, strict=True):
        if not must and isinstance(choice, SwitchChoice):
            return False
        if revive and must:  # 041-6f: Revival Blessing picks a fainted one
            if not isinstance(choice, SwitchChoice) or choice.team_index not in fainted:
                return False
        elif isinstance(choice, SwitchChoice) and choice.team_index not in bench:
            return False
    need = [m and not r for m, r in zip(need, revives, strict=True)]
    chosen = [
        c.team_index
        for c, r in zip(choices, revives, strict=True)
        if isinstance(c, SwitchChoice) and not r
    ]
    # Every position that needs a replacement gets one while Pokémon remain on the bench.
    return len(chosen) == min(sum(need), len(bench))


def _holds_berry(pokemon: BattlePokemon) -> bool:
    """041-6f: ``getItem().isBerry``."""
    from pokesv_sim.dex import get_dex

    item = get_dex().item(pokemon.held_item) if pokemon.held_item else None
    return item is not None and item.is_berry
