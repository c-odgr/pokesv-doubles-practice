"""035 smart-ai: an AI that scores its actions from what its side sees (specs/035-smart-ai)."""

from pokesv_sim.ai.player import SmartPlayer

__all__ = ["SmartPlayer"]
