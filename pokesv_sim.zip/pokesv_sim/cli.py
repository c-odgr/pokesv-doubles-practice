"""Command line.

- ``simulate TEAM1 TEAM2 [-n N] [--seed S] [--tera P] [--regulation regf] [--json]``: a team is a
  file in Showdown's export format, or ``regf:<ID>`` for an imported tournament team (018)
- ``teams [--period P] [--runnable] [--show ID]``: the imported Reg F tournament teams (018)
- ``coverage [--period P] [--top N]``: how many of them the engine can battle (018)
- ``evaluate OWN [CANDIDATES...] [--field all|top8] [--period P] [--teams FILE] [-n N] [--seed S]
  [--tera P] [--jobs J] [--regulation regf] [--out FILE] [--top K]``: a team against the imported
  teams, its hardest opponents and loss patterns; candidates also play each other (019)
"""

from __future__ import annotations

import argparse
import io
import json
import sys
from collections.abc import Sequence
from pathlib import Path

from pokesv_sim.analysis.simulate import (
    PlayerFactory,
    SidePlayers,
    Summary,
    random_player,
    search_player,
    simulate,
    smart_player,
    summarize,
)
from pokesv_sim.analysis.team_eval import (
    DEFAULT_TERA,
    MAX_CANDIDATES,
    Evaluation,
    Field,
    Progress,
    evaluate,
    format_evaluation,
    format_round_robin,
    random_preview_player,
    round_robin,
    select_field,
)
from pokesv_sim.dex import STAT_IDS, get_dex
from pokesv_sim.regf_teams import REGF_PREFIX, coverage, get_regf_team, regf_teams, status
from pokesv_sim.regulation import adjust_team, check_regulation, get_regulation, regulation_ids
from pokesv_sim.runner import TeamInvalidError, UnsupportedError, check_teams
from pokesv_sim.team import Team, parse_team


def _format(summary: Summary, names: tuple[str, str]) -> str:
    lo, hi = summary.win_rate_p1_ci
    lines = [
        f"{summary.n} battles: p1 = {names[0]}, p2 = {names[1]} (random AI on both sides)",
        f"p1 win rate {summary.win_rate_p1:.1%} (95% CI {lo:.1%} - {hi:.1%}); "
        f"p1 {summary.wins_p1} / p2 {summary.wins_p2} / ties {summary.ties} / "
        f"aborted {summary.aborted}",
        f"turns: mean {summary.turns_mean:.2f}, median {summary.turns_median:g}",
    ]
    peak = max(summary.turns_histogram.values(), default=1)
    for turn, count in sorted(summary.turns_histogram.items()):
        bar = "#" * max(1, round(30 * count / peak))
        lines.append(f"  {turn:4d} {count:6d} {bar}")
    for side in ("p1", "p2"):
        lines.append(f"{side}:  {'Pokemon':<22} brought  sent in  fainted  damage/battle")
        for row in summary.per_pokemon[side]:
            lines.append(
                f"     {row.species:<22} {row.brought:7d}  {row.sent_in:7d}  {row.fainted:7d}"
                f"  {row.damage_mean:13.1f}"
            )
    return "\n".join(lines)


def _load_team(spec: str) -> Team:
    """A team file, or ``regf:<ID>``. Raises ValueError for an unknown ID."""
    if spec.startswith(REGF_PREFIX):
        found = get_regf_team(spec)
        if found is None:
            raise ValueError(f"no imported team {spec!r} (see: python -m pokesv_sim teams)")
        return found.team
    return parse_team(Path(spec).read_text(encoding="utf-8"))


def _species_ja(name: str) -> str:
    species = get_dex().species(name)
    return (species.name_ja or species.name) if species else name


def _show_team(team_id: str) -> int:
    t = get_regf_team(team_id)
    if t is None:
        print(f"no imported team {team_id!r}", file=sys.stderr)
        return 2
    s = status(t.id)
    print(f"{t.id}  {t.tournament} ({t.date}, {t.players} players)  {t.placing}  {t.player}")
    for i, m in enumerate(t.team.members):
        evs = "/".join(str(m.evs[k]) for k in STAT_IDS)
        mark = "  (no spread in the stats: default)" if i in t.no_spread else ""
        print(
            f"  #{i + 1} {_species_ja(m.species)} ({m.species}) @ {m.item}  {m.ability}"
            f" / Tera {m.tera_type} / {m.nature} {evs}{mark}"
        )
        print(f"      {' / '.join(m.moves)}")
    for note in t.corrections:  # 032: what the import corrected in the source
        print(f"  corrected: {note}")
    print("runnable" if s.runnable else "not runnable:")
    reasons = (("invalid", s.errors), ("Reg F", s.regulation), ("not supported yet", s.unsupported))
    for kind, items in reasons:
        for item in items:
            print(f"  {kind}: {item}")
    return 0


def _teams(args: argparse.Namespace) -> int:
    if args.show:
        return _show_team(args.show)
    shown = 0
    for t in regf_teams():
        if args.period and t.period != args.period:
            continue
        s = status(t.id)
        if args.runnable and not s.runnable:
            continue
        if s.runnable:
            why = "ok"
        elif s.errors or s.regulation:
            why = "invalid"
        else:
            why = f"{len(s.unsupported)} unsupported"
        names = " / ".join(_species_ja(m.species) for m in t.team.members)
        print(f"{t.id}  {t.date}  {t.placing:>5}  {why:<15}  {t.player}: {names}")
        shown += 1
    print(f"{shown} teams", file=sys.stderr)
    return 0


def _coverage(args: argparse.Namespace) -> int:
    c = coverage(args.period)
    print(
        f"{c.runnable} of {c.total} teams can battle ({c.runnable / c.total:.1%}); "
        f"{c.supported} have nothing unsupported, {c.invalid} are refused by the team checks"
    )
    print(f"what keeps the others (share of all {c.total} teams):")
    for b in c.blockers[: args.top]:
        print(f"  {b.share(c.total):6.1%}  {b.teams:4d}  {b.name}  {b.name_ja or ''}")
    return 0


def _simulate(args: argparse.Namespace) -> int:
    try:
        team1, team2 = _load_team(args.team1), _load_team(args.team2)
    except ValueError as e:
        print(e, file=sys.stderr)
        return 2
    if args.regulation:  # FR-011: only when asked
        reg = get_regulation(args.regulation)
        failed = False
        for side, team in (("p1", team1), ("p2", team2)):
            for problem in check_regulation(team, reg):
                print(f"not allowed in {reg.name} ({side}): {problem.message}", file=sys.stderr)
                failed = True
        if failed:
            return 2
        team1, team2 = adjust_team(team1, reg), adjust_team(team2, reg)
    try:
        factory: PlayerFactory = random_player
        if args.ai != "random" or args.ai2 is not None:
            factory = SidePlayers(
                _ai(args.ai, random_player), _ai(args.ai2 or args.ai, random_player)
            )
        records = simulate(team1, team2, args.n, args.seed, args.tera, factory)
    except TeamInvalidError as e:
        print(f"invalid team ({e.side}):", file=sys.stderr)
        for err in e.errors:
            print(f"  #{err.index + 1} {err.field}: {err.message}", file=sys.stderr)
        return 2
    except UnsupportedError as e:
        print(f"not supported yet ({e.side}):", file=sys.stderr)
        for item in e.items:
            print(f"  {item}", file=sys.stderr)
        return 2
    summary = summarize(records, team1, team2)
    if args.json:
        print(json.dumps(summary.to_dict(), ensure_ascii=False, indent=1))
    else:
        print(_format(summary, (Path(args.team1).name, Path(args.team2).name)))
    return 0


def _label(spec: str) -> str:
    """How a team is named in the results: the file name, or ``regf:<ID>``."""
    if spec.startswith(REGF_PREFIX):
        return REGF_PREFIX + spec.removeprefix(REGF_PREFIX)
    return Path(spec).name


def _progress(label: str) -> Progress:
    """Prints about every 5% of the pairings, and the last one, to stderr (FR-008)."""

    def report(done: int, total: int) -> None:
        if done == total or done % max(1, total // 20) == 0:
            print(f"{label}: {done}/{total}", file=sys.stderr, flush=True)

    return report


AI_NAMES = ("random", "smart", "search")


def _ai(name: str, random: PlayerFactory) -> PlayerFactory:
    """The ``PlayerFactory`` for ``--ai`` (035 FR-008, 036 FR-001); ``random`` is the command's
    own default."""
    return {"smart": smart_player, "search": search_player}.get(name, random)


def _evaluate_one(
    own: Team,
    label: str,
    field: Field,
    n: int,
    seed: int,
    tera: float,
    jobs: int | None,
    progress: Progress,
    ai: str = "random",
    foe_ai: str | None = None,
) -> Evaluation:
    own_ai = _ai(ai, random_preview_player)
    opponent_ai = None if foe_ai is None else _ai(foe_ai, random_preview_player)
    return evaluate(own, label, field, n, seed, tera, jobs, progress, own_ai, opponent_ai)


def _report_refusal(e: TeamInvalidError | UnsupportedError, label: str) -> None:
    if isinstance(e, TeamInvalidError):
        print(f"invalid team ({label}):", file=sys.stderr)
        for err in e.errors:
            print(f"  #{err.index + 1} {err.field}: {err.message}", file=sys.stderr)
    else:
        print(f"not supported yet ({label}):", file=sys.stderr)
        for item in e.items:
            print(f"  {item}", file=sys.stderr)


def _evaluate(args: argparse.Namespace) -> int:
    specs = [args.own, *args.candidates]
    n = args.n if args.n is not None else (1000 if args.field == "top8" else 100)
    if n % 2 or n <= 0:
        print(f"-n must be a positive even number (each position plays half): {n}",
              file=sys.stderr)  # fmt: skip
        return 2
    if len(specs) > MAX_CANDIDATES:
        print(f"give at most {MAX_CANDIDATES} teams", file=sys.stderr)
        return 2
    labels = [_label(s) for s in specs]
    if len(set(labels)) != len(labels):
        print(f"teams must have distinct names: {labels}", file=sys.stderr)
        return 2
    try:
        teams = [_load_team(s) for s in specs]
        ids = None
        if args.teams:
            lines = Path(args.teams).read_text(encoding="utf-8").splitlines()
            ids = [x.strip() for x in lines if x.strip() and not x.lstrip().startswith("#")]
        field = select_field(args.period, 8 if args.field == "top8" else None, ids)
    except (ValueError, KeyError) as e:
        print(e.args[0] if e.args else e, file=sys.stderr)
        return 2
    if not field.teams:  # a filter mistake must not read as a 0% team
        print(f"no opponent can battle after the filters ({len(field.excluded)} left out)",
              file=sys.stderr)  # fmt: skip
        for ex in field.excluded[:10]:
            print(f"  {ex.id}: {'; '.join(ex.reasons)}", file=sys.stderr)
        return 2
    if args.regulation:  # only when asked, as in simulate
        reg = get_regulation(args.regulation)
        failed = False
        for label, team in zip(labels, teams, strict=True):
            for problem in check_regulation(team, reg):
                print(f"not allowed in {reg.name} ({label}): {problem.message}", file=sys.stderr)
                failed = True
        if failed:
            return 2
        teams = [adjust_team(t, reg) for t in teams]
    for label, team in zip(labels, teams, strict=True):  # FR-006: refuse before any battle
        try:
            check_teams(team, team)
        except (TeamInvalidError, UnsupportedError) as e:
            _report_refusal(e, label)
            return 2
    evaluations = [
        _evaluate_one(
            team,
            label,
            field,
            n,
            args.seed,
            args.tera,
            args.jobs,
            _progress(label),
            args.ai,
            args.foe_ai,
        )
        for label, team in zip(labels, teams, strict=True)
    ]
    rr = None
    if len(teams) > 1:
        rr = round_robin(list(zip(labels, teams, strict=True)), n, args.seed, args.tera,
                         args.jobs, _progress("round robin"))  # fmt: skip
    for ev in evaluations:
        print(format_evaluation(ev, args.top))
        print()
    if rr is not None:
        print(format_round_robin(rr))
        for i, ev in enumerate(evaluations):
            print(f"  {i + 1:>2}. field win rate {ev.total.win_rate:.1%}  {ev.own_label}")
    if args.out:
        data = {
            "evaluations": [ev.to_dict() for ev in evaluations],
            "round_robin": rr.to_dict() if rr else None,
        }
        text = json.dumps(data, ensure_ascii=False, indent=1) + "\n"
        Path(args.out).write_bytes(text.encode("utf-8"))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="pokesv_sim", description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sim = sub.add_parser("simulate", help="play two teams N times and summarize")
    sim.add_argument("team1", help="team file (Showdown export format) or regf:<ID>")
    sim.add_argument("team2")
    sim.add_argument("-n", type=int, default=1000, help="number of battles (default 1000)")
    sim.add_argument("--seed", type=int, default=1)
    sim.add_argument("--json", action="store_true", help="print the summary as JSON")
    sim.add_argument("--ai", choices=AI_NAMES, default="random", help="team1's AI (and team2's)")
    sim.add_argument("--ai2", choices=AI_NAMES, help="team2's AI (default: --ai)")
    sim.add_argument(
        "--tera", type=float, default=0.0,
        help="chance that the random AI terastallizes a Pokémon (0-1, default 0: never)",
    )  # fmt: skip
    sim.add_argument(
        "--regulation", choices=regulation_ids(),
        help="check both teams against a regulation first (default: no regulation)",
    )  # fmt: skip
    teams = sub.add_parser("teams", help="list the imported Reg F tournament teams")
    teams.add_argument("--period", choices=("2024", "2026"))
    teams.add_argument("--runnable", action="store_true", help="only the teams that can battle")
    teams.add_argument("--show", metavar="ID", help="one team's sets and status")
    play = sub.add_parser("play", help="battle an AI yourself in the browser (039)")
    play.add_argument("--port", type=int, default=8765)
    play.add_argument("--no-browser", action="store_true", help="do not open the browser")
    play.add_argument(
        "--lan", action="store_true",
        help="also open it to phones on the same Wi-Fi, behind a key shown at start (045)",
    )  # fmt: skip
    cov = sub.add_parser("coverage", help="how many imported teams the engine can battle")
    cov.add_argument("--period", choices=("2024", "2026"))
    cov.add_argument("--top", type=int, default=20, help="how many blockers to list")
    ev = sub.add_parser(
        "evaluate", help="play a team (or 2-10 candidates) against the imported teams"
    )
    ev.add_argument("own", help="team file or regf:<ID>")
    ev.add_argument("candidates", nargs="*", help="more teams: they also play each other")
    ev.add_argument(
        "--field", choices=("all", "top8"), default="all",
        help="all: every runnable team, 100 battles each (default); top8: placed 8th or better, "
             "1,000 battles each",
    )  # fmt: skip
    ev.add_argument("--period", choices=("2024", "2026"))
    ev.add_argument("--teams", metavar="FILE", help="only the IDs listed in FILE, one per line")
    ev.add_argument("-n", type=int, help="battles per opponent (even; default by --field)")
    ev.add_argument("--seed", type=int, default=1)
    ev.add_argument("--ai", choices=AI_NAMES, default="random", help="the evaluated team's AI")
    ev.add_argument("--foe-ai", choices=AI_NAMES, help="the opponents' AI (default: --ai)")
    ev.add_argument(
        "--tera", type=float, default=DEFAULT_TERA,
        help=f"chance that the AI terastallizes a Pokémon (default {DEFAULT_TERA:g})",
    )  # fmt: skip
    ev.add_argument("--jobs", type=int, help="processes (default: one per CPU)")
    ev.add_argument("--regulation", choices=regulation_ids(), help="check the teams first")
    ev.add_argument("--out", metavar="FILE", help="save the results as JSON")
    ev.add_argument("--top", type=int, default=20, help="rows per table (default 20)")
    for stream in (sys.stdout, sys.stderr):
        # a pipe on Japanese Windows is cp932, which has no "é" (Pokémon): print "?" for it
        if isinstance(stream, io.TextIOWrapper):
            stream.reconfigure(errors="replace")
    args = parser.parse_args(argv)
    if args.command == "play":
        from pokesv_sim.play.server import serve

        serve(args.port, open_browser=not args.no_browser, lan=args.lan)
        return 0
    if args.command == "evaluate":
        return _evaluate(args)
    if args.command == "teams":
        return _teams(args)
    if args.command == "coverage":
        return _coverage(args)
    return _simulate(args)
