"""What a player may see (constitution VII): their own side in full, the foe only as shown."""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass, replace

from pokesv_sim.choices import locked_slot, request_target
from pokesv_sim.dex import get_dex
from pokesv_sim.events import Event
from pokesv_sim.protection import SHOWN
from pokesv_sim.state import SIDE_IDS, BattlePokemon, BattleState, foe_of


@dataclass(frozen=True, slots=True)
class OwnMoveView:
    name: str
    target: str  # Showdown target type, e.g. "normal", "allAdjacentFoes"
    pp: int
    max_pp: int


@dataclass(frozen=True, slots=True)
class OwnPokemonView:
    team_index: int
    species: str
    hp: int
    max_hp: int
    fainted: bool
    position: int | None
    status: str | None
    boosts: tuple[tuple[str, int], ...]
    confused: bool
    moves: tuple[OwnMoveView, ...]
    stats: tuple[tuple[str, int], ...]
    single_turn: tuple[str, ...] = ()  # one-turn effects this turn (Protect, Follow Me, ...)
    tera_type: str = ""  # 017
    terastallized: str | None = None
    locked: bool = False  # 020: must use its charged move (one move, no target, no switch)
    # 035: its own item, ability and types as they are now (a side knows its own Pokémon)
    item: str = ""  # item id ("" for none)
    ability: str = ""  # ability id
    types: tuple[str, ...] = ()
    booster: str | None = None  # the stat Protosynthesis / Quark Drive raises now


@dataclass(frozen=True, slots=True)
class FoePokemonView:
    """A foe on the field: species and HP shown as a percentage (rounded up, like the games)."""

    species: str
    hp_percent: int
    fainted: bool
    position: int
    status: str | None
    boosts: tuple[tuple[str, int], ...]  # stat stages are shown in the games
    confused: bool  # shown when it starts
    single_turn: tuple[str, ...] = ()  # shown when they start (-singleturn)
    terastallized: str | None = None  # 017: shown once it terastallizes (-terastallize)


@dataclass(frozen=True, slots=True)
class SideView:
    side: str
    turn: int
    team: tuple[OwnPokemonView, ...]  # the full submitted team
    brought: tuple[int, ...]  # team indices chosen at preview, leads first (empty before)
    order: tuple[int, ...]  # brought Pokémon in Showdown's side.pokemon order (switches swap)
    foe_preview: tuple[str, ...]  # species shown at team preview (all six)
    foe_active: tuple[FoePokemonView | None, ...]
    foe_left: int  # how many of the foe's brought Pokémon have not fainted
    # Conditions in play as (id, turns left); both players can count the turns.
    field_conditions: tuple[tuple[str, int], ...]  # the whole field (Trick Room)
    own_side_conditions: tuple[tuple[str, int], ...]  # this side (Tailwind)
    foe_side_conditions: tuple[tuple[str, int], ...]
    weather: tuple[str, int] | None = None  # (id, turns left), e.g. ("raindance", 4)
    terrain: tuple[str, int] | None = None  # 010: (id, turns left)
    can_terastallize: bool = False  # 017: this side has not terastallized yet
    # 020: entry hazards as (id, layers), in the order they were set
    own_hazards: tuple[tuple[str, int], ...] = ()
    foe_hazards: tuple[tuple[str, int], ...] = ()
    # 035 (plan R1): the public events since this side's last decision; the foe's HP as the
    # games show it (a percentage in ``hp``, no ``value``, no team index), not its preview
    log: tuple[Event, ...] = ()


def _preview_name(p: BattlePokemon) -> str:
    """The name team preview shows: the set's own species, not a forme it has taken on since
    (a Transformed Ditto, a Terastallized Ogerpon)."""
    own = p.pokemon_set
    species = get_dex().species(own.species) if own is not None else None
    return species.name if species is not None else p.species.name


def _own(p: BattlePokemon) -> OwnPokemonView:
    return OwnPokemonView(
        team_index=p.team_index,
        species=p.species.name,
        hp=p.hp,
        max_hp=p.max_hp,
        fainted=p.fainted,
        position=p.position,
        status=p.status,
        boosts=tuple(p.boosts.items()),
        confused=p.confusion_turns > 0,
        moves=tuple(
            OwnMoveView(m.move.name, request_target(p, m.move), m.pp, m.max_pp)
            # (a fainted Ditto is its own again: Showdown's request gives the base moves back;
            # the engine keeps the copied ones in ``moves`` until it could be revived)
            for m in (p.base_moves if p.fainted and p.base_moves is not None else p.moves)
        ),  # (032: Curse's nonGhostTarget)
        stats=tuple(p.stats.items()),
        single_turn=_single_turn(p),
        tera_type=p.tera_type,
        terastallized=p.terastallized,
        locked=locked_slot(p) is not None,  # 020, 022, 030 (Recharge)
        item=p.held_item or "",
        ability=p.ability_id,
        types=tuple(p.types),
        booster=None if p.neutralized else p.booster_stat,
    )


def side_view(
    state: BattleState, side_id: str, events: Sequence[Event] = (), since: int = 0
) -> SideView:
    """What ``side_id`` sees; ``log`` holds ``events[since:]`` as that side sees them."""
    assert side_id in SIDE_IDS
    side, foe = state.sides[side_id], state.sides[foe_of(side_id)]
    foe_active = tuple(
        None
        if p is None or p.fainted
        else FoePokemonView(
            (p.illusion or p).species.name,  # 034: Illusion's disguise (constitution VII)
            _hp_percent(p),
            p.fainted,
            pos,
            p.status,
            tuple(p.boosts.items()),
            p.confusion_turns > 0,
            _single_turn(p),
            p.terastallized,
        )
        for pos, p in enumerate(foe.active)
    )
    return SideView(
        side=side_id,
        turn=state.turn,
        team=tuple(_own(p) for p in side.team),
        brought=tuple(p.team_index for p in side.brought),
        order=tuple(p.team_index for p in (side.order or side.brought)),
        foe_preview=tuple(_preview_name(p) for p in foe.team),
        foe_active=foe_active,
        foe_left=foe.pokemon_left() if foe.brought else len(foe.team),
        field_conditions=tuple(state.field.pseudo_weather.items()),
        own_side_conditions=tuple(state.field.sides[side_id].items()),
        foe_side_conditions=tuple(state.field.sides[foe.id].items()),
        weather=(state.field.weather, state.field.weather_turns) if state.field.weather else None,
        terrain=(state.field.terrain, state.field.terrain_turns) if state.field.terrain else None,
        can_terastallize=side.can_terastallize(),
        own_hazards=tuple(state.field.hazards[side_id].items()),
        foe_hazards=tuple(state.field.hazards[foe.id].items()),
        log=public_log(state, side_id, events, since),
    )


_HP_KINDS = frozenset({"switch", "drag", "damage", "heal", "sethp"})


def public_log(
    state: BattleState, side_id: str, events: Sequence[Event], since: int = 0
) -> tuple[Event, ...]:
    """035 (plan R1): ``events[since:]`` as ``side_id`` sees them. The foe's team preview is
    left out; the foe's HP becomes the shown percentage (the occupant of each position is
    followed from the start through switch, drag and the swap of Ally Switch)."""
    if since >= len(events):
        return ()
    foe_id = foe_of(side_id)
    team = state.sides[foe_id].team
    at: dict[str, int] = {}
    out: list[Event] = []
    for i, e in enumerate(events):
        if e.kind in ("switch", "drag") and e.actor and e.actor.startswith(foe_id):
            assert e.team_index is not None
            at[e.actor] = e.team_index
        elif e.kind == "swap" and e.actor and e.actor.startswith(foe_id):
            other = e.actor[:2] + ("b" if e.actor[2] == "a" else "a")
            at[e.actor], at[other] = at.get(other, -1), at[e.actor]
        if i < since or (e.kind == "preview" and e.actor == foe_id):
            continue
        about = (e.actor if e.kind in ("switch", "drag") else e.target) or ""
        if e.kind in _HP_KINDS and about.startswith(foe_id):
            hp = e.value if e.kind in ("switch", "drag") else e.hp
            # (041-6f: a Pokémon off the field, Revival Blessing, carries its team_index)
            index = at.get(about, e.team_index)
            assert index is not None
            shown = None if hp is None else _percent(hp, team[index].max_hp)
            e = replace(e, value=None, hp=shown, team_index=None)
        out.append(e)
    return tuple(out)


def _single_turn(p: BattlePokemon) -> tuple[str, ...]:
    """The Pokémon's one-turn volatiles (009); the consecutive-use counters stay hidden."""
    return tuple(v for v in p.timed if v in SHOWN)


def _hp_percent(p: BattlePokemon) -> int:
    return _percent(p.hp, p.max_hp)


def _percent(hp: int, max_hp: int) -> int:
    """Showdown ``getHealth``: rounded up, but 99 when the Pokémon is not at full HP."""
    percent = math.ceil(100 * hp / max_hp)
    return 99 if percent == 100 and hp < max_hp else percent
