"""Play the same pairing N times and summarize the results."""

from __future__ import annotations

from collections import Counter
from collections.abc import Callable
from dataclasses import dataclass, field
from statistics import median
from typing import Any

from pokesv_sim.analysis.normalize import Metrics, metrics, normalize_events
from pokesv_sim.analysis.seeds import BattleSeeds, battle_seeds
from pokesv_sim.analysis.stats import wilson_interval
from pokesv_sim.dex import get_dex
from pokesv_sim.events import Event
from pokesv_sim.players import Player, RandomPlayer
from pokesv_sim.prng import Seed
from pokesv_sim.runner import check_teams, run_battle
from pokesv_sim.team import Team

type PokemonKey = tuple[str, int]  # (side, team index)
type PlayerFactory = Callable[[Seed, str, float], Player]
"""019: builds a side's AI from its PRNG words, its side id and the tera chance."""


@dataclass(frozen=True, slots=True)
class PokemonResult:
    """One brought Pokémon in one battle."""

    sent_in: bool
    fainted: bool
    damage: int  # HP taken off by this Pokémon's moves
    knockouts: int = 0  # foes that fainted right after this Pokémon's move hit them last (019)
    faint_order: int | None = None  # 1 for the first of its side to faint, ... (019)


@dataclass(frozen=True, slots=True)
class BattleRecord:
    index: int
    seeds: BattleSeeds
    winner: str | None
    turns: int
    aborted: bool
    lines: list[str]
    metrics: Metrics
    per_pokemon: dict[PokemonKey, PokemonResult] = field(default_factory=dict)
    leads: dict[str, tuple[int, ...]] = field(default_factory=dict)  # side -> team indices (019)


def _per_pokemon(
    events: tuple[Event, ...], brought: dict[str, tuple[int, ...]]
) -> dict[PokemonKey, PokemonResult]:
    """Per brought Pokémon: sent in or not, fainted or not, the damage its moves dealt.

    019: a knockout goes to the mover whose move dealt the target's last damage in the same
    action (residual damage, recoil and the like after it take the credit away); faints of
    its own side do not count. ``faint_order`` numbers each side's faints from 1.
    """
    at: dict[str, int] = {}  # position label -> team index
    hp: dict[str, int] = {}
    sent: set[PokemonKey] = set()
    damage: Counter[PokemonKey] = Counter()
    knockouts: Counter[PokemonKey] = Counter()
    fainted: dict[PokemonKey, int] = {}
    mover: PokemonKey | None = None
    last_hit: dict[str, PokemonKey | None] = {}  # position label -> mover, within this action
    for e in events:
        if e.kind in ("switch", "drag") and e.actor and e.team_index is not None:
            at[e.actor] = e.team_index
            hp[e.actor] = e.value or 0
            sent.add((e.actor[:2], e.team_index))
        elif e.kind == "move" and e.actor:
            mover = (e.actor[:2], at[e.actor])
            last_hit.clear()
        elif e.kind == "turn":
            last_hit.clear()
        elif e.kind == "damage" and e.target:
            left = e.hp or 0
            direct = e.detail is None and mover is not None  # residual and recoil are not dealt
            if direct and mover is not None:
                damage[mover] += hp.get(e.target, left) - left
            last_hit[e.target] = mover if direct else None
            hp[e.target] = left
        elif e.kind == "faint" and e.target:
            key = (e.target[:2], at[e.target])
            fainted[key] = sum(k[0] == key[0] for k in fainted) + 1
            by = last_hit.pop(e.target, None)
            if by is not None and by[0] != key[0]:
                knockouts[by] += 1
    keys = [(side, i) for side, indices in brought.items() for i in indices]
    return {
        k: PokemonResult(k in sent, k in fainted, damage[k], knockouts[k], fainted.get(k))
        for k in keys
    }


def _leads(events: tuple[Event, ...]) -> dict[str, tuple[int, ...]]:
    """019: each side's team indices on the field when the battle starts, by position."""
    on_field: dict[str, int] = {}
    for e in events:
        if e.kind == "turn":
            break
        if e.kind in ("switch", "drag") and e.actor and e.team_index is not None:
            on_field.setdefault(e.actor, e.team_index)
    leads: dict[str, tuple[int, ...]] = {}
    for label in sorted(on_field):
        leads[label[:2]] = (*leads.get(label[:2], ()), on_field[label])
    return leads


def random_player(words: Seed, side: str, tera: float) -> Player:
    """The default ``PlayerFactory``: Showdown's random AI, bringing the first four."""
    return RandomPlayer(words, tera=tera)


def smart_player(words: Seed, side: str, tera: float) -> Player:
    """035's smart AI (``tera`` is the random AI's; the smart AI decides for itself)."""
    from pokesv_sim.ai import SmartPlayer

    return SmartPlayer(words)


def search_player(words: Seed, side: str, tera: float) -> Player:
    """036's search AI with its default settings (``tera`` is the random AI's)."""
    from pokesv_sim.search import SearchPlayer

    return SearchPlayer(words)


@dataclass(frozen=True, slots=True)
class SidePlayers:
    """A ``PlayerFactory`` giving p1 and p2 their own AIs (035 FR-008). Module level and frozen,
    so it can be pickled for worker processes."""

    p1: PlayerFactory
    p2: PlayerFactory

    def __call__(self, words: Seed, side: str, tera: float) -> Player:
        return (self.p1 if side == "p1" else self.p2)(words, side, tera)

    @property
    def __name__(self) -> str:  # for reports (019 ``ai``)
        return f"{getattr(self.p1, '__name__', self.p1)} vs {getattr(self.p2, '__name__', self.p2)}"


def simulate(
    team1: Team,
    team2: Team,
    n: int,
    seed: int,
    tera: float = 0.0,
    player_factory: PlayerFactory = random_player,
) -> list[BattleRecord]:
    """``n`` battles between Showdown-style random AIs; battle ``i`` uses ``battle_seeds(seed, i)``.
    ``tera``: the AIs' chance to terastallize (017; 0: never).
    ``player_factory``: builds each side's AI (019; default ``random_player``).

    Raises ``TeamInvalidError`` / ``UnsupportedError`` before any battle (see ``run_battle``).
    """
    check_teams(team1, team2)
    records = []
    for i in range(n):
        s = battle_seeds(seed, i)
        result = run_battle(
            team1,
            team2,
            player_factory(s.p1_words, "p1", tera),
            player_factory(s.p2_words, "p2", tera),
            s.battle_words,
        )
        lines = normalize_events(result.events)
        records.append(
            BattleRecord(
                index=i,
                seeds=s,
                winner=result.winner,
                turns=result.turns,
                aborted=result.aborted is not None,
                lines=lines,
                metrics=metrics(lines),
                per_pokemon=_per_pokemon(result.events, result.brought or {}),
                leads=_leads(result.events),
            )
        )
    return records


@dataclass(frozen=True, slots=True)
class PokemonSummary:
    team_index: int
    species: str
    brought: int  # battles in which it was chosen at team preview
    sent_in: int  # battles in which it entered the field
    fainted: int
    damage_mean: float  # mean damage per battle it was brought to

    def to_dict(self) -> dict[str, Any]:
        return {
            "team_index": self.team_index,
            "species": self.species,
            "brought": self.brought,
            "sent_in": self.sent_in,
            "fainted": self.fainted,
            "damage_mean": round(self.damage_mean, 2),
        }


@dataclass(frozen=True, slots=True)
class Summary:
    n: int
    wins_p1: int
    wins_p2: int
    ties: int
    aborted: int
    win_rate_p1: float
    win_rate_p1_ci: tuple[float, float]
    turns_mean: float
    turns_median: float
    turns_histogram: dict[int, int]
    per_pokemon: dict[str, list[PokemonSummary]]

    def to_dict(self) -> dict[str, Any]:
        return {
            "n": self.n,
            "wins_p1": self.wins_p1,
            "wins_p2": self.wins_p2,
            "ties": self.ties,
            "aborted": self.aborted,
            "win_rate_p1": round(self.win_rate_p1, 4),
            "win_rate_p1_ci": [round(x, 4) for x in self.win_rate_p1_ci],
            "turns_mean": round(self.turns_mean, 3),
            "turns_median": self.turns_median,
            "turns_histogram": {str(k): v for k, v in sorted(self.turns_histogram.items())},
            "per_pokemon": {s: [p.to_dict() for p in rows] for s, rows in self.per_pokemon.items()},
        }


def summarize(records: list[BattleRecord], team1: Team, team2: Team) -> Summary:
    n = len(records)
    wins_p1 = sum(r.winner == "p1" for r in records)
    wins_p2 = sum(r.winner == "p2" for r in records)
    aborted = sum(r.aborted for r in records)
    turns = [r.turns for r in records]
    per_pokemon: dict[str, list[PokemonSummary]] = {"p1": [], "p2": []}
    teams = {"p1": team1, "p2": team2}
    for side, index in sorted({k for r in records for k in r.per_pokemon}):
        results = [r.per_pokemon[(side, index)] for r in records if (side, index) in r.per_pokemon]
        per_pokemon[side].append(
            PokemonSummary(
                team_index=index,
                species=species_name(teams[side], index),
                brought=len(results),
                sent_in=sum(p.sent_in for p in results),
                fainted=sum(p.fainted for p in results),
                damage_mean=sum(p.damage for p in results) / len(results),
            )
        )
    return Summary(
        n=n,
        wins_p1=wins_p1,
        wins_p2=wins_p2,
        ties=n - wins_p1 - wins_p2 - aborted,
        aborted=aborted,
        win_rate_p1=wins_p1 / n if n else 0.0,
        win_rate_p1_ci=wilson_interval(wins_p1, n),
        turns_mean=sum(turns) / n if n else 0.0,
        turns_median=float(median(turns)) if turns else 0.0,
        turns_histogram=dict(Counter(turns)),
        per_pokemon=per_pokemon,
    )


def species_name(team: Team, index: int) -> str:
    species = get_dex().species(team.members[index].species)
    return species.name if species else team.members[index].species
