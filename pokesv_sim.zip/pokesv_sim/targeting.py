"""Who a move hits (Showdown ``getTarget``, ``getRandomTarget``, ``getMoveTargets``).

Doubles only: every position is adjacent to every other.
"""

from __future__ import annotations

from dataclasses import dataclass, replace

from pokesv_sim.choices import ALLY_OR_SELF, ALLY_TARGETS, SINGLE_TARGETS, TWO_TURN, USER_TARGETS
from pokesv_sim.dex import Move, get_dex
from pokesv_sim.field import RAIN, SUN
from pokesv_sim.prng import Prng
from pokesv_sim.state import BattlePokemon, BattleState, foe_of
from pokesv_sim.weather import SOLAR_MOVES, effective_weather


@dataclass(frozen=True, slots=True)
class Targeting:
    targets: list[BattlePokemon]  # empty: the move fails for lack of a target
    spread: bool  # more than one target when the move was used (spread modifier applies)
    smart: bool = False  # 030: Dragon Darts' smartTarget is still on (one hit on each target)
    # 040-3 (review P2): getTarget's random foe for a spread move (useMoveInner's ModifyMove
    # target: the storms' Utility Umbrella check)
    chosen: BattlePokemon | None = None


def _at_location(state: BattleState, user: BattlePokemon, loc: int) -> BattlePokemon | None:
    side = foe_of(user.side) if loc > 0 else user.side
    return state.at(side, abs(loc) - 1)


def _random_foe(state: BattleState, user: BattlePokemon, prng: Prng) -> BattlePokemon | None:
    """Showdown ``side.randomFoe()``: one draw among the foes still standing."""
    foes = state.sides[foe_of(user.side)].alive_active()
    return prng.sample(foes) if foes else None


def resolve_targets(
    state: BattleState,
    user: BattlePokemon,
    move: Move,
    target_loc: int | None,
    prng: Prng,
    *,
    tracked: BattlePokemon | None = None,
) -> Targeting:
    if move.target in USER_TARGETS:  # the user, its side or the field (tryMoveHit)
        return Targeting([user], spread=False)
    if move.target == ALLY_OR_SELF:
        # 041-6f: getTarget: the Pokémon at the location; a fainted ally (or none) gives the
        # user (getRandomTarget, no draw)
        at = _at_location(state, user, target_loc) if target_loc is not None else None
        return Targeting([at if at is not None and not at.fainted else user], spread=False)
    if tracked is not None:  # 043-2b: Stalwart / Propeller Tail: originalTarget (no draw)
        if move.target in ("randomNormal", "scripted") or move.target in SINGLE_TARGETS:
            return _single_targets(state, user, move, tracked)
        return replace(_spread_targets(state, user, move), chosen=tracked)
    # I-001 (old bug from 026): getTarget's own-location check is only for adjacentAlly, any
    # and normal (a locked Uproar kept at the user's own location picks a random foe)
    own = (
        move.target in ("adjacentAlly", "any", "normal")
        and target_loc is not None
        and target_loc < 0
        and _at_location(state, user, target_loc) is user
    )
    if own and TWO_TURN not in user.timed:
        # getTarget returns null (no draw) for a location that is now the user's own (after
        # Ally Switch): the move fails.
        return Targeting([], spread=False)
    if move.target in ALLY_TARGETS:  # Helping Hand, Coaching: the ally, never redirected
        assert target_loc is not None
        ally = _at_location(state, user, target_loc)
        return Targeting([ally] if ally is not None and not ally.fainted else [], spread=False)
    if move.target == "randomNormal":  # Struggle: getRandomTarget picks a foe
        target = _random_foe(state, user, prng)
    elif is_smart(move):
        # 030: getTarget's smartTarget branch: the Pokémon at the location unless it fainted
        # (a fainted ally too), else getRandomTarget
        assert target_loc is not None
        target = _at_location(state, user, target_loc)
        if target is None or target.fainted:
            target = _random_foe(state, user, prng)
    elif move.target in SINGLE_TARGETS or move.target == "scripted":  # 041-4a: Counter
        assert target_loc is not None
        target = _at_location(state, user, target_loc)
        if target is None or target is user or (target.fainted and target_loc > 0):
            # (026: its own location, kept by a charging move: not a valid target location)
            target = _random_foe(state, user, prng)  # a fainted ally is kept (and fails)
    else:
        target = None
    if move.target in ("randomNormal", "scripted") or move.target in SINGLE_TARGETS:
        return _single_targets(state, user, move, target)

    # Showdown's getTarget never finds a valid location for a spread move, so it picks a random
    # foe and then ignores it (one draw while a foe stands; keeps the PRNGs in step).
    chosen = _random_foe(state, user, prng)
    return replace(_spread_targets(state, user, move), chosen=chosen)


def _spread_targets(state: BattleState, user: BattlePokemon, move: Move) -> Targeting:
    targets: list[BattlePokemon] = []
    if move.target == "allies":  # 015: alliesAndSelf, in position order (Howl)
        targets = state.sides[user.side].alive_active()
        return Targeting(targets, spread=len(targets) > 1)
    if move.target == "foeSide":  # 020: getMoveTargets: the foes (tryMoveHit on their side)
        targets = state.sides[foe_of(user.side)].alive_active()
        return Targeting(targets, spread=False)
    if move.target == "allAdjacent":
        targets += [p for p in state.sides[user.side].alive_active() if p is not user]
    if move.target in ("allAdjacent", "allAdjacentFoes"):
        targets += state.sides[foe_of(user.side)].alive_active()
    else:
        raise ValueError(f"unsupported move target: {move.target}")
    return Targeting(targets, spread=len(targets) > 1)


def random_targeting(state: BattleState, user: BattlePokemon, move: Move, prng: Prng) -> Targeting:
    """Showdown ``getRandomTarget`` (015: Encore's new move), then getMoveTargets: the user for
    self / field moves, a random adjacent ally for ``adjacentAlly``, otherwise a random foe
    (one draw; also for spread moves and ``allies``)."""
    if move.target in USER_TARGETS or move.target == ALLY_OR_SELF:
        return Targeting([user], spread=False)
    if move.target in ALLY_TARGETS:
        allies = [p for p in state.sides[user.side].alive_active() if p is not user]
        return Targeting([prng.sample(allies)] if allies else [], spread=False)
    target = _random_foe(state, user, prng)
    if move.target in ("randomNormal", "scripted") or move.target in SINGLE_TARGETS:
        # (041-6f: ModifyMove sees getRandomTarget's foe, before the redirection: Rollout's
        # lastMoveTargetLoc)
        return replace(_single_targets(state, user, move, target), chosen=target)
    return replace(_spread_targets(state, user, move), chosen=target)


def bounce_targeting(
    state: BattleState, holder: BattlePokemon, move: Move, source: BattlePokemon
) -> Targeting:
    """031 (R3): Magic Bounce's ``useMove(newMove, holder, {target: source})``. The target is
    given (no getTarget draw); getMoveTargets runs from the holder, so a spread move hits all
    the holder's adjacent foes and a hazard goes on their side."""
    if move.target in SINGLE_TARGETS:
        return _single_targets(state, holder, move, source)
    return _spread_targets(state, holder, move)


def is_smart(move: Move) -> bool:
    """030 (R9): ``move.smartTarget`` (Dragon Darts)."""
    return "smartTarget" in move.keys


def _single_targets(
    state: BattleState, user: BattlePokemon, move: Move, target: BattlePokemon | None
) -> Targeting:
    """getMoveTargets for one target: the redirection, then (030) ``getSmartTargets``: the
    target and its ally (one hit each) when the ally has HP and is not the user. Follow Me /
    Rage Powder turn smartTarget off (their onFoeRedirectTarget)."""
    if target is None:
        return Targeting([], spread=False)
    smart = is_smart(move) and not redirecting_foes(state, user)  # (not a charge move)
    target = redirect(state, user, move, target)
    if target.fainted:
        return Targeting([], spread=False)
    if smart:
        side = state.sides[target.side].alive_active()
        partner = next((p for p in side if p is not target), None)
        if partner is not None and partner is not user and partner.hp > 0:
            if target.hp <= 0:
                return Targeting([partner], spread=False)
            return Targeting([target, partner], spread=False, smart=True)
    return Targeting([target], spread=False)


def fires_at_once(move: Move, weather: str | None) -> bool:
    """021 (R8): Electro Shot does not charge in the rain; 026 (R1): Solar Beam / Solar Blade
    in the sun (``effectiveWeather``: Cloud Nine and Utility Umbrella are unsupported)."""
    if move.id in SOLAR_MOVES:
        return weather == SUN
    return move.id == "electroshot" and weather == RAIN


def is_charging(user: BattlePokemon, move: Move, weather: str | None) -> bool:
    """getMoveTargets' ``isCharging`` (020, 021): a charge move on its charging turn (no
    twoturnmove yet, no Power Herb, not Electro Shot in the rain) is not redirected, neither
    by Follow Me nor by Lightning Rod / Storm Drain."""
    return (
        "charge" in move.flags
        and "twoturnmove" not in user.timed
        and user.item != "powerherb"
        and not fires_at_once(move, weather)
    )


def redirecting_foes(state: BattleState, user: BattlePokemon) -> list[BattlePokemon]:
    """The foes whose Follow Me / Rage Powder affect the user. Rage Powder does nothing for a
    user immune to powder (``runStatusImmunity('powder')``: Grass types, Overcoat, Safety
    Goggles; 012)."""
    holders = []
    for foe in state.sides[foe_of(user.side)].alive_active():
        for volatile in ("followme", "ragepowder"):
            if volatile not in foe.timed:
                continue
            if volatile == "ragepowder" and (
                get_dex().effect_immune("powder", user.types)
                or user.ability_id == "overcoat"
                or user.item == "safetygoggles"
            ):
                continue
            holders.append(foe)
    return holders


def redirect(
    state: BattleState, user: BattlePokemon, move: Move, target: BattlePokemon
) -> BattlePokemon:
    """``priorityEvent('RedirectTarget')`` (009): the foes' Follow Me / Rage Powder, faster
    first, then the one set earlier (``compareRedirectOrder``: no random draw). Rage Powder
    does not affect a user immune to powder (Grass). 020: not a charge move on its charging
    turn (``isCharging``: no twoturnmove yet and no Power Herb; 021: not Electro Shot in the
    rain)."""
    if is_charging(user, move, effective_weather(state.field.active_weather, user.item)):
        return target
    if "tracksTarget" in move.keys or user.ability_id in ("propellertail", "stalwart"):
        return target  # 041-6a: getMoveTargets skips RedirectTarget (Snipe Shot; 043-2b)
    holders = redirecting_foes(state, user)
    if not holders:
        return target
    holders.sort(key=lambda p: (-p.cached_speed, p.counters.get("redirect_order", 0)))
    return holders[0]
