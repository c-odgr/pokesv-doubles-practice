"""Pokémon Scarlet/Violet doubles battle simulator."""

from pokesv_sim.battle import Battle, EngineError, IllegalChoiceError
from pokesv_sim.choices import Choice, MoveChoice, PassChoice, Preview, SwitchChoice
from pokesv_sim.damage import Combatant, damage_rolls
from pokesv_sim.dex import get_dex
from pokesv_sim.events import Event
from pokesv_sim.players import Player, RandomPlayer
from pokesv_sim.runner import BattleResult, TeamInvalidError, UnsupportedError, run_battle
from pokesv_sim.support import unsupported
from pokesv_sim.team import PokemonSet, Team, TeamError, parse_team, validate_team
from pokesv_sim.view import SideView

__all__ = [
    "Battle",
    "BattleResult",
    "Choice",
    "Combatant",
    "EngineError",
    "Event",
    "IllegalChoiceError",
    "MoveChoice",
    "PassChoice",
    "Player",
    "PokemonSet",
    "Preview",
    "RandomPlayer",
    "SideView",
    "SwitchChoice",
    "Team",
    "TeamError",
    "TeamInvalidError",
    "UnsupportedError",
    "damage_rolls",
    "get_dex",
    "parse_team",
    "run_battle",
    "unsupported",
    "validate_team",
]
