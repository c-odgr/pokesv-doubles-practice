"""035 FR-014: battle records for learning (stage 3), one JSON line per decision.

Each line: ``side``, ``kind`` (``preview`` / ``turn`` / ``replace``), ``turn``, the ``view`` the
player saw (``SideView`` as a dictionary), the ``choice`` it made, and, written once the battle
is over, ``winner`` and ``won``. Recording wraps the players and leaves the battle alone, so a
recorded battle plays exactly as an unrecorded one (the default records nothing).
"""

from __future__ import annotations

import json
from collections.abc import Sequence
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, TextIO

from pokesv_sim.choices import Choice, MoveChoice, PassChoice, Preview, SwitchChoice
from pokesv_sim.players import Player
from pokesv_sim.prng import Seed
from pokesv_sim.runner import BattleResult, run_battle
from pokesv_sim.team import Team
from pokesv_sim.view import SideView


def _choice(c: object) -> dict[str, Any]:
    data = asdict(c) if is_dataclass(c) and not isinstance(c, type) else {}
    return {"type": type(c).__name__, **data}


class RecordingPlayer:
    """Passes every decision to ``inner`` and keeps (kind, turn, view, choice). A choice the
    engine refused and asked again for (022) replaces the refused one."""

    def __init__(self, inner: Player) -> None:
        self.inner = inner
        self.records: list[dict[str, Any]] = []

    def _add(self, kind: str, view: SideView, choice: Any) -> None:
        record = {"kind": kind, "turn": view.turn, "view": asdict(view), "choice": choice}
        last = self.records[-1] if self.records else None
        retried = kind == "turn" and last is not None and last["kind"] == "turn"
        if retried and last is not None and last["turn"] == view.turn:
            if not view.log:  # asked again with the log already shown: keep the first ask's
                record["view"]["log"] = last["view"]["log"]
            self.records[-1] = record
        else:
            self.records.append(record)

    def choose_preview(self, view: SideView) -> Preview:
        chosen = self.inner.choose_preview(view)
        self._add("preview", view, _choice(chosen))
        return chosen

    def choose_turn(
        self, view: SideView, legal: Sequence[Sequence[MoveChoice | SwitchChoice]]
    ) -> list[Choice]:
        chosen = self.inner.choose_turn(view, legal)
        self._add("turn", view, [_choice(c) for c in chosen])
        return chosen

    def choose_replacements(
        self, view: SideView, need: Sequence[bool]
    ) -> list[SwitchChoice | PassChoice]:
        chosen = self.inner.choose_replacements(view, need)
        self._add("replace", view, [_choice(c) for c in chosen])
        return chosen


def record_battle(
    team1: Team,
    team2: Team,
    player1: Player,
    player2: Player,
    seed: int | Seed,
    out: TextIO | Path,
) -> BattleResult:
    """``run_battle`` with both sides' decisions written to ``out`` (appended to a path)."""
    sides = {"p1": RecordingPlayer(player1), "p2": RecordingPlayer(player2)}
    result = run_battle(team1, team2, sides["p1"], sides["p2"], seed)
    lines = []
    for side, recorder in sides.items():
        for record in recorder.records:
            row = {"side": side, **record, "winner": result.winner, "won": result.winner == side}
            lines.append(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    if isinstance(out, Path):
        with out.open("a", encoding="utf-8", newline="\n") as f:
            f.writelines(lines)
    else:
        out.writelines(lines)
    return result
