"""Moves that protect, redirect and help in doubles (009; Showdown ``data/moves.ts``).

Protection is a volatile status with a duration of one turn (Protect and its variants, Endure)
or a side condition of one turn (Wide Guard, Quick Guard). Using them in a row is limited by the
``stall`` volatile (two turns, a counter tripled by each success). The battle calls these
functions at Showdown's points: PrepareHit (may the move succeed), TryHit (is the target
protected), BreakProtect (Feint) and the end of the turn.
"""

from __future__ import annotations

from pokesv_sim.dex import Move
from pokesv_sim.prng import Prng
from pokesv_sim.state import BattlePokemon

STALL = "stall"
ALLY_SWITCH = "allyswitch"
STALL_DURATION = 2
COUNTER_START, COUNTER_MAX = 3, 729

# Volatiles that block moves (``onTryHit``, priority 3): whether they block status moves
# (``checkMoveBypassesProtect(..., blockStatus)``) and what contact does to the attacker.
PROTECTIONS = {
    "protect": (True, None),
    "spikyshield": (True, "damage"),
    "banefulbunker": (True, "psn"),
    "silktrap": (False, "spe"),
    "burningbulwark": (False, "brn"),
}
# hitStepBreakProtect removes these (in this order; King's Shield and Obstruct are not in SV).
BREAKABLE = ("banefulbunker", "burningbulwark", "protect", "silktrap", "spikyshield")
GUARDS = ("quickguard", "wideguard")  # side conditions Feint removes (Crafty Shield: not in SV)

# ``-singleturn`` names (data/moves.ts condition onStart).
SINGLE_TURN_NAMES = {
    "protect": "Protect",
    "silktrap": "Protect",
    "spikyshield": "move: Protect",
    "banefulbunker": "move: Protect",
    "burningbulwark": "move: Protect",
    "endure": "move: Endure",
    "followme": "move: Follow Me",
    "ragepowder": "move: Rage Powder",
    "helpinghand": "Helping Hand",
    "wideguard": "Wide Guard",
    "quickguard": "Quick Guard",
}
GUARD_NAMES = {"wideguard": "move: Wide Guard", "quickguard": "move: Quick Guard"}
REDIRECTORS = ("followme", "ragepowder")
# Status moves whose effect is a one-turn volatile on the user (or the ally: Helping Hand), or
# Ally Switch's swap.
ONE_TURN_MOVES = frozenset(
    {"protect", "detect", "spikyshield", "banefulbunker", "silktrap", "burningbulwark",
     "endure", "followme", "ragepowder", "helpinghand", "allyswitch"}
)  # fmt: skip
# Volatiles a player can see (the counters are hidden).
SHOWN = frozenset(SINGLE_TURN_NAMES)


def is_stalling(move: Move) -> bool:
    return "stallingMove" in move.keys


def breaks_protect(move: Move) -> bool:
    return "breaksProtect" in move.keys


def bypasses_protect(move: Move, *, block_status: bool = True) -> bool:
    """``checkMoveBypassesProtect``: moves without the ``protect`` flag go through."""
    blocked = (move.category != "Status" or block_status) and "protect" in move.flags
    return not blocked


def guard_blocks(guard: str, move: Move) -> bool:
    """Wide Guard / Quick Guard ``onTryHit`` (priority 4)."""
    if guard == "wideguard":
        applies = move.target in ("allAdjacent", "allAdjacentFoes")
    else:
        applies = move.priority > 0.1
    return applies and not bypasses_protect(move)


def protection_of(pokemon: BattlePokemon) -> str | None:
    """The blocking volatile the Pokémon holds, if any (at most one per turn)."""
    for volatile in pokemon.timed:
        if volatile in PROTECTIONS:
            return volatile
    return None


def protects_against(volatile: str, move: Move) -> bool:
    block_status, _ = PROTECTIONS[volatile]
    return not bypasses_protect(move, block_status=block_status)


def contact_effect(volatile: str) -> str | None:
    return PROTECTIONS[volatile][1]


def add_timed(pokemon: BattlePokemon, volatile: str, duration: int = 1) -> bool:
    """``addVolatile`` of a volatile with a duration: False if the Pokémon already has it."""
    if pokemon.hp <= 0 or volatile in pokemon.timed:
        return False
    pokemon.timed[volatile] = duration
    return True


def stall_check(pokemon: BattlePokemon, prng: Prng) -> bool:
    """``runEvent('StallMove')``: no handler (no draw) without the stall volatile; otherwise
    ``randomChance(1, counter)``, removing stall on failure."""
    if STALL not in pokemon.timed:
        return True
    counter = pokemon.counters.get(STALL) or 1
    if prng.random_chance(1, counter):
        return True
    del pokemon.timed[STALL]
    pokemon.counters.pop(STALL, None)
    return False


def add_stall(pokemon: BattlePokemon) -> None:
    """``addVolatile('stall')``: start (counter 3) or restart (counter x3, duration 2)."""
    _add_counted(pokemon, STALL)


def ally_switch_check(pokemon: BattlePokemon, prng: Prng) -> bool:
    """Ally Switch ``onPrepareHit``: ``addVolatile('allyswitch')``; a restart succeeds with
    ``randomChance(1, counter)`` and removes the volatile on failure."""
    if ALLY_SWITCH in pokemon.timed:
        counter = pokemon.counters.get(ALLY_SWITCH) or 1
        if not prng.random_chance(1, counter):
            del pokemon.timed[ALLY_SWITCH]
            pokemon.counters.pop(ALLY_SWITCH, None)
            return False
    _add_counted(pokemon, ALLY_SWITCH)
    return True


def _add_counted(pokemon: BattlePokemon, volatile: str) -> None:
    if volatile in pokemon.timed:
        if pokemon.counters[volatile] < COUNTER_MAX:
            pokemon.counters[volatile] *= 3
    else:
        pokemon.counters[volatile] = COUNTER_START
    pokemon.timed[volatile] = STALL_DURATION
