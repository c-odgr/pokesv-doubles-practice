"""The state of a doubles battle in progress: Pokémon, sides and positions."""

from __future__ import annotations

from dataclasses import dataclass, field, replace

from pokesv_sim.abilities import BOOSTER_SPEED, NEUTRALIZING_GAS, SLOW_START, weather_speed
from pokesv_sim.boosts import BOOST_IDS, boosted_stat, wonder_swapped
from pokesv_sim.damage import Combatant, chain_modify, modify
from pokesv_sim.dex import Move, Species, default_tera_type, get_dex, to_id
from pokesv_sim.field import GRASS_PLEDGE, MAGIC_ROOM, TAILWIND, WONDER_ROOM, FieldState
from pokesv_sim.items import ABILITY_SHIELD, CROWNED, HALF_SPEED_ITEMS, can_be_taken
from pokesv_sim.stats import calc_stats
from pokesv_sim.team import PokemonSet
from pokesv_sim.weather import effective_weather

SIDE_IDS = ("p1", "p2")
SLOT_NAMES = ("a", "b")
ACTIVE_PER_SIDE = 2
PREVIEW_PICK = 4  # bring 4 of 6


STELLAR = "Stellar"  # 017


def _tera_type_name(name: str | None) -> str | None:
    """The type's proper name ("stellar" -> "Stellar")."""
    if name is None:
        return None
    wanted = to_id(name)
    return next((t for t in get_dex().type_names() if to_id(t) == wanted), name)


def foe_of(side_id: str) -> str:
    return "p2" if side_id == "p1" else "p1"


def max_pp(move: Move) -> int:
    """PP with the maximum PP Ups (Showdown's default): pp * 8 / 5."""
    return move.pp * 8 // 5


# 043-5d: items whose handlers still run under Klutz (ignoreKlutz)
IGNORE_KLUTZ = frozenset({"abilityshield", "machobrace", "poweranklet", "powerband",
                          "powerbelt", "powerbracer", "powerlens", "powerweight"})  # fmt: skip


@dataclass(slots=True)
class MoveSlot:
    move: Move
    pp: int
    max_pp: int
    used: bool = False  # 041-4e: moveSlot.used (deductPP; reset by switchIn)


@dataclass(slots=True, eq=False)
class BattlePokemon:
    side: str
    team_index: int  # index in the side's full team (as submitted)
    name: str
    species: Species
    level: int
    base_types: tuple[str, ...]  # its own types (017: ``types`` is what it is now)
    stats: dict[str, int]
    max_hp: int
    hp: int
    moves: list[MoveSlot]
    ability: str
    gender: str | None = None  # "M"/"F"/"N"; drawn at battle creation when not given
    position: int | None = None  # 0/1 while active
    fainted: bool = False
    status: str | None = None  # "brn", "par", "psn", "tox", "slp", "frz"
    sleep_turns: int = 0  # Showdown statusState.time: moves left before waking
    toxic_stage: int = 0
    boosts: dict[str, int] = field(default_factory=lambda: dict.fromkeys(BOOST_IDS, 0))
    status_order: int = 0  # when the status was set (Showdown effectOrder, for sorting)
    flinched: bool = False  # volatile: cannot move this turn
    # 023: the timed volatiles it came after (pokemon.volatiles keeps the order they were added)
    flinch_after: tuple[str, ...] = ()
    confusion_turns: int = 0  # volatile: Showdown confusion time (0: not confused)
    active_move_actions: int = 0  # moves started since switching in (Fake Out)
    newly_switched: bool = False  # switched in this turn (Helping Hand onTryHit)
    # 009: volatile statuses with a duration (Showdown ``volatiles`` that hold ``duration``):
    # id -> turns left, in the order they were added (Protect, Follow Me, Helping Hand, stall).
    timed: dict[str, int] = field(default_factory=dict)
    # 009: ``effectState.counter`` of the stall and allyswitch volatiles (consecutive use).
    counters: dict[str, int] = field(default_factory=dict)
    # Showdown ``pokemon.speed``: refreshed only at updateSpeed() calls, so it can be stale
    # (e.g. right after paralysis). Sorting for events uses it; action order does not.
    cached_speed: int = -1
    # 011: the stat Protosynthesis / Quark Drive raises (their volatile), or None
    booster_stat: str | None = None
    # 012: Mold Breaker's move is running and this Pokémon's ability is breakable
    ability_suppressed: bool = False
    flash_fire: bool = False  # 012: the flashfire volatile
    trace_seeking: bool = False  # 031: Trace's effectState.seek
    # 027: baseAbility (``ability`` is what it has now: Skill Swap changes it until it
    # leaves the field) and the set's ability (faintMessages' formeRegression)
    own_ability: str = ""
    set_ability: str = ""
    ability_order: int = 0  # 012: abilityState.effectOrder (set on switching in)
    # 013: held item id ("" once used up or knocked off). 041-6f: `item` (below) is what the
    # item handlers see: nothing while Magic Room is up (ignoringItem); `held_item` is what
    # it holds (Trick, Knock Off, Thief, Acrobatics, Poltergeist, Recycle)
    held_item: str = ""
    choice_lock: str | None = None  # 013: the choicelock volatile (the move id it locks)
    unburden: bool = False  # 013: the unburden volatile
    booster_from_item: bool = False  # 013: the booster volatile came from Booster Energy
    item_started: bool = False  # 013: itemState.started (Booster Energy's onStart has run)
    nature_minus: str | None = None  # 013: the stat its nature lowers (pinch berries)
    # 013: Berserk's effectState.checkedBerserk (False from a move's hit until its
    # AfterMoveSecondary: no healing berry in between; None: not set yet)
    checked_berserk: bool | None = None
    # 014: pokemon.switchFlag (the move id of U-turn etc.; True for Eject Pack): it switches
    # out at the end of the action; skipBeforeSwitchOutEventFlag once BeforeSwitchOut ran
    switch_flag: str | bool | None = None
    force_switch: bool = False  # 034 (R1): forceSwitchFlag (Roar: dragged out after the action)
    skip_before_switch_out: bool = False
    eject_pending: bool = False  # 014: Eject Pack's effectState.eject (a stat was lowered)
    # 040-3b: Mirror Herb's effectState.boosts (the foes' raised stages; ready when any)
    mirror_boosts: dict[str, int] = field(default_factory=dict)
    opportunist: dict[str, int] = field(default_factory=dict)  # 043-4i: effectState.boosts
    # 015: pokemon.lastMove (the move id it last used: Encore), moveThisTurnResult and
    # moveLastTurnResult (True / False, None for undefined or null: Stomping Tantrum doubles
    # after False), activeTurns (turns started on the field: Taunt's duration)
    last_move: str | None = None
    move_this_turn_result: bool | None = None
    move_last_turn_result: bool | None = None
    active_turns: int = 0
    encore_move: str | None = None  # 015: the encore volatile's effectState.move
    substitute_hp: int = 0  # 016: the substitute volatile's effectState.hp (0: none)
    # 020: a two-turn move (Meteor Beam). The twoturnmove volatile is ``timed["twoturnmove"]``
    # (duration 2; its onLockMove locks ``two_turn_move``, aimed at ``charge_loc``);
    # ``charged`` is the move's own volatile (removed when the move fires on the next turn).
    two_turn_move: str | None = None
    charge_loc: int | None = None
    charged: bool = False
    # 041-5: the locked move a queued LOCKED_EXTERNAL choice uses (the action's move is
    # resolved when queued; the lock may end before the action runs)
    queued_external: str | None = None
    # 017: pokemon.teraType (the set's, else the species' first type), pokemon.terastallized
    # (the Tera Type once it terastallized, for the rest of the battle) and
    # stellarBoostedTypes (the types a Stellar Pokémon has already boosted)
    tera_type: str = ""
    terastallized: str | None = None
    stellar_boosted: list[str] = field(default_factory=list)
    focus_energy: bool = False  # 017: the focusenergy volatile (crit ratio +2)
    imprison: bool = False  # 022: the imprison volatile (foes cannot use its moves)
    # 022: the lockedmove volatile (Outrage) is ``timed["lockedmove"]``; its effectState.move
    # and trueDuration (the turns left: random(2, 4), one less at each residual)
    locked_move: str | None = None
    locked_turns: int = 0
    set_base_atk: int = 0  # 033 (R11): the set's species' base Attack (Beat Up)
    fallen: int = 0  # 043-1: Supreme Overlord's effectState.fallen
    unnerved: bool = False  # 043-1: Unnerve / As One's effectState.unnerved
    truant: bool = False  # 043-5c: the truant volatile
    bond_triggered: bool = False  # 043-6c: bondTriggered (Battle Bond)
    disguise_busted: bool = False  # 043-6e: effectState.busted (Disguise / Ice Face)
    hero_shown: bool = False  # 043-6b: heroMessageDisplayed (Zero to Hero)
    trap_hidden: bool = False  # 043-5b: trapped only by a foe's ability (trapped 'hidden')
    klutz_probe: bool = False  # 043-5d: item's guard while it asks ability_id
    protean_used: bool = False  # 043-5c: Protean / Libero's effectState.protean
    used_item_this_turn: bool = False  # 043-5c: usedItemThisTurn (Pickup)
    cud_chew: tuple[str, int] | None = None  # 043-4h: Cud Chew's effectState (berry, counter)
    show_cure: bool | None = None  # 043-1: pokemon.showCure (Natural Cure)
    slow_start: int = 0  # 033 (R12): Slow Start's effectState.counter (turns left)
    # 022: pokemon.lastMoveTargetLoc (a locked move is chosen with it), and the location the
    # queue picked at random for a move chosen without a target (resolveAction)
    last_move_loc: int | None = None
    resolved_loc: int | None = None
    # 023: pokemon.hurtThisTurn (the HP left after damage taken this turn through
    # spreadDamage; None: not hurt) and timesAttacked (hits taken from other Pokemon's
    # moves; kept on switching out)
    hurt_this_turn: int | None = None
    stats_lowered_this_turn: bool = False  # 041-1e: statsLoweredThisTurn (Lash Out)
    smacked_down: bool = False  # 041-2: the smackdown volatile (no duration, noCopy)
    # 041-3a: dragoncheer (its crit ratio bonus: 2 for a Dragon type, else 1; copied by
    # Baton Pass) and defensecurl (noCopy; doubles Rollout)
    dragon_cheer: int = 0
    defense_curl: bool = False
    charge: bool = False  # 041-4e: the charge volatile (Electric power x2)
    gravity: bool = False  # 041-4e: Gravity is up (set on every team member)
    destiny_bond: bool = False  # 041-4e: the destinybond volatile (noCopy)
    # 041-4e: faint()'s source when a move (not a future one) took the last HP
    faint_source: BattlePokemon | None = None
    ate_berry: bool = False  # 041-4e: ateBerry (Belch; kept through switches)
    last_item: str = ""  # 041-6f: lastItem (eatItem / useItem / Fling; Recycle)
    sparkling_aria: bool = False  # 041-6f: the sparklingaria volatile (no condition)
    last_move_used_type: str | None = None  # 041-6f: lastMoveUsed's type (Conversion 2)
    # 041-1e: attackedBy this turn with damage > 0, by id() of the source (Avalanche)
    damaged_by: set[int] = field(default_factory=set)
    # 041-4a: attackedBy's entries from foes (getLastDamagedBy(true), Metal Burst): the
    # source, its slot position, the damage and the turn (thisTurn). nextTurn drops those
    # whose source is no longer active.
    damaged_log: list[tuple[BattlePokemon, int, int, int]] = field(default_factory=list, repr=False)
    # 041-4a: the counter / mirrorcoat volatile's effectState: (side, position, damage)
    # of the last foe's physical / special hit this turn, None for slot === null
    counter_hit: tuple[str, int, int] | None = None
    # 041-4c: the leechseed volatile's sourceSlot (side, position)
    leech_slot: tuple[str, int] | None = None
    # 041-4d: the stockpile volatile (noCopy): [layers, def, spd] (the stages to take back)
    stockpile: list[int] | None = None
    # 027: pokemon.statsRaisedThisTurn (Burning Jealousy; kept on turn 1, cleared on
    # switching out)
    # 041-6c: the tarshot volatile; the stored stats before Power / Guard Split or Speed Swap
    # (setSpecies on clearVolatile computes them again)
    tar_shot: bool = False
    saved_stats: dict[str, int] | None = None
    stats_raised_this_turn: bool = False
    times_attacked: int = 0
    glaive_rush: bool = False  # 023: the glaiverush volatile (no duration)
    minimized: bool = False  # 034 (R5): the minimize volatile (no duration, noCopy)
    # 034 (R6): pokemon.illusion (Illusion: the team member it looks like; None: itself)
    illusion: BattlePokemon | None = field(default=None, repr=False)
    disabled_move: str | None = None  # 023: the disable volatile's effectState.move
    # 024: the partiallytrapped volatile is ``timed["partiallytrapped"]``; its effectState.source
    # (the binder) and sourceEffect (the move id). pokemon.trapped: it cannot switch (set at
    # endTurn by the TrapPokemon event, read by the next move request).
    trap_source: BattlePokemon | None = field(default=None, repr=False)
    trap_move: str | None = None
    trap_divisor: int = 8  # 042-1: effectState.boundDivisor (Binding Band: 6)
    trapped: bool = False
    # 042-1: the metronome volatile (the item's onStart): effectState.lastMove and
    # numConsecutive; None without the volatile
    metronome: tuple[str, int] | None = None
    # 041-3g: the trapped volatile (Block, Mean Look, Spirit Shackle): its source, linked
    # (removed when the source leaves the field); the torment volatile
    trapper: BattlePokemon | None = field(default=None, repr=False)
    torment: bool = False
    gastro_acid: bool = False  # 041-3h: the gastroacid volatile (Baton Pass passes it)
    no_retreat: bool = False  # 041-6d: the noretreat volatile (onTrapPokemon; passed too)
    power_trick: bool = False  # 041-6f: the powertrick volatile (atk and def swapped)
    syrup_source: BattlePokemon | None = None  # 041-6f: syrupbomb's effectState.source
    syrup_triggered: bool = False  # 043-4e: pokemon.syrupTriggered (Supersweet Syrup, once)
    attract_source: BattlePokemon | None = None  # 041-6f: the attract volatile's source
    # 041-6f: Mimic's moveSlots entry over baseMoveSlots: (index, the base slot)
    mimicked: tuple[int, MoveSlot] | None = None
    # 041-6f: pokemon.transformed: what clearVolatile's setSpecies(baseSpecies) and
    # baseMoveSlots give back (species, types, stored stats, move slots)
    # 041-6f: pokemon.set (setSpecies computes the stats from it: Transform's speed)
    pokemon_set: PokemonSet | None = field(default=None, repr=False)
    # 041-6f: baseMoveSlots held back after a transformed Pokémon fainted (its queued action
    # keeps action.move; this engine reads the slot), given back when it switches in
    base_moves: list[MoveSlot] | None = field(default=None, repr=False)
    transform_base: tuple[Species, tuple[str, ...], dict[str, int], list[MoveSlot]] | None = field(
        default=None, repr=False
    )
    lock_on_target: BattlePokemon | None = None  # 041-6f: lockon's effectState.source
    # 028: the commanding volatile (a Tatsugiri in its Dondozo's mouth) and the commanded
    # volatile's source (the Tatsugiri; it stays when that Tatsugiri faints)
    commanding: bool = False
    commanded_by: BattlePokemon | None = field(default=None, repr=False)
    # 029: Neutralizing Gas's abilityState.ending (its End has begun: it suppresses no more;
    # a new abilityState on switching in clears it), and the battle whose field decides
    # whether the gas suppresses this Pokémon's ability (None outside a battle)
    gas_ending: bool = False
    arena: BattleState | None = field(default=None, repr=False)
    # 029: Embody Aspect's effectState.embodied (it boosted once since switching in; a Start
    # again when the gas leaves does nothing)
    embodied: bool = False
    # 042-2: pokemon.swordBoost / shieldBoost (Intrepid Sword, Dauntless Shield: once a battle)
    once_boosted: set[str] = field(default_factory=set)
    # 042-3: terastallized as Morpeko-Hangry (baseSpecies = species, formeRegression)
    hangry_base: bool = False
    # 042-6: Tera Shell's abilityState.resisted (this move resisted already)
    shell_resisted: bool = False

    def set_species(self, species: Species) -> None:
        """042-4: ``setSpecies`` (a forme change not for good): the types, the stats
        from the set (the HP stays) and ``speed`` = storedStats.spe."""
        pset = self.pokemon_set
        assert pset is not None
        nature = get_dex().nature(pset.nature)
        assert nature is not None
        stats = calc_stats(species.base_stats, pset.ivs, pset.evs,
                           pset.level, nature)  # fmt: skip
        self.species = species
        self.base_types = species.types
        self.type_changed = False
        self.added_type = None
        self.apparent_type = species.types if self.terastallized is None else (self.terastallized,)
        self.stats = {**stats, "hp": self.stats["hp"]}
        self.cached_speed = self.stats["spe"]

    def set_base_species(self) -> str:
        """``baseSpecies.baseSpecies``: the set's species, not a Transform's."""
        if self.pokemon_set is None:
            return self.species.base_species
        species = get_dex().species(self.pokemon_set.species)
        return self.species.base_species if species is None else species.base_species

    def update_max_hp(self) -> bool:
        """042-6: ``updateMaxHp`` after a forme change for good: the new forme's HP stat;
        the damage taken stays (at least 1 HP left). True when it changed."""
        pset = self.pokemon_set
        assert pset is not None
        nature = get_dex().nature(pset.nature)
        assert nature is not None
        new = calc_stats(self.species.base_stats, pset.ivs, pset.evs, pset.level, nature)["hp"]
        if new == self.max_hp:
            return False
        self.hp = 0 if self.hp <= 0 else max(1, new - (self.max_hp - self.hp))
        self.max_hp = new
        self.stats = {**self.stats, "hp": new}
        return True

    # 034 (T011): pokemon.apparentType (the types last shown: set by setSpecies, Terastallizing
    # and nextTurn's typechange; a disguised Zoroark shows its disguise's)
    apparent_type: tuple[str, ...] = ()
    type_changed: bool = False  # 041-1g: setType (Double Shock); clearVolatile resets it
    added_type: str | None = None  # 041-6f: addedType (Forest's Curse); setType clears it

    @property
    def types(self) -> tuple[str, ...]:
        """Showdown ``getTypes()``: the Tera Type once terastallized (Stellar keeps its own).
        022: Roost's onType drops Flying (none left: Normal)."""
        if self.terastallized is not None and self.terastallized != STELLAR:
            return (self.terastallized,)
        types = self.base_types
        if "roost" in self.timed:
            types = tuple(t for t in types if t != "Flying") or ("Normal",)
        return (*types, self.added_type) if self.added_type else types

    @property
    def own_types(self) -> tuple[str, ...]:
        """041-6f: ``getTypes(true)``: without the added type."""
        types = self.types
        return types[:-1] if self.added_type and self.terastallized in (None, STELLAR) else types

    @property
    def pinned(self) -> bool:
        """isGrounded's volatiles: Ingrain (041-4c) and Smack Down (041-2); 041-4e: Gravity
        (the field's, checked first)."""
        return self.gravity or self.smacked_down or "ingrain" in self.timed

    @property
    def ability_id(self) -> str:
        """The ability that acts: "" while Mold Breaker ignores it (012; 029: not with an
        Ability Shield, looked at each time as suppressingAbility does) or Neutralizing Gas
        suppresses it (029)."""
        if (self.ability_suppressed and self.item != ABILITY_SHIELD) or self.neutralized:
            return ""
        if self.gastro_acid:  # 041-3h: ignoringAbility's gastroacid
            return ""
        return to_id(self.ability)

    @property
    def neutralized(self) -> bool:
        """029 (R1): Showdown ``ignoringAbility()``'s Neutralizing Gas part. Not its own gas,
        not with an Ability Shield (029, R5), not a commanding Tatsugiri; otherwise suppressed
        while a Pokémon on the field (not fainted) has Neutralizing Gas (its ability itself,
        suppressed or not) whose End has not begun."""
        arena = self.arena
        if arena is None or not arena.gas_possible:
            return False
        if self.item == ABILITY_SHIELD or to_id(self.ability) == NEUTRALIZING_GAS:
            return False
        if self.commanding:
            return False
        return any(
            to_id(p.ability) == NEUTRALIZING_GAS and not p.gas_ending and not p.gastro_acid
            for p in arena.all_active()
        )  # (041-3h: a gas holder under Gastro Acid does not suppress)

    @property
    def base_ability_id(self) -> str:
        """The ability it has (its handlers are still collected and sorted while ignored)."""
        return to_id(self.ability)

    @property
    def item(self) -> str:
        """041-6f: the item whose handlers run: none while Magic Room is up (ignoringItem; its
        handlers are still collected and sorted, from `held_item`)."""
        arena = self.arena
        if arena is not None and MAGIC_ROOM in arena.field.pseudo_weather:
            return ""
        held = self.held_item
        # 043-5d: Klutz (hasAbility: not while suppressed), except the ignoreKlutz items. The
        # probe keeps ability_id's own item checks (Ability Shield) from coming back here.
        if (
            held
            and held not in IGNORE_KLUTZ
            and not self.klutz_probe
            and to_id(self.ability) == "klutz"
        ):
            self.klutz_probe = True
            try:
                klutz = self.ability_id == "klutz"
            finally:
                self.klutz_probe = False
            if klutz:
                return ""
        return held

    @item.setter
    def item(self, value: str) -> None:
        self.held_item = value

    @classmethod
    def from_set(cls, side: str, team_index: int, pokemon_set: PokemonSet) -> BattlePokemon:
        """Build from a set that already passed ``validate_team``."""
        dex = get_dex()
        species = dex.species(pokemon_set.species)
        nature = dex.nature(pokemon_set.nature)
        assert species is not None and nature is not None
        name = pokemon_set.nickname or species.name
        crowned = CROWNED.get((species.id, to_id(pokemon_set.item or "")))
        if crowned is not None:
            # 042-2: onBattleStart (before any switch-in, no message): setSpecies, the
            # baseSpecies too; Iron Head's slot becomes the signature move (the name stays)
            species = dex.species(crowned[0])
            assert species is not None
            pokemon_set = replace(
                pokemon_set,
                moves=tuple(crowned[1] if to_id(m) == "ironhead" else m for m in pokemon_set.moves),
            )
        stats = calc_stats(
            species.base_stats, pokemon_set.ivs, pokemon_set.evs, pokemon_set.level, nature
        )
        moves = []
        for name in pokemon_set.moves:
            move = dex.move(name)
            assert move is not None
            moves.append(MoveSlot(move, max_pp(move), max_pp(move)))
        ability = pokemon_set.ability or species.abilities[0]
        item = dex.item(pokemon_set.item) if pokemon_set.item else None
        return cls(
            side=side,
            team_index=team_index,
            name=name,
            species=species,
            level=pokemon_set.level,
            base_types=species.types,
            stats=stats,
            max_hp=stats["hp"],
            hp=stats["hp"],
            moves=moves,
            ability=ability,
            gender=pokemon_set.gender or species.gender,
            held_item=item.id if item else "",
            nature_minus=nature.minus,
            pokemon_set=pokemon_set,
            tera_type=_tera_type_name(pokemon_set.tera_type) or default_tera_type(species),
            set_base_atk=species.base_stats["atk"],
            apparent_type=species.types,
        )

    @property
    def label(self) -> str:
        """Position label such as ``p1a`` (or the side id when not active)."""
        if self.position is None:
            return self.side
        return self.side + SLOT_NAMES[self.position]

    def __post_init__(self) -> None:
        if self.cached_speed < 0:
            self.cached_speed = self.stats["spe"]  # setSpecies: storedStats.spe
        self.own_ability = self.own_ability or self.ability
        self.set_ability = self.set_ability or self.ability

    def update_speed(self, field_state: FieldState) -> None:
        self.cached_speed = action_speed(self, field_state)

    @property
    def weight_hg(self) -> int:
        """``getWeight``: 033 (R5) Light Metal's onModifyWeight halves it (truncated)."""
        weight = round(self.species.weightkg * 10)
        if self.ability_id == "heavymetal":
            weight *= 2  # 043-2a: onModifyWeightPriority 1
        if self.ability_id == "lightmetal":
            weight //= 2
        if self.item == "floatstone":  # 042-1: onModifyWeight trunc(weighthg / 2)
            weight //= 2
        return max(1, weight)

    def combatant(self, field_state: FieldState | None = None) -> Combatant:
        """``field_state``: given for a damage roll (getStat("spe"), Gyro Ball, 021)."""
        return Combatant(
            level=self.level,
            types=self.types,
            base_types=self.base_types,
            tera=self.terastallized,
            stellar_boosted=frozenset(self.stellar_boosted),
            species=self.species.name,
            pikachu=self.set_base_species() == "Pikachu",
            # 041-6f: calculateStat under Wonder Room (a damage roll)
            stats=wonder_swapped(
                self.stats, field_state is not None and WONDER_ROOM in field_state.pseudo_weather
            ),
            wonder_room=field_state is not None and WONDER_ROOM in field_state.pseudo_weather,
            tar_shot=self.tar_shot,
            burned=self.status == "brn",
            boosts=dict(self.boosts),
            ability=self.ability_id,
            booster=None if self.neutralized else self.booster_stat,  # 029
            statused=self.status is not None,
            flash_fire=self.flash_fire,
            full_hp=self.hp >= self.max_hp,
            item=self.item,
            holds_item=bool(self.held_item),
            nfe=self.species.nfe,
            item_takeable=can_be_taken(self.held_item, self.species),
            status=self.status,
            hp=self.hp,
            max_hp=self.max_hp,
            weight_hg=self.weight_hg,
            speed=stat_speed(self, field_state) if field_state is not None else 0,
            failed_last_turn=self.move_last_turn_result is False,
            hurt_this_turn=bool(self.hurt_this_turn),
            stats_lowered=self.stats_lowered_this_turn,
            smacked_down=self.pinned,  # 041-4c: Ingrain too
            rising="magnetrise" in self.timed,  # 041-6f
            times_attacked=self.times_attacked,
            slow_start=self.slow_start > 0 and self.ability_id == SLOW_START,
            fresh=self.active_turns == 0,  # 043-2a
            gender="" if self.gender in (None, "N") else self.gender,
        )

    def reset_boosts(self) -> None:
        for name in self.boosts:
            self.boosts[name] = 0


MAX_SPEED = 10000  # getStat caps speed; Trick Room reverses it against this value


def stat_speed(pokemon: BattlePokemon, field_state: FieldState) -> int:
    """Showdown ``getStat('spe')``: the stat with its stage, Tailwind's x2 (chained), then
    paralysis (which applies the chained modifiers first), capped at 10000 (021: split out of
    ``action_speed`` for Gyro Ball)."""
    speed = boosted_stat(pokemon.stats["spe"], pokemon.boosts["spe"])
    # A fainted Pokémon is no longer active, so runEvent finds no ModifySpe handlers for it
    # (no Tailwind, no paralysis); Trick Room is applied by getActionSpeed itself.
    if not pokemon.fainted:
        # runEvent('ModifySpe'): Tailwind x2 and Protosynthesis/Quark Drive x1.5 chained
        # (011); paralysis (priority -101) applies the chain first (finalModify), then halves.
        modifier = 4096
        if field_state.has_side(pokemon.side, TAILWIND):
            modifier = chain_modify(modifier, 2)
        if field_state.has_side(pokemon.side, GRASS_PLEDGE):
            modifier = chain_modify(modifier, 1, 4)  # 041-5: the swamp's onModifySpe
        # A Pokémon not yet on the field (the 'team' actions before the leads come in) has
        # its ability and item ignored (ignoringAbility / ignoringItem: not isActive).
        active = pokemon.position is not None
        # (029: the volatile's onModifySpe does nothing while ignoringAbility())
        if pokemon.booster_stat == "spe" and not pokemon.neutralized:
            modifier = chain_modify(modifier, *BOOSTER_SPEED)
        weather = effective_weather(field_state.active_weather, pokemon.item if active else "")
        if active and weather_speed(pokemon.ability_id, weather):
            modifier = chain_modify(modifier, 2)  # Chlorophyll, Swift Swim, ... (012)
        if active and pokemon.slow_start and pokemon.ability_id == SLOW_START:
            modifier = chain_modify(modifier, 1, 2)  # 033 (R12): Slow Start onModifySpe
        if pokemon.unburden and not pokemon.held_item and pokemon.ability_id == "unburden":
            modifier = chain_modify(modifier, 2)  # the unburden volatile (013)
        if active and pokemon.ability_id == "quickfeet" and pokemon.status:
            modifier = chain_modify(modifier, 3, 2)  # 043-2b: Quick Feet onModifySpe
        if (
            active
            and pokemon.ability_id == "surgesurfer"
            and field_state.terrain == "electricterrain"
        ):
            modifier = chain_modify(modifier, 2)  # 043-2b: Surge Surfer onModifySpe
        if active and pokemon.item == "choicescarf":
            modifier = chain_modify(modifier, 3, 2)  # 013
        if active and pokemon.item in HALF_SPEED_ITEMS:
            modifier = chain_modify(modifier, 1, 2)  # 032 (R3): Power Band, Iron Ball
        if modifier != 4096:
            speed = modify(speed, modifier, 4096)
        if pokemon.status == "par" and not (active and pokemon.ability_id == "quickfeet"):
            speed = speed * 50 // 100  # (043-2b: not with Quick Feet)
    return min(speed, MAX_SPEED)


def action_speed(pokemon: BattlePokemon, field_state: FieldState) -> int:
    """Showdown ``getActionSpeed``: ``getStat('spe')``; Trick Room turns it into
    10000 - speed; truncated to 13 bits."""
    speed = stat_speed(pokemon, field_state)
    if field_state.trick_room:
        speed = MAX_SPEED - speed
    return speed % (1 << 13)


@dataclass(slots=True)
class SideState:
    id: str
    team: list[BattlePokemon]  # the full submitted team
    brought: list[BattlePokemon] = field(default_factory=list)  # chosen at preview, leads first
    # Showdown ``side.pokemon``: starts as ``brought``; a switch swaps the two Pokémon's places.
    # The bench (and so the random AI's switch choices) follows this order.
    order: list[BattlePokemon] = field(default_factory=list)
    active: list[BattlePokemon | None] = field(default_factory=lambda: [None] * ACTIVE_PER_SIDE)
    tera_used: bool = False  # 017: a Pokémon on this side has terastallized
    total_fainted: int = 0  # 023: side.totalFainted (Last Respects; at most 100)
    fainted_this_turn: bool = False  # 041-1e: side.faintedThisTurn / faintedLastTurn
    fainted_last_turn: bool = False

    def can_terastallize(self) -> bool:
        return not self.tera_used

    def bench(self) -> list[BattlePokemon]:
        """Brought Pokémon that can still switch in, in Showdown's ``side.pokemon`` order."""
        if not self.order:
            self.order = list(self.brought)
        return [p for p in self.order if not p.fainted and p.position is None]

    def pokemon_left(self) -> int:
        return sum(not p.fainted for p in self.brought)

    def alive_active(self) -> list[BattlePokemon]:
        return [p for p in self.active if p is not None and not p.fainted]


@dataclass(slots=True)
class BattleState:
    sides: dict[str, SideState]
    turn: int = 0
    ended: bool = False
    winner: str | None = None  # side id; None with ended=True means a tie (or aborted)
    # 014: a switch request made by switch flags only (in the middle of a turn, or after the
    # replacements); fainted Pokémon are replaced only at the end of the turn
    flag_request: bool = False
    field: FieldState = field(default_factory=FieldState)
    # 029: a Pokémon in the battle has Neutralizing Gas (it cannot be gained: failskillswap),
    # so ``BattlePokemon.neutralized`` has to look at the field
    gas_possible: bool = False

    def at(self, side: str, position: int) -> BattlePokemon | None:
        return self.sides[side].active[position]

    def all_active(self) -> list[BattlePokemon]:
        return [p for s in SIDE_IDS for p in self.sides[s].alive_active()]
