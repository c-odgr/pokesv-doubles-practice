"""Evaluate a team against the imported tournament teams (019).

Each pairing is ``simulate`` run twice, half the battles with the own team as p1 and half as p2,
each half with its own seed (``pair_seed``), so any pairing can be replayed on its own (SC-001).
"""

from __future__ import annotations

import hashlib
import os
import re
import unicodedata
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from functools import cached_property
from typing import Any

from pokesv_sim.analysis.simulate import (
    BattleRecord,
    PlayerFactory,
    PokemonResult,
    SidePlayers,
    simulate,
    species_name,
)
from pokesv_sim.analysis.stats import wilson_interval
from pokesv_sim.dex import get_dex
from pokesv_sim.players import Player, RandomPlayer
from pokesv_sim.prng import Seed
from pokesv_sim.regf_teams import REGF_PREFIX, RegfTeam, get_regf_team, regf_teams, status
from pokesv_sim.runner import check_teams
from pokesv_sim.team import Team

POSITIONS = ("p1", "p2")
DEFAULT_TERA = 0.3  # the AIs' chance to terastallize, as in 018's crosscheck pairs


def random_preview_player(words: Seed, side: str, tera: float) -> Player:
    """019's AI: Showdown's random AI choosing four at random at team preview (spec Assumptions;
    the crosscheck's ``random`` preview)."""
    return RandomPlayer(words, tera=tera, random_preview=True)


def pair_seed(seed: int, own_label: str, opponent: str, position: str) -> int:
    """The seed of one half of a pairing: the first 8 bytes of sha256 of the four, big-endian."""
    text = f"{seed}:{own_label}:{opponent}:{position}"
    return int.from_bytes(hashlib.sha256(text.encode("utf-8")).digest()[:8], "big")


type Members = tuple[tuple[int, PokemonResult], ...]  # (team index, result), by team index


@dataclass(frozen=True, slots=True)
class BattleDigest:
    """One battle seen from the own team's side."""

    position: str  # the own team's side, "p1" or "p2"
    result: str  # "win", "loss", "tie" or "aborted"
    turns: int
    own_leads: tuple[int, ...]
    own: Members  # the own team's brought Pokémon
    foe: Members


def digest(record: BattleRecord, position: str) -> BattleDigest:
    foe_side = "p2" if position == "p1" else "p1"
    if record.aborted:
        result = "aborted"
    elif record.winner == position:
        result = "win"
    elif record.winner == foe_side:
        result = "loss"
    else:
        result = "tie"

    def members(side: str) -> Members:
        return tuple(sorted((i, p) for (s, i), p in record.per_pokemon.items() if s == side))

    return BattleDigest(
        position=position,
        result=result,
        turns=record.turns,
        own_leads=record.leads.get(position, ()),
        own=members(position),
        foe=members(foe_side),
    )


@dataclass(frozen=True, slots=True)
class Tally:
    n: int
    wins: int
    losses: int
    ties: int
    aborted: int

    @property
    def win_rate(self) -> float:
        return self.wins / self.n if self.n else 0.0

    @property
    def ci(self) -> tuple[float, float]:
        return wilson_interval(self.wins, self.n)


def tally(battles: Iterable[BattleDigest]) -> Tally:
    results = [b.result for b in battles]
    return Tally(
        n=len(results),
        wins=results.count("win"),
        losses=results.count("loss"),
        ties=results.count("tie"),
        aborted=results.count("aborted"),
    )


@dataclass(frozen=True)
class PairResult:
    """The own team against one opponent: ``n`` battles, the first half as p1."""

    opponent: str  # the opponent's label (an imported team's ID)
    battles: tuple[BattleDigest, ...]

    @cached_property
    def total(self) -> Tally:
        return tally(self.battles)

    @property
    def n(self) -> int:
        return self.total.n

    @property
    def wins(self) -> int:
        return self.total.wins

    @property
    def losses(self) -> int:
        return self.total.losses

    @property
    def ties(self) -> int:
        return self.total.ties

    @property
    def aborted(self) -> int:
        return self.total.aborted

    @property
    def win_rate(self) -> float:
        return self.total.win_rate

    @cached_property
    def by_position(self) -> Mapping[str, Tally]:
        return {p: tally(b for b in self.battles if b.position == p) for p in POSITIONS}


def play_pair(
    own: Team,
    own_label: str,
    opponent: Team,
    opponent_label: str,
    n: int,
    seed: int,
    tera: float = DEFAULT_TERA,
    player_factory: PlayerFactory = random_preview_player,
    opponent_factory: PlayerFactory | None = None,
) -> PairResult:
    """``n`` battles (even): ``n / 2`` with ``own`` as p1, then ``n / 2`` as p2.
    ``opponent_factory``: the opponent's AI, if not ``player_factory``'s (035 FR-008).

    Raises ``ValueError`` for an odd ``n``, and ``TeamInvalidError`` / ``UnsupportedError``
    before any battle.
    """
    if n % 2:
        raise ValueError(f"the number of battles must be even (each position plays half): {n}")
    check_teams(own, opponent)
    half = n // 2
    first: PlayerFactory = player_factory
    second: PlayerFactory = player_factory
    if opponent_factory is not None:
        first = SidePlayers(player_factory, opponent_factory)
        second = SidePlayers(opponent_factory, player_factory)
    as_p1 = simulate(
        own, opponent, half, pair_seed(seed, own_label, opponent_label, "p1"), tera, first
    )
    as_p2 = simulate(
        opponent, own, half, pair_seed(seed, own_label, opponent_label, "p2"), tera, second
    )
    return PairResult(
        opponent=opponent_label,
        battles=tuple([digest(r, "p1") for r in as_p1] + [digest(r, "p2") for r in as_p2]),
    )


# --- the field ---------------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Excluded:
    id: str
    reasons: tuple[str, ...]  # the team's errors, Reg F problems and unsupported items


@dataclass(frozen=True, slots=True)
class Field:
    teams: tuple[RegfTeam, ...]  # by ID
    excluded: tuple[Excluded, ...]  # picked by the filters but unable to battle, by ID


def placing_number(placing: str) -> int | None:
    """``"22nd"`` -> 22."""
    m = re.match(r"\d+", placing)
    return int(m.group()) if m else None


def select_field(
    period: str | None = None,
    max_placing: int | None = None,
    ids: Iterable[str] | None = None,
) -> Field:
    """The imported teams that can battle, filtered by period, placing and IDs (FR-002).

    Teams the filters pick but that cannot battle go to ``excluded`` with their reasons.
    Raises ``KeyError`` for an unknown ID.
    """
    if ids is None:
        picked = list(regf_teams())
    else:
        found = []
        for i in ids:
            t = get_regf_team(i)
            if t is None:
                raise KeyError(f"no imported team {i.removeprefix(REGF_PREFIX)!r}")
            found.append(t)
        picked = sorted({t.id: t for t in found}.values(), key=lambda t: t.id)
    teams: list[RegfTeam] = []
    excluded: list[Excluded] = []
    for t in picked:
        if period is not None and t.period != period:
            continue
        if max_placing is not None:
            place = placing_number(t.placing)
            if place is None or place > max_placing:
                continue
        s = status(t.id)
        if s.runnable:
            teams.append(t)
        else:
            excluded.append(Excluded(t.id, s.errors + s.regulation + s.unsupported))
    return Field(tuple(teams), tuple(excluded))


# --- loss patterns (spec US2) ------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class FoeRow:
    """A foe species: how the own team fares in the battles where it is brought."""

    species: str
    brought: int  # battles it was brought to
    win_rate: float  # the own team's win rate in those battles
    delta: float  # win_rate minus the overall win rate (lowest: the most harmful)
    knockouts: int  # own Pokémon it knocked out
    damage_mean: float  # damage it dealt per battle it was brought to


@dataclass(frozen=True, slots=True)
class OwnSplit:
    """An own Pokémon over the battles of one result that it was brought to."""

    battles: int
    sent_in: int
    fainted: int
    first_fainted: int  # battles in which it was the first of its side to faint
    knockouts: int
    damage_mean: float


@dataclass(frozen=True, slots=True)
class OwnRow:
    team_index: int
    species: str
    win: OwnSplit
    loss: OwnSplit


@dataclass(frozen=True, slots=True)
class LeadRow:
    leads: tuple[int, ...]  # own team indices, sorted
    species: tuple[str, ...]
    battles: int
    wins: int

    @property
    def win_rate(self) -> float:
        return self.wins / self.battles if self.battles else 0.0


@dataclass(frozen=True, slots=True)
class LossPatterns:
    win_rate: float  # over every battle counted
    foes: tuple[FoeRow, ...]  # lowest delta first
    own: tuple[OwnRow, ...]  # by team index
    leads: tuple[LeadRow, ...]  # lowest win rate first

    def to_dict(self) -> dict[str, Any]:
        return {
            "win_rate": _r(self.win_rate),
            "foes": [
                {"species": f.species, "brought": f.brought, "win_rate": _r(f.win_rate),
                 "delta": _r(f.delta), "knockouts": f.knockouts,
                 "damage_mean": _r(f.damage_mean)}
                for f in self.foes
            ],
            "own": [
                {"team_index": o.team_index, "species": o.species,
                 "win": _split_dict(o.win), "loss": _split_dict(o.loss)}
                for o in self.own
            ],
            "leads": [
                {"leads": list(lr.leads), "species": list(lr.species), "battles": lr.battles,
                 "wins": lr.wins, "win_rate": _r(lr.win_rate)}
                for lr in self.leads
            ],
        }  # fmt: skip


def _split_dict(s: OwnSplit) -> dict[str, Any]:
    return {
        "battles": s.battles,
        "sent_in": s.sent_in,
        "fainted": s.fainted,
        "first_fainted": s.first_fainted,
        "knockouts": s.knockouts,
        "damage_mean": _r(s.damage_mean),
    }


def _split(results: list[PokemonResult]) -> OwnSplit:
    return OwnSplit(
        battles=len(results),
        sent_in=sum(p.sent_in for p in results),
        fainted=sum(p.fainted for p in results),
        first_fainted=sum(p.faint_order == 1 for p in results),
        knockouts=sum(p.knockouts for p in results),
        damage_mean=sum(p.damage for p in results) / len(results) if results else 0.0,
    )


def loss_patterns(
    own: Team, pairs: Iterable[PairResult], opponents: Mapping[str, Team]
) -> LossPatterns:
    """What happens in the battles of ``pairs`` (spec US2). ``opponents``: label -> team.

    Ties and aborted battles count in the win rates (as non-wins) but in neither split of
    ``own``.
    """
    battles = [(opponents[p.opponent], b) for p in pairs for b in p.battles]
    overall = sum(b.result == "win" for _, b in battles) / len(battles) if battles else 0.0

    foe: dict[str, list[tuple[bool, PokemonResult]]] = {}
    mine: dict[int, dict[str, list[PokemonResult]]] = {}
    leads: dict[tuple[int, ...], list[bool]] = {}
    for team, b in battles:
        won = b.result == "win"
        for i, p in b.foe:
            foe.setdefault(species_name(team, i), []).append((won, p))
        for i, p in b.own:
            mine.setdefault(i, {"win": [], "loss": []})
            if b.result in ("win", "loss"):
                mine[i][b.result].append(p)
        leads.setdefault(tuple(sorted(b.own_leads)), []).append(won)

    foe_rows = []
    for species, rows in foe.items():
        rate = sum(won for won, _ in rows) / len(rows)
        foe_rows.append(
            FoeRow(
                species=species,
                brought=len(rows),
                win_rate=rate,
                delta=rate - overall,
                knockouts=sum(p.knockouts for _, p in rows),
                damage_mean=sum(p.damage for _, p in rows) / len(rows),
            )
        )
    foe_rows.sort(key=lambda r: (r.delta, -r.brought, r.species))
    own_rows = tuple(
        OwnRow(i, species_name(own, i), _split(s["win"]), _split(s["loss"]))
        for i, s in sorted(mine.items())
    )
    lead_rows = sorted(
        (
            LeadRow(k, tuple(species_name(own, i) for i in k), len(v), sum(v))
            for k, v in leads.items()
        ),
        key=lambda r: (r.win_rate, -r.battles, r.leads),
    )
    return LossPatterns(overall, tuple(foe_rows), own_rows, tuple(lead_rows))


# --- the whole evaluation ----------------------------------------------------------------------

type Progress = Callable[[int, int], None]  # (pairings done, pairings in all)


@dataclass(frozen=True)
class Evaluation:
    """The own team against every team of a field (spec US1)."""

    own_label: str
    own: Team
    field: Field
    n: int  # battles per opponent
    seed: int
    tera: float
    ai: str  # the player factory's name
    pairs: tuple[PairResult, ...]  # by opponent ID

    @cached_property
    def total(self) -> Tally:
        return tally(b for p in self.pairs for b in p.battles)

    @cached_property
    def by_position(self) -> Mapping[str, Tally]:
        return {
            pos: tally(b for p in self.pairs for b in p.battles if b.position == pos)
            for pos in POSITIONS
        }

    def to_dict(self) -> dict[str, Any]:
        """Fixed key order, rates rounded to 4 places (SC-002)."""
        return {
            "own": self.own_label,
            "n": self.n,
            "seed": self.seed,
            "tera": self.tera,
            "ai": self.ai,
            "field": {
                "teams": len(self.field.teams),
                "excluded": [{"id": e.id, "reasons": list(e.reasons)} for e in self.field.excluded],
            },
            "total": _tally_dict(self.total),
            "by_position": {pos: _tally_dict(t) for pos, t in self.by_position.items()},
            "opponents": [
                {
                    "id": p.opponent,
                    **_tally_dict(p.total),
                    "by_position": {pos: _tally_dict(t) for pos, t in p.by_position.items()},
                }
                for p in self.pairs
            ],
            "loss_patterns": self.loss_patterns().to_dict(),
        }

    def loss_patterns(self, opponent: str | None = None) -> LossPatterns:
        """Over the whole field, or against one opponent (spec US2 scene 2)."""
        pairs = [p for p in self.pairs if opponent is None or p.opponent == opponent]
        if opponent is not None and not pairs:
            raise KeyError(f"no opponent {opponent!r} in this evaluation")
        return loss_patterns(self.own, pairs, {t.id: t.team for t in self.field.teams})


def _r(x: float) -> float:
    return round(x, 4)


def _tally_dict(t: Tally) -> dict[str, Any]:
    return {
        "n": t.n,
        "wins": t.wins,
        "losses": t.losses,
        "ties": t.ties,
        "aborted": t.aborted,
        "win_rate": _r(t.win_rate),
        "ci": [_r(x) for x in t.ci],
    }


def _play_job(
    own: Team,
    own_label: str,
    opponent: Team,
    opponent_label: str,
    n: int,
    seed: int,
    tera: float,
    player_factory: PlayerFactory,
    opponent_factory: PlayerFactory | None = None,
) -> PairResult:
    """One pairing in a worker process (module level, so it can be pickled)."""
    return play_pair(
        own, own_label, opponent, opponent_label, n, seed, tera, player_factory, opponent_factory
    )


def play_all(
    own: Team,
    own_label: str,
    opponents: Sequence[tuple[str, Team]],
    n: int,
    seed: int,
    tera: float = DEFAULT_TERA,
    jobs: int | None = None,
    progress: Progress | None = None,
    player_factory: PlayerFactory = random_preview_player,
    opponent_factory: PlayerFactory | None = None,
) -> tuple[PairResult, ...]:
    """``play_pair`` against each ``(label, team)``, in ``jobs`` processes (default: one per
    CPU; 1: in this process). The results come back in the order of ``opponents``, whatever
    the order they finish in, so the outcome does not depend on ``jobs`` (FR-003)."""
    pairings = [(own, own_label, team, label) for label, team in opponents]
    return _play_pairings(pairings, n, seed, tera, jobs, progress, player_factory, opponent_factory)


type Pairing = tuple[Team, str, Team, str]  # own, own label, opponent, opponent label


def _play_pairings(
    pairings: Sequence[Pairing],
    n: int,
    seed: int,
    tera: float,
    jobs: int | None,
    progress: Progress | None,
    player_factory: PlayerFactory,
    opponent_factory: PlayerFactory | None = None,
) -> tuple[PairResult, ...]:
    """Check everything first, then play, in parallel unless ``jobs`` is 1; in input order."""
    if n % 2:
        raise ValueError(f"the number of battles must be even (each position plays half): {n}")
    for own, _, opponent, _ in pairings:
        check_teams(own, opponent)
    args = [(*p, n, seed, tera, player_factory, opponent_factory) for p in pairings]
    total = len(args)
    results: list[PairResult | None] = [None] * total
    workers = jobs if jobs is not None else (os.cpu_count() or 1)
    if workers <= 1 or total <= 1:
        for i, a in enumerate(args):
            results[i] = _play_job(*a)
            if progress:
                progress(i + 1, total)
    else:
        # 056: imported here, as the offline version's Python (in the browser) has no processes
        from concurrent.futures import ProcessPoolExecutor, as_completed

        with ProcessPoolExecutor(max_workers=min(workers, total)) as pool:
            futures = {pool.submit(_play_job, *a): i for i, a in enumerate(args)}
            for done, future in enumerate(as_completed(futures), 1):
                results[futures[future]] = future.result()
                if progress:
                    progress(done, total)
    return tuple(r for r in results if r is not None)


def evaluate(
    own: Team,
    own_label: str,
    field: Field,
    n: int,
    seed: int,
    tera: float = DEFAULT_TERA,
    jobs: int | None = None,
    progress: Progress | None = None,
    player_factory: PlayerFactory = random_preview_player,
    opponent_factory: PlayerFactory | None = None,
) -> Evaluation:
    """``own`` against every team of ``field``, ``n`` battles each (FR-001).

    Raises ``ValueError`` for an odd ``n`` and ``TeamInvalidError`` / ``UnsupportedError`` for
    the own team, before any battle (FR-006).
    """
    pairs = play_all(
        own,
        own_label,
        [(t.id, t.team) for t in field.teams],
        n,
        seed,
        tera,
        jobs,
        progress,
        player_factory,
        opponent_factory,
    )
    return Evaluation(
        own_label=own_label,
        own=own,
        field=field,
        n=n,
        seed=seed,
        tera=tera,
        ai=_ai_name(player_factory, opponent_factory),
        pairs=pairs,
    )


def _ai_name(player_factory: PlayerFactory, opponent_factory: PlayerFactory | None = None) -> str:
    own = getattr(player_factory, "__name__", repr(player_factory))
    if opponent_factory is None:
        return own
    return f"{own} vs {getattr(opponent_factory, '__name__', repr(opponent_factory))}"


# --- candidates against each other (spec US3) --------------------------------------------------

MAX_CANDIDATES = 10


def _flip(t: Tally) -> Tally:
    return Tally(t.n, t.losses, t.wins, t.ties, t.aborted)


@dataclass(frozen=True)
class RoundRobin:
    """Every pair of candidates played once: ``pairs[(i, j)]`` with ``i < j`` is candidate
    ``i`` against ``j``; ``(j, i)`` is read from the same battles."""

    labels: tuple[str, ...]
    teams: tuple[Team, ...]
    n: int
    seed: int
    tera: float
    ai: str
    pairs: Mapping[tuple[int, int], PairResult]

    def tally(self, i: int, j: int) -> Tally:
        """Candidate ``i`` against ``j``."""
        if i == j:
            raise ValueError("a candidate does not play itself here")
        return self.pairs[(i, j)].total if i < j else _flip(self.pairs[(j, i)].total)

    def win_rate(self, i: int, j: int) -> float:
        return self.tally(i, j).win_rate

    def to_dict(self) -> dict[str, Any]:
        k = len(self.labels)
        return {
            "candidates": list(self.labels),
            "n": self.n,
            "seed": self.seed,
            "tera": self.tera,
            "ai": self.ai,
            "win_rates": [
                [None if i == j else _r(self.win_rate(i, j)) for j in range(k)] for i in range(k)
            ],
            "pairs": [
                {"own": self.labels[i], "opponent": self.labels[j], **_tally_dict(p.total)}
                for (i, j), p in sorted(self.pairs.items())
            ],
        }


def round_robin(
    candidates: Sequence[tuple[str, Team]],
    n: int,
    seed: int,
    tera: float = DEFAULT_TERA,
    jobs: int | None = None,
    progress: Progress | None = None,
    player_factory: PlayerFactory = random_preview_player,
) -> RoundRobin:
    """Candidates ``(label, team)``, 2 to 10 with distinct labels, against each other (FR-005)."""
    labels = [label for label, _ in candidates]
    if not 2 <= len(candidates) <= MAX_CANDIDATES:
        raise ValueError(f"give 2 to {MAX_CANDIDATES} candidates, not {len(candidates)}")
    if len(set(labels)) != len(labels):
        raise ValueError(f"candidate labels must be distinct: {labels}")
    keys = [(i, j) for i in range(len(candidates)) for j in range(i + 1, len(candidates))]
    pairings = [(*candidates[i][::-1], *candidates[j][::-1]) for i, j in keys]
    results = _play_pairings(pairings, n, seed, tera, jobs, progress, player_factory)
    return RoundRobin(
        labels=tuple(labels),
        teams=tuple(t for _, t in candidates),
        n=n,
        seed=seed,
        tera=tera,
        ai=_ai_name(player_factory),
        pairs=dict(zip(keys, results, strict=True)),
    )


# --- the human-readable report (FR-007) --------------------------------------------------------


def ja(species: str) -> str:
    """The Japanese name from the dex, or the name as given."""
    s = get_dex().species(species)
    return (s.name_ja or s.name) if s else species


def _pad(text: str, width: int) -> str:
    """Left-aligned in ``width`` terminal cells (full-width characters take two)."""
    cells = sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in text)
    return text + " " * max(0, width - cells)


def _pct(x: float) -> str:
    return f"{x:.1%}"


def _ci(t: Tally) -> str:
    lo, hi = t.ci
    return f"{lo:.1%}-{hi:.1%}"


def format_evaluation(ev: Evaluation, top: int = 20) -> str:
    """Overall and per-position win rates, the hardest opponents and the loss patterns."""
    t = ev.total
    teams = {f.id: f for f in ev.field.teams}
    lines = [
        f"{ev.own_label}: {len(ev.pairs)} opponents x {ev.n} battles = {t.n} battles "
        f"(AI {ev.ai}, tera {ev.tera:g}, seed {ev.seed})",
        f"win rate {_pct(t.win_rate)} (95% CI {_ci(t)}); wins {t.wins} / losses {t.losses} / "
        f"ties {t.ties} / aborted {t.aborted}",
        "by position: "
        + " / ".join(f"as {p} {_pct(x.win_rate)} ({x.n})" for p, x in ev.by_position.items()),
    ]
    if ev.field.excluded:
        lines.append(f"left out: {len(ev.field.excluded)} teams that cannot battle")
    rows = sorted(ev.pairs, key=lambda p: (p.win_rate, p.opponent))[:top]
    lines.append(f"hardest opponents (lowest win rate first, {len(rows)} of {len(ev.pairs)}):")
    for p in rows:
        opp = teams.get(p.opponent)
        place = opp.placing if opp else ""
        names = " / ".join(ja(m.species) for m in opp.team.members) if opp else ""
        lines.append(
            f"  {_pct(p.win_rate):>6}  {_ci(p.total):>11}  {p.opponent}  {place:>5}  {names}"
        )
    lines.append(format_loss_patterns(ev.loss_patterns(), top))
    return "\n".join(lines)


def format_loss_patterns(lp: LossPatterns, top: int = 20) -> str:
    lines = [
        f"foe Pokémon, most harmful first ({min(top, len(lp.foes))} of {len(lp.foes)}; "
        "win rate when brought, difference from the overall rate):",
        "  species                brought   win%    diff   KOs  damage",
    ]
    for f in lp.foes[:top]:
        lines.append(
            f"  {_pad(ja(f.species), 20)} {f.brought:8d} {_pct(f.win_rate):>6} {f.delta:+7.1%}"
            f" {f.knockouts:5d} {f.damage_mean:7.1f}"
        )
    lines += [
        "own Pokémon (won / lost battles it was brought to):",
        "  species                brought    sent in    fainted   1st down       KOs     damage",
    ]
    for o in lp.own:
        w, x = o.win, o.loss
        lines.append(
            f"  {_pad(ja(o.species), 20)} {w.battles:5d}/{x.battles:<5d}"
            f"{w.sent_in:5d}/{x.sent_in:<5d}{w.fainted:5d}/{x.fainted:<5d}"
            f"{w.first_fainted:5d}/{x.first_fainted:<5d}{w.knockouts:5d}/{x.knockouts:<5d}"
            f"{w.damage_mean:5.0f}/{x.damage_mean:<5.0f}"
        )
    lines.append("own leads (lowest win rate first):")
    for lr in lp.leads[:top]:
        names = " + ".join(ja(s) for s in lr.species)
        lines.append(f"  {_pct(lr.win_rate):>6}  {lr.battles:6d}  {names}")
    return "\n".join(lines)


def format_round_robin(rr: RoundRobin) -> str:
    k = len(rr.labels)
    lines = [
        f"round robin: {k} candidates, {rr.n} battles per pair (row: own, column: opponent)",
        "  " + " " * 4 + "".join(f"{j + 1:>8}" for j in range(k)),
    ]
    for i, label in enumerate(rr.labels):
        cells = "".join(
            f"{'-':>8}" if i == j else f"{_pct(rr.win_rate(i, j)):>8}" for j in range(k)
        )
        lines.append(f"  {i + 1:>2}. {cells}  {label}")
    return "\n".join(lines)
