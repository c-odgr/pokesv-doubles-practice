"""036: the search AI. It is given only its side's view (constitution VII); the battles it
plays ahead are its own, built from that view and its guesses (``world``).

Each turn (plan R2, R3): its own candidates are the smart AI's best pairs; on each hypothetical
battle (one per rank of the foe guesses, weighted), the foe's candidates are the pairs the smart
AI would score best from the foe's side, each with a probability (softmax of their scores; every
pair of 1% or more counts, and the best pair with a status move is always a candidate). Each own
candidate's value is the expected leaf value over the worlds and the foe's pairs, after playing
the turn (and ``depth - 1`` more turns of both sides' smart AIs). The best one is chosen.
"""

from __future__ import annotations

import copy
import math
import time
from collections.abc import Sequence
from dataclasses import dataclass

from pokesv_sim.ai import SmartPlayer
from pokesv_sim.ai.belief import Beliefs
from pokesv_sim.ai.player import scored_pairs
from pokesv_sim.ai.score import Evaluator
from pokesv_sim.battle import Battle
from pokesv_sim.choices import (
    Choice,
    MoveChoice,
    PassChoice,
    Preview,
    SwitchChoice,
    legal_move_choices,
)
from pokesv_sim.dex import get_dex
from pokesv_sim.players import seed_words
from pokesv_sim.prng import Prng, Seed
from pokesv_sim.search.leaf import LEAVES, LeafEval
from pokesv_sim.search.world import World, WorldError, build_world
from pokesv_sim.view import SideView, side_view

type Option = MoveChoice | SwitchChoice | None
type Pair = tuple[Option, ...]

MIN_SHARE = 0.01  # a foe pair this likely or more counts (依頼者 2026-11-16)


@dataclass(frozen=True, slots=True)
class Settings:
    own: int = 4  # own candidate pairs
    foe: int = 6  # foe candidate pairs (before the status-move pair)
    worlds: int = 2  # ranks of the foe guesses tried
    depth: int = 1  # turns played ahead (the later ones by both sides' smart AIs)
    temperature: float = 0.1  # of the softmax over the foe pairs' scores
    time_limit: float = 2.0  # seconds per decision; past it, what was computed decides
    solve: str = "expect"  # "expect" (foe pairs by probability) or "regret" (equilibrium)
    rolls: int = 1  # times each cell is played, each with its own random numbers
    leaf: str = "fitted"  # the leaf evaluation by name (``leaf.LEAVES``; 037 T004)


class SearchPlayer:
    """Team preview and replacements as the smart AI (035); each turn's choice by search."""

    def __init__(
        self, seed: int | Seed, settings: Settings | None = None, leaf: LeafEval | None = None
    ) -> None:
        self.smart = SmartPlayer(seed)
        words = seed_words(seed)
        self.prng = Prng((words[0] ^ 0x5EA7, words[1], words[2], words[3] ^ 0x036))
        self.settings = settings or Settings()
        self.leaf = leaf or LEAVES[self.settings.leaf]
        self.fallbacks = 0  # decisions left to the smart AI (no world, an engine error)
        self.decisions = 0
        self.seconds = 0.0
        self.cancelled = False  # 039: set from outside to cut a search short
        # 038: (turn, the search's choice, the smart AI's) for each turn decided
        self.history: list[tuple[int, list[Choice], list[Choice]]] = []

    def choose_preview(self, view: SideView) -> Preview:
        return self.smart.choose_preview(view)

    def choose_replacements(
        self, view: SideView, need: Sequence[bool]
    ) -> list[SwitchChoice | PassChoice]:
        return self.smart.choose_replacements(view, need)

    def choose_turn(
        self, view: SideView, legal: Sequence[Sequence[MoveChoice | SwitchChoice]]
    ) -> list[Choice]:
        start = time.perf_counter()
        fallback = self.smart.choose_turn(view, legal)  # also keeps its knowledge up to date
        asked = self.smart._asked
        beliefs = self.smart.beliefs
        self.decisions += 1
        try:
            if beliefs is None or asked is None:
                raise WorldError("no knowledge yet")
            evaluator = Evaluator(view, beliefs, asked[1], asked[2])
            chosen = self._search(view, legal, beliefs, evaluator, start)
        except (WorldError, Exception):
            chosen = None
        self.seconds += time.perf_counter() - start
        if chosen is None:
            self.fallbacks += 1
            self.history.append((view.turn, fallback, fallback))
            return fallback
        out: list[Choice] = [PassChoice() if c is None else c for c in chosen]
        self.history.append((view.turn, out, fallback))
        return out

    # -- the search -----------------------------------------------------------------------------

    def _search(
        self,
        view: SideView,
        legal: Sequence[Sequence[MoveChoice | SwitchChoice]],
        beliefs: Beliefs,
        evaluator: Evaluator,
        start: float,
    ) -> Pair | None:
        s = self.settings
        ranked = sorted(scored_pairs(evaluator, view, legal), key=lambda vp: -vp[0])
        own = [pair for _, pair in ranked[: s.own]]
        if len(own) <= 1:
            return own[0] if own else None
        worlds = []
        for rank in range(s.worlds):
            world = build_world(view, beliefs, rank, self._seed())
            if world.weight > 0:
                worlds.append(world)
        total = sum(w.weight for w in worlds)
        if not worlds or total <= 0:
            return None
        values = [0.0] * len(own)
        done = [True] * len(own)
        for world in worlds:
            share = world.weight / total
            foe_pairs, probs = self._foe_candidates(world, view.side)
            table = self._table(world, view.side, own, foe_pairs, start)
            if table is None:
                return None
            row_values = self._solve(table, probs)
            for i, v in enumerate(row_values):
                if v is None:
                    done[i] = False
                else:
                    values[i] += share * v
        candidates = [i for i in range(len(own)) if done[i]]
        if not candidates:
            return None
        top = max(values[i] for i in candidates)
        best = [i for i in candidates if values[i] > top - 1e-9]
        pick = best[0] if len(best) == 1 else best[self.prng.random_int(len(best))]
        return own[pick]

    def _seed(self) -> Seed:
        return (
            self.prng.random_int(1 << 16),
            self.prng.random_int(1 << 16),
            self.prng.random_int(1 << 16),
            self.prng.random_int(1 << 16),
        )

    def _foe_candidates(self, world: World, me: str) -> tuple[list[Pair], list[float]]:
        """The foe's likely pairs on this world and their probabilities (plan R3)."""
        foe = "p2" if me == "p1" else "p1"
        state = world.battle.state
        view = side_view(state, foe)
        beliefs = Beliefs(view.foe_preview, foe)
        evaluator = Evaluator(view, beliefs, frozenset(), frozenset())
        scored = scored_pairs(evaluator, view, legal_move_choices(state, foe))
        ranked = sorted(scored, key=lambda vp: -vp[0])
        chosen = ranked[: self.settings.foe]
        status = next((vp for vp in ranked if _has_status(view, vp[1])), None)
        if status is not None and status not in chosen:
            chosen.append(status)
        return [p for _, p in chosen], foe_probabilities(
            [v for v, _ in chosen], self.settings.temperature
        )

    def _table(
        self, world: World, me: str, own: list[Pair], foe: list[Pair], start: float
    ) -> list[list[float | None]] | None:
        """Leaf values after playing each own pair against each foe pair (None: not reached
        in time). The cells share the world's random numbers (common random numbers)."""
        table: list[list[float | None]] = []
        for a in own:
            row: list[float | None] = []
            for b in foe:
                if self.cancelled or time.perf_counter() - start > self.settings.time_limit:
                    row.append(None)
                    continue
                row.append(self._play(world.battle, me, a, b))
            table.append(row)
        return table

    def _play(self, battle: Battle, me: str, own: Pair, foe: Pair) -> float | None:
        mine = [PassChoice() if c is None else c for c in own]
        theirs = [PassChoice() if c is None else c for c in foe]
        total = 0.0
        for roll in range(self.settings.rolls):
            sim = copy.deepcopy(battle)
            if roll:  # the first roll keeps the world's numbers (shared by all cells)
                words = sim.prng.seed
                sim.prng = Prng((words[0], words[1], words[2] ^ roll, words[3] ^ (roll << 4)))
            try:
                sim.play_turn(*((mine, theirs) if me == "p1" else (theirs, mine)))
                for _ in range(self.settings.depth - 1):
                    if sim.state.ended or sim.awaiting_replacements:
                        break
                    sim.play_turn(_smart_turn(sim, "p1"), _smart_turn(sim, "p2"))
            except Exception:
                return None
            total += self.leaf(sim, me)
        return total / self.settings.rolls

    def _solve(self, table: list[list[float | None]], probs: list[float]) -> list[float | None]:
        """Each own pair's value: expected over the foe pairs (or, ``regret``, against the
        foe's equilibrium mix). A row with a missing cell has no value."""
        if self.settings.solve == "regret":
            probs = regret_mix(table)
        out: list[float | None] = []
        for row in table:
            if any(v is None for v in row):
                out.append(None)
                continue
            out.append(sum(p * (v or 0.0) for p, v in zip(probs, row, strict=True)))
        return out


def foe_probabilities(values: Sequence[float], temperature: float) -> list[float]:
    """Softmax of the foe pairs' scores; pairs under ``MIN_SHARE`` get 0 (the rest rescaled)."""
    if not values:
        return []
    top = max(values)
    raw = [math.exp((v - top) / max(temperature, 1e-9)) for v in values]
    total = sum(raw)
    probs = [r / total for r in raw]
    kept = [p if p >= MIN_SHARE else 0.0 for p in probs]
    total = sum(kept) or 1.0
    return [p / total for p in kept]


def regret_mix(table: list[list[float | None]], rounds: int = 300) -> list[float]:
    """The foe's mix in the zero-sum game of ``table`` (rows: own, columns: foe; values for
    own), by regret matching of both sides; missing cells count as 0."""
    rows, cols = len(table), len(table[0]) if table else 0
    value = [[v or 0.0 for v in row] for row in table]
    r_regret, c_regret = [0.0] * rows, [0.0] * cols
    c_sum = [0.0] * cols
    for _ in range(rounds):
        r_mix = _mix(r_regret)
        c_mix = _mix(c_regret)
        for j in range(cols):
            c_sum[j] += c_mix[j]
        r_val = [sum(c_mix[j] * value[i][j] for j in range(cols)) for i in range(rows)]
        c_val = [-sum(r_mix[i] * value[i][j] for i in range(rows)) for j in range(cols)]
        r_avg = sum(r_mix[i] * r_val[i] for i in range(rows))
        c_avg = sum(c_mix[j] * c_val[j] for j in range(cols))
        for i in range(rows):
            r_regret[i] = max(0.0, r_regret[i] + r_val[i] - r_avg)
        for j in range(cols):
            c_regret[j] = max(0.0, c_regret[j] + c_val[j] - c_avg)
    total = sum(c_sum) or 1.0
    return [c / total for c in c_sum]


def _mix(regret: list[float]) -> list[float]:
    total = sum(regret)
    if total <= 0:
        return [1.0 / len(regret)] * len(regret)
    return [r / total for r in regret]


def _has_status(view: SideView, pair: Pair) -> bool:
    dex = get_dex()
    for position, c in enumerate(pair):
        if not isinstance(c, MoveChoice) or c.move_index < 0:
            continue
        user = next((p for p in view.team if p.position == position and not p.fainted), None)
        if user is None or c.move_index >= len(user.moves):
            continue
        move = dex.move(user.moves[c.move_index].name)
        if move is not None and move.category == "Status":
            return True
    return False


def _smart_turn(battle: Battle, side: str) -> list[Choice]:
    """A later turn of a look-ahead: the side's smart AI, knowing only what it sees now."""
    view = side_view(battle.state, side)
    player = SmartPlayer(0)
    player.beliefs = Beliefs(view.foe_preview, side)
    return player.choose_turn(view, legal_move_choices(battle.state, side))
