"""The Reg F tournament teams imported by ``tools/import_regf.py`` (018).

Each team keeps its tournament, date, placing and player, and six full sets: the source's item,
ability, Tera Type and moves, with the species' most used EV spread and nature from Smogon's
stats (``regf_spreads.json``), every IV at 31 and level 50. Errors in the source are kept as they
are, except those with one answer, corrected by the import and listed in ``corrections`` (032);
``status`` says why a team cannot battle.
"""

from __future__ import annotations

import json
from collections import Counter
from collections.abc import Mapping
from dataclasses import dataclass
from functools import cache
from importlib import resources
from typing import Any

from pokesv_sim.dex import get_dex
from pokesv_sim.regulation import check_regulation, get_regulation
from pokesv_sim.support import unsupported
from pokesv_sim.team import DEFAULT_LEVEL, PokemonSet, Team, validate_team

REGF_PREFIX = "regf:"


@dataclass(frozen=True, slots=True)
class RegfTeam:
    id: str  # <period>-<tournament id>-<order>, e.g. 2026-0423-027
    period: str  # "2024" or "2026"
    tournament: str
    tournament_id: str
    date: str
    players: int
    placing: str
    player: str
    team: Team
    no_spread: tuple[int, ...]  # members whose species has no stats (default spread)
    corrections: tuple[str, ...] = ()  # 032: source errors the import corrected


def _member(m: Mapping[str, Any]) -> PokemonSet:
    return PokemonSet(
        species=m["species"],
        moves=tuple(m["moves"]),
        item=m["item"],
        ability=m["ability"],
        level=DEFAULT_LEVEL,
        nature=m["nature"],
        tera_type=m["tera_type"],
        evs=dict(m["evs"]),
    )


@cache
def regf_teams() -> tuple[RegfTeam, ...]:
    """Every imported team, sorted by ID."""
    text = resources.files("pokesv_sim.data").joinpath("regf_teams.json").read_text("utf-8")
    out = []
    for t in json.loads(text):
        out.append(
            RegfTeam(
                id=t["id"],
                period=t["period"],
                tournament=t["tournament"],
                tournament_id=t["tournament_id"],
                date=t["date"],
                players=t["players"],
                placing=t["placing"],
                player=t["player"],
                team=Team(tuple(_member(m) for m in t["members"])),
                no_spread=tuple(i for i, m in enumerate(t["members"]) if m.get("no_spread")),
                corrections=tuple(t.get("corrections", ())),
            )
        )
    return tuple(out)


@cache
def _by_id() -> dict[str, RegfTeam]:
    return {t.id: t for t in regf_teams()}


def get_regf_team(team_id: str) -> RegfTeam | None:
    """The team with this ID (``regf:`` in front is allowed), or None."""
    return _by_id().get(team_id.removeprefix(REGF_PREFIX))


def periods() -> Counter[str]:
    return Counter(t.period for t in regf_teams())


@dataclass(frozen=True, slots=True)
class TeamStatus:
    """Whether a team can battle, and why not. Every list is empty for a team that can."""

    errors: tuple[str, ...]  # validate_team (rules of every regulation; source errors land here)
    regulation: tuple[str, ...]  # check_regulation against Reg F
    unsupported: tuple[str, ...]  # what the engine cannot simulate yet: "move Outrage", ...

    @property
    def supported(self) -> bool:
        return not self.unsupported

    @property
    def runnable(self) -> bool:
        return not (self.errors or self.regulation or self.unsupported)


def _blocker(label: str) -> str:
    """``#3 Dragonite: move Outrage`` -> ``move Outrage``."""
    return label.split(": ", 1)[1]


@cache
def status(team_id: str) -> TeamStatus:
    """The status of an imported team (KeyError for an unknown ID)."""
    t = _by_id()[team_id.removeprefix(REGF_PREFIX)]
    return TeamStatus(
        errors=tuple(f"#{e.index + 1} {e.message}" if e.index >= 0 else e.message
                     for e in validate_team(t.team)),
        regulation=tuple(p.message for p in check_regulation(t.team, get_regulation("regf"))),
        unsupported=tuple(dict.fromkeys(_blocker(u) for u in unsupported(t.team))),
    )  # fmt: skip


@dataclass(frozen=True, slots=True)
class Blocker:
    name: str  # "move Outrage"
    name_ja: str | None  # "技 げきりん", from the data
    teams: int  # teams it keeps from battling

    def share(self, total: int) -> float:
        return self.teams / total if total else 0.0


@dataclass(frozen=True, slots=True)
class Coverage:
    total: int
    supported: int  # nothing unsupported (how 017 counted)
    runnable: int  # supported, valid and within Reg F
    invalid: int  # refused by validate_team or check_regulation
    blockers: tuple[Blocker, ...]  # by teams, most first


_KIND_JA = {"move": "技", "ability": "特性", "item": "持ち物"}


def _name_ja(blocker: str) -> str | None:
    kind, _, name = blocker.partition(" ")
    dex = get_dex()
    if kind == "move":
        entry: object = dex.move(name)
    elif kind == "ability":
        entry = dex.ability(name)
    elif kind == "item":
        entry = dex.item(name)
    else:
        return None
    ja = getattr(entry, "name_ja", None)
    return f"{_KIND_JA[kind]} {ja}" if ja else None


def coverage(period: str | None = None) -> Coverage:
    """How many imported teams can battle with the engine's current support (spec US3)."""
    teams = [t for t in regf_teams() if period is None or t.period == period]
    counts: Counter[str] = Counter()
    supported = runnable = invalid = 0
    for t in teams:
        s = status(t.id)
        supported += s.supported
        runnable += s.runnable
        invalid += bool(s.errors or s.regulation)
        counts.update(s.unsupported)
    blockers = tuple(
        Blocker(name, _name_ja(name), n)
        for name, n in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    )
    return Coverage(len(teams), supported, runnable, invalid, blockers)
