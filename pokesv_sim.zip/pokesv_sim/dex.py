"""Read-only access to the generated Gen 9 data (species, moves, abilities, items, types, natures).

The data is generated from Pokémon Showdown and PokeAPI by ``tools/build_data.py`` and must not be
edited by hand. Lookups accept English names, Showdown ids or Japanese names.
"""

from __future__ import annotations

import json
import re
import unicodedata
from collections.abc import Iterator, Mapping
from dataclasses import dataclass
from functools import cache
from importlib import resources
from typing import Any

STAT_IDS = ("hp", "atk", "def", "spa", "spd", "spe")
SKETCH = "sketch"

# Showdown's TypeChart damageTaken codes.
_NEUTRAL, _WEAK, _RESIST, _IMMUNE = 0, 1, 2, 3


@cache  # 018: called for every ability check in battle (a quarter of the run time uncached)
def to_id(text: str) -> str:
    """Normalize a name to a Showdown id (lowercase alphanumerics only, accents dropped)."""
    plain = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z0-9]", "", plain.lower())


@dataclass(frozen=True, slots=True)
class Species:
    id: str
    name: str
    name_ja: str | None
    num: int
    types: tuple[str, ...]
    base_stats: Mapping[str, int]
    abilities: tuple[str, ...]
    weightkg: float
    gender: str | None = None  # fixed gender ("M", "F", "N"), None if it varies
    battle_only: str | None = None  # base forme if this forme exists only in battle
    required_item: str | None = None
    nfe: bool = False  # not fully evolved (Eviolite, 013)
    tags: tuple[str, ...] = ()  # e.g. "Paradox" (013)
    base_species: str = ""  # e.g. "Ogerpon" for every Ogerpon forme (017)
    display_ja: str | None = None  # 039: with the forme's Japanese name, オーガポン(いどのめん)


@dataclass(frozen=True, slots=True)
class Secondary:
    chance: int | None  # percent; None means always
    status: str | None  # "brn", "par", ... when the effect is a status condition
    keys: frozenset[str]  # every key Showdown sets on this secondary effect
    boosts: Mapping[str, int] | None = None  # stat stages of the target
    self_boosts: Mapping[str, int] | None = None  # stat stages of the user
    self_keys: frozenset[str] = frozenset()
    volatile_status: str | None = None  # "flinch", "confusion", ...


@dataclass(frozen=True, slots=True)
class Move:
    id: str
    name: str
    name_ja: str | None
    type: str
    category: str  # "Physical" | "Special" | "Status"
    base_power: int
    accuracy: int | None  # None: never misses
    pp: int
    priority: int
    target: str
    crit_ratio: int
    flags: frozenset[str]
    keys: frozenset[str]  # every key in Showdown's raw definition
    function_keys: frozenset[str]  # keys whose value is a function (on*, *Callback)
    secondaries: tuple[Secondary, ...] = ()
    status: str | None = None  # status condition a status move inflicts
    volatile_status: str | None = None  # volatile status a status move adds (Confuse Ray)
    pseudo_weather: str | None = None  # field condition a move sets (Trick Room)
    side_condition: str | None = None  # side condition a move sets (Tailwind)
    weather: str | None = None  # weather a move sets (sunnyday, raindance, sandstorm, snowscape)
    terrain: str | None = None  # terrain a move sets (electricterrain, ...) (010)
    ignore_immunity: bool | None = None  # Showdown's explicit ignoreImmunity, if set
    thaws_target: bool = False
    boosts: Mapping[str, int] | None = None  # status moves that change stat stages
    self_boosts: Mapping[str, int] | None = None  # ``self.boosts`` (Close Combat, Draco Meteor)
    self_chance: int | None = None
    self_keys: frozenset[str] = frozenset()
    recoil: tuple[int, int] | None = None
    drain: tuple[int, int] | None = None
    multihit: tuple[int, int] | None = None  # (min, max) hits
    will_crit: bool = False
    self_boost: Mapping[str, int] | None = None  # 023: ``selfBoost`` (after the hits)
    type_boosted: bool = False  # 030: typeChangerBoosted (Pixilate changed its type)
    force_stab: bool = False  # 041-5: forceSTAB (a combined Pledge)
    num: int = 0  # 041-6f: Metronome samples its moves sorted by num
    unobtainable: bool = False  # 041-6f: isNonstandard Unobtainable (only Metronome calls it)


@dataclass(frozen=True, slots=True)
class Ability:
    id: str
    name: str
    name_ja: str | None
    keys: frozenset[str]
    function_keys: frozenset[str]
    mentioned_in: tuple[str, ...]  # Showdown source files that refer to it by name or id
    breakable: bool = False  # flags.breakable: Mold Breaker ignores it (012)
    fail_skill_swap: bool = False  # flags.failskillswap: Skill Swap fails on it (027)
    no_trace: bool = False  # flags.notrace: Trace does not copy it (031)
    cant_suppress: bool = False  # 041-3h: flags.cantsuppress
    fail_role_play: bool = False  # 041-3h: flags.failroleplay
    no_entrain: bool = False  # 041-3h: flags.noentrain


@dataclass(frozen=True, slots=True)
class Item:
    id: str
    name: str
    name_ja: str | None
    keys: frozenset[str]
    function_keys: frozenset[str]
    mentioned_in: tuple[str, ...]  # Showdown source files that refer to it by name or id
    is_choice: bool = False  # Choice Band / Specs / Scarf (013)
    is_berry: bool = False
    boosts: Mapping[str, int] | None = None  # stages when used (Throat Spray, the seeds)
    # 032: Fling's ``item.fling``: basePower, status / volatileStatus, effect (a function: True)
    fling: Mapping[str, object] | None = None


@dataclass(frozen=True, slots=True)
class Nature:
    id: str
    name: str
    plus: str | None
    minus: str | None
    name_ja: str | None = None  # 039


def _stages(pairs: Any) -> dict[str, int] | None:
    """[[stat, stages], ...] in Showdown's key order (the order boosts are applied in)."""
    return {str(k): int(v) for k, v in pairs} if pairs else None


def _multihit(value: Any) -> tuple[int, int] | None:
    if value is None:
        return None
    if isinstance(value, list):
        return (int(value[0]), int(value[1]))
    return (int(value), int(value))


def _load(name: str) -> dict[str, Any]:
    text = resources.files("pokesv_sim.data").joinpath(f"{name}.json").read_text(encoding="utf-8")
    data: dict[str, Any] = json.loads(text)["data"]
    return data


class Dex:
    """Lookup tables built from the generated data files."""

    def __init__(self) -> None:
        self._species: dict[str, Species] = {}
        self._species_alias: dict[str, str] = {}
        for sid, s in _load("species").items():
            self._species[sid] = Species(
                id=sid,
                name=s["name"],
                name_ja=s["nameJa"],
                num=s["num"],
                types=tuple(s["types"]),
                base_stats={k: s["baseStats"][k] for k in STAT_IDS},
                abilities=tuple(s["abilities"].values()),
                weightkg=s["weightkg"],
                gender=s.get("gender"),
                battle_only=s["battleOnly"] if isinstance(s["battleOnly"], str) else None,
                required_item=s["requiredItem"],
                nfe=s.get("nfe", False),
                tags=tuple(s.get("tags", ())),
                base_species=s["baseSpecies"],
                display_ja=s.get("displayJa"),
            )
            for cosmetic in s.get("cosmeticFormes", []):
                self._species_alias[to_id(cosmetic)] = sid
            if s["nameJa"] and not s["forme"]:
                self._species_alias.setdefault(s["nameJa"], sid)

        self._moves: dict[str, Move] = {}
        self._move_alias: dict[str, str] = {}
        for mid, m in _load("moves").items():
            self._moves[mid] = Move(
                id=mid,
                name=m["name"],
                name_ja=m["nameJa"],
                num=m["num"],
                unobtainable=m.get("isNonstandard") == "Unobtainable",
                type=m["type"],
                category=m["category"],
                base_power=m["basePower"],
                accuracy=None if m["accuracy"] is True else m["accuracy"],
                pp=m["pp"],
                priority=m["priority"],
                target=m["target"],
                crit_ratio=m["critRatio"],
                flags=frozenset(k for k, v in m["flags"].items() if v),
                keys=frozenset(m["keys"]),
                function_keys=frozenset(m["functionKeys"]),
                secondaries=tuple(
                    Secondary(
                        sec["chance"],
                        sec["status"],
                        frozenset(sec["keys"]),
                        _stages(sec["boosts"]),
                        _stages(sec["selfBoosts"]),
                        frozenset(sec["selfKeys"]),
                        sec["volatileStatus"],
                    )
                    for sec in m["secondaries"]
                ),
                boosts=_stages(m["boosts"]),
                self_boosts=_stages((m["self"] or {}).get("boosts")),
                self_chance=(m["self"] or {}).get("chance"),
                self_keys=frozenset((m["self"] or {}).get("keys", [])),
                recoil=tuple(m["recoil"]) if m["recoil"] else None,
                drain=tuple(m["drain"]) if m["drain"] else None,
                multihit=_multihit(m["multihit"]),
                self_boost=_stages(m["selfBoost"]),
                will_crit=bool(m["willCrit"]),
                status=m["status"],
                volatile_status=m["volatileStatus"],
                pseudo_weather=m["pseudoWeather"],
                side_condition=m["sideCondition"],
                weather=m["weather"],
                terrain=m.get("terrain"),
                ignore_immunity=m["ignoreImmunity"]
                if isinstance(m["ignoreImmunity"], bool)
                else None,
                thaws_target=m["thawsTarget"],
            )
            if m["nameJa"]:
                self._move_alias[m["nameJa"]] = mid

        self._abilities: dict[str, Ability] = {}
        self._ability_alias: dict[str, str] = {}
        for aid, a in _load("abilities").items():
            self._abilities[aid] = Ability(
                aid,
                a["name"],
                a["nameJa"],
                frozenset(a["keys"]),
                frozenset(a["functionKeys"]),
                tuple(a["mentionedIn"]),
                a.get("breakable", False),
                a.get("failSkillSwap", False),
                a.get("noTrace", False),
                a.get("cantSuppress", False),
                a.get("failRolePlay", False),
                a.get("noEntrain", False),
            )
            if a["nameJa"]:
                self._ability_alias[a["nameJa"]] = aid

        self._items: dict[str, Item] = {}
        self._item_alias: dict[str, str] = {}
        for iid, i in _load("items").items():
            self._items[iid] = Item(
                iid,
                i["name"],
                i["nameJa"],
                frozenset(i["keys"]),
                frozenset(i["functionKeys"]),
                tuple(i["mentionedIn"]),
                i.get("isChoice", False),
                i.get("isBerry", False),
                _stages(i.get("boosts")),
                i.get("fling"),
            )
            if i["nameJa"]:
                self._item_alias[i["nameJa"]] = iid

        self._natures = {
            nid: Nature(nid, n["name"], n["plus"], n["minus"], n.get("nameJa"))
            for nid, n in _load("natures").items()
        }
        self._typechart: dict[str, dict[str, int]] = _load("typechart")
        self._learnsets = {sid: frozenset(moves) for sid, moves in _load("learnsets").items()}

    @staticmethod
    def _find[T](table: Mapping[str, T], alias: Mapping[str, str], name: str) -> T | None:
        key = to_id(name)
        if key in table:
            return table[key]
        target = alias.get(key) or alias.get(name.strip())
        return table[target] if target else None

    def species(self, name: str) -> Species | None:
        return self._find(self._species, self._species_alias, name)

    def move(self, name: str) -> Move | None:
        return self._find(self._moves, self._move_alias, name)

    def ability(self, name: str) -> Ability | None:
        return self._find(self._abilities, self._ability_alias, name)

    def item(self, name: str) -> Item | None:
        return self._find(self._items, self._item_alias, name)

    def nature(self, name: str) -> Nature | None:
        return self._natures.get(to_id(name))

    def all_species(self) -> Iterator[Species]:
        return iter(self._species.values())

    def all_moves(self) -> Iterator[Move]:
        return iter(self._moves.values())

    def all_abilities(self) -> Iterator[Ability]:
        return iter(self._abilities.values())

    def can_learn(self, species_id: str, move_id: str) -> bool:
        learnset = self._learnsets.get(species_id, frozenset())
        if move_id in learnset:
            return True
        # 018: Sketch copies any move without the nosketch flag (TeamValidator.checkCanLearn)
        move = self._moves.get(move_id)
        return SKETCH in learnset and move is not None and "nosketch" not in move.flags

    def learnable(self, species_id: str) -> frozenset[str]:
        return self._learnsets.get(species_id, frozenset())

    def effect_immune(self, effect: str, defender_types: tuple[str, ...]) -> bool:
        """Showdown ``getImmunity`` for a non-type effect ("brn", "par", "psn", "frz", "powder")."""
        return any(self._typechart.get(t, {}).get(effect) == _IMMUNE for t in defender_types)

    def type_ids(self) -> frozenset[str]:
        return frozenset(to_id(t) for t in self._typechart)

    def type_names(self) -> tuple[str, ...]:
        return tuple(self._typechart)

    def resists(self, defender_type: str, move_type: str) -> bool:
        """041-6f: ``damageTaken[move_type]`` of one type is 2 (resists) or 3 (immune)."""
        return self._typechart.get(defender_type, {}).get(move_type) in (_RESIST, _IMMUNE)

    def is_immune(self, move_type: str, defender_types: tuple[str, ...]) -> bool:
        """Type immunity (Showdown ``runImmunity`` without abilities or items)."""
        # (041-1g: the ??? type has no entry: neutral to everything)
        return any(self._typechart.get(t, {}).get(move_type) == _IMMUNE for t in defender_types)

    def type_mod(self, move_type: str, defender_types: tuple[str, ...]) -> int:
        """Sum of per-type effectiveness: +1 per weakness, -1 per resistance (Showdown typeMod)."""
        total = 0
        for t in defender_types:
            code = self._typechart.get(t, {}).get(move_type, _NEUTRAL)
            if code == _WEAK:
                total += 1
            elif code == _RESIST:
                total -= 1
        return total


@cache
def get_dex() -> Dex:
    """The shared, read-only Dex instance."""
    return Dex()


def tera_forme(species: Species) -> Species | None:
    """017: the forme Ogerpon takes when it terastallizes (``actions.terastallize``:
    ``<battleOnly or id>`` + ``tera``, or ``tealtera`` for the maskless Ogerpon)."""
    if species.base_species != "Ogerpon":
        return None
    sid = to_id(species.battle_only or species.id)
    return get_dex().species(sid + ("tealtera" if sid == "ogerpon" else "tera"))


def default_tera_type(species: Species) -> str:
    """017: the Tera Type of a set without one (team-validator: ``set.teraType ||
    species.requiredTeraType || species.types[0]``; Ogerpon requires its forme's type)."""
    forme = tera_forme(species)
    return forme.types[-1] if forme is not None else species.types[0]
