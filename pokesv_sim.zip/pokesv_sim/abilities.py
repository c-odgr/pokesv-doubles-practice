"""Abilities (011; Showdown ``data/abilities.ts``): those that act on switch-in, change move order,
block moves, or act on switching out. Abilities that change damage come in 012.

The battle calls these helpers at fixed points; they only look at Pokémon and field state.
Ability ids are Showdown ids (``to_id`` of the name), as in ``BattlePokemon.ability_id``.
"""

from __future__ import annotations

from collections.abc import Mapping

from pokesv_sim.boosts import boosted_stat
from pokesv_sim.dex import Move, get_dex
from pokesv_sim.field import ELECTRIC, GRASSY, MISTY, PSYCHIC, RAIN, SAND, SNOW, SUN

INTIMIDATE = "intimidate"
# onTryBoost: these keep their Attack against Intimidate (``-fail ... unboost``).
INTIMIDATE_BLOCKERS = {
    "innerfocus": "Inner Focus",
    "oblivious": "Oblivious",
    "owntempo": "Own Tempo",
    "scrappy": "Scrappy",
}
GUARD_DOG = "guarddog"  # onTryBoost (priority 2): Intimidate raises its Attack instead
SUCTION_CUPS = "suctioncups"  # 034 (R3)
ILLUSION = "illusion"  # 034 (R6)
# 034 (R3): onDragOut (priority 1): -activate and null (Roar and Whirlwind do nothing). Both
# are breakable (Mold Breaker ignores them).
DRAG_OUT_BLOCKERS = {GUARD_DOG: "Guard Dog", SUCTION_CUPS: "Suction Cups"}
# onAfterEachBoost: a stat lowered by a foe raises this stat by 2.
STAT_DROP_REACTIONS = {"defiant": ("atk", "Defiant"), "competitive": ("spa", "Competitive")}

WEATHER_SETTERS = {"drought": SUN, "drizzle": RAIN, "sandstream": SAND, "snowwarning": SNOW}
TERRAIN_SETTERS = {
    "grassysurge": GRASSY,
    "psychicsurge": PSYCHIC,
    "electricsurge": ELECTRIC,
    "mistysurge": MISTY,
}
# The Ruin abilities: the stat they lower (x0.75) on every other Pokémon, and whose stat it is
# (the defender's for Sword and Beads, the attacker's for Vessel and Tablets).
RUIN = {"swordofruin": "def", "beadsofruin": "spd", "vesselofruin": "spa", "tabletsofruin": "atk"}
RUIN_NAMES = {
    "swordofruin": "Sword of Ruin",
    "beadsofruin": "Beads of Ruin",
    "vesselofruin": "Vessel of Ruin",
    "tabletsofruin": "Tablets of Ruin",
}
RUIN_MODIFIER = (3, 4)  # chainModify(0.75)
DOWNLOAD = "download"
# 043-1
ORICHALCUM_PULSE = "orichalcumpulse"
HADRON_ENGINE = "hadronengine"
SUPREME_OVERLORD = "supremeoverlord"
SUPREME_OVERLORD_MODS = (4096, 4506, 4915, 5325, 5734, 6144)
STEELY_SPIRIT = "steelyspirit"
BATTERY = "battery"
POWER_SPOT = "powerspot"
UNNERVERS = frozenset({"unnerve", "asoneglastrier", "asonespectrier"})
INFILTRATOR = "infiltrator"
TELEPATHY = "telepathy"
HEALER = "healer"
NATURAL_CURE = "naturalcure"
SYMBIOSIS = "symbiosis"
RECEIVERS = {"receiver": "Receiver", "powerofalchemy": "Power of Alchemy"}
# flags.noreceiver (Receiver / Power of Alchemy do not copy these)
NO_RECEIVER = frozenset({
    "asoneglastrier", "asonespectrier", "battlebond", "comatose", "commander", "disguise",
    "embodyaspectcornerstone", "embodyaspecthearthflame", "embodyaspectteal",
    "embodyaspectwellspring", "flowergift", "forecast", "hungerswitch", "iceface",
    "illusion", "imposter", "multitype", "neutralizinggas", "poisonpuppeteer",
    "powerconstruct", "powerofalchemy", "protosynthesis", "quarkdrive", "receiver",
    "rkssystem", "schooling", "shieldsdown", "stancechange", "teraformzero", "terashell",
    "terashift", "trace", "wonderguard", "zenmode", "zerotohero", "noability",
})  # fmt: skip
# onSourceAfterFaint: a stat +1 per fainted Pokemon (the boost's effect)
AFTER_FAINT_BOOSTS = {
    "chillingneigh": ("atk", "Chilling Neigh"),
    "asoneglastrier": ("atk", "Chilling Neigh"),
    "grimneigh": ("spa", "Grim Neigh"),
    "moxie": ("atk", "Moxie"),  # 043-4b
    "asonespectrier": ("spa", "Grim Neigh"),
}
HOSPITALITY = "hospitality"
PRANKSTER = "prankster"
PRIORITY_BLOCKERS = {
    "armortail": "Armor Tail",
    "queenlymajesty": "Queenly Majesty",
    "dazzling": "Dazzling",
}
_ALL_TARGET_EXCEPTIONS = frozenset({"perishsong", "flowershield", "rototiller"})
GOOD_AS_GOLD = "goodasgold"
LEVITATE = "levitate"
UNSEEN_FIST = "unseenfist"
SCRAPPY = "scrappy"
INNER_FOCUS = "innerfocus"
OWN_TEMPO = "owntempo"
REGENERATOR = "regenerator"
COMMANDER = "commander"  # 028: onStart, onAnySwitchIn (-2) and onUpdate run the same code
# 029: while its holder is on the field, the other abilities are suppressed
# (``BattlePokemon.ability_id``, Showdown ignoringAbility)
NEUTRALIZING_GAS = "neutralizinggas"
# 032 (R6): berries at 1/2 HP instead of 1/4 (abilityState.gluttony, set by its onStart)
GLUTTONY = "gluttony"
# Protosynthesis / Quark Drive: the ability, the field that starts it, and its display name.
BOOSTERS = {"protosynthesis": "Protosynthesis", "quarkdrive": "Quark Drive"}
BOOSTER_MODIFIER = (5325, 4096)  # Atk, Def, SpA, SpD
BOOSTER_SPEED = (3, 2)  # Spe: chainModify(1.5)
_BEST_STAT_ORDER = ("atk", "def", "spa", "spd", "spe")

# 017: Embody Aspect (Ogerpon's terastallized formes) -> the stat it raises
EMBODY_ASPECT = {
    "embodyaspectteal": "spe",
    "embodyaspectwellspring": "spd",
    "embodyaspecthearthflame": "atk",
    "embodyaspectcornerstone": "def",
}

SLOW_START = "slowstart"  # 033 (R12)
PRESSURE = "pressure"  # 033 (R14)
# onSwitchInPriority (the handlers run by priority, then by the switch-in speed order).
_SWITCH_IN_PRIORITY = {
    HOSPITALITY: -2,
    "protosynthesis": -2,
    "quarkdrive": -2,
    **dict.fromkeys(("unnerve", "asoneglastrier", "asonespectrier"), 1),
    "costar": -2,
}  # (043-1)
# Abilities with an onStart (run as onSwitchIn handlers).
_ON_START = frozenset(
    {INTIMIDATE, DOWNLOAD, HOSPITALITY, *WEATHER_SETTERS, *TERRAIN_SETTERS, *RUIN, *BOOSTERS,
     "moldbreaker", "turboblaze", "teravolt", *EMBODY_ASPECT, COMMANDER, "trace", GLUTTONY,
     SLOW_START, PRESSURE, "comatose", "windrider", "cloudnine", "airlock",
    "frisk", "anticipation", "forewarn", "truant",
    "supersweetsyrup", "curiousmedicine", "intrepidsword", "dauntlessshield",  # (042-2)
     ORICHALCUM_PULSE, HADRON_ENGINE, SUPREME_OVERLORD, *UNNERVERS, "costar"}  # (043-1)
)  # fmt: skip


def has_switch_in(ability: str) -> bool:
    return ability in _ON_START


def switch_in_priority(ability: str) -> int:
    return _SWITCH_IN_PRIORITY.get(ability, 0)


def booster_active(ability: str, weather: str | None, terrain: str | None) -> bool:
    """Protosynthesis in the sun, Quark Drive in Electric Terrain (Booster Energy is 013)."""
    if ability == "protosynthesis":
        return weather == SUN
    if ability == "quarkdrive":
        return terrain == ELECTRIC
    return False


def best_stat(stats: Mapping[str, int], boosts: Mapping[str, int]) -> str:
    """``getBestStat(false, true)``: the highest stat with its stage (no other modifiers); the
    first in atk, def, spa, spd, spe order on a tie."""
    best, value = "atk", 0
    for stat in _BEST_STAT_ORDER:
        current = boosted_stat(stats[stat], boosts.get(stat, 0))
        if current > value:
            best, value = stat, current
    return best


def download_stat(foes: list[tuple[Mapping[str, int], Mapping[str, int]]]) -> str | None:
    """Download: the foes' Def and SpD (with stages) summed; SpA when Def >= SpD."""
    total_def = sum(boosted_stat(s["def"], b.get("def", 0)) for s, b in foes)
    total_spd = sum(boosted_stat(s["spd"], b.get("spd", 0)) for s, b in foes)
    if total_def and total_def >= total_spd:
        return "spa"
    if total_spd:
        return "atk"
    return None


def modify_priority(ability: str, move: Move, *, full_hp: bool = False) -> int:
    """The ability's ``onModifyPriority``: Prankster +1 for status moves, Triage +3 for heal
    moves (032), Gale Wings +1 for Flying moves at full HP (043-2b)."""
    if ability == "galewings" and move.type == "Flying" and full_hp:
        return 1
    if ability == TRIAGE and "heal" in move.flags:
        return 3
    return 1 if ability == PRANKSTER and move.category == "Status" else 0


def blocks_priority_move(move: Move, *, last_target_on_holder_side: bool) -> bool:
    """Armor Tail / Queenly Majesty / Dazzling ``onFoeTryMove``."""
    if move.target == "foeSide" or (move.target == "all" and move.id not in _ALL_TARGET_EXCEPTIONS):
        return False
    return (last_target_on_holder_side or move.target == "all") and move.priority > 0.1


def ruin_modifier(stat: str, holder_abilities: frozenset[str], own_ability: str) -> bool:
    """Whether a Ruin ability on the field lowers this Pokémon's ``stat`` (its own does not)."""
    return any(
        RUIN[ruin] == stat and own_ability != ruin for ruin in holder_abilities if ruin in RUIN
    )


# -- 012: abilities that change damage or act when hit ------------------------------------------

MOLD_BREAKER = "moldbreaker"
# 041-6a: Turboblaze and Teravolt are Mold Breaker under another name (the same handlers)
MOLD_BREAKERS = {MOLD_BREAKER: "Mold Breaker", "turboblaze": "Turboblaze", "teravolt": "Teravolt"}
SHEER_FORCE = "sheerforce"
# 021: hasSheerForceBoost: Sheer Force raises the power (the move keeps everything else)
SHEER_FORCE_BOOST = frozenset({"electroshot", "orderup"})  # (028: Order Up)
MINDS_EYE = "mindseye"
KEEN_EYE = "keeneye"  # 043-4a: ignoreEvasion and TryBoost (accuracy), as Mind's Eye
# 043-4a: onTryBoost against one stat's drop by another (-fail unboost unless secondaries)
ONE_STAT_GUARDS = {MINDS_EYE: "accuracy", KEEN_EYE: "accuracy", "illuminate": "accuracy",
                   "hypercutter": "atk", "bigpecks": "def"}  # fmt: skip
LIQUID_VOICE = "liquidvoice"
UNAWARE = "unaware"
FLASH_FIRE = "flashfire"
STURDY = "sturdy"
SNOW_CLOAK = "snowcloak"  # 026
SAND_VEIL = "sandveil"  # 032
SHELL_ARMOR = "shellarmor"  # 027
CRIT_BLOCKERS = frozenset({SHELL_ARMOR, "battlearmor"})  # onCriticalHit: false (043-2b)
NO_GUARD = "noguard"  # 043-2b
TRACKERS = frozenset({"propellertail", "stalwart"})  # 043-2b: move.tracksTarget
FULL_METAL_BODY = "fullmetalbody"  # 043-2b: Clear Body, not breakable
# 043-2b: the target's onSourceModifyDamage (subOrder 7): Solid Rock / Filter / Prism Armor
# (x0.75 super effective), Ice Scales (x0.5 special), Shadow Shield (x0.5 at full HP)
FILTERS = frozenset({"solidrock", "filter", "prismarmor"})
BERSERK = "berserk"
FLAME_BODY = "flamebody"
FRIEND_GUARD = "friendguard"
MULTISCALE = "multiscale"
OVERCOAT = "overcoat"
MAGIC_BOUNCE = "magicbounce"  # 031
TRACE = "trace"  # 031
THERMAL_EXCHANGE = "thermalexchange"
CLEAR_BODY = "clearbody"
MIRROR_ARMOR = "mirrorarmor"
UNBURDEN = "unburden"  # 013
# onTryHit: the type each absorbs, and whether it heals 1/4 (else SpA +1).
# 032 (R11): onTryHit: Bulletproof (bullet moves) and Soundproof (sound moves, not its own),
# priority 0; Sap Sipper (Grass moves, not its own: Atk +1, else -immune), priority 1
BULLETPROOF = "bulletproof"
SOUNDPROOF = "soundproof"
SAP_SIPPER = "sapsipper"
ABSORBERS = {
    "waterabsorb": ("Water", "heal", "Water Absorb"),
    "voltabsorb": ("Electric", "heal", "Volt Absorb"),
    "eartheater": ("Ground", "heal", "Earth Eater"),
    "stormdrain": ("Water", "spa", "Storm Drain"),
    "lightningrod": ("Electric", "spa", "Lightning Rod"),
    "motordrive": ("Electric", "spe", "Motor Drive"),  # 043-4b
    "dryskin": ("Water", "heal", "Dry Skin"),  # 043-4c
    "wellbakedbody": ("Fire", "def", "Well-Baked Body"),  # 043-4c (+2)
}
# onAnyRedirectTarget: the type each draws in.
REDIRECT_ABILITIES = {
    "stormdrain": ("Water", "Storm Drain"),
    "lightningrod": ("Electric", "Lightning Rod"),
}
# onDamagingHit: the stat raised by 1 (Thermal Exchange only for Fire moves).
ON_HIT_BOOSTS: dict[str, tuple[str, tuple[str, ...] | None, str, int]] = {
    "stamina": ("def", None, "Stamina", 1),
    "thermalexchange": ("atk", ("Fire",), "Thermal Exchange", 1),
    "justified": ("atk", ("Dark",), "Justified", 1),  # 032 (R12)
    "steamengine": ("spe", ("Water", "Fire"), "Steam Engine", 6),  # 043-4b
    "watercompaction": ("def", ("Water",), "Water Compaction", 2),  # 043-4b
    "rattled": ("spe", ("Dark", "Bug", "Ghost"), "Rattled", 1),  # 043-4b
}
# 032 (R12): Rough Skin (onDamagingHitOrder 1: before Rocky Helmet's 2) 1/8 to a contact
# attacker; Weak Armor: a physical hit, Def -1 and Spe +2; Toxic Chain: the attacker's
# onSourceDamagingHit, randomChance(3, 10) of tox (not on Shield Dust / Covert Cloak)
ROUGH_SKIN = "roughskin"
TRIAGE = "triage"  # 032 (R14): onModifyPriority +3 for heal moves
ICE_BODY = "icebody"  # 032 (R14): onWeather: 1/16 HP in the snow
# 032 (R13): Sweet Veil (onAllySetStatus sleep, onAllyTryAddVolatile yawn) and Aroma Veil
# (onAllyTryAddVolatile of these, -block only from a move); Corrosion poisons Steel and Poison
SWEET_VEIL = "sweetveil"
AROMA_VEIL = "aromaveil"
AROMA_VEIL_BLOCKS = frozenset({"attract", "disable", "encore", "healblock", "taunt", "torment"})
CORROSION = "corrosion"
WEAK_ARMOR = "weakarmor"
TOXIC_CHAIN = "toxicchain"
# onModifySpe: x2 in this weather.
WEATHER_SPEED = {"chlorophyll": SUN, "swiftswim": RAIN, "sandrush": SAND, "slushrush": SNOW}
# Immune to the weather's damage (onImmunity 'sandstorm').
WEATHER_DAMAGE_IMMUNE = frozenset({OVERCOAT, "sandrush", SAND_VEIL, "sandforce"})  # (043-2a)
_TECHNICIAN_MAX = 60
_CRASH_MOVES = frozenset({"highjumpkick", "supercellslam", "axekick"})  # hasCrashDamage


def ignores_ghost_immunity(ability: str) -> bool:
    """Scrappy (011) / Mind's Eye (012) ``ignoreImmunity`` for Normal and Fighting."""
    return ability in (SCRAPPY, MINDS_EYE)


def has_sheer_force(ability: str, move: Move) -> bool:
    """Sheer Force ``onModifyMove``: a move with secondaries loses them (and ``self``)."""
    return ability == SHEER_FORCE and bool(move.secondaries)


PIXILATE = "pixilate"  # 030
GALVANIZE = "galvanize"  # 043-2a: Pixilate for Electric
LONG_REACH = "longreach"  # 043-2a: onModifyMove: no contact
ROCK_HEAD = "rockhead"  # 043-2a: onDamage: no recoil (not Struggle's)
PUNK_ROCK = "punkrock"  # 043-2a
TINTED_LENS = "tintedlens"  # 043-2a: onModifyDamage x2 (not very effective)
SNIPER = "sniper"  # 043-2a: onModifyDamage x1.5 (a critical hit)
# 043-2a: Overgrow's siblings (onModifyAtk / SpA 5, x1.5 at 1/3 HP)
PINCH_TYPES = {"overgrow": "Grass", "torrent": "Water", "blaze": "Fire", "swarm": "Bug"}
# 030: Pixilate's noModifyType (the moves that set their own type)
_NO_MODIFY_TYPE = frozenset({"judgment", "multiattack", "naturalgift", "revelationdance",
                             "technoblast", "terrainpulse", "weatherball"})  # fmt: skip


def pixilate_changes(move: Move, terastallized: bool) -> bool:
    """030 (R1): Pixilate's onModifyType turns this move Fairy (a Normal move, status moves
    too, except the noModifyType ones and a terastallized user's Tera Blast)."""
    if move.type != "Normal" or move.id in _NO_MODIFY_TYPE:
        return False
    return not (move.id == "terablast" and terastallized)


WATER_BUBBLE = "waterbubble"  # 030
# 030 (R2): the abilities' ModifyAtk / ModifySpA handlers and their priorities. runEvent
# collects and sorts them whether they apply or not, so holders with the same priority and
# speed tie (Ruin's onAny handlers, priority 0, are counted separately).
# 032 (R10): the target's onSourceModifyAtk (6) / SpA (5) x0.5: Thick Fat (Fire, Ice), Heatproof
# (Fire), Purifying Salt (Ghost); the user's Overgrow (5) x1.5 (Grass, at 1/3 HP)
THICK_FAT = "thickfat"
HEATPROOF = "heatproof"
PURIFYING_SALT = "purifyingsalt"
OVERGROW = "overgrow"
HALVING_ABILITIES: Mapping[str, frozenset[str]] = {
    THICK_FAT: frozenset({"Fire", "Ice"}),
    HEATPROOF: frozenset({"Fire"}),
    PURIFYING_SALT: frozenset({"Ghost"}),
}
MODIFY_ATTACK_PRIORITY: Mapping[str, Mapping[str, int]] = {
    "guts": {"atk": 5},
    OVERGROW: {"atk": 5, "spa": 5},
    **{key: {"atk": 5, "spa": 5} for key in ("torrent", "blaze", "swarm", "rockypayload")},
    "dragonsmaw": {"atk": 5, "spa": 5},
    "transistor": {"atk": 5, "spa": 5},
    WATER_BUBBLE: {"atk": 0, "spa": 0},
    SLOW_START: {"atk": 5},  # 033 (R12)
    # 043-1: Huge Power, Pure Power, Orichalcum Pulse (Atk), Hadron Engine, Plus, Minus (SpA)
    "hugepower": {"atk": 5},
    "purepower": {"atk": 5},
    ORICHALCUM_PULSE: {"atk": 5},
    HADRON_ENGINE: {"spa": 5},
    "plus": {"spa": 5},
    "hustle": {"atk": 5},  # 043-2a
    "solarpower": {"spa": 5},
    "stakeout": {"atk": 5, "spa": 5},
    "minus": {"spa": 5},
}
SOURCE_MODIFY_ATTACK_PRIORITY: Mapping[str, Mapping[str, int]] = {
    WATER_BUBBLE: {"atk": 5, "spa": 5},  # onSourceModifyAtk / SpA (the target's)
    **{key: {"atk": 6, "spa": 5} for key in HALVING_ABILITIES},  # 032
}
# onUpdate: cure a burn (029: Thermal Exchange; 030: Water Bubble)
BURN_CURERS = {THERMAL_EXCHANGE: "Thermal Exchange", WATER_BUBBLE: "Water Bubble"}
# 043-3a: onSetStatus false (-immune for a move's own status) and onUpdate cureStatus
# (041-3h: Insomnia, 041-6f: Limber)
STATUS_GUARDS: dict[str, tuple[frozenset[str], str]] = {
    "insomnia": (frozenset({"slp"}), "Insomnia"),
    "vitalspirit": (frozenset({"slp"}), "Vital Spirit"),
    "limber": (frozenset({"par"}), "Limber"),
    "immunity": (frozenset({"psn", "tox"}), "Immunity"),
    "waterveil": (frozenset({"brn"}), "Water Veil"),
}
MAGMA_ARMOR = "magmaarmor"  # 043-3a: onImmunity frz; onUpdate cures frz
LEAF_GUARD = "leafguard"  # 043-3a: onSetStatus false in the sun (and Yawn)
# 043-3a: the target's onDamagingHit on contact, randomChance(3, 10): the status
CONTACT_STATUS = {"static": "par", "poisonpoint": "psn"}
EFFECT_SPORE = "effectspore"
LIQUID_OOZE, AFTERMATH, DAMP = "liquidooze", "aftermath", "damp"  # 043-3b
POISON_HEAL = "poisonheal"  # 043-3b
SPEED_BOOST = "speedboost"  # 043-4b: onResidual (28, subOrder 2)
COMATOSE = "comatose"  # 043-3c: asleep for the moves that check
FLOWER_VEIL = "flowerveil"  # 043-3c: onAllyTryBoost / SetStatus / TryAddVolatile (Grass)
BAD_DREAMS = "baddreams"  # 043-3b: onResidual (28, subOrder 2)
DAMP_MOVES = frozenset({"explosion", "mindblown", "mistyexplosion", "selfdestruct"})
HYDRATION, SHED_SKIN = "hydration", "shedskin"  # 043-3a: onResidual (5, subOrder 3)


def base_power_modifiers(
    ability: str,
    move: Move,
    power: int,
    item: str = "",
    *,
    ally_abilities: frozenset[str] = frozenset(),
    fallen: int = 0,
    status: str | None = None,
    weather: str | None = None,
    genders: tuple[str, str] = ("", ""),
    last_to_move: bool = False,
) -> list[tuple[int, int]]:
    """The user's ``onBasePower`` handlers by priority: Technician (30; the power so far is
    the callback's, nothing ran before it), Pixilate (23, 030), Sheer Force (21), Sharpness
    (19). 040-2: the user's item at the same priorities after its ability (subOrder:
    abilities 7, items 8): Punching Glove (23), Muscle Band / Wise Glasses (16)."""
    modifiers = []
    if ability == "technician" and power <= _TECHNICIAN_MAX:
        modifiers.append((3, 2))
    if ability == "rivalry" and all(genders):  # 043-2a (24)
        modifiers.append((5, 4) if genders[0] == genders[1] else (3, 4))
    if ability in (PIXILATE, GALVANIZE) and move.type_boosted:
        modifiers.append((4915, 4096))
    # 043-2a (23): Iron Fist (punch), Reckless (recoil, crash)
    if ability == "ironfist" and "punch" in move.flags:
        modifiers.append((4915, 4096))
    if ability == "reckless" and (move.recoil or move.id in _CRASH_MOVES):
        modifiers.append((4915, 4096))
    if item == "punchingglove" and "punch" in move.flags:
        modifiers.append((4506, 4096))
    # 043-1: onAllyBasePower (22): the user's and its allies' Steely Spirit, the allies'
    # Battery (special moves) and Power Spot
    if move.type == "Steel":
        modifiers.extend(
            [(3, 2)] * ((ability == STEELY_SPIRIT) + (STEELY_SPIRIT in ally_abilities))
        )
    if BATTERY in ally_abilities and move.category == "Special":
        modifiers.append((5325, 4096))
    if POWER_SPOT in ally_abilities:
        modifiers.append((5325, 4096))
    # 043-2a (21): Tough Claws (contact), Sand Force (Rock / Ground / Steel in the sandstorm)
    if ability == "toughclaws" and "contact" in move.flags:
        modifiers.append((5325, 4096))
    if ability == "sandforce" and weather == SAND and move.type in ("Rock", "Ground", "Steel"):
        modifiers.append((5325, 4096))
    if ability == "analytic" and last_to_move:  # 043-2a (21)
        modifiers.append((5325, 4096))
    if ability == SUPREME_OVERLORD and fallen:  # 043-1: onBasePower (21)
        modifiers.append((SUPREME_OVERLORD_MODS[fallen], 4096))
    if has_sheer_force(ability, move) or (ability == SHEER_FORCE and move.id in SHEER_FORCE_BOOST):
        modifiers.append((5325, 4096))
    if ability == "sharpness" and "slicing" in move.flags:
        modifiers.append((3, 2))
    # 043-2a (19): Strong Jaw (bite), Mega Launcher (pulse), Flare Boost, Toxic Boost
    if (ability == "strongjaw" and "bite" in move.flags) or (
        ability == "megalauncher" and "pulse" in move.flags
    ):
        modifiers.append((3, 2))
    if (ability == "flareboost" and status == "brn" and move.category == "Special") or (
        ability == "toxicboost" and status in ("psn", "tox") and move.category == "Physical"
    ):
        modifiers.append((3, 2))
    if (item == "muscleband" and move.category == "Physical") or (
        item == "wiseglasses" and move.category == "Special"
    ):
        modifiers.append((4505, 4096))
    if ability == PUNK_ROCK and "sound" in move.flags:  # 043-2a (7)
        modifiers.append((5325, 4096))
    return modifiers


def attack_modifier(
    ability: str,
    move: Move,
    *,
    statused: bool,
    hp: int = 0,
    max_hp: int = 0,
    weather: str | None = None,
    terrain: str | None = None,
    ally_abilities: frozenset[str] = frozenset(),
    target_fresh: bool = False,
) -> tuple[int, int] | None:
    """The user's ``onModifyAtk``/``onModifySpA`` (priority 5): Guts (Atk, with a status
    condition), Dragon's Maw (Dragon), Transistor (Electric), Overgrow (Grass at 1/3 HP, 032)."""
    if PINCH_TYPES.get(ability) == move.type and max_hp and hp <= max_hp / 3:
        return (3, 2)
    if ability == "rockypayload" and move.type == "Rock":  # 043-2a
        return (3, 2)
    if ability == "solarpower" and move.category == "Special" and weather == SUN:
        return (3, 2)  # 043-2a: the user's effectiveWeather
    if ability == "stakeout" and target_fresh:
        return (2, 1)  # 043-2a: !defender.activeTurns
    if ability == "guts" and statused and move.category == "Physical":
        return (3, 2)
    if ability == "dragonsmaw" and move.type == "Dragon":
        return (3, 2)
    if ability == "transistor" and move.type == "Electric":
        return (5325, 4096)
    # 043-1: ``weather`` is the user's effectiveWeather (Utility Umbrella)
    physical = move.category == "Physical"
    if ability in ("hugepower", "purepower") and physical:
        return (2, 1)
    if ability == ORICHALCUM_PULSE and physical and weather == SUN:
        return (5461, 4096)
    if ability == HADRON_ENGINE and not physical and terrain == ELECTRIC:
        return (5461, 4096)
    if ability in ("plus", "minus") and not physical and ally_abilities & {"plus", "minus"}:
        return (3, 2)
    return None


def fails_skill_swap(ability: str) -> bool:
    """027: ``flags.failskillswap`` (Protosynthesis, Quark Drive, Embody Aspect, ...)."""
    data = get_dex().ability(ability) if ability else None
    return data is not None and data.fail_skill_swap


def is_breakable(ability: str) -> bool:
    """``flags.breakable``: ignored by a Mold Breaker user's move."""
    data = get_dex().ability(ability) if ability else None
    return data is not None and data.breakable


def weather_speed(ability: str, weather: str | None) -> bool:
    """Chlorophyll / Swift Swim / Sand Rush / Slush Rush ``onModifySpe``: x2."""
    return weather is not None and WEATHER_SPEED.get(ability) == weather
