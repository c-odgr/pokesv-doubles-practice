"""What the screens do (Showdown ``data/moves.ts`` reflect, lightscreen, auroraveil, and the
moves that break them: brickbreak, psychicfangs, ragingbull).

The screens themselves (which side, turns left) are side conditions in ``field.py``. Functions
here take plain values so that damage calculation stays independent of the battle.
"""

from __future__ import annotations

from collections.abc import Collection
from dataclasses import replace

from pokesv_sim.dex import Move
from pokesv_sim.field import AURORA_VEIL, LIGHT_SCREEN, REFLECT
from pokesv_sim.order import speed_sort
from pokesv_sim.prng import Prng

# chainModify([2732, 4096]) when activePerHalf > 1 (always, in doubles).
SCREEN_MODIFIER = (2732, 4096)
_BY_CATEGORY = {"Physical": REFLECT, "Special": LIGHT_SCREEN}
SCREEN_BREAKERS = frozenset({"brickbreak", "psychicfangs", "ragingbull"})
_RAGING_BULL_TYPE = {
    "Tauros-Paldea-Combat": "Fighting",
    "Tauros-Paldea-Blaze": "Fire",
    "Tauros-Paldea-Aqua": "Water",
}


def reduces(screens: Collection[str], move: Move, crit: bool) -> bool:
    """``onAnyModifyDamage`` of the defender side's screens: Reflect (physical), Light Screen
    (special) or Aurora Veil (both, giving way to the screen of the move's category), never on a
    critical hit. At most one of them applies."""
    if crit or move.category not in _BY_CATEGORY:
        return False
    return _BY_CATEGORY[move.category] in screens or AURORA_VEIL in screens


def modify_damage_draws(screens_on_field: int, prng: Prng) -> None:
    """``runEvent('ModifyDamage')`` collects the ``onAnyModifyDamage`` handler of every screen on
    the field (both sides) and speed-sorts them: all equal, so two or more are shuffled."""
    speed_sort(list(range(screens_on_field)), prng, lambda a, b: 0)


def breaks_screens(move: Move) -> bool:
    """``onTryHit``: the move removes the target side's screens before it hits."""
    return move.id in SCREEN_BREAKERS


def modify_type(move: Move, species_name: str) -> Move:
    """Raging Bull's ``onModifyType``: the type of the user's Paldean Tauros forme."""
    if move.id == "ragingbull" and species_name in _RAGING_BULL_TYPE:
        return replace(move, type=_RAGING_BULL_TYPE[species_name])
    return move
