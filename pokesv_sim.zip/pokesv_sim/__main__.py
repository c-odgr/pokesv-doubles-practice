"""Entry point: python -m pokesv_sim."""

import sys

from pokesv_sim.cli import main

sys.exit(main())
