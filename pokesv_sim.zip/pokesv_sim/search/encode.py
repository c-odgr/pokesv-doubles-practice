"""052 (stage 1): a battle as numbers for the value network, from one side's seat.

``encode(battle, side)`` gives a fixed-length list of floats: eight Pokémon blocks (this
side's four brought ones, then the foe's; each side's active slots first, then the bench,
then the fainted) and a block for the field, with 036's leaf features at the end. It reads
the battle the search plays on (a world: its guesses fill what the side cannot see).
Pure Python, so it runs in the browser version too.
"""

from __future__ import annotations

from pokesv_sim.battle import Battle
from pokesv_sim.search.leaf import FEATURES, _best_hit, features
from pokesv_sim.state import BattlePokemon, action_speed

TYPES = (
    "Normal", "Fire", "Water", "Electric", "Grass", "Ice", "Fighting", "Poison", "Ground",
    "Flying", "Psychic", "Bug", "Rock", "Ghost", "Dragon", "Dark", "Steel", "Fairy",
)  # fmt: skip
STATUSES = ("brn", "par", "psn", "tox", "slp", "frz")
BOOSTS = ("atk", "def", "spa", "spd", "spe", "accuracy", "evasion")
STATS = ("atk", "def", "spa", "spd", "spe")
WEATHERS = ("sun", "rain", "sand", "snow")
TERRAINS = ("electricterrain", "grassyterrain", "psychicterrain", "mistyterrain")
SIDE_CONDITIONS = ("tailwind", "reflect", "lightscreen", "auroraveil")
BROUGHT = 4  # Pokémon per side in a block (doubles: bring four)

MON_SIZE = 4 + len(BOOSTS) + len(STATUSES) + len(TYPES) + 1 + len(STATS) + 2 + BROUGHT + 2
FIELD_SIZE = len(WEATHERS) + len(TERRAINS) + 1 + 2 * (len(SIDE_CONDITIONS) + 1) + 1
SIZE = 2 * BROUGHT * MON_SIZE + FIELD_SIZE + len(FEATURES)


def _weather(name: str | None) -> list[float]:
    name = name or ""
    keys = (("sunnyday", "desolateland"), ("raindance", "primordialsea"), ("sandstorm",),
            ("snow", "hail"))  # fmt: skip
    return [float(any(k in name for k in ks)) for ks in keys]


def _ordered(battle: Battle, side: str) -> list[BattlePokemon | None]:
    s = battle.state.sides[side]
    brought = list(s.brought) or list(s.team[:BROUGHT])
    active = [m for m in s.active if m is not None and not m.fainted]
    rest = [m for m in brought if m not in active and not m.fainted]
    gone = [m for m in brought if m not in active and m.fainted]
    out: list[BattlePokemon | None] = [*active, *rest, *gone][:BROUGHT]
    return out + [None] * (BROUGHT - len(out))


def _mon(
    battle: Battle, mon: BattlePokemon | None, foes: list[BattlePokemon | None]
) -> list[float]:
    if mon is None:
        return [0.0] * MON_SIZE
    alive = not mon.fainted and mon.hp > 0
    out = [1.0, float(alive), float(mon.position is not None and alive), mon.hp / mon.max_hp]
    out += [mon.boosts.get(b, 0) / 6 for b in BOOSTS]
    out += [float(mon.status == s) for s in STATUSES]
    out += [float(t in mon.types) for t in TYPES]
    out.append(float(mon.terastallized is not None))
    out += [mon.stats.get(s, 0) / 200 for s in STATS]
    out += [float(bool(mon.item)), float(mon.choice_lock is not None)]
    field = battle.state.field
    hits = []
    faster = 0.0
    taken = 0.0
    for foe in foes:
        if foe is None or foe.fainted or foe.hp <= 0 or not alive:
            hits.append(0.0)
            continue
        hits.append(min(1.0, _best_hit(mon, foe)[0] * foe.max_hp / max(1, foe.hp)))
        if foe.position is not None:
            taken = max(taken, min(1.0, _best_hit(foe, mon)[0] * mon.max_hp / max(1, mon.hp)))
            if mon.position is not None:
                faster += action_speed(mon, field) > action_speed(foe, field)
    return out + hits + [taken, faster / 2]


def encode(battle: Battle, side: str) -> list[float]:
    """``SIZE`` floats describing ``battle`` as ``side`` stands in it."""
    foe = "p2" if side == "p1" else "p1"
    mine, theirs = _ordered(battle, side), _ordered(battle, foe)
    out: list[float] = []
    for m in mine:
        out += _mon(battle, m, theirs)
    for m in theirs:
        out += _mon(battle, m, mine)
    state = battle.state
    field = state.field
    out += _weather(field.weather)
    out += [float(field.terrain == t) for t in TERRAINS]
    out.append(field.pseudo_weather.get("trickroom", 0) / 5)
    for s in (side, foe):
        conds = field.sides.get(s, {})
        out += [conds.get(c, 0) / 5 for c in SIDE_CONDITIONS]
        out.append(float(not state.sides[s].tera_used))
    out.append(min(state.turn, 20) / 20)
    values = features(battle, side)
    out += [values[f] for f in FEATURES]
    return out
