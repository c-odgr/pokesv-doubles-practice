"""035 (plan R2): the prior guesses at a foe's set, from public statistics.

A species' prior is its tournament sets (item, ability, Tera Type, moves: ``regf_teams.json``),
each with the species' most used spreads (``regf_spreads.json``, Smogon's stats), weighted by
how often they appear. A small share goes to generic guesses (any moves, any item), so that a set
no statistic knows still has somewhere to go (US5-6).
"""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass
from functools import cache
from importlib import resources
from typing import Any

from pokesv_sim.dex import STAT_IDS, get_dex, to_id
from pokesv_sim.regf_teams import regf_teams

GENERIC_WEIGHT = 0.05  # plan Risks: always keep a little room for an unknown set
DEFAULT_NATURE = "Serious"

type Evs = tuple[tuple[str, int], ...]


@dataclass(frozen=True, slots=True)
class SetHypothesis:
    """One guess at a foe's set. In a generic guess, ``None`` (item, ability, Tera Type) and
    empty ``moves`` mean "not known yet": observations fill them in instead of ruling it out."""

    species: str  # species id
    nature: str
    evs: Evs
    item: str | None  # item id ("" for no item)
    ability: str | None  # ability id
    tera_type: str | None
    moves: tuple[str, ...]  # move ids
    generic: bool = False


@cache
def _spreads() -> dict[str, Any]:
    text = resources.files("pokesv_sim.data").joinpath("regf_spreads.json").read_text("utf-8")
    species: dict[str, Any] = json.loads(text)["species"]
    return species


def _evs(table: dict[str, int]) -> Evs:
    return tuple((stat, int(table[stat])) for stat in STAT_IDS)


def spreads(species: str) -> list[tuple[str, Evs, float]]:
    """The species' most used spreads as ``(nature, evs, share)``, heaviest first, the shares
    scaled to add up to 1. A forme without stats uses its base species' (as the import does);
    with none at all, one default: 252 HP and 252 in the better attacking stat."""
    dex = get_dex()
    found = dex.species(species)
    table = _spreads()
    entry = None
    if found is not None:
        entry = table.get(found.id) or table.get(to_id(found.base_species))
    if entry is None:
        stats = found.base_stats if found is not None else {"atk": 1, "spa": 0}
        attack = "atk" if stats["atk"] >= stats["spa"] else "spa"
        evs = dict.fromkeys(STAT_IDS, 0) | {"hp": 252, attack: 252, "spe": 4}
        return [(DEFAULT_NATURE, _evs(evs), 1.0)]
    top = entry.get("top") or [entry]
    total = sum(t["share"] for t in top) or 1.0
    return [(t["nature"], _evs(t["evs"]), t["share"] / total) for t in top]


@cache
def _tournament_sets() -> dict[str, Counter[tuple[str, str, str | None, tuple[str, ...]]]]:
    dex = get_dex()
    out: dict[str, Counter[tuple[str, str, str | None, tuple[str, ...]]]] = {}
    for team in regf_teams():
        for m in team.team.members:
            species = dex.species(m.species)
            if species is None:
                continue
            key = (
                to_id(m.item or ""),
                to_id(m.ability or ""),
                m.tera_type,
                tuple(sorted(to_id(x) for x in m.moves)),
            )
            out.setdefault(species.id, Counter())[key] += 1
    return out


def _hidden_prior(base_name: str) -> tuple[tuple[SetHypothesis, float], ...]:
    dex = get_dex()
    base = dex.species(base_name)
    if base is None:
        return prior(base_name)
    used = {}
    for sid, sets in _tournament_sets().items():
        found = dex.species(sid)
        if found is not None and found.base_species == base.base_species:
            used[sid] = sum(sets.values())
    total = sum(used.values())
    if not total:
        return prior(base.id)
    likelier = sorted(used.items(), key=lambda kv: (-kv[1], kv[0]))
    return tuple((h, w * n / total) for sid, n in likelier for h, w in prior(sid))


@cache
def prior(species: str) -> tuple[tuple[SetHypothesis, float], ...]:
    """The prior guesses for ``species`` (a name or id) and their weights, adding up to 1.
    A forme preview hides (``Urshifu-*``, 054): each forme's guesses, by how often it is used."""
    if species.endswith("-*"):
        return _hidden_prior(species.removesuffix("-*"))
    dex = get_dex()
    found = dex.species(species)
    sid = found.id if found is not None else to_id(species)
    spread_list = spreads(species)
    sets = _tournament_sets().get(sid, Counter())
    out: list[tuple[SetHypothesis, float]] = []
    generic_share = GENERIC_WEIGHT if sets else 1.0
    total = sum(sets.values())
    for (item, ability, tera, moves), count in sorted(sets.items(), key=lambda kv: -kv[1]):
        for nature, evs, share in spread_list:
            weight = (1 - generic_share) * count / total * share
            out.append((SetHypothesis(sid, nature, evs, item, ability, tera, moves), weight))
    for nature, evs, share in spread_list:
        hyp = SetHypothesis(sid, nature, evs, None, None, None, (), generic=True)
        out.append((hyp, generic_share * share))
    return tuple(out)
