"""035 (plan R3): the AI's guesses at each foe's set, updated by what its side sees.

``Belief`` holds one foe's weighted guesses (from ``sets.prior``); each observation multiplies
the weights by how likely it is under each guess (0 when it contradicts the guess) and scales
them back to add up to 1. When nothing is left, generic guesses that fit everything seen so far
take over (US5-6). ``Beliefs`` keeps one ``Belief`` per foe species and reads the side's log.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from dataclasses import replace

from pokesv_sim.ai.estimate import field_of
from pokesv_sim.ai.infer import damage_dealt, damage_taken, move_order, skipped_best
from pokesv_sim.ai.observe import Hit, Order, hits_and_orders
from pokesv_sim.ai.sets import SetHypothesis, prior, spreads
from pokesv_sim.dex import get_dex, to_id
from pokesv_sim.events import Event
from pokesv_sim.view import FoePokemonView, SideView, species_key

MAX_MOVES = 4
# Effects named on a damage / heal line that the other Pokémon holds, not the one it hits
NOT_OWN_MOVES = frozenset({"struggle", "recharge"})  # used without knowing them
OTHER_HOLDER = frozenset({"rockyhelmet", "roughskin", "ironbarbs", "aftermath", "innardsout"})


class Belief:
    """One foe's guesses. ``observe_*`` take names as shown (``"Knock Off"``) or ids."""

    def __init__(self, species: str) -> None:
        found = get_dex().species(species)
        self.key = species_key(species)
        self.hidden = species.endswith("-*")  # 054: which forme is not known yet
        self.name = species  # as given: preview's ``Urshifu-*`` until the forme is seen
        self.species = found.id if found is not None else to_id(species)
        self._abilities = frozenset(to_id(a) for a in found.abilities) if found else frozenset()
        self._hyps: list[tuple[SetHypothesis, float]] = list(prior(species))
        if self.hidden:  # the likelier forme (all its guesses together) stands for it
            totals: dict[str, float] = {}
            for h, w in self._hyps:
                totals[h.species] = totals.get(h.species, 0.0) + w
            self.species = max(totals, key=lambda sid: totals[sid])
            self._abilities = frozenset(
                to_id(a)
                for sid in {h.species for h, _ in self._hyps}
                if (forme := get_dex().species(sid)) is not None
                for a in forme.abilities
            )
        self.moves: list[str] = []  # moves seen, in order
        self.item: str | None = None
        self.ability: str | None = None
        self.tera_type: str | None = None

    def hypotheses(self) -> list[tuple[SetHypothesis, float]]:
        """The guesses still possible (weight > 0), heaviest first."""
        return sorted(((h, w) for h, w in self._hyps if w > 0), key=lambda hw: -hw[1])

    def top(self, k: int, forme: str | None = None) -> list[tuple[SetHypothesis, float]]:
        """The ``k`` heaviest guesses (of ``forme`` only, if given), their weights scaled to add
        up to 1."""
        best = [hw for hw in self.hypotheses() if forme is None or hw[0].species == forme][:k]
        total = sum(w for _, w in best) or 1.0
        return [(h, w / total) for h, w in best]

    # -- observations -----------------------------------------------------------------------

    def reveal(self, forme: str) -> None:
        """054: a hidden forme was seen on the field: only its guesses are left."""
        found = get_dex().species(forme)
        if not self.hidden or found is None or forme.endswith("-*"):
            return
        self.hidden = False
        self.name = found.name
        self.species = found.id
        self._abilities = frozenset(to_id(a) for a in found.abilities)
        self._apply(lambda h: h if h.species == found.id else None)

    def observe_move(self, move: str) -> None:
        move_id = to_id(move)
        if move_id in self.moves:
            return
        self.moves.append(move_id)

        def fit(h: SetHypothesis) -> SetHypothesis | None:
            if move_id in h.moves:
                return h
            if h.generic and len(h.moves) < MAX_MOVES:
                return replace(h, moves=(*h.moves, move_id))
            return None

        self._apply(fit)

    def observe_item(self, item: str) -> None:
        item_id = to_id(item)
        self.item = item_id
        self._apply(lambda h: _fill(h, "item", item_id))

    def observe_ability(self, ability: str) -> None:
        """Only an ability the species can have says something about its set (Trace and
        Skill Swap show abilities it did not come with)."""
        ability_id = to_id(ability)
        if self._abilities and ability_id not in self._abilities:
            return
        self.ability = ability_id
        self._apply(lambda h: _fill(h, "ability", ability_id))

    def observe_tera(self, tera_type: str) -> None:
        self.tera_type = tera_type
        self._apply(lambda h: _fill(h, "tera_type", tera_type))

    def reweight(self, likelihood: Callable[[SetHypothesis], float]) -> None:
        """Multiply each guess's weight by how likely an observation is under it."""
        kept = [(h, w * likelihood(h)) for h, w in self._hyps if w > 0]
        total = sum(w for _, w in kept)
        if total > 0:
            self._hyps = [(h, w / total) for h, w in kept]

    def _apply(self, fit: Callable[[SetHypothesis], SetHypothesis | None]) -> None:
        kept: list[tuple[SetHypothesis, float]] = []
        for h, w in self._hyps:
            if w <= 0:
                continue
            new = fit(h)
            if new is not None:
                kept.append((new, w))
        if not kept:
            kept = self._generic()
        total = sum(w for _, w in kept)
        self._hyps = [(h, w / total) for h, w in kept]

    def _generic(self) -> list[tuple[SetHypothesis, float]]:
        """US5-6: generic guesses holding everything seen so far."""
        return [
            (
                SetHypothesis(
                    self.species,
                    nature,
                    evs,
                    self.item,
                    self.ability,
                    self.tera_type,
                    tuple(self.moves[-MAX_MOVES:]),
                    generic=True,
                ),
                share,
            )
            for nature, evs, share in spreads(self.species)
        ]


def _fill(h: SetHypothesis, field: str, value: str) -> SetHypothesis | None:
    known = getattr(h, field)
    if known == value:
        return h
    if known is None:  # a generic guess learns it
        return replace(h, **{field: value})  # type: ignore[arg-type]
    return None


class Beliefs:
    """The guesses for every foe seen at team preview, kept up to date from the side's log."""

    def __init__(self, foe_species: Iterable[str], side: str) -> None:
        self.foe = "p2" if side == "p1" else "p1"
        # keyed like ``__getitem__`` looks up: a cosmetic forme (Showdown's preview shows
        # "Florges-Blue") has the id of its base (053: the key was "florgesblue", the lookup
        # "florges")
        self._by_species = {species_key(s): Belief(s) for s in foe_species}
        self._at: dict[str, str] = {}  # foe position label -> species id
        self._traded: set[str] = set()  # species whose item was swapped (Trick): items say nothing
        self._lost: set[str] = set()  # species that lost their item (it holds nothing now)
        self._last: Event | None = None
        self._hp: dict[str, int] = {}  # position label -> HP shown (own: HP, foe: percentage)
        self._own_at: dict[str, int] = {}  # own position label -> team index
        self._own_tera: dict[int, str] = {}  # own team index -> the Tera Type it took
        self.fainted: set[str] = set()  # 036: foe species seen fainting
        self._attacks: list[tuple[str, str]] = []  # (species, move) the foe attacked with

    def __getitem__(self, species: str) -> Belief:
        return self._by_species[species_key(species)]

    def at(self, label: str) -> Belief | None:
        """The guesses for the foe at a position label (``"p2a"``)."""
        species = self._at.get(label)
        return self._by_species.get(species) if species else None

    def read(self, log: Sequence[Event], view: SideView | None = None) -> None:
        """Read the side's log. With the view of the next decision, the hits and move orders
        are also read (US5-2..4): their conditions are taken from that view."""
        for e in log:
            own_switch = (
                e.kind in ("switch", "drag") and e.actor and not e.actor.startswith(self.foe)
            )
            if own_switch and e.actor and e.team_index is not None:
                self._own_at[e.actor] = e.team_index
            own_tera = e.kind == "terastallize" and e.target and not e.target.startswith(self.foe)
            if own_tera and e.target in self._own_at and e.detail:
                self._own_tera[self._own_at[e.target]] = e.detail  # (fainting clears it)
            self._read(e)
            self._last = e
        hits, orders = hits_and_orders(log, self._hp)
        if view is not None:
            for belief, likelihood, _ in self.likelihoods(hits, orders, view):
                belief.reweight(likelihood)
            for belief, likelihood in self._tendencies(view):
                belief.reweight(likelihood)
        self._attacks = []

    def see_field(self, view: SideView) -> None:
        """055: for a view that comes with no log (the search's imagined foe, a playout): the
        foes on the field, as their switch records would have shown them. Without it there are
        no guesses at their positions (``at``), so nothing is known of them."""
        for p in view.foe_active:
            if p is not None and not p.fainted:
                label = f"{self.foe}{'ab'[p.position]}"
                self._read(Event("switch", view.turn, actor=label, detail=p.species))

    def reindex_own(self, index: dict[int, int]) -> None:
        """055: go on in an imagined battle, whose own team is numbered ``index[real]``."""
        self._own_at = {label: index.get(i, -1) for label, i in self._own_at.items()}
        self._own_tera = {index[i]: t for i, t in self._own_tera.items() if i in index}

    def reveal_active(self, view: SideView) -> None:
        """054: the foes on the field show their forme. Only for a side with no log (the
        search's imagined foe): the view shows a Transformed Pokémon as what it copied, so
        ``read`` takes the forme from the switch records instead."""
        for p in view.foe_active:
            if p is not None:
                self._reveal(p.species)

    def _reveal(self, species: str) -> None:
        belief = self._by_species.get(species_key(species))
        if belief is not None:
            belief.reveal(species)

    def _tendencies(self, view: SideView) -> list[tuple[Belief, Callable[[SetHypothesis], float]]]:
        """US5-5: the attacks the foe chose since the last decision, against this side's
        Pokémon on the field now."""
        targets = [
            p.types for p in view.team if p.position is not None and not p.fainted and p.types
        ]
        out = []
        for species, move in self._attacks:
            belief = self._by_species.get(species)
            found = get_dex().species(belief.species) if belief is not None else None
            if belief is None or found is None or not targets:
                continue
            user_types = (belief.tera_type,) if belief.tera_type else found.types
            out.append((belief, skipped_best(move, user_types, targets)))
        return out

    def _shown(self, view: SideView, label: str) -> FoePokemonView | None:
        foe = view.foe_active[0 if label[2] == "a" else 1]
        belief = self.at(label)
        if foe is None or belief is None or species_key(foe.species) != belief.key:
            return None
        return foe

    def likelihoods(
        self, hits: Sequence[Hit], orders: Sequence[Order], view: SideView
    ) -> list[tuple[Belief, Callable[[SetHypothesis], float], str]]:
        """Each observation as (the foe's guesses, its likelihood, "taken" / "dealt" /
        "order"), with the conditions of ``view``."""
        out: list[tuple[Belief, Callable[[SetHypothesis], float], str]] = []
        by_index = {
            p.team_index: replace(p, terastallized=self._own_tera[p.team_index])
            if p.fainted and p.team_index in self._own_tera
            else p
            for p in view.team
        }
        actives = [self.at(f"{self.foe}{c}") for c in "ab"]
        abilities = [b.ability for b in actives if b is not None and b.ability]
        field = field_of(view, abilities)
        for hit in hits:
            foe_hits = hit.attacker.startswith(self.foe)
            if foe_hits == hit.target.startswith(self.foe):
                continue  # a hit on an ally
            foe_label, own_label = (
                (hit.attacker, hit.target) if foe_hits else (hit.target, hit.attacker)
            )
            belief = self.at(foe_label)
            own = by_index.get(self._own_at.get(own_label, -1))
            if belief is None or own is None:
                continue
            lost = belief.key in self._lost
            shown = self._shown(view, foe_label)
            tera = belief.tera_type
            if foe_hits and hit.damage is not None:
                out.append((belief, damage_taken(hit, own, shown, field, lost, tera), "taken"))
            elif not foe_hits and hit.hp_before is not None:
                out.append((belief, damage_dealt(hit, own, shown, field, lost, tera), "dealt"))
        own_side = dict(view.own_side_conditions)
        foe_side = dict(view.foe_side_conditions)
        trick_room = "trickroom" in dict(view.field_conditions)
        for order in orders:
            foe_first = order.first.startswith(self.foe)
            foe_label, own_label = (
                (order.first, order.second) if foe_first else (order.second, order.first)
            )
            belief = self.at(foe_label)
            own = by_index.get(self._own_at.get(own_label, -1))
            if belief is None or own is None:
                continue
            likelihood = move_order(
                own, self._shown(view, foe_label), foe_first, "tailwind" in own_side,
                "tailwind" in foe_side, trick_room, belief.key in self._lost,
            )  # fmt: skip
            out.append((belief, likelihood, "order"))
        return out

    def _read(self, e: Event) -> None:
        if e.kind == "faint" and e.target and e.target.startswith(self.foe):
            species = self._at.get(e.target)
            if species is not None:
                self.fainted.add(species)
            return
        if e.kind in ("switch", "drag", "replace", "detailschange"):
            label = e.actor if e.kind in ("switch", "drag") else e.target
            if label and label.startswith(self.foe) and e.detail:
                species = species_key(e.detail)
                if e.kind == "detailschange" and label in self._at:
                    return  # a forme change of the same Pokémon (Terastal formes): keep its guesses
                self._reveal(e.detail)
                self._at[label] = species
            return
        if e.kind == "swap" and e.actor and e.actor.startswith(self.foe):
            other = e.actor[:2] + ("b" if e.actor[2] == "a" else "a")
            mine, theirs = self._at.get(e.actor), self._at.get(other)
            for place, who in ((other, mine), (e.actor, theirs)):
                if who is None:
                    self._at.pop(place, None)
                else:
                    self._at[place] = who
            return
        about = e.actor if e.kind == "move" else e.target
        belief = self.at(about) if about and about.startswith(self.foe) else None
        if belief is None:
            return
        if e.kind == "move" and e.detail:
            if self._called(e) or to_id(e.detail) in NOT_OWN_MOVES:
                return
            belief.observe_move(e.detail)
            move = get_dex().move(e.detail)
            if move is not None and move.category != "Status":
                self._attacks.append((belief.key, move.id))
        elif e.kind == "terastallize" and e.detail:
            belief.observe_tera(e.detail)
        elif e.kind == "ability" and e.detail:
            belief.observe_ability(e.detail)
        elif e.kind == "item":
            self._traded.add(belief.key)  # Trick (Air Balloon's announcement: see enditem)
        elif e.kind == "enditem" and e.detail:
            self._lost.add(belief.key)
            if belief.key not in self._traded:
                belief.observe_item(e.detail)
        if e.detail and e.kind in ("damage", "heal"):
            source, _, name = e.detail.partition(": ")
            if to_id(name) in OTHER_HOLDER:
                return  # the attacker's foe holds it (Rocky Helmet hurts the attacker)
            if source == "item" and name and belief.key not in self._traded:
                belief.observe_item(name)
            elif source == "ability" and name:
                belief.observe_ability(name)

    def _called(self, e: Event) -> bool:
        """A move another move called right away (Sleep Talk) is not one of the user's own."""
        last = self._last
        return last is not None and last.kind == "move" and last.actor == e.actor
