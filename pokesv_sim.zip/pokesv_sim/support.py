"""What the engine can simulate today, and which parts of a team it cannot (constitution IV).

Support is decided from Showdown's own definitions: a move or ability is supported only when its
definition carries nothing beyond the fields this engine implements. Widening support in later
features means widening these rules, never ignoring an effect.
"""

from __future__ import annotations

from functools import cache

from pokesv_sim.dex import Item, Move, Secondary, get_dex, to_id
from pokesv_sim.items import (
    LEGEND_CRYSTALS,
    NO_EAT_BERRIES,
    OGERPON_MASKS,
    PINCH_BERRIES,
    POWER_ITEMS,
    RESIST_BERRIES,
    SEEDS,
    TYPE_BOOSTERS,
    WEATHER_ROCKS,
)
from pokesv_sim.team import Team

NO_ABILITY = "noability"

# Raw Showdown move fields that carry no behaviour beyond what the engine implements.
_PLAIN_MOVE_KEYS = frozenset(
    {
        "num", "name", "type", "category", "basePower", "accuracy", "pp", "priority", "target",
        "flags", "contestType", "maxMove", "zMove",
    }
)  # fmt: skip
_SUPPORTED_TARGETS = frozenset({"normal", "any", "adjacentFoe", "allAdjacentFoes", "allAdjacent"})
# Flags that change how a move is used, not just how it is classified.
_BEHAVIOUR_FLAGS = frozenset({"cantusetwice", "charge", "recharge", "futuremove"})
_PLAIN_ABILITY_KEYS = frozenset({"num", "name", "flags", "rating"})

# 003: status conditions, from status moves or as secondary effects.
STATUSES = frozenset({"brn", "par", "psn", "tox", "slp", "frz"})
_DAMAGING_EXTRA_KEYS = frozenset(
    {"secondary", "secondaries", "thawsTarget",  # 003
     "self", "critRatio", "willCrit", "recoil", "drain", "multihit",  # 004
     "breaksProtect"}  # 009 (Feint)
)  # fmt: skip
_STATUS_MOVE_KEYS = _PLAIN_MOVE_KEYS | {"status", "ignoreImmunity", "boosts", "volatileStatus"}
_STATUS_MOVE_TARGETS = frozenset(
    {"normal", "allAdjacentFoes", "self", "adjacentAlly", "adjacentAllyOrSelf"}
)

# 005: volatile statuses, as secondary effects (flinch, confusion) or from status moves.
SECONDARY_VOLATILES = frozenset({"flinch", "confusion"})
STATUS_MOVE_VOLATILES = frozenset({"confusion"})

# Moves whose Showdown definition has functions that this engine ports by hand (constitution IV:
# listed here with the function ported; the battle implements exactly that function).
HAND_PORTED_MOVES: dict[str, dict[str, str]] = {
    "fakeout": {"onTry": "fails unless it is the user's first move since switching in"},
    # 013: removes the target's item.
    "knockoff": {
        "onBasePower": "x1.5 when the target's item can be taken",
        "onAfterHit": "takes the target's item",
    },
    # 014: switch the user out after the move (selfSwitch).
    "uturn": {"selfSwitch": "the user switches out after hitting"},
    "voltswitch": {"selfSwitch": "the user switches out after hitting"},
    "flipturn": {"selfSwitch": "the user switches out after hitting"},
    # 015 (research R1-R7)
    "suckerpunch": {"onTry": "fails unless the target's queued action is a non-status move"},
    "thunderclap": {"onTry": "fails unless the target's queued action is a non-status move"},
    "stompingtantrum": {"basePowerCallback": "x2 when the user's last move failed"},
    "facade": {"onBasePower": "x2 with a status but sleep (and no burn halving)"},
    "heavyslam": {"basePowerCallback": "weight ratio", "onTryHit": "fails on Dynamax"},
    "heatcrash": {"basePowerCallback": "weight ratio", "onTryHit": "fails on Dynamax"},
    "eruption": {"basePowerCallback": "150 * hp / maxhp"},
    "acrobatics": {"basePowerCallback": "x2 without an item"},
    "pollenpuff": {
        "onTryHit": "on an ally: no damage",
        "onTryMove": "Heal Block (unsupported, never active)",
        "onHit": "on an ally: heals half its max HP",
    },
    "lunarblessing": {"onHit": "user and ally heal 1/4 and are cured"},
    "partingshot": {
        "onHit": "target Atk -1 SpA -1; no switch when neither drops (unless Mirror Armor)",
        "selfSwitch": "the user switches out",
    },
    # 006: field and side conditions (``condition``: duration, start/restart/end, ModifySpe).
    "trickroom": {"condition": "5 turns; using it again ends it; reverses speed order"},
    "tailwind": {"condition": "4 turns; fails if already set; doubles the side's speed"},
    # 007: weather (``condition`` = the weather in data/conditions.ts: duration, start, upkeep,
    # end, damage modifier, Rock SpD / Ice Def, sandstorm damage, no freezing in sun).
    "sunnyday": {"condition": "5 turns; Fire x1.5, Water x0.5 (Hydro Steam x1.5); no freezing"},
    "raindance": {"condition": "5 turns; Water x1.5, Fire x0.5"},
    "sandstorm": {"condition": "5 turns; Rock SpD x1.5; 1/16 damage unless Rock/Ground/Steel"},
    "snowscape": {"condition": "5 turns; Ice Def x1.5"},
    # 007: moves that change with the weather.
    "thunder": {"onModifyMove": "always hits in rain; 50% accuracy in sun"},
    "hurricane": {"onModifyMove": "always hits in rain; 50% accuracy in sun"},
    "blizzard": {"onModifyMove": "always hits in snow"},
    "bleakwindstorm": {"onModifyMove": "always hits in rain"},
    "wildboltstorm": {"onModifyMove": "always hits in rain"},
    "sandsearstorm": {"onModifyMove": "always hits in rain"},
    "weatherball": {
        "onModifyType": "Fire / Water / Rock / Ice in sun / rain / sand / snow",
        "onModifyMove": "double power in any weather",
    },
    # 008: screens (side conditions: 5 turns, fail if already set, ModifyDamage x2732/4096 in
    # doubles unless a crit; Aurora Veil gives way to the screen of the same category).
    "reflect": {"condition": "5 turns; physical damage to the side x2732/4096 (not crits)"},
    "lightscreen": {"condition": "5 turns; special damage to the side x2732/4096 (not crits)"},
    "auroraveil": {
        "condition": "5 turns; all damage to the side x2732/4096 (not crits)",
        "onTry": "fails unless it is snowing",
    },
    # 008: moves that break the target side's screens before the hit (TryHit).
    "brickbreak": {"onTryHit": "removes the target side's screens"},
    "psychicfangs": {"onTryHit": "removes the target side's screens"},
    "ragingbull": {
        "onTryHit": "removes the target side's screens",
        "onModifyType": "Fighting / Fire / Water for Paldean Tauros (Combat / Blaze / Aqua)",
    },
    # 009: protection (one-turn volatiles; ``stall``: 1/3^n success in a row).
    **{
        m: {
            "onPrepareHit": "fails unless a later action is queued, then the stall check",
            "onHit": "adds the stall volatile",
            "condition": desc,
        }
        for m, desc in {
            "protect": "blocks moves with the protect flag this turn",
            "detect": "blocks moves with the protect flag this turn",
            "spikyshield": "blocks; contact loses 1/8 of its max HP",
            "banefulbunker": "blocks; contact is poisoned",
            "silktrap": "blocks (not status moves); contact loses 1 Speed stage",
            "burningbulwark": "blocks (not status moves); contact is burned",
            "endure": "survives a move's damage with 1 HP this turn",
        }.items()
    },
    "wideguard": {
        "onTry": "fails unless a later action is queued",
        "onHitSide": "adds the stall volatile",
        "condition": "blocks spread moves on the side this turn",
    },
    "quickguard": {
        "onTry": "fails unless a later action is queued",
        "onHitSide": "adds the stall volatile",
        "condition": "blocks moves of raised priority on the side this turn",
    },
    "followme": {
        "onTry": "always succeeds in doubles",
        "condition": "redirects the foes' single-target moves this turn",
    },
    "ragepowder": {
        "onTry": "always succeeds in doubles",
        "condition": "redirects the foes' single-target moves (not powder-immune users)",
    },
    "helpinghand": {
        "onTryHit": "fails if the ally already moved",
        "condition": "the ally's moves get x1.5 base power this turn",
    },
    "allyswitch": {
        "onPrepareHit": "allyswitch volatile: 1/3^n success in a row",
        "onHit": "swaps places with the ally (fails without one)",
        "condition": "the consecutive-use counter",
    },
}
# 010: terrain (``condition``: 5 turns; grounded Pokémon only).
HAND_PORTED_MOVES.update(
    {
        "electricterrain": {"condition": "Electric moves x5325/4096; grounded Pokémon stay awake"},
        "grassyterrain": {
            "condition": "Grass moves x5325/4096; Earthquake, Bulldoze x0.5; heals 1/16"
        },
        "psychicterrain": {
            "condition": "Psychic moves x5325/4096; blocks the foes' priority moves"
        },
        "mistyterrain": {"condition": "Dragon moves x0.5; no status conditions or confusion"},
        # 010: moves that change with the terrain, and moves that end it.
        "terrainpulse": {
            "onModifyType": "the terrain's type when the user is grounded",
            "onModifyMove": "double power in a terrain when the user is grounded",
        },
        "expandingforce": {
            "onBasePower": "x1.5 in Psychic Terrain when the user is grounded",
            "onModifyMove": "hits both foes in Psychic Terrain when the user is grounded",
        },
        "risingvoltage": {
            "basePowerCallback": "double power on a grounded target in Electric Terrain"
        },
        "grassyglide": {
            "onModifyPriority": "+1 priority in Grassy Terrain when the user is grounded"
        },
        "psyblade": {"onBasePower": "x1.5 in Electric Terrain"},
        "steelroller": {
            "onTry": "fails without a terrain",
            "onHit": "ends the terrain",
            "onAfterSubDamage": "ends the terrain (no substitutes in this engine)",
        },
        "icespinner": {
            "onAfterHit": "ends the terrain",
            "onAfterSubDamage": "ends the terrain (no substitutes in this engine)",
        },
    }
)

# 020: entry hazards (side conditions with layers on the foes' side; their onSwitchIn effects,
# battle._hazard_switch_in). ``reflectable`` (Magic Bounce) and ``mustpressure`` (Pressure)
# have no effect while those abilities are unsupported.
HAND_PORTED_MOVES.update(
    {
        "stealthrock": {"condition": "1 layer; on switch-in maxhp * 2^(Rock typeMod) / 8"},
        "spikes": {"condition": "3 layers; on a grounded switch-in 3/4/6 x maxhp / 24"},
        "toxicspikes": {
            "condition": "2 layers; a grounded switch-in is poisoned (badly at 2) unless "
            "Steel; a grounded Poison type removes them"
        },
        "stickyweb": {"condition": "1 layer; a grounded switch-in gets Spe -1"},
    }
)

# 009: moves whose definition keys (besides functions) this engine implements.
_DOUBLES_MOVE_KEYS = _PLAIN_MOVE_KEYS | {"condition", "stallingMove", "volatileStatus",
                                         "sideCondition"}  # fmt: skip
_DOUBLES_MOVES = frozenset(
    {"protect", "detect", "spikyshield", "banefulbunker", "silktrap", "burningbulwark",
     "endure", "wideguard", "quickguard", "followme", "ragepowder", "helpinghand",
     "allyswitch"}
)  # fmt: skip
_FIELD_MOVE_KEYS = _PLAIN_MOVE_KEYS | {"pseudoWeather", "sideCondition", "weather", "condition",
                                       "terrain"}  # fmt: skip


# Species whose behaviour Showdown implements outside move/ability/item definitions, for
# mechanics this engine has (data/conditions.ts frz onStart: Shaymin-Sky reverts when frozen).
SPECIES_WITH_UNSUPPORTED_MECHANICS = {"shayminsky": "changes forme when frozen"}


def species_supported(species_id: str) -> bool:
    species = get_dex().species(species_id)
    return (
        species is not None
        and species.battle_only is None
        and species.required_item is None
        and species.id not in SPECIES_WITH_UNSUPPORTED_MECHANICS
    )


def _supported_secondary(sec: Secondary) -> bool:
    """A status condition (003), stat stages of the target or the user (004), flinch or
    confusion (005)."""
    if sec.keys <= {"chance", "status"}:
        return sec.status in STATUSES
    if sec.keys <= {"chance", "boosts"}:
        return bool(sec.boosts)
    if sec.keys <= {"chance", "self"}:
        return sec.self_keys <= {"boosts"} and bool(sec.self_boosts)
    if sec.keys <= {"chance", "volatileStatus"}:  # 005
        return sec.volatile_status in SECONDARY_VOLATILES
    return False


def _status_only_secondaries(move: Move) -> bool:
    """Supported secondary effects, and a ``self`` effect that only changes stat stages."""
    self_ok = "self" not in move.keys or (
        move.self_keys <= {"boosts", "chance"} and bool(move.self_boosts)
    )
    return self_ok and all(_supported_secondary(sec) for sec in move.secondaries)


def _ported_functions_only(move: Move) -> bool:
    return move.function_keys <= HAND_PORTED_MOVES.get(move.id, {}).keys()


def _is_supported_damaging(move: Move) -> bool:
    return (
        move.category in ("Physical", "Special")
        and _ported_functions_only(move)
        and move.keys - move.function_keys <= _PLAIN_MOVE_KEYS | _DAMAGING_EXTRA_KEYS
        and _status_only_secondaries(move)
        and move.target in _SUPPORTED_TARGETS
        and not (move.flags & _BEHAVIOUR_FLAGS)
    )


def _is_supported_status_move(move: Move) -> bool:
    return (
        move.category == "Status"
        and not move.function_keys
        and move.keys <= _STATUS_MOVE_KEYS
        and _one_status_move_effect(move)
        and move.target in _STATUS_MOVE_TARGETS
        and (move.target != "self" or bool(move.boosts))
        and not (move.flags & _BEHAVIOUR_FLAGS)
    )


def _one_status_move_effect(move: Move) -> bool:
    """A status condition, stat stages, or confusion (with or without stages: Swagger)."""
    if move.volatile_status is not None:
        return move.volatile_status in STATUS_MOVE_VOLATILES and move.status is None
    return (move.status in STATUSES) != bool(move.boosts)


def _is_supported_field_move(move: Move) -> bool:
    """A field or side condition (006) or a weather (007) whose ``condition`` this engine
    ports by hand."""
    return (
        move.category == "Status"
        and move.id in HAND_PORTED_MOVES
        and "condition" in HAND_PORTED_MOVES[move.id]
        and _ported_functions_only(move)
        and move.keys - move.function_keys <= _FIELD_MOVE_KEYS
        and move.target in ("all", "allySide", "foeSide")
    )


def _is_supported_doubles_move(move: Move) -> bool:
    """009: protection, redirection, Helping Hand and Ally Switch, ported by hand."""
    return (
        move.id in _DOUBLES_MOVES
        and _ported_functions_only(move)
        and move.keys - move.function_keys <= _DOUBLES_MOVE_KEYS
    )


# 014: the moves that switch the user out (selfSwitch: true), ported by hand.
PIVOT_MOVES = frozenset({"uturn", "voltswitch", "flipturn", "partingshot"})


def _is_supported_pivot_move(move: Move) -> bool:
    return (
        move.id in PIVOT_MOVES
        and _ported_functions_only(move)
        and move.keys - move.function_keys <= _PLAIN_MOVE_KEYS | {"selfSwitch"}
        and not move.secondaries
    )


# 015: moves with their own handling, ported by hand. The value is every key beyond the plain
# ones that the engine handles for the move (its functions are in HAND_PORTED_MOVES).
MOVE_EFFECT_KEYS: dict[str, frozenset[str]] = {
    "suckerpunch": frozenset(),
    "thunderclap": frozenset(),
    "taunt": frozenset({"volatileStatus", "condition"}),
    "encore": frozenset({"volatileStatus", "condition"}),
    "sacredsword": frozenset({"ignoreDefensive", "ignoreEvasion"}),
    "stompingtantrum": frozenset(),
    "facade": frozenset(),
    "heavyslam": frozenset(),
    "heatcrash": frozenset(),
    "bodypress": frozenset({"overrideOffensiveStat"}),
    "eruption": frozenset(),
    "acrobatics": frozenset(),
    "recover": frozenset({"heal"}),
    "howl": frozenset({"boosts"}),
    "pollenpuff": frozenset(),
    "lunarblessing": frozenset(),
}
MOVE_EFFECT_MOVES = frozenset(MOVE_EFFECT_KEYS)

# 020: the moves that remove the hazards (specs/020-hazards research R4; battle._spin_away,
# _defog, _tidy_up). Leech Seed, partial trapping, Safeguard and Mist are unsupported, so their
# parts of these functions have nothing to act on.
_SPIN = {
    "onAfterHit": "the hazards on the user's side (not with Sheer Force)",
    "onAfterSubDamage": "the same, behind a substitute",
}
HAND_PORTED_MOVES.update(
    {
        "rapidspin": _SPIN,
        "mortalspin": _SPIN,
        "defog": {
            "onHit": "evasion -1 (not through a substitute); the target side's screens and "
            "hazards, the user side's hazards; the terrain"
        },
        "tidyup": {"onHit": "every substitute, both sides' hazards; Atk and Spe +1"},
    }
)
MOVE_EFFECT_KEYS["defog"] = frozenset()
# 020: Meteor Beam (research R6): the only two-turn move (the charge flag) supported
CHARGE_MOVES = frozenset({"meteorbeam", "electroshot"})  # (021: Electro Shot)
HAND_PORTED_MOVES["meteorbeam"] = {
    "onTryMove": "turn 1: -prepare, SpA +1, ChargeMove (Power Herb), then twoturnmove; "
    "turn 2: fires (no PP, the locked target)"
}
MOVE_EFFECT_KEYS["tidyup"] = frozenset()

# 021: simple moves (specs/021-simple-moves research R1-R8). Each is supported as a whole
# (its data keys are what the battle implements: overrideDefensiveStat, hasSheerForceBoost,
# Throat Chop's condition and secondary onHit, Upper Hand's flinch).
SIMPLE_MOVES_021 = frozenset({
    "dragonenergy", "electroshot", "painsplit", "throatchop", "grassknot", "lowkick",
    "clearsmog", "upperhand", "freezedry", "psyshock", "gyroball",
})  # fmt: skip
_WEIGHT_POWER = {
    "basePowerCallback": "20-120 by the target's weight (10/25/50/100/200 kg)",
    "onTryHit": "fails on Dynamax (not in SV)",
}
HAND_PORTED_MOVES.update(
    {
        "dragonenergy": {"basePowerCallback": "150 * hp / maxhp"},
        "electroshot": {
            "onTryMove": "-prepare, SpA +1; fires at once in the rain; otherwise as Meteor Beam"
        },
        "painsplit": {"onHit": "both HPs become their average (sethp)"},
        "throatchop": {
            "secondary.onHit": "throatchop: 2 turns; sound moves disabled and stopped (cant)"
        },
        "grassknot": _WEIGHT_POWER,
        "lowkick": _WEIGHT_POWER,
        "clearsmog": {"onHit": "clears the target's stat stages"},
        "upperhand": {"onTry": "fails unless the target's queued move is a priority attack"},
        "freezedry": {"onEffectiveness": "super effective on Water"},
        "psyshock": {"overrideDefensiveStat": "def"},
        "gyroball": {"basePowerCallback": "25 * target Spe / user Spe + 1, at most 150"},
    }
)

# 022: moves that keep a state across turns (specs/022-stateful-moves research R1-R7). Each is
# supported as a whole (Blood Moon's cantusetwice, Imprison's and Roost's conditions, Outrage's
# self lockedmove are what the battle implements).
STATEFUL_MOVES_022 = frozenset({"bloodmoon", "imprison", "outrage", "perishsong", "trick", "roost"})
HAND_PORTED_MOVES["perishsong"] = {
    "onHitField": "a count (perish3) for every active Pokémon without one; TryHit can stop it",
}
HAND_PORTED_MOVES["trick"] = {
    "onTryImmunity": "Sticky Hold (unsupported: refused as an ability)",
    "onHit": "takeItem both ways (the items' TakeItem), then setItem (the items' Start)",
}

# 023: moves whose power, damage or state is a little more than the plain ones (specs/023-simple-
# moves-2 research R4-R17). Each is supported as a whole (Scale Shot's selfBoost, Glaive Rush's
# self volatile, Psychic Noise's healblock, Disable's condition are what the battle implements).
SIMPLE_MOVES_023 = frozenset({
    "hex", "assurance", "payback", "lastrespects", "ragefist", "endeavor", "finalgambit",
    "scaleshot", "glaiverush", "psychicnoise", "strengthsap", "haze", "disable",
})  # fmt: skip
HAND_PORTED_MOVES.update(
    {
        "hex": {"basePowerCallback": "x2 against a status condition (Comatose unsupported)"},
        "assurance": {"basePowerCallback": "x2 against a target hurt this turn"},
        "payback": {"basePowerCallback": "x2 unless the target is newly switched or will move"},
        "lastrespects": {"basePowerCallback": "50 + 50 * the user's side's fainted"},
        "ragefist": {"basePowerCallback": "50 + 50 * times attacked, at most 350"},
        "endeavor": {
            "damageCallback": "target HP - user HP",
            "onTryImmunity": "immune unless the user has less HP",
        },
        "finalgambit": {"damageCallback": "the user's HP; the user faints (queued first)"},
        "strengthsap": {"onHit": "fails at -6 Atk; Atk -1, heals the Atk (stage, no modifiers)"},
        "haze": {"onHitField": "-clearallboost; every active Pokémon's stages reset"},
        "disable": {"onTryHit": "fails without a last move or after Struggle"},
    }
)

# 024: the binding moves the tournament teams use (partiallytrapped: specs/024-binding-moves
# research R1-R7) and Ruination (R8). Each is supported as a whole (the partiallytrapped
# condition and Ruination's damageCallback are what the battle implements; Bind, Wrap, Fire
# Spin, Whirlpool, Thunder Cage, Binding Band and Grip Claw stay out).
BINDING_MOVES_024 = frozenset({"sandtomb", "magmastorm", "infestation", "ruination"})
HAND_PORTED_MOVES["ruination"] = {"damageCallback": "half the target's HP, at least 1"}

# 025: Yawn, Sleep Talk, Healing Wish, After You (specs/025-yawn-and-friends research R1-R7).
# Each is supported as a whole (Yawn's condition, Sleep Talk's sleepUsable and callsMove,
# Healing Wish's selfdestruct and slot condition are what the battle implements).
MOVES_025 = frozenset({"yawn", "sleeptalk", "healingwish", "afteryou"})
HAND_PORTED_MOVES["yawn"] = {"onTryHit": "fails against a status condition"}
HAND_PORTED_MOVES["sleeptalk"] = {
    "onTry": "the user must be asleep (Comatose is unsupported)",
    "onHit": "useMove of a random move without nosleeptalk / charge",
}
# 026: Solar Beam / Solar Blade, Sheer Cold / Fissure (ohko), Phantom Force
# (specs/026-charge-and-ohko research R1-R9). Each is supported as a whole (the ohko key,
# breaksProtect and Phantom Force's condition are what the battle implements).
MOVES_026 = frozenset({"solarbeam", "solarblade", "sheercold", "fissure", "phantomforce"})
HAND_PORTED_MOVES.update({
    **{solar: {
        "onTryMove": "-prepare; fires at once in the sun; otherwise as Meteor Beam (no boost)",
        "onBasePower": "x0.5 in the rain, a sandstorm or snow",
    } for solar in ("solarbeam", "solarblade")},
    "phantomforce": {
        "onTryMove": "-prepare, ChargeMove (Power Herb), then twoturnmove",
        "condition": "duration 2, onInvulnerability false (the user vanishes)",
    },
})  # fmt: skip
# 027: Skill Swap and Burning Jealousy (specs/027-skill-swap research R1-R7). Each is
# supported as a whole (Skill Swap's onTryHit/onHit, Burning Jealousy's secondary onHit).
MOVES_027 = frozenset({"skillswap", "burningjealousy"})
HAND_PORTED_MOVES.update({
    "skillswap": {
        "onTryHit": "fails on a fainted Pokemon or a failskillswap ability (either side)",
        "onHit": "-activate; End both, swap the abilities, Start the target's then the "
        "user's",
    },
    "burningjealousy": {
        "secondary.onHit": "burns a target whose stats rose this turn (statsRaisedThisTurn)",
    },
})  # fmt: skip
# 028: Order Up (specs/028-commander research R4; hasSheerForceBoost: Sheer Force's power only).
MOVES_028 = frozenset({"orderup"})
HAND_PORTED_MOVES["orderup"] = {
    "onAfterMoveSecondarySelf": "while commanded: Atk +1 (Curly), Def +1 (Droopy) or Spe +1 "
    "(Stretchy), by the Tatsugiri's form",
}
# 030: the small blockers' moves (specs/030-small-blockers research R4-R9). Each is supported
# as a whole (Dire Claw's secondary onHit, Life Dew's heal, Giga Impact's mustrecharge, Shed
# Tail's substitute and selfSwitch, Dragon Darts' smartTarget are what the battle implements).
MOVES_030 = frozenset({"direclaw", "healpulse", "lifedew", "gigaimpact", "shedtail",
                       "dragondarts"})  # fmt: skip
HAND_PORTED_MOVES.update({
    "healpulse": {"onHit": "heals ceil(1/2); -fail at full HP or heal-blocked (NOT_FAIL)"},
    "shedtail": {
        "onTryHit": "fails with nothing to switch in, a substitute up or at half HP or less",
        "onHit": "a substitute (1/4), pays ceil(1/2); the switch-in keeps only the substitute",
    },
})  # fmt: skip
# 031: Alluring Voice (specs/031-magic-bounce research R5).
MOVES_031 = frozenset({"alluringvoice"})
HAND_PORTED_MOVES["alluringvoice"] = {
    "secondary.onHit": "confuses a target whose stats rose this turn (statsRaisedThisTurn)",
}
# 032: the items' moves, the recovery and the stat-stage moves (specs/032-items-abilities-boosts
# research R8, R9, R14-R16). Fling with a berry or a fling.effect item is refused per team.
MOVES_032 = frozenset({"fling", "thief", "moonlight", "morningsun", "slackoff", "floralhealing",
                       "bellydrum", "clangoroussoul", "storedpower", "curse", "saltcure",
                       "clangingscales"})  # fmt: skip
HAND_PORTED_MOVES.update({
    "fling": {
        "onPrepareHit": "fails without an item (or one it cannot lose); base power "
        "fling.basePower, the item is used; King's Rock flinches",
        "condition": "the flung item counts as held until the next Update",
    },
    "thief": {"onAfterHit": "takes the target's item when the user holds none"},
    "moonlight": {"onHit": "heals 2/3 in the sun, 1/4 in rain, sand, snow, else 1/2"},
    "morningsun": {"onHit": "heals 2/3 in the sun, 1/4 in rain, sand, snow, else 1/2"},
    "floralhealing": {"onHit": "heals ceil(1/2), 2/3 on Grassy Terrain"},
    "bellydrum": {"onHit": "fails at half HP or less or +6 Atk; pays 1/2, Atk to +6"},
    "clangoroussoul": {
        "onTry": "fails at 33% HP or less",
        "onTryHit": "every stat +1 (null when none rose)",
        "onHit": "pays 33% of the max HP",
    },
    "storedpower": {"basePowerCallback": "20 + 20 per positive stage"},
    "curse": {
        "onModifyMove": "a non-Ghost user targets itself; a Ghost aiming at its ally: "
        "randomNormal",
        "onTryHit": "non-Ghost: Spe -1, Atk +1, Def +1 (move.self); fails on a cursed target",
        "onHit": "the Ghost user pays 1/2; the target loses 1/4 each turn (residual 12)",
    },
})  # fmt: skip
# 033: the move calculations (specs/033-move-calculations research R1-R11, R13).
MOVES_033 = frozenset({"nightshade", "superfang", "hardpress", "crushgrip", "darkestlariat",
                       "foulplay", "gigatonhammer", "triattack", "poltergeist",
                       "steelbeam", "populationbomb", "tripleaxel", "beatup",
                       "uproar"})  # fmt: skip
HAND_PORTED_MOVES.update({
    "superfang": {"damageCallback": "half the target's HP, at least 1"},
    "hardpress": {"basePowerCallback": "100 by the target's HP fraction, at least 1"},
    "crushgrip": {"basePowerCallback": "120 by the target's HP fraction, at least 1"},
    "triattack": {"secondary.onHit": "trySetStatus(sample of brn, par, frz)"},
    "poltergeist": {
        "onTry": "fails when the target holds no item",
        "onTryHit": "-activate with the target's item",
    },
    "steelbeam": {"onMoveFail": "the user loses round(max HP / 2) (mindBlownRecoil on a hit)"},
    "tripleaxel": {"basePowerCallback": "20 * the hit number"},
    "beatup": {
        "onModifyMove": "one hit per party member (the user, the rest unfainted and statusless)",
        "basePowerCallback": "5 + that member's base Atk / 10",
    },
    "uproar": {
        "onTryHit": "every sleeping active Pokémon wakes",
        "condition": "duration 3, onLockMove, onResidual (Throat Chop, Struggle), "
        "onAnySetStatus: sleep fails",
    },
})  # fmt: skip
# 034: forced switches, Baton Pass, Minimize (specs/034-forced-switch-illusion research R1-R5).
MOVES_034 = frozenset({"roar", "whirlwind", "batonpass", "minimize"})
HAND_PORTED_MOVES.update({
    "roar": {"forceSwitch": "DragOut, then dragIn at the end of the action (sample of the bench)"},
    "whirlwind": {"forceSwitch": "as Roar"},
    "batonpass": {
        "onHit": "-fail (NOT_FAIL) with nothing to switch in or commanded",
        "self.onHit": "skipBeforeSwitchOutEventFlag",
        "selfSwitch": "copyvolatile: the stages and the volatiles without noCopy",
    },
    "minimize": {
        "condition": "noCopy; onRestart null; onSourceModifyDamage x2 and onAccuracy true for "
        "a move with the minimize flag",
    },
})  # fmt: skip
# 041-1a: moves on mechanisms the battle already has (specs/041-more-moves)
MOVES_041_1A = frozenset({
    "hyperbeam", "blastburn", "hydrocannon", "frenzyplant", "rockwrecker", "prismaticlaser",
    "roaroftime",
    "whirlpool", "firespin", "wrap", "bind",
    "thrash", "petaldance", "ragingfury",
    "seismictoss", "waterspout", "softboiled", "milkdrink", "synthesis", "temperflare",
    "powertrip", "triplekick",
})  # fmt: skip
HAND_PORTED_MOVES.update(
    {
        "waterspout": {"basePowerCallback": "150 * hp / maxhp (as Eruption)"},
        "synthesis": {"onHit": "heals 2/3 in the sun, 1/4 in rain, sand, snow, else 1/2"},
        "temperflare": {"basePowerCallback": "x2 when the user's last move failed"},
        "powertrip": {"basePowerCallback": "20 + 20 per positive stage"},
        "triplekick": {"basePowerCallback": "10 * the hit number"},
    }
)
# 041-1b: new base power formulas
MOVES_041_1B = frozenset({"reversal", "flail", "electroball", "venoshock", "brine"})
HAND_PORTED_MOVES.update(
    {
        "reversal": {"basePowerCallback": "200 to 20 by floor(48 * hp / maxhp)"},
        "flail": {"basePowerCallback": "200 to 20 by floor(48 * hp / maxhp)"},
        "electroball": {"basePowerCallback": "40 to 150 by user Spe / target Spe"},
        "venoshock": {"onBasePower": "x2 against a poisoned target"},
        "brine": {"onBasePower": "x2 against a target at half HP or less"},
    }
)
# 041-1c: crash damage
MOVES_041_1C_CRASH = frozenset({"highjumpkick", "supercellslam", "axekick"})
MOVES_041_1C = MOVES_041_1C_CRASH | {"selfdestruct", "explosion", "mistyexplosion"}
HAND_PORTED_MOVES["mistyexplosion"] = {"onBasePower": "x1.5 in Misty Terrain, user grounded"}
HAND_PORTED_MOVES.update(
    {m: {"onMoveFail": "the user takes 1/2 of its max HP"} for m in MOVES_041_1C_CRASH}
)
# 041-1d: small effects of their own
MOVES_041_1D = frozenset({"falseswipe", "shoreup", "growth", "firstimpression", "fellstinger",
                          "dragontail", "circlethrow"})  # fmt: skip
HAND_PORTED_MOVES.update(
    {
        "falseswipe": {"onDamage": "leaves the target 1 HP (priority -20)"},
        "shoreup": {"onHit": "heals 2/3 in a sandstorm, else 1/2"},
        "growth": {"onModifyMove": "+2 / +2 in the user's sun"},
        "firstimpression": {"onTry": "fails unless it is the user's first move since switching in"},
        "fellstinger": {"onAfterMoveSecondarySelf": "+3 Atk when the target fainted"},
    }
)
# 041-1e: moves that look back on this turn or the last
MOVES_041_1E = frozenset({"retaliate", "lashout", "avalanche"})
HAND_PORTED_MOVES.update(
    {
        "retaliate": {"onBasePower": "x2 when a Pokémon on the user's side fainted last turn"},
        "lashout": {"onBasePower": "x2 when the user's stats were lowered this turn"},
        "avalanche": {"basePowerCallback": "x2 when the target damaged the user this turn"},
    }
)
# 041-1f: Echoed Voice, Round
MOVES_041_1F = frozenset({"echoedvoice", "round"})
HAND_PORTED_MOVES.update(
    {
        "echoedvoice": {
            "basePowerCallback": "x1 to x5 by the echoedvoice pseudo-weather",
            "onTryMove": "addPseudoWeather echoedvoice",
        },
        "round": {"onTry": "calls the next Round forward", "basePowerCallback": "x2 when called"},
    }
)
# 041-1g: Double Shock
MOVES_041_1G = frozenset({"doubleshock"})
HAND_PORTED_MOVES["doubleshock"] = {
    "onTryMove": "fails unless the user is Electric (self onHit: Electric becomes ???)",
}
# 041-2: the two-turn moves that vanish, Sky Attack
MOVES_041_2 = frozenset({"dig", "fly", "dive", "bounce", "shadowforce", "skyattack", "smackdown"})
HAND_PORTED_MOVES.update(
    {
        m: {
            "onTryMove": "-prepare, ChargeMove (Power Herb), then twoturnmove",
            "condition": "duration 2, onInvulnerability (some moves still hit), Dig and Dive: no "
            "sandstorm damage, x2 from Earthquake / Surf; Fly and Bounce: x2 from Gust / Twister",
        }
        for m in ("dig", "fly", "dive", "bounce", "shadowforce")
    }
)
HAND_PORTED_MOVES["smackdown"] = {
    "volatileStatus": "smackdown",
    "condition": "onStart / onRestart: ends Fly and Bounce (cancelMove), grounds a Flying "
    "type or Levitate (not with an Iron Ball)",
}
HAND_PORTED_MOVES["skyattack"] = {"onTryMove": "-prepare, ChargeMove (Power Herb), twoturnmove"}
# 041-3a: the moves that do nothing, Defense Curl, Dragon Cheer
MOVES_041_3A = frozenset({"splash", "celebrate", "happyhour", "defensecurl", "dragoncheer"})
HAND_PORTED_MOVES.update(
    {
        "splash": {"onTry": "Gravity (unsupported)", "onTryHit": "-nothing"},
        "celebrate": {"onTryHit": "-activate"},
        "happyhour": {"onTryHit": "-activate (not run for a side move)"},
        "defensecurl": {"volatileStatus": "defensecurl", "condition": "noCopy, onRestart null"},
        "dragoncheer": {
            "volatileStatus": "dragoncheer",
            "condition": "onStart: fails with Focus Energy, -start; crit ratio +2 (Dragon) or +1",
        },
    }
)
# 041-3b: Rollout, Fury Cutter
MOVES_041_3B = frozenset({"rollout", "furycutter"})
HAND_PORTED_MOVES.update(
    {
        "rollout": {
            "basePowerCallback": "30 x 2 ** hits, x2 (Defense Curl); counts unless asleep",
            "onModifyMove": "addVolatile rollout (not asleep, with a target)",
            "onAfterMove": "rolloutstorage (never: every hit is a contact hit)",
            "condition": "duration 1 (2 below 5 hits), onLockMove; onResidual: Struggle ends it",
        },
        "furycutter": {
            "basePowerCallback": "addVolatile furycutter; 40 x multiplier (1, 2, 4), at most 160",
            "condition": "duration 2; onRestart doubles the multiplier up to 4",
        },
    }
)
# 041-3c: the moves that take an item
MOVES_041_3C = frozenset({"covet", "switcheroo", "bugbite", "pluck", "incinerate"})
HAND_PORTED_MOVES.update(
    {
        "covet": {"onAfterHit": "Thief's"},
        "switcheroo": {"onTryImmunity": "Sticky Hold (unsupported)", "onHit": "Trick's"},
        **{
            m: {"onHit": "a user with HP takes the target's berry and eats it (its onEat)"}
            for m in ("bugbite", "pluck")
        },
        "incinerate": {"onHit": "the target's berry (gems unsupported) is burnt up"},
    }
)
# 041-3d: Rest, Snore
MOVES_041_3D = frozenset({"rest", "snore"})
HAND_PORTED_MOVES.update(
    {
        "rest": {
            "onTry": "fails asleep, at full HP (-fail heal), with Insomnia / Vital Spirit",
            "onHit": "setStatus slp (replaces another status), time 3, heal maxhp",
        },
        "snore": {"onTry": "fails unless asleep (Comatose unsupported)"},
    }
)
# 041-3e: Mist, Safeguard
MOVES_041_3E = frozenset({"mist", "safeguard"})
HAND_PORTED_MOVES.update(
    {
        "mist": {"condition.onTryBoost": "blocks drops by others (-activate without secondaries)"},
        "safeguard": {
            "condition.onSetStatus": "blocks others' status except Yawn's (Infiltrator)",
            "condition.onTryAddVolatile": "blocks others' confusion and yawn",
        },
    }
)
# 041-3f: Spite, Psych Up
MOVES_041_3F = frozenset({"spite", "psychup", "healbell"})
HAND_PORTED_MOVES.update(
    {
        "spite": {"onHit": "deductPP(lastMove, 4), -activate; false without PP"},
        "psychup": {"onHit": "copy boosts, dragoncheer and focusenergy"},
        "healbell": {"onHit": "-activate, cureStatus the side (Soundproof / Good as Gold -immune)"},
    }
)
# 041-3g: Block, Mean Look, Spirit Shackle, Torment
MOVES_041_3G = frozenset({"block", "meanlook", "spiritshackle", "torment"})
HAND_PORTED_MOVES.update(
    {
        "block": {"onHit": "addVolatile trapped (linked to the source; Ghost immune)"},
        "meanlook": {"onHit": "addVolatile trapped (linked to the source; Ghost immune)"},
        "spiritshackle": {"secondary.onHit": "addVolatile trapped while the user is active"},
        "torment": {"condition": "-start Torment; onDisableMove: the last move (not Struggle)"},
    }
)
# 041-3h: Soak, Gastro Acid, Role Play, Entrainment, Worry Seed, Simple Beam (Insomnia and
# Simple act when a move gives them; they stay unsupported for teams)
MOVES_041_3H = frozenset(
    {"soak", "gastroacid", "roleplay", "entrainment", "worryseed", "simplebeam"}
)
HAND_PORTED_MOVES.update(
    {
        "soak": {"onHit": "setType Water (-fail target when Water or terastallized)"},
        "gastroacid": {
            "onTryHit": "cantsuppress false, Ability Shield -block",
            "condition": "ignoringAbility; onStart: the ability's End; onCopy",
        },
        "roleplay": {"onTryHit": "same / failroleplay / cantsuppress", "onHit": "setAbility"},
        "entrainment": {
            "onTryHit": "same / cantsuppress / truant / noentrain",
            "onHit": "setAbility",
        },
        "worryseed": {
            "onTryImmunity": "truant / insomnia",
            "onTryHit": "cantsuppress",
            "onHit": "setAbility insomnia, cure sleep",
        },
        "simplebeam": {"onTryHit": "cantsuppress / simple / truant", "onHit": "setAbility simple"},
    }
)
# 041-4a: the moves that return damage
MOVES_041_4A = frozenset({"counter", "mirrorcoat", "metalburst"})
HAND_PORTED_MOVES.update(
    {
        "counter": {
            "beforeTurnCallback": "adds the counter volatile (duration 1)",
            "damageCallback": "twice the last foe's physical hit, at its slot",
            "onTry": "fails without the volatile or a hit",
        },
        "mirrorcoat": {
            "beforeTurnCallback": "adds the mirrorcoat volatile (duration 1)",
            "damageCallback": "twice the last foe's special hit, at its slot",
            "onTry": "fails without the volatile or a hit",
        },
        "metalburst": {
            "damageCallback": "1.5x the last damage from a foe",
            "onTry": "fails unless a foe damaged the user this turn",
            "onModifyTarget": "the last damaging foe's slot",
        },
    }
)
# 041-4b: the moves that act later
MOVES_041_4B = frozenset({"futuresight", "wish"})
HAND_PORTED_MOVES.update(
    {
        "futuresight": {
            "onTry": "addSlotCondition futuremove (-start; NOT_FAIL)",
            "condition": "futuremove: two turns later (residual 3) hits the slot",
        },
        "wish": {"condition": "slot condition: heals half the wisher's max HP (residual 4)"},
    }
)
# 041-4c: the volatiles with an end-of-turn effect
MOVES_041_4C = frozenset({"leechseed", "aquaring", "ingrain"})
HAND_PORTED_MOVES.update(
    {
        "leechseed": {
            "onTryImmunity": "a Grass type is immune",
            "condition": "residual 8: baseMaxhp / 8 to the Pokemon at the seeder's slot",
        },
        "aquaring": {"condition": "residual 6: heals baseMaxhp / 16"},
        "ingrain": {
            "condition": "residual 7: heals baseMaxhp / 16; traps; DragOut null; grounds",
        },
    }
)
# 041-4d: Stockpile and the moves that use it
MOVES_041_4D = frozenset({"stockpile", "spitup", "swallow"})
HAND_PORTED_MOVES.update(
    {
        "stockpile": {
            "onTry": "fails at 3 layers",
            "condition": "layers; Def / SpD +1 each, taken back on its end (noCopy)",
        },
        "spitup": {
            "basePowerCallback": "100 per layer",
            "onTry": "fails without stockpile",
            "onAfterMove": "removes stockpile",
        },
        "swallow": {
            "onTry": "fails without stockpile",
            "onHit": "heals 1/4, 1/2 or all by layers, removes stockpile",
        },
    }
)
# 041-4e: Memento, Charge, Last Resort, Belch
MOVES_041_4E = frozenset({"memento", "charge", "lastresort", "belch"})
HAND_PORTED_MOVES.update(
    {
        "charge": {"condition": "Electric power x2, ends after an Electric move"},
        "lastresort": {"onTry": "every other move used since switching in"},
        "belch": {"onDisableMove": "until a berry was eaten", "onTry": "ateBerry"},
    }
)
# 041-4e: Focus Punch, Destiny Bond
MOVES_041_4F = frozenset({"focuspunch", "destinybond"})
HAND_PORTED_MOVES.update(
    {
        "focuspunch": {
            "priorityChargeCallback": "focuspunch volatile (-singleturn)",
            "beforeMoveCallback": "lost focus -> cant",
            "condition": "onHit lostFocus, onTryAddVolatile flinch null",
        },
        "destinybond": {
            "onPrepareHit": "fails in a row",
            "condition": "onFaint takes the attacker down; ends on another move (noCopy)",
        },
    }
)
# 041-4e: Gravity
MOVES_041_4G = frozenset({"gravity"})
HAND_PORTED_MOVES.update(
    {
        "gravity": {
            "condition": "isGrounded; accuracy x6840/4096; gravity moves disabled / cant; "
            "brings Fly / Bounce down",
        },
    }
)
# 041-5: Copycat
MOVES_041_5 = frozenset({"copycat", "firepledge", "grasspledge", "waterpledge"})
HAND_PORTED_MOVES["copycat"] = {
    "onHit": "useMove of Battle.lastMove (fails on failcopycat; nothing without one)",
}
HAND_PORTED_MOVES["firepledge"] = {
    "basePowerCallback": "150 with another Pledge as sourceEffect (-combine)",
    "onPrepareHit": "prioritizeAction of an ally's other Pledge (-waiting, null)",
    "onModifyMove": "the combination's type, forceSTAB and side condition",
}
HAND_PORTED_MOVES["grasspledge"] = {
    "basePowerCallback": "150 with another Pledge as sourceEffect (-combine)",
    "onPrepareHit": "prioritizeAction of an ally's other Pledge (-waiting, null)",
    "onModifyMove": "the combination's type, forceSTAB and side condition",
}
HAND_PORTED_MOVES["waterpledge"] = {
    "basePowerCallback": "150 with another Pledge as sourceEffect (-combine)",
    "onPrepareHit": "prioritizeAction of an ally's other Pledge (-waiting, null)",
    "onModifyMove": "the combination's type, forceSTAB and side condition",
}
# 041-6a: Horn Drill, Guillotine (ohko, as 026), Psystrike, Secret Sword
# (overrideDefensiveStat), Snipe Shot (critRatio 2, tracksTarget: no RedirectTarget), Flying
# Press, Fusion Bolt, Fusion Flare
MOVES_041_6A = frozenset({
    "horndrill", "guillotine", "psystrike", "secretsword", "snipeshot", "flyingpress",
    "fusionbolt", "fusionflare",
})  # fmt: skip
HAND_PORTED_MOVES["flyingpress"] = {"onEffectiveness": "adds Flying's effectiveness"}
for _fusion in ("fusionbolt", "fusionflare"):
    HAND_PORTED_MOVES[_fusion] = {
        "onBasePower": "x2 after the other Fusion move (lastSuccessfulMoveThisTurn)"
    }
# 041-6b: Collision Course / Electro Drift (x5461/4096 when super effective), Grav Apple
# (x1.5 in Gravity), Barb Barrage (x2 on a poisoned target), Infernal Parade (x2 on a status),
# Fickle Beam (randomChance 3/10: x2), Chloroblast (chloroblastRecoil), Sunsteel Strike /
# Moongeist Beam / Photon Geyser (ignoreAbility; Photon Geyser physical when Atk > SpA),
# Dream Eater (onTryImmunity: asleep)
MOVES_041_6B = frozenset({
    "collisioncourse", "electrodrift", "gravapple", "barbbarrage", "infernalparade",
    "ficklebeam", "chloroblast", "sunsteelstrike", "moongeistbeam", "photongeyser",
    "dreameater",
})  # fmt: skip
HAND_PORTED_MOVES.update(
    {
        "collisioncourse": {"onBasePower": "x5461/4096 when super effective"},
        "electrodrift": {"onBasePower": "x5461/4096 when super effective"},
        "gravapple": {"onBasePower": "x1.5 in Gravity"},
        "barbbarrage": {"onBasePower": "x2 on a poisoned target"},
        "infernalparade": {"basePowerCallback": "x2 on a target with a status"},
        "ficklebeam": {"onBasePower": "randomChance(3, 10): -activate, x2"},
        "photongeyser": {"onModifyMove": "physical when the staged Atk is above the SpA"},
        "dreameater": {"onTryImmunity": "only an asleep target"},
    }
)
# 041-6c: stages and stats traded, types set, Tar Shot, Toxic Thread, Take Heart (Acupressure
# waits: its adjacentAllyOrSelf target is not supported)
MOVES_041_6C = frozenset({
    "guardswap", "powerswap", "heartswap", "topsyturvy", "speedswap", "powersplit",
    "guardsplit", "magicpowder", "reflecttype", "tarshot", "toxicthread", "takeheart",
})  # fmt: skip
HAND_PORTED_MOVES.update(
    {
        "guardswap": {"onHit": "swap the def / spd stages"},
        "powerswap": {"onHit": "swap the atk / spa stages"},
        "heartswap": {"onHit": "swap every stage"},
        "topsyturvy": {"onHit": "invert the stages (false when all 0)"},
        "speedswap": {"onHit": "swap storedStats.spe"},
        "powersplit": {"onHit": "average storedStats atk / spa"},
        "guardsplit": {"onHit": "average storedStats def / spd"},
        "magicpowder": {"onHit": "setType Psychic"},
        "reflecttype": {"onHit": "copy the target's types"},
        "tarshot": {"condition": "Fire +1 on the first type; not when terastallized"},
        "takeheart": {"onHit": "spa / spd +1, cure the status"},
    }
)
# 041-6d: Jungle Healing (Lunar Blessing's onHit), Lunar Dance (Healing Wish's slot condition
# that also restores the PP), Teleport, Fillet Away, No Retreat, Chilly Reception
MOVES_041_6D = frozenset({
    "junglehealing", "lunardance", "teleport", "filletaway", "noretreat", "chillyreception",
})  # fmt: skip
HAND_PORTED_MOVES.update(
    {
        "junglehealing": {"onHit": "heal modify(maxhp, 0.25) and cure (allies)"},
        "lunardance": {"onTryHit": "canSwitch", "condition": "heal, clearStatus, PP on Swap"},
        "teleport": {"onTry": "canSwitch"},
        "filletaway": {
            "onTry": "more than half HP",
            "onTryHit": "boost",
            "onHit": "directDamage(maxhp / 2)",
        },
        "noretreat": {
            "onTry": "not again; no volatile while trapped",
            "condition": "onTrapPokemon",
        },
        "chillyreception": {
            "priorityChargeCallback": "addVolatile",
            "condition": "onBeforeMove: -prepare",
        },
    }
)
# 041-6e: Teeter Dance, Water Shuriken, Thunder Cage, Ice Burn, Freeze Shock, Diamond Storm,
# Revelation Dance, Stone Axe, Ceaseless Edge, Eerie Spell
MOVES_041_6E = frozenset({
    "teeterdance", "watershuriken", "thundercage", "iceburn", "freezeshock",
    "diamondstorm", "revelationdance", "stoneaxe", "ceaselessedge", "eeriespell",
})  # fmt: skip
HAND_PORTED_MOVES.update(
    {
        "watershuriken": {"basePowerCallback": "+5 for Greninja-Ash only (not in the dex)"},
        "iceburn": {"onTryMove": "the charge move's (-prepare, ChargeMove, twoturnmove)"},
        "freezeshock": {"onTryMove": "the charge move's (-prepare, ChargeMove, twoturnmove)"},
        "revelationdance": {"onModifyType": "the user's first type"},
        "stoneaxe": {
            "onAfterHit": "Stealth Rock on the foe side",
            "onAfterSubDamage": "Stealth Rock on the foe side",
        },
        "ceaselessedge": {
            "onAfterHit": "Spikes on the foe side",
            "onAfterSubDamage": "Spikes on the foe side",
        },
    }
)
MOVES_041_6F = frozenset({"conversion", "powertrick", "syrupbomb", "lockon", "present",
                          "darkvoid", "forestscurse", "jawlock", "magnetrise",
                          "shellsidearm", "stuffcheeks", "recycle",
                          "teatime", "comeuppance", "sparklingaria",
                          "doomdesire", "magneticflux",
                          "fairylock", "judgment",
                          "conversion2", "courtchange",
                          "quash", "instruct", "attract", "beakblast", "wonderroom",
                          "acupressure", "mimic", "sketch", "revivalblessing",
                          "doodle", "transform", "magicroom",
                          "cut", "holdback", "burnup", "corrosivegas", "metronome"})  # fmt: skip
HAND_PORTED_MOVES.update(
    {
        "conversion": {"onHit": "the type of the first move slot"},
        "darkvoid": {"onTry": "-fail unless Darkrai or bounced"},
        "jawlock": {"onHit": "trapped on the user, then on the target"},
        "stuffcheeks": {
            "onDisableMove": "without a berry",
            "onTry": "the item is a berry",
            "onHit": "def +2 (else null), then eatItem(true)",
        },
        "recycle": {"onHit": "false with an item or no lastItem; -item, setItem"},
        "magneticflux": {"onHitSide": "Plus / Minus allies Def / SpD +1, else false"},
        "judgment": {"onModifyType": "the held plate's type (onPlate)"},
        "attract": {
            "onTryImmunity": "opposite genders",
            "condition": "-start Attract (Destiny Knot); onBeforeMove 1/2 cant; "
            "onUpdate: the source gone",
        },
        "transform": {
            "onHit": "transformInto: species, types, stats, moves (pp 5), boosts, ability"
        },
        "doodle": {"onHit": "the target's ability to the user's side (setAbility), else NOT_FAIL"},
        "revivalblessing": {
            "onTryHit": "a fainted ally",
            "selfSwitch": "pick a fainted one: half HP",
        },
        "mimic": {"onHit": "the target's lastMove in its slot (pp = move.pp) until clearVolatile"},
        "sketch": {"onHit": "the target's lastMove in its slot for good (pp = move.pp)"},
        "acupressure": {"onHit": "sample a stat below +6: +2"},
        "wonderroom": {"condition": "def/spd swap in calculateStat and getStat(unmodified)"},
        "magicroom": {"condition": "ignoringItem: item handlers collected and sorted, not run"},
        # the Unobtainable moves Metronome calls (isNonstandard: no Pokémon learns them)
        "holdback": {"onDamage": "leaves the target 1 HP (priority -20; False Swipe)"},
        "burnup": {"onTryMove": "fails unless the user is Fire (self onHit: Fire becomes ???)"},
        "corrosivegas": {"onHit": "takeItem; -enditem [from] move: Corrosive Gas, else -fail"},
        "metronome": {"onHit": "sample of the metronome-flag moves by num; useMove (Copycat)"},
        "beakblast": {
            "priorityChargeCallback": "the beakblast volatile (-singleturn)",
            "condition": "onHit: a contact move burns its user",
            "onAfterMove": "removeVolatile",
        },
        "instruct": {"onHit": "the target's lastMove again, first (prioritizeAction)"},
        "quash": {"onHit": "the target's queued move gets order 201 (willMove)"},
        "courtchange": {"onHitField": "swap the listed side conditions"},
        "conversion2": {"onHit": "a sampled type resisting the target's lastMoveUsed; setType"},
        "fairylock": {"condition": "duration 2, -fieldactivate, onTrapPokemon tryTrap"},
        "doomdesire": {"onTry": "Future Sight's futuremove with Doom Desire (-start Doom Desire)"},
        "sparklingaria": {
            "onAfterMove": "the hit targets that lose the volatile (or any with"
            " two targets) cure a burn"
        },
        "comeuppance": {
            "damageCallback": "1.5x the last damage from a foe (Metal Burst's)",
            "onTry": "fails unless a foe damaged the user this turn",
            "onModifyTarget": "the last damaging foe's slot",
        },
        "teatime": {
            "onHitField": "-miss / TryHit and a berry; -fieldactivate; -fail and"
            " NOT_FAIL with nobody; eatItem(true) each"
        },
        "shellsidearm": {
            "onModifyMove": "Physical (contact) when the physical estimate is"
            " higher, or equal and randomChance(1, 2)",
            "onPrepareHit": "[anim] only",
            "onHit": "-hint only (not compared)",
            "onAfterSubDamage": "-hint only (not compared)",
        },
        "magnetrise": {
            "onTry": "false with Smack Down / Ingrain (Gravity: its BeforeMove)",
            "condition": "duration 5, onImmunity Ground (isGrounded), order 18",
        },
        "forestscurse": {"onHit": "addType Grass (addedType)"},
        "present": {"onModifyMove": "random(10): heal 1/4 (infiltrates) or 40 / 80 / 120"},
        "lockon": {
            "onTryHit": "false with the volatile",
            "onHit": "the lockon volatile",
            "condition": "onSourceInvulnerability 0, onSourceAccuracy true",
        },
    }
)
MOVES_041 = (
    MOVES_041_1A | MOVES_041_1B | MOVES_041_1C | MOVES_041_1D | MOVES_041_1E | MOVES_041_1F
    | MOVES_041_1G | MOVES_041_2 | MOVES_041_3A | MOVES_041_3B | MOVES_041_3C
    | MOVES_041_3D | MOVES_041_3E | MOVES_041_3F | MOVES_041_3G | MOVES_041_3H
    | MOVES_041_4A | MOVES_041_4B | MOVES_041_4C | MOVES_041_4D | MOVES_041_4E | MOVES_041_4F
    | MOVES_041_4G | MOVES_041_5 | MOVES_041_6A | MOVES_041_6B | MOVES_041_6C
    | MOVES_041_6D | MOVES_041_6E | MOVES_041_6F
)  # fmt: skip
HAND_PORTED_MOVES["afteryou"] = {
    "onHit": "the target's queued move goes next (prioritizeAction, order 3)",
}
HAND_PORTED_MOVES["healingwish"] = {
    "onTryHit": "fails (NOT_FAIL) with nothing to switch in",
    "condition": "slot condition: on switching in or swapping, heals a hurt or statused "
    "Pokemon to full, then ends",
}

# 016: Substitute (``BattlePokemon.substitute_hp``; the substitute takes the hits in
# ``battle._one_hit``, specs/016-substitute research R1-R4).
SUBSTITUTE = "substitute"
MOVE_EFFECT_KEYS[SUBSTITUTE] = frozenset({"volatileStatus", "condition"})
HAND_PORTED_MOVES[SUBSTITUTE] = {
    "onTryHit": "fails with a substitute up or at 1/4 max HP or less",
    "onHit": "pays 1/4 max HP",
}


# 017: Terastallization's moves (specs/017-terastal research R4).
TERA_BLAST = "terablast"
IVY_CUDGEL = "ivycudgel"
FOCUS_ENERGY = "focusenergy"
TERA_MOVES = frozenset({TERA_BLAST, IVY_CUDGEL, FOCUS_ENERGY})
MOVE_EFFECT_KEYS[TERA_BLAST] = frozenset()
MOVE_EFFECT_KEYS[IVY_CUDGEL] = frozenset({"critRatio"})
MOVE_EFFECT_KEYS[FOCUS_ENERGY] = frozenset({"volatileStatus", "condition"})
HAND_PORTED_MOVES[TERA_BLAST] = {
    "basePowerCallback": "100 when Stellar",
    "onModifyType": "the Tera Type when terastallized",
    "onModifyMove": "Physical when Atk > SpA (stages, no modifiers); Stellar: Atk/SpA -1",
    "onPrepareHit": "animation only",
}
HAND_PORTED_MOVES[IVY_CUDGEL] = {
    "onModifyType": "Water/Fire/Rock for the masked formes",
    "onPrepareHit": "animation only",
}


def _is_supported_move_effect(move: Move) -> bool:
    return (
        move.id in MOVE_EFFECT_KEYS
        and _ported_functions_only(move)
        and move.keys - move.function_keys <= _PLAIN_MOVE_KEYS | MOVE_EFFECT_KEYS[move.id]
        and not move.secondaries
    )


@cache
def supported_moves() -> frozenset[str]:
    return frozenset(
        m.id
        for m in get_dex().all_moves()
        if _is_supported_damaging(m)
        or _is_supported_status_move(m)
        or _is_supported_field_move(m)
        or _is_supported_doubles_move(m)
        or _is_supported_pivot_move(m)
        or _is_supported_move_effect(m)
        or (m.id in CHARGE_MOVES and _ported_functions_only(m))
        or (m.id in SIMPLE_MOVES_021 and _ported_functions_only(m))
        or (m.id in STATEFUL_MOVES_022 and _ported_functions_only(m))
        or (m.id in SIMPLE_MOVES_023 and _ported_functions_only(m))
        or (m.id in BINDING_MOVES_024 and _ported_functions_only(m))
        or (m.id in MOVES_025 and _ported_functions_only(m))
        or (m.id in MOVES_026 and _ported_functions_only(m))
        or (m.id in MOVES_027 and _ported_functions_only(m))
        or (m.id in MOVES_028 and _ported_functions_only(m))
        or (m.id in MOVES_030 and _ported_functions_only(m))
        or (m.id in MOVES_031 and _ported_functions_only(m))
        or (m.id in MOVES_032 and _ported_functions_only(m))
        or (m.id in MOVES_033 and _ported_functions_only(m))
        or (m.id in MOVES_034 and _ported_functions_only(m))
        or (m.id in MOVES_041 and _ported_functions_only(m))
    )


# 011: abilities whose effects are hand-ported (``abilities.py``), with what was ported.
HAND_PORTED_ABILITIES: dict[str, str] = {
    "intimidate": "onStart: adjacent foes Atk -1",
    "innerfocus": "onTryBoost: no Intimidate drop; onTryAddVolatile: no flinch",
    "oblivious": "onTryBoost: no Intimidate drop; onTryHit: Taunt fails (Attract is unsupported)",
    "owntempo": "onTryBoost: no Intimidate drop; onTryAddVolatile: no confusion",
    "scrappy": "onTryBoost: no Intimidate drop; onModifyMove: Normal/Fighting hit Ghost",
    "guarddog": "onTryBoost: Intimidate raises Atk; onDragOut (034): -activate, null",
    "defiant": "onAfterEachBoost: Atk +2 when a foe lowers a stat",
    "competitive": "onAfterEachBoost: SpA +2 when a foe lowers a stat",
    "drought": "onStart: Sunny Day",
    "drizzle": "onStart: Rain Dance",
    "sandstream": "onStart: Sandstorm",
    "snowwarning": "onStart: Snowscape",
    "grassysurge": "onStart: Grassy Terrain",
    "psychicsurge": "onStart: Psychic Terrain",
    "electricsurge": "onStart: Electric Terrain",
    "mistysurge": "onStart: Misty Terrain",
    "swordofruin": "onAnyModifyDef: x0.75",
    "beadsofruin": "onAnyModifySpD: x0.75",
    "vesselofruin": "onAnyModifySpA: x0.75",
    "tabletsofruin": "onAnyModifyAtk: x0.75",
    "download": "onStart: Atk or SpA +1 from the foes' Def and SpD",
    "hospitality": "onStart: heals the ally 1/4",
    "prankster": "onModifyPriority: status moves +1; Dark foes are immune",
    "armortail": "onFoeTryMove: blocks foes' priority moves",
    "queenlymajesty": "onFoeTryMove: blocks foes' priority moves",
    "dazzling": "onFoeTryMove: blocks foes' priority moves",
    "goodasgold": "onTryHit: immune to others' status moves",
    "levitate": "isGrounded: not grounded (Ground immunity, no terrain)",
    "unseenfist": "onModifyMove: contact moves ignore protection",
    "protosynthesis": "sun: best stat x1.3 (Spe x1.5); Booster Energy is an unsupported item",
    "quarkdrive": "Electric Terrain: best stat x1.3 (Spe x1.5); Booster Energy is unsupported",
    "regenerator": "onSwitchOut: heals 1/3",
    # 012: abilities that change damage or act when hit
    "sheerforce": "onModifyMove: drops secondaries; onBasePower: x1.3",
    "guts": "onModifyAtk: x1.5 with a status condition; no burn halving",
    "technician": "onBasePower: x1.5 at 60 or less",
    "sharpness": "onBasePower: slicing moves x1.5",
    "dragonsmaw": "onModifyAtk/SpA: Dragon moves x1.5",
    "transistor": "onModifyAtk/SpA: Electric moves x5325/4096",
    "adaptability": "onModifySTAB: 2",
    "liquidvoice": "onModifyType: sound moves become Water",
    "mindseye": "onModifyMove: ignores evasion, Normal/Fighting hit Ghost; onTryBoost",
    "moldbreaker": "onModifyMove: ignoreAbility (breakable abilities)",
    "waterabsorb": "onTryHit: Water moves heal 1/4",
    "voltabsorb": "onTryHit: Electric moves heal 1/4",
    "eartheater": "onTryHit: Ground moves heal 1/4",
    "stormdrain": "onTryHit: Water moves SpA +1; onAnyRedirectTarget",
    "lightningrod": "onTryHit: Electric moves SpA +1; onAnyRedirectTarget",
    "flashfire": "onTryHit: Fire moves start Flash Fire (Fire moves x1.5)",
    "multiscale": "onSourceModifyDamage: x0.5 at full HP",
    "friendguard": "onAnyModifyDamage: allies x0.75",
    "sturdy": "onDamage: survives at 1 HP from full; onTryHit: OHKO moves (026)",
    "stamina": "onDamagingHit: Def +1",
    "berserk": "onAfterMoveSecondary: SpA +1 below half HP",
    "thermalexchange": "onDamagingHit: Fire moves Atk +1; onSetStatus: no burn",
    "unaware": "onAnyModifyBoost: ignores the other side's stages",
    "flamebody": "onDamagingHit: contact 30% burn",
    "clearbody": "onTryBoost: no drops from others",
    "mirrorarmor": "onTryBoost: reflects drops from others",
    "chlorophyll": "onModifySpe: x2 in sun",
    "swiftswim": "onModifySpe: x2 in rain",
    "sandrush": "onModifySpe: x2 in sandstorm; no sandstorm damage",
    "slushrush": "onModifySpe: x2 in snow",
    "overcoat": "onImmunity: weather damage, powder; onTryHit: powder moves",
}
# 013: Unburden acts when the held item is used up or knocked off.
HAND_PORTED_ABILITIES["toxicdebris"] = (
    "onDamagingHit: a physical hit adds a Toxic Spikes layer on the attacker's foes' side (020)"
)
HAND_PORTED_ABILITIES["unburden"] = "onAfterUseItem/onTakeItem: Spe x2 while it has no item"
# 017: Ogerpon's terastallized formes.
HAND_PORTED_ABILITIES.update({
    "embodyaspectteal": "onStart: Spe +1 when terastallized (once per switch-in)",
    "embodyaspectwellspring": "onStart: SpD +1 when terastallized (once per switch-in)",
    "embodyaspecthearthflame": "onStart: Atk +1 when terastallized (once per switch-in)",
    "embodyaspectcornerstone": "onStart: Def +1 when terastallized (once per switch-in)",
})  # fmt: skip
# 023: Moody (specs/023-simple-moves-2 research R12).
HAND_PORTED_ABILITIES["moody"] = "onResidual (28, 2): a stat +2, another -1 (two samples)"
# 041-6f: Limber (for Ditto in the Transform pair)
HAND_PORTED_ABILITIES["limber"] = "onUpdate: cure paralysis; onSetStatus: no paralysis (-immune)"
ABILITIES_041_6F = frozenset({"limber"})
ABILITIES_023 = frozenset({"moody"})
# 026: Snow Cloak (specs/026-charge-and-ohko research R6).
HAND_PORTED_ABILITIES["snowcloak"] = "onModifyAccuracy: x3277/4096 in snow"
ABILITIES_026 = frozenset({"snowcloak"})
# 027: Shell Armor (specs/027-skill-swap research R5).
HAND_PORTED_ABILITIES["shellarmor"] = "onCriticalHit: false (breakable)"
ABILITIES_027 = frozenset({"shellarmor"})
# 028: Commander (specs/028-commander research R1-R3).
HAND_PORTED_ABILITIES["commander"] = (
    "onStart/onAnySwitchIn/onUpdate: goes into an allied Dondozo's mouth (commanding: passes, "
    "missed, trapped; commanded: +2 to five stats, trapped)"
)
ABILITIES_028 = frozenset({"commander"})
# 029: Neutralizing Gas (specs/029-neutralizing-gas research R1-R4).
HAND_PORTED_ABILITIES["neutralizinggas"] = (
    "ignoringAbility: suppresses the other abilities while on the field; onSwitchIn (2); "
    "onEnd: the others' Start in speed order"
)
ABILITIES_029 = frozenset({"neutralizinggas"})
# 030: Pixilate and Water Bubble (specs/030-small-blockers research R1, R2).
HAND_PORTED_ABILITIES.update({
    "pixilate": "onModifyType: Normal moves become Fairy; onBasePower: x4915/4096",
    "waterbubble": "onModifyAtk/SpA: Water x2; onSourceModifyAtk/SpA: Fire x0.5; no burn",
})  # fmt: skip
ABILITIES_030 = frozenset({"pixilate", "waterbubble"})
# 031: Magic Bounce and Trace (specs/031-magic-bounce research R1-R3, R6).
HAND_PORTED_ABILITIES.update({
    "magicbounce": "onTryHit (1) / onAllyTryHitSide: a reflectable move is used again by the "
    "holder against its user (hasBounced, not Prankster-boosted); breakable",
    "trace": "onStart / onUpdate: copies a random foe's ability (not notrace, not No Ability; "
    "Ability Shield: -block)",
})  # fmt: skip
ABILITIES_031 = frozenset({"magicbounce", "trace"})
# 032 (specs/032-items-abilities-boosts research R1, R5, R10-R14).
HAND_PORTED_ABILITIES.update({
    "sandveil": "onModifyAccuracy: x3277/4096 in a sandstorm; no sandstorm damage",
    "gluttony": "pinch berries and Custap Berry at 1/2 HP",
    "thickfat": "onSourceModifyAtk/SpA: Fire and Ice x0.5",
    "heatproof": "onSourceModifyAtk/SpA: Fire x0.5; onDamage: burn halved",
    "purifyingsalt": "onSourceModifyAtk/SpA: Ghost x0.5; onSetStatus / onTryAddVolatile (yawn)",
    "overgrow": "onModifyAtk/SpA: Grass x1.5 at 1/3 HP",
    "bulletproof": "onTryHit: bullet moves -immune",
    "soundproof": "onTryHit: sound moves -immune (not its own)",
    "sapsipper": "onTryHit (1): Grass moves, Atk +1 or -immune",
    "roughskin": "onDamagingHit (1): contact 1/8",
    "weakarmor": "onDamagingHit: physical hits Def -1, Spe +2",
    "justified": "onDamagingHit: Dark moves Atk +1",
    "toxicchain": "onSourceDamagingHit: 30% badly poisons",
    "sweetveil": "onAllySetStatus / onAllyTryAddVolatile: no sleep, no Yawn",
    "aromaveil": "onAllyTryAddVolatile: no Taunt, Encore, Disable, Heal Block (attract, torment)",
    "corrosion": "poisons Steel and Poison types",
    "triage": "onModifyPriority: heal moves +3",
    "icebody": "onWeather: heals 1/16 in snow; no snow damage",
})  # fmt: skip
ABILITIES_032 = frozenset({"sandveil", "gluttony", "thickfat", "heatproof", "purifyingsalt",
                           "overgrow", "bulletproof", "soundproof", "sapsipper", "roughskin",
                           "weakarmor", "justified", "toxicchain", "sweetveil", "aromaveil",
                           "corrosion", "triage", "icebody"})  # fmt: skip
# 033 (specs/033-move-calculations research R5, R12, R14).
HAND_PORTED_ABILITIES.update({
    "lightmetal": "onModifyWeight: halved (truncated); breakable",
    "slowstart": "onStart: counter 5; onResidual: -1 after the first turn, -end at 0; "
    "onModifyAtk / onModifySpe: x0.5 while counting; onEnd: -end [silent]",
    "pressure": "onStart: -ability; onDeductPP: 1 unless the user is an ally",
})  # fmt: skip
ABILITIES_033 = frozenset({"lightmetal", "slowstart", "pressure"})
# 034 (specs/034-forced-switch-illusion research R3, R6).
HAND_PORTED_ABILITIES.update({
    "suctioncups": "onDragOut: -activate, null; breakable",
    "illusion": "onBeforeSwitchIn: the last unfainted Pokemon after it; onDamagingHit / "
    "Neutralizing Gas / Terastallizing into Ogerpon's or Terapagos's look: replace, -end; "
    "onFaint: cleared",
})  # fmt: skip
ABILITIES_034 = frozenset({"suctioncups", "illusion"})
# The 011 abilities (the 011 cross-check pairs choose from these, so their teams stay the same).
ABILITIES_011 = frozenset(list(HAND_PORTED_ABILITIES)[:32])
ABILITIES_012 = frozenset(list(HAND_PORTED_ABILITIES)[:63])

# 013: held items whose effects are hand-ported (``items.py``), with what was ported.
HAND_PORTED_ITEMS: dict[str, str] = {
    "heavydutyboots": "no hazard effects on switch-in (020: checked by each hazard)",
    "powerherb": "onChargeMove: useItem; the move fires on its first turn (020)",
    "choiceband": "onModifyAtk x1.5; choicelock",
    "choicespecs": "onModifySpA x1.5; choicelock",
    "choicescarf": "onModifySpe x1.5; choicelock",
    "assaultvest": "onModifySpD x1.5; onDisableMove: status moves",
    "lifeorb": "onModifyDamage x5324/4096; onAfterMoveSecondarySelf: 1/10 recoil",
    "eviolite": "onModifyDef/SpD x1.5 when not fully evolved",
    "loadeddice": "multihit 2-5: 4 or 5 hits",
    "focussash": "onDamage: survives at 1 HP from full",
    "sitrusberry": "onUpdate: heals 1/4 at half HP",
    "boosterenergy": "onUpdate: starts Protosynthesis / Quark Drive",
    "leftovers": "onResidual: heals 1/16",
    "blacksludge": "onResidual: heals 1/16 (Poison) or 1/8 damage",
    "flameorb": "onResidual: burns",
    "toxicorb": "onResidual: badly poisons",
    "rockyhelmet": "onDamagingHit: contact 1/6 damage",
    "throatspray": "onAfterMoveSecondarySelf: sound moves SpA +1",
    "whiteherb": "restores lowered stats",
    "ejectpack": "014: switches the holder out after its stats are lowered (not by Parting Shot)",
    "mentalherb": "onUpdate: cures Taunt and Encore (015; the others are unsupported)",
    "safetygoggles": "onImmunity: weather damage, powder; onTryHit: powder moves",
    "covertcloak": "onModifySecondaries: no secondaries",
    "clearamulet": "onTryBoost: no drops from others",
    "lightclay": "screens last 8 turns",
    **{rock: f"{weather} lasts 8 turns" for rock, weather in WEATHER_ROCKS.items()},
    **{seed: f"used in {terrain}" for seed, terrain in SEEDS.items()},
    **{item: f"onBasePower: {t} moves x4915/4096" for item, t in TYPE_BOOSTERS.items()},
    **{berry: f"onSourceModifyDamage: {t} x0.5" for berry, t in RESIST_BERRIES.items()},
    **{b: f"onUpdate: heals 1/3 at 1/4 HP ({stat} nature)" for b, stat in PINCH_BERRIES.items()},
    # 017
    **{mask: f"onBasePower: {forme} x4915/4096; onTakeItem: Ogerpon keeps it"
       for mask, forme in OGERPON_MASKS.items()},
    # 029 (research R5)
    "abilityshield": "ignoringAbility / suppressingAbility: not suppressed; onSetAbility: -block",
    # 030 (research R3)
    "souldew": "onBasePower: Latios / Latias Psychic and Dragon moves x4915/4096",
}  # fmt: skip
ITEMS_029 = frozenset({"abilityshield"})
ITEMS_030 = frozenset({"souldew"})
# 032 (specs/032-items-abilities-boosts research R1-R7).
ITEMS_032_PORTED = {
    "widelens": "onSourceModifyAccuracy: x4505/4096",
    "zoomlens": "onSourceModifyAccuracy: x4915/4096 when the target already moved",
    "brightpowder": "onModifyAccuracy: x3686/4096",
    "scopelens": "onModifyCritRatio: +1",
    "kingsrock": "onModifyMove: 10% flinch on moves without one",
    "focusband": "onDamage: 10% to survive at 1 HP",
    "powerband": "onModifySpe: x0.5",
    "ironball": "onModifySpe: x0.5; grounded (Ground moves hit Flying types neutrally)",
    "airballoon": "onStart: -item; not grounded; pops when hit",
    "lumberry": "onUpdate: cures a status and confusion",
    "custapberry": "onFractionalPriority: +0.1 at 1/4 HP (Gluttony: 1/2)",
    "weaknesspolicy": "onDamagingHit: super effective hit, Atk and SpA +2",
}
HAND_PORTED_ITEMS.update(ITEMS_032_PORTED)
ITEMS_032 = frozenset(ITEMS_032_PORTED)

# 040-1: items with no effect in battle (no handler in Showdown's items.ts and not named elsewhere
# in sim/; Fling power and Knock Off come from the data as for any item)
ITEMS_040 = frozenset({
    "auspiciousarmor",
    "beastball",
    "berrysweet",
    "bignugget",
    "bottlecap",
    "chippedpot",
    "cloversweet",
    "crackedpot",
    "dawnstone",
    "diveball",
    "dragonscale",
    "dreamball",
    "dubiousdisc",
    "duskball",
    "duskstone",
    "electirizer",
    "fastball",
    "firestone",
    "flowersweet",
    "friendball",
    "galaricacuff",
    "galaricawreath",
    "goldbottlecap",
    "greatball",
    "healball",
    "heavyball",
    "icestone",
    "leafstone",
    "levelball",
    "loveball",
    "lovesweet",
    "lureball",
    "luxuryball",
    "magmarizer",
    "maliciousarmor",
    "masterball",
    "masterpieceteacup",
    "metalalloy",
    "moonball",
    "moonstone",
    "nestball",
    "netball",
    "ovalstone",
    "pokeball",
    "premierball",
    "prismscale",
    "protector",
    "quickball",
    "rarebone",
    "reapercloth",
    "repeatball",
    "ribbonsweet",
    "safariball",
    "shinystone",
    "sportball",
    "starsweet",
    "strawberrysweet",
    "sunstone",
    "sweetapple",
    "syrupyapple",
    "tartapple",
    "thunderstone",
    "timerball",
    "ultraball",
    "unremarkableteacup",
    "upgrade",
    "waterstone",
})  # fmt: skip
HAND_PORTED_ITEMS.update(dict.fromkeys(ITEMS_040, "no effect in battle"))
# 040-2
ITEMS_040_2_PORTED = {
    "punchingglove": "onBasePower 23: punch x1.1; onModifyMove 1: a punch loses contact",
    "muscleband": "onBasePower 16: physical x1.1",
    "wiseglasses": "onBasePower 16: special x1.1",
    "expertbelt": "onModifyDamage: super effective x1.2",
    "absorbbulb": "onDamagingHit: Water -> SpA +1",
    "cellbattery": "onDamagingHit: Electric -> Atk +1",
    "snowball": "onDamagingHit: Ice -> Atk +1",
    "luminousmoss": "onDamagingHit: Water -> SpD +1",
    "liechiberry": "onUpdate at 1/4 HP: Atk +1",
    "ganlonberry": "onUpdate at 1/4 HP: Def +1",
    "salacberry": "onUpdate at 1/4 HP: Spe +1",
    "petayaberry": "onUpdate at 1/4 HP: SpA +1",
    "apicotberry": "onUpdate at 1/4 HP: SpD +1",
    "blunderpolicy": "sim: a missed move (not OHKO) -> Spe +2",
    "roomservice": "onStart (-1) / onAnyPseudoWeatherChange: Trick Room -> Spe -1",
    "keeberry": "onAfterMoveSecondary: physical -> Def +1",
    "marangaberry": "onAfterMoveSecondary: special -> SpD +1",
    "lansatberry": "onUpdate at 1/4 HP: focusenergy",
    "starfberry": "onUpdate at 1/4 HP: a random stat +2",
}
HAND_PORTED_ITEMS.update(ITEMS_040_2_PORTED)
ITEMS_040_2 = frozenset(ITEMS_040_2_PORTED)
# 040-3
ITEMS_040_3_PORTED = {
    "ejectbutton": "onAfterMoveSecondary (priority 2): switchFlag; the attacker's is cancelled",
    "redcard": "onAfterMoveSecondary: useItem(source), DragOut -> forceSwitchFlag",
    "protectivepads": "Battle#checkMoveMakesContact: no contact for the holder's moves",
    "adamantorb": "onBasePower 15: Dialga's Steel / Dragon x1.2",
    "adamantcrystal": "onBasePower 15: Dialga's Steel / Dragon x1.2; onTakeItem",
    "lustrousorb": "onBasePower 15: Palkia's Water / Dragon x1.2",
    "lustrousglobe": "onBasePower 15: Palkia's Water / Dragon x1.2; onTakeItem",
    "griseousorb": "onBasePower 15: Giratina's Ghost / Dragon x1.2",
    "griseouscore": "onBasePower 15: Giratina's Ghost / Dragon x1.2; onTakeItem",
    "micleberry": "onResidual at 1/4 HP: micleberry (onSourceAccuracy x1.2)",
    "mirrorherb": "onFoeAfterBoost; onAnySwitchIn / AfterTera / AfterMove / onResidual: copy",
    "utilityumbrella": "Pokemon#effectiveWeather: no sun or rain for its holder",
}
HAND_PORTED_ITEMS.update(ITEMS_040_3_PORTED)
ITEMS_040_3 = frozenset(ITEMS_040_3_PORTED)
# 040-4a
ITEMS_040_4A_PORTED = {
    "cheriberry": "onUpdate: par -> eatItem, cureStatus",
    "chestoberry": "onUpdate: slp -> eatItem, cureStatus",
    "pechaberry": "onUpdate: psn / tox -> eatItem, cureStatus",
    "rawstberry": "onUpdate: brn -> eatItem, cureStatus",
    "aspearberry": "onUpdate: frz -> eatItem, cureStatus",
    "persimberry": "onUpdate: confusion -> eatItem, removeVolatile",
    "oranberry": "onUpdate at 1/2 HP (onTryEatItem TryHeal): heal 10",
    "enigmaberry": "onHit: super effective -> eatItem, heal baseMaxhp / 4",
    "leppaberry": "onUpdate: a move at 0 PP -> eatItem, +10 PP",
    "jabocaberry": "onDamagingHit: physical -> eatItem, the source loses baseMaxhp / 8",
    "rowapberry": "onDamagingHit: special -> eatItem, the source loses baseMaxhp / 8",
}
HAND_PORTED_ITEMS.update(ITEMS_040_4A_PORTED)
ITEMS_040_4A = frozenset(ITEMS_040_4A_PORTED)
# 040-4b
ITEMS_040_4B_PORTED = {
    "shellbell": "onAfterMoveSecondarySelf (-1): heal move.totalDamage / 8",
    "quickclaw": "onFractionalPriority: randomChance(1, 5) -> +0.1 (-activate)",
    "laggingtail": "onFractionalPriority: -0.1",
    "bigroot": "onTryHeal (1): drain / Strength Sap x5324/4096",
    "shedshell": "onTrapPokemon (-10): trapped = false",
    "stickybarb": "onResidual (28, 3): 1/8; onHit: takeItem -> a contact attacker with no item",
    "destinyknot": "onAttract (Attract and Cute Charm are unsupported: no effect)",
    "ringtarget": "onNegateImmunity: false",
    "adrenalineorb": "onAfterBoost: Intimidate -> useItem (Spe +1)",
    "terrainextender": "the terrains' durationCallback: 8 turns",
    "razorclaw": "onModifyCritRatio +1",
    "razorfang": "onModifyMove (-1): a 10% flinch secondary",
}
HAND_PORTED_ITEMS.update(ITEMS_040_4B_PORTED)
ITEMS_040_4B = frozenset(ITEMS_040_4B_PORTED)
# 042-1 (specs/042-remaining-items-moves R1a-c)
ITEMS_042_1_PORTED = {
    **dict.fromkeys(NO_EAT_BERRIES, "onEat: false (Bug Bite: no ateBerry)"),
    "prettyfeather": "no effect in battle",
    **dict.fromkeys(POWER_ITEMS, "onModifySpe: x0.5"),
    "lightball": "onModifyAtk/SpA (priority 1): Pikachu x2",
    "floatstone": "onModifyWeight: trunc(weighthg / 2)",
    "normalgem": "onSourceTryPrimaryHit: Normal -> useItem, gem (onBasePower 14: x5325/4096)",
    "metronome": "onStart: metronome (onTryMove -2: count; onModifyDamage x1 + 0.2n)",
    "bindingband": "partiallytrapped onStart: boundDivisor 6",
    "gripclaw": "partiallytrapped durationCallback: 8 (no draw)",
}
HAND_PORTED_ITEMS.update(ITEMS_042_1_PORTED)
ITEMS_042_1 = frozenset(ITEMS_042_1_PORTED)
# 042-2 (R1d): the rusted items; Zacian / Zamazenta's onBattleStart (`state.from_set`)
ITEMS_042_2_PORTED = {
    "rustedsword": "onTakeItem: false for Zacian; Zacian-Crowned at battle start, Behemoth Blade",
    "rustedshield": "onTakeItem: false for Zamazenta; Zamazenta-Crowned, Behemoth Bash",
}
HAND_PORTED_ITEMS.update(ITEMS_042_2_PORTED)
ITEMS_042_2 = frozenset(ITEMS_042_2_PORTED)
ABILITIES_042_2 = {
    "intrepidsword": "onStart: Atk +1 once a battle (swordBoost)",
    "dauntlessshield": "onStart: Def +1 once a battle (shieldBoost)",
}
HAND_PORTED_ABILITIES.update(ABILITIES_042_2)
# 042-3 (R2a): Morpeko
MOVES_042_3 = {"aurawheel": {"onTry": "Morpeko only (null)", "onModifyType": "Dark when Hangry"}}
HAND_PORTED_MOVES.update(MOVES_042_3)
ABILITIES_042_3 = {"hungerswitch": "onResidual (order 29): formeChange Morpeko <-> Hangry"}
HAND_PORTED_ABILITIES.update(ABILITIES_042_3)
# 042-4 (R2b): Meloetta
MOVES_042_4 = {"relicsong": {"onAfterMoveSecondarySelf": "formeChange Meloetta <-> Pirouette"}}
HAND_PORTED_MOVES.update(MOVES_042_4)
ABILITIES_042_4 = {"serenegrace": "onModifyMove (-2): secondary and self chances x2"}
HAND_PORTED_ABILITIES.update(ABILITIES_042_4)
# 042-5 (R2c): Hoopa
MOVES_042_5 = {"hyperspacefury": {"onTry": "Hoopa-Unbound only (null)"}}
HAND_PORTED_MOVES.update(MOVES_042_5)
ABILITIES_042_5 = {"magician": "onAfterMoveSecondarySelf: takes a hit target's item"}
HAND_PORTED_ABILITIES.update(ABILITIES_042_5)
# 042-6 (R2d): Terapagos
MOVES_042_6 = {"terastarstorm": {"onModifyType": "Stellar (Physical)", "onModifyMove": "spread"}}
HAND_PORTED_MOVES.update(MOVES_042_6)
ABILITIES_042_6 = {
    "terashift": "onSwitchIn (2): formeChange Terapagos-Terastal for good",
    "terashell": "runEffectiveness: not very effective at full HP",
    "teraformzero": "onAfterTerastallization: clears the weather and the terrain",
}
HAND_PORTED_ABILITIES.update(ABILITIES_042_6)
# 043-1: the remaining abilities, part 1 (the commonly used ones and the doubles ones)
ABILITIES_043_1 = {
    "hugepower": "onModifyAtk (5): x2",
    "purepower": "onModifyAtk (5): x2",
    "orichalcumpulse": "onStart: sun (-activate); onModifyAtk (5): x5461/4096 in the sun",
    "hadronengine": "onStart: Electric Terrain (-activate); onModifySpA (5): x5461/4096 in it",
    "supremeoverlord": "onStart: fallen (side.totalFainted, max 5); onBasePower (21)",
    "battery": "onAllyBasePower (22): an ally's special move x5325/4096",
    "powerspot": "onAllyBasePower (22): an ally's move x5325/4096",
    "steelyspirit": "onAllyBasePower (22): a Steel move x1.5 (the holder's too)",
    "plus": "onModifySpA (5): x1.5 with an ally's Plus / Minus",
    "minus": "onModifySpA (5): x1.5 with an ally's Plus / Minus",
    "telepathy": "onTryHit: an ally's attack fails (-activate; breakable)",
    "healer": "onResidual (5, 3): randomChance(3, 10) per statused adjacent ally: cureStatus",
    "unnerve": "onStart (1, once): -ability; onFoeTryEatItem: the foes cannot eat berries",
    "asoneglastrier": "Unnerve, then onSourceAfterFaint: Atk +n (Chilling Neigh)",
    "asonespectrier": "Unnerve, then onSourceAfterFaint: SpA +n (Grim Neigh)",
    "chillingneigh": "onSourceAfterFaint (a move): Atk + the faint queue's length",
    "grimneigh": "onSourceAfterFaint (a move): SpA + the faint queue's length",
    "infiltrator": "onModifyMove: infiltrates (substitute, screens, Defog's evasion)",
    "naturalcure": "onSwitchOut: clearStatus (-curestatus unless onCheckShow hid it)",
    "symbiosis": "onAllyAfterUseItem: gives its item to the ally (-activate)",
    "receiver": "onAllyFaint: setAbility(the fainted ally's ability; not noreceiver)",
    "powerofalchemy": "onAllyFaint: setAbility(the fainted ally's ability; not noreceiver)",
    "costar": "onStart (-2): copies the ally's stages, Focus Energy, Dragon Cheer (-copyboost)",
}
HAND_PORTED_ABILITIES.update(ABILITIES_043_1)

# 043-2a: the user's power and attack modifiers
ABILITIES_043_2A = {
    "torrent": "onModifyAtk / SpA (5): x1.5 for Water at 1/3 HP",
    "blaze": "onModifyAtk / SpA (5): x1.5 for Fire at 1/3 HP",
    "swarm": "onModifyAtk / SpA (5): x1.5 for Bug at 1/3 HP",
    "rockypayload": "onModifyAtk / SpA (5): x1.5 for Rock",
    "ironfist": "onBasePower (23): x4915/4096 for punches",
    "reckless": "onBasePower (23): x4915/4096 for recoil and crash moves",
    "galvanize": "onModifyType: Normal moves become Electric; onBasePower (23): x4915/4096",
    "toughclaws": "onBasePower (21): x5325/4096 for contact moves",
    "sandforce": "onBasePower (21): x5325/4096 for Rock / Ground / Steel in the sandstorm; "
    "no sandstorm damage",
    "strongjaw": "onBasePower (19): x1.5 for bite moves",
    "megalauncher": "onBasePower (19): x1.5 for pulse moves",
    "flareboost": "onBasePower (19): x1.5 for special moves while burned",
    "toxicboost": "onBasePower (19): x1.5 for physical moves while poisoned",
    "punkrock": "onBasePower (7): x5325/4096 for sound; onSourceModifyDamage: x0.5",
    "tintedlens": "onModifyDamage: x2 when not very effective",
    "sniper": "onModifyDamage: x1.5 on a critical hit",
    "longreach": "onModifyMove: the move makes no contact",
    "rockhead": "onDamage: no recoil (not Struggle's)",
}
HAND_PORTED_ABILITIES.update(ABILITIES_043_2A)
# 043-2a (the second commit)
ABILITIES_043_2A2 = {
    "hustle": "onModifyAtk (5): this.modify(atk, 1.5); onSourceModifyAccuracy (-1): x3277/4096",
    "solarpower": "onModifySpA (5): x1.5 in the sun; onWeather: 1/8 HP in the sun",
    "stakeout": "onModifyAtk / SpA (5): x2 on a target with activeTurns 0",
    "analytic": "onBasePower (21): x5325/4096 when no other active Pokemon will move",
    "rivalry": "onBasePower (24): x1.25 for the same gender, x0.75 for the other",
    "skilllink": "onModifyMove: the most hits; no multiaccuracy",
    "heavymetal": "onModifyWeight (1): x2",
}
HAND_PORTED_ABILITIES.update(ABILITIES_043_2A2)

# 043-2b: the target's modifiers, accuracy, critical hits (and speed, priority, redirection)
ABILITIES_043_2B = {
    "compoundeyes": "onSourceModifyAccuracy (-1): x5325/4096",
    "tangledfeet": "onModifyAccuracy (-1): x0.5 while confused",
    "noguard": "onAnyAccuracy: true for its moves and the moves at it",
    "fluffy": "onSourceModifyDamage: x2 Fire, x0.5 contact",
    "solidrock": "onSourceModifyDamage: x0.75 super effective",
    "filter": "onSourceModifyDamage: x0.75 super effective",
    "prismarmor": "onSourceModifyDamage: x0.75 super effective (not breakable)",
    "icescales": "onSourceModifyDamage: x0.5 special",
    "shadowshield": "onSourceModifyDamage: x0.5 at full HP (not breakable)",
    "furcoat": "onModifyDef (6): x2",
    "marvelscale": "onModifyDef (6): x1.5 with a status condition",
    "grasspelt": "onModifyDef (6): x1.5 in Grassy Terrain",
    "superluck": "onModifyCritRatio: +1",
    "merciless": "onModifyCritRatio: 5 on a poisoned target",
    "battlearmor": "onCriticalHit: false",
    "propellertail": "onModifyMove: tracksTarget (no redirection)",
    "stalwart": "onModifyMove: tracksTarget (no redirection)",
    "fullmetalbody": "onTryBoost: another's drops fail (-fail unboost; not breakable)",
    "surgesurfer": "onModifySpe: x2 in Electric Terrain",
    "quickfeet": "onModifySpe: x1.5 with a status condition; no paralysis drop",
    "galewings": "onModifyPriority: +1 for Flying moves at full HP",
}
HAND_PORTED_ABILITIES.update(ABILITIES_043_2B)

# 043-3a: preventing and curing status conditions, and the contact ones
ABILITIES_043_3A = {
    "insomnia": "onSetStatus: no sleep; onUpdate cures it; onTryAddVolatile: no Yawn",
    "vitalspirit": "onSetStatus: no sleep; onUpdate cures it; onTryAddVolatile: no Yawn",
    "immunity": "onSetStatus: no poison; onUpdate cures it",
    "waterveil": "onSetStatus: no burn; onUpdate cures it",
    "magmaarmor": "onImmunity: frz; onUpdate cures it",
    "leafguard": "onSetStatus / onTryAddVolatile (yawn): nothing in the sun",
    "static": "onDamagingHit: contact 30% paralysis",
    "poisonpoint": "onDamagingHit: contact 30% poison",
    "effectspore": "onDamagingHit: contact, random(100): sleep 11 / paralysis 10 / poison 9",
    "hydration": "onResidual (5, subOrder 3): cure in the rain",
    "shedskin": "onResidual (5, subOrder 3): 33% cure",
    "earlybird": "slp onBeforeMove: the sleep counts down twice",
}
HAND_PORTED_ABILITIES.update(ABILITIES_043_3A)

# 043-3b (the first part)
ABILITIES_043_3B = {
    "liquidooze": "onSourceTryHeal: drain / Leech Seed / Strength Sap hurt instead",
    "aftermath": "onDamagingHit (1): fainted by contact, the attacker loses 1/4",
    "damp": "onAnyTryMove: no Explosion-like moves; onAnyDamage: no Aftermath",
}
HAND_PORTED_ABILITIES.update(ABILITIES_043_3B)
ABILITIES_043_4A = {  # 043-4a
    "whitesmoke": "onTryBoost: as Clear Body",
    "keeneye": "onTryBoost (accuracy drops) and ignoreEvasion, as Mind's Eye",
    "hypercutter": "onTryBoost: Attack drops by another",
    "bigpecks": "onTryBoost: Defense drops by another",
    "moxie": "onSourceAfterFaint: Attack + the count (as Chilling Neigh)",
    "motordrive": "onTryHit: Electric moves raise Speed (as Lightning Rod's absorb)",
    "steamengine": "onDamagingHit: Water / Fire, Speed +6",
    "watercompaction": "onDamagingHit: Water, Defense +2",
    "rattled": "onDamagingHit (Dark / Bug / Ghost) and onAfterBoost (Intimidate): Speed +1",
    "speedboost": "onResidual (28, subOrder 2): Speed +1 after its first turn",
    "steadfast": "onFlinch: Speed +1",
    "raindish": "onWeather: 1/16 in the (effective) rain",
    "dryskin": "Water absorbed (1/4), Fire x1.25, rain +1/8, sun -1/8",
    "wellbakedbody": "onTryHit: Fire moves raise Defense by 2 instead",
    "electromorphosis": "onDamagingHit (1): charge",
    "windpower": "onDamagingHit (1) by a wind move, and Tailwind starting: charge",
    "windrider": "wind moves raise Attack instead; Tailwind (start, onStart): Attack +1",
    "sandspit": "onDamagingHit: setWeather('sandstorm')",
    "seedsower": "onDamagingHit: setTerrain('grassyterrain')",
    "gooey": "onDamagingHit: contact, the attacker's Speed -1",
    "tanglinghair": "onDamagingHit: contact, the attacker's Speed -1",
    "simple": "onChangeBoost: doubled (041-3h)",
    "contrary": "onChangeBoost: inverted",
    "soulheart": "onAnyFaint (1): SpA +1",
    "supersweetsyrup": "onStart (once): adjacent foes' evasion -1 (-immune behind a substitute)",
    "curiousmedicine": "onStart: the ally's stages are cleared (-clearboost)",
    "quickdraw": "onFractionalPriority (-1): a non-status move, randomChance(3, 10) +0.1",
    "angerpoint": "onHit: a critical hit sets Attack to +6 (-setboost)",
    "cheekpouch": "onEatItem: heal 1/3",
    "harvest": "onResidual (28, 2): the sun or randomChance(1, 2): the last berry back",
    "cloudnine": "suppressWeather (-ability on switching in; WeatherChange on start / end)",
    "airlock": "suppressWeather (-ability on switching in; WeatherChange on start / end)",
    "ripen": "berries: heal x2, boosts x2, resist berries x0.5 again; -activate on eating",
    "cudchew": "onEatItem / onResidual (28, 2): the berry is eaten again a turn later",
    "angershell": "as Berserk: Atk / SpA / Spe +1, Def / SpD -1",
    "opportunist": "as Mirror Herb (the ability, subOrder 7; residual 29), no item used",
}
ABILITIES_043_3B2 = {  # 043-3b
    "poisonheal": "onDamage (1): psn / tox heal 1/8 instead",
    "wonderskin": "onModifyAccuracy (10): a status move's numeric accuracy is 50",
    "stench": "onModifyMove (-1): a 10% flinch secondary (as King's Rock)",
    "shielddust": "onModifySecondaries: only self effects (as Covert Cloak)",
    "poisontouch": "onSourceDamagingHit: contact 30% poison (as Toxic Chain)",
    "cutecharm": "onDamagingHit: contact 30% attract",
    "baddreams": "onResidual (28, subOrder 2): each sleeping foe loses 1/8",
    "poisonpuppeteer": "onAnyAfterSetStatus: Pecharunt's move poison also confuses",
    "flowerveil": "onAllyTryBoost / onAllySetStatus / onAllyTryAddVolatile (yawn): Grass allies",
    "comatose": "onStart -ability; onSetStatus false; asleep for Sleep Talk, Snore, Rest, Hex, ...",
    "magicguard": "onDamage: false unless the effect is a move",
    "synchronize": "onAfterSetStatus: the source gets the status (not sleep, freeze, Toxic Spikes)",
}
HAND_PORTED_ABILITIES.update(ABILITIES_043_3B2)
HAND_PORTED_ABILITIES.update(ABILITIES_043_4A)

# 043-5a: the abilities around items, moves and the field (tools/make_matchups.py leaves them
# out of the earlier pairs' pools)
ABILITIES_043_5A = {
    "frisk": "onStart: -item of each foe's item",
    "anticipation": "onStart: -ability when a foe has a move it is weak to (or OHKO)",
    "forewarn": "onStart: -activate with one of the foes' strongest moves (sampled)",
    "illuminate": "onTryBoost (accuracy drops by another) and ignoreEvasion, as Keen Eye",
    "stickyhold": "onTakeItem: another Pokemon cannot take its item (-activate)",
    "cursedbody": "onDamagingHit: randomChance(3, 10): the attacker's move is disabled",
    "pickpocket": "onAfterMoveSecondary: a contact attacker's item is taken",
    "shadowtag": "onFoeTrapPokemon: not another Shadow Tag (a Ghost is immune)",
    "arenatrap": "onFoeTrapPokemon: a grounded foe",
    "magnetpull": "onFoeTrapPokemon: a Steel foe",
    "stall": "onFractionalPriority: -0.1",
    "protean": "onPrepareHit: the move's type (once per switch-in)",
    "libero": "onPrepareHit: the move's type (once per switch-in)",
    "lingeringaroma": "onDamagingHit: contact, the attacker's ability becomes it",
    "truant": "onBeforeMove (9): every other move (cant)",
    "klutz": "ignoringItem: its item does nothing (not the ignoreKlutz ones; no Fling)",
    "dancer": "runMove: another Pokemon's dance move is copied (externalMove)",
    "imposter": "onSwitchIn: transformInto the foe in the opposite slot",
    "pickup": "onResidual (28, 2): an adjacent Pokemon's item used this turn (sampled)",
    "myceliummight": "a status move: -0.1, ignoreAbility (no Quick Claw / Custap Berry)",
}
HAND_PORTED_ABILITIES.update(ABILITIES_043_5A)

# 043-6: the abilities that change the form (tools/make_matchups.py leaves them out of the
# earlier pairs' pools)
ABILITIES_043_6 = {
    "zerotohero": "onSwitchOut: Palafin-Hero for good; onSwitchIn: -activate once",
    "battlebond": "onSourceAfterFaint: Atk, SpA, Spe +1 once (Greninja-Bond)",
    "shieldsdown": "onStart (-1) / onResidual (29): Meteor above half HP; onSetStatus, yawn",
    "disguise": "onDamage (1): 0 by a move; onCriticalHit / onEffectiveness; onUpdate: busted",
    "iceface": "as Disguise for a physical move; onStart (-2) / onWeatherChange: snow",
    "gulpmissile": "Surf (TryPrimaryHit) / Dive: Gulping or Gorging; onDamagingHit: 1/4 and more",
    "multitype": "no handler (the type is the forme's); cantsuppress, failskillswap",
}
HAND_PORTED_ABILITIES.update(ABILITIES_043_6)


# 020: what 020 adds (tools/make_matchups.py leaves these out of the earlier pairs' pools)
MOVES_020 = frozenset({"stealthrock", "spikes", "toxicspikes", "stickyweb", "rapidspin",
                       "mortalspin", "defog", "tidyup", "meteorbeam"})  # fmt: skip
ITEMS_020 = frozenset({"heavydutyboots", "powerherb"})
ABILITIES_020 = frozenset({"toxicdebris"})


def supported_items() -> frozenset[str]:
    return frozenset(HAND_PORTED_ITEMS)


@cache
def supported_abilities() -> frozenset[str]:
    plain = {
        a.id
        for a in get_dex().all_abilities()
        if not a.function_keys and a.keys <= _PLAIN_ABILITY_KEYS and not a.mentioned_in
    }
    return frozenset(plain | set(HAND_PORTED_ABILITIES) | {NO_ABILITY})


def _mask_forme(species_id: str) -> bool:
    """017: Ogerpon's masked formes; 040-3b: the Origin formes and their crystals; 044: the
    Arceus formes and their plates."""
    species = get_dex().species(species_id)
    required = to_id(species.required_item or "") if species is not None else ""
    plate = species is not None and species.num == 493 and required.endswith("plate")
    return required in OGERPON_MASKS or required in LEGEND_CRYSTALS or plate


def _unflingable(item: Item) -> bool:
    """032 (T006): Fling with a berry (the target eats it) or a fling.effect item (White Herb,
    Mental Herb) is not ported; the battle stops with an EngineError if one is flung anyway
    (an item given in the battle)."""
    return item.is_berry or bool(item.fling and item.fling.get("effect"))


def unsupported(team: Team) -> list[str]:
    """Every part of a (valid) team the engine cannot simulate yet, as readable labels.

    017: Ogerpon's masked formes need their mask, which is supported (``team.py`` checks it).
    """
    dex = get_dex()
    problems: list[str] = []
    moves, abilities = supported_moves(), supported_abilities()
    for i, member in enumerate(team.members):
        species = dex.species(member.species)
        label = f"#{i + 1} {species.name if species else member.species}"
        if species is not None and species.required_item and not _mask_forme(species.id):
            problems.append(f"{label}: requires item {species.required_item}")
        if species is not None and species.id in SPECIES_WITH_UNSUPPORTED_MECHANICS:
            reason = SPECIES_WITH_UNSUPPORTED_MECHANICS[species.id]
            problems.append(f"{label}: species {species.name} ({reason})")
        if member.item is not None:
            item = dex.item(member.item)
            if item is None or item.id not in HAND_PORTED_ITEMS:
                problems.append(f"{label}: item {item.name if item else member.item}")
            flings = any(to_id(name) == "fling" for name in member.moves)
            if flings and item is not None and _unflingable(item):
                # 032 (T006): the target eating a flung berry and fling.effect are not ported
                problems.append(f"{label}: Fling with {item.name}")
        if member.ability is not None:
            ability_id = to_id(member.ability)
            ability = dex.ability(member.ability)
            ability_name = ability.name if ability else member.ability
            if ability is not None:
                ability_id = ability.id
        elif species is not None:
            ability_name = species.abilities[0]
            ability_id = to_id(ability_name)
        else:
            continue
        if ability_id not in abilities:
            problems.append(f"{label}: ability {ability_name}")
        for name in member.moves:
            move = dex.move(name)
            if move is not None and move.id not in moves:
                problems.append(f"{label}: move {move.name}")
    return problems


# 041-6a: Turboblaze and Teravolt, Mold Breaker under another name (added last: the earlier
# pairs slice HAND_PORTED_ABILITIES in its order)
ABILITIES_041_6A = frozenset({"turboblaze", "teravolt"})
for _clone in sorted(ABILITIES_041_6A):
    HAND_PORTED_ABILITIES[_clone] = "onModifyMove: Mold Breaker under another name (041-6a)"
