"""039: what the team builder offers (Japanese names from the generated data) and the team it
makes. Only what the engine supports and Regulation F allows is offered."""

from __future__ import annotations

from functools import cache
from typing import Any

from pokesv_sim.dex import STAT_IDS, get_dex
from pokesv_sim.play import labels
from pokesv_sim.play.labels import TYPES_JA
from pokesv_sim.regulation import check_regulation, get_regulation
from pokesv_sim.support import (
    species_supported,
    supported_abilities,
    supported_items,
    supported_moves,
)
from pokesv_sim.team import PokemonSet, Team


def _ja(x: Any) -> str:
    return str(x.name_ja or x.name)


def _name(found: Any) -> str | None:
    return None if found is None else str(found.name)


def _id(found: Any) -> str | None:
    return None if found is None else str(found.id)


@cache
def catalog() -> dict[str, Any]:
    dex, reg = get_dex(), get_regulation("regf")
    species = []
    for s in dex.all_species():
        if s.battle_only or not species_supported(s.id):
            continue
        problems = check_regulation(Team((PokemonSet(s.name),)), reg)
        if any(p.kind in ("not_in_game", "banned") for p in problems):
            continue
        species.append({"id": s.id, "name": s.display_ja or _ja(s), "en": s.name})
    species.sort(key=lambda x: x["name"])
    items = sorted(
        ({"id": i, "name": _ja(dex.item(i))} for i in supported_items() if dex.item(i)),
        key=lambda x: x["name"],
    )
    natures = []
    for n in sorted(_natures(), key=lambda n: n.name_ja or n.name):
        effect = (
            f"{labels.STATS[n.plus]}↑ {labels.STATS[n.minus]}↓"
            if n.plus and n.minus
            else "補正なし"
        )
        natures.append(
            {
                "id": n.name,
                "name": f"{n.name_ja or n.name}（{effect}）",
                "plus": n.plus,
                "minus": n.minus,
            }
        )
    types = [{"id": t, "name": TYPES_JA.get(t, t)} for t in TYPES_JA]
    return {"species": species, "items": items, "natures": natures, "types": types}


def _natures() -> list[Any]:
    dex = get_dex()
    names = (  # noqa: SIM905
        "Hardy Lonely Brave Adamant Naughty Bold Docile Relaxed Impish Lax Timid Hasty Serious "
        "Jolly Naive Modest Mild Quiet Bashful Rash Calm Gentle Sassy Careful Quirky"
    ).split()
    return [n for n in (dex.nature(x) for x in names) if n is not None]


@cache
def species_detail(species_id: str) -> dict[str, Any]:
    dex = get_dex()
    s = dex.species(species_id)
    if s is None:
        return {}
    ok = supported_abilities()
    abilities = [{"id": a, "name": _ja(dex.ability(a))} for a in s.abilities if dex.ability(a)]
    abilities = [a for a in abilities if a["id"] in ok or _id(dex.ability(a["id"])) in ok]
    usable = supported_moves()
    moves = []
    for mid in dex.learnable(s.id):
        m = dex.move(mid)
        if m is not None and m.id in usable:
            moves.append({"id": m.id, "name": _ja(m)})
    moves.sort(key=lambda x: x["name"])
    return {
        **labels.species(s.name),
        "abilities": abilities,
        "moves": moves,
        "required_item": s.required_item,
        "base": dict(s.base_stats),
    }


def team_from_json(members: list[dict[str, Any]]) -> Team:
    """The builder's team. Raises ValueError for an unknown name."""
    dex = get_dex()
    out = []
    for m in members:
        s = dex.species(m.get("species") or "")
        if s is None:
            raise ValueError(f"ポケモン {m.get('species')!r} が見つかりません")
        moves = tuple(n for n in (_name(dex.move(x)) for x in m.get("moves", []) if x) if n)
        item = _name(dex.item(m["item"])) if m.get("item") else None
        ability = _name(dex.ability(m["ability"])) if m.get("ability") else None
        evs = {k: int(m.get("evs", {}).get(k, 0) or 0) for k in STAT_IDS}
        given = m.get("ivs", {})
        ivs = {k: int(given[k]) if given.get(k) not in (None, "") else 31 for k in STAT_IDS}
        out.append(
            PokemonSet(
                species=s.name,
                moves=moves,
                item=item,
                ability=ability,
                level=50,
                nature=m.get("nature") or "Serious",
                tera_type=m.get("tera") or None,
                evs=evs,
                ivs=ivs,
            )
        )
    if not out:
        raise ValueError("ポケモンを1体以上選んでください")
    return Team(tuple(out))


def team_to_json(team: Team) -> list[dict[str, Any]]:
    """039: a team in the builder's form (to load a tournament team and edit it)."""
    dex = get_dex()
    out = []
    for m in team.members:
        s = dex.species(m.species)
        item = dex.item(m.item) if m.item else None
        ability = dex.ability(m.ability) if m.ability else None
        out.append(
            {
                "species": s.id if s else "",
                "item": item.id if item else "",
                "ability": ability.name if ability else "",
                "nature": m.nature,
                "tera": m.tera_type or "",
                "moves": [_id(dex.move(x)) or "" for x in m.moves][:4] + [""] * (4 - len(m.moves)),
                "evs": dict(m.evs),
                "ivs": dict(m.ivs),
            }
        )
    return out


@cache
def _tournament_members() -> dict[str, list[PokemonSet]]:
    """039: each species' sets as the runnable tournament teams use them (repeats kept, so a
    random pick follows how often each set is used)."""
    from pokesv_sim.regf_teams import regf_teams, status

    dex = get_dex()
    out: dict[str, list[PokemonSet]] = {}
    for t in regf_teams():
        if not status(t.id).runnable:
            continue
        for m in t.team.members:
            s = dex.species(m.species)
            if s is not None:
                out.setdefault(s.id, []).append(m)
    return out


def random_set(species_id: str, rng: Any) -> dict[str, Any] | None:
    """A tournament set of ``species_id`` picked at random, in the builder's form, or None."""
    sets = _tournament_members().get(species_id)
    if not sets:
        return None
    return team_to_json(Team((rng.choice(sets),)))[0]
