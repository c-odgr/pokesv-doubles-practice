"""Players choose actions from what they can see (``SideView``) and the legal choices."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import replace
from typing import Protocol

from pokesv_sim.choices import (
    ALLY_OR_SELF,
    ALLY_TARGETS,
    SINGLE_TARGETS,
    STRUGGLE,
    Choice,
    MoveChoice,
    PassChoice,
    Preview,
    SwitchChoice,
)
from pokesv_sim.prng import Prng, Seed
from pokesv_sim.state import PREVIEW_PICK
from pokesv_sim.view import SideView


class Player(Protocol):
    def choose_preview(self, view: SideView) -> Preview: ...

    def choose_turn(
        self, view: SideView, legal: Sequence[Sequence[MoveChoice | SwitchChoice]]
    ) -> list[Choice]: ...

    def choose_replacements(
        self, view: SideView, need: Sequence[bool]
    ) -> list[SwitchChoice | PassChoice]: ...


def seed_words(seed: int | Seed) -> Seed:
    """Four 16-bit words from an integer seed (or pass a word tuple through)."""
    if isinstance(seed, tuple):
        return seed
    n = seed & ((1 << 64) - 1)
    return ((n >> 48) & 0xFFFF, (n >> 32) & 0xFFFF, (n >> 16) & 0xFFFF, n & 0xFFFF)


class RandomPlayer:
    """Showdown's ``RandomPlayerAI`` with its defaults (``sim/tools/random-player-ai.ts``).

    Brings the first four in team order (or, with ``random_preview``, four in a shuffled order:
    the crosscheck's ``chooseTeamPreview`` override in ``tools/oracle/run_matchups.mjs``);
    switches only when a roll exceeds ``move`` (never with the default 1.0, but the roll is
    still drawn, as Showdown does); picks a move uniformly;
    aims single-target moves at a random foe position (a target is drawn for every candidate
    move); replaces fainted Pokémon uniformly from the bench (in Showdown's side order).
    Uses its own PRNG, separate from the battle's.

    017: with ``tera`` > 0 it terastallizes with that chance per Pokémon while its side still
    can (``tools/oracle/tera_ai.mjs``: the roll is drawn before the move targets, and only
    applies when it then picks a move). With the default 0 it draws nothing for it.
    """

    def __init__(
        self,
        seed: int | Seed,
        move: float = 1.0,
        *,
        random_preview: bool = False,
        tera: float = 0.0,
    ) -> None:
        """``move``: Showdown's ``options.move``; below 1, it sometimes switches voluntarily."""
        self.prng = Prng(seed_words(seed))
        self.move = move
        self.random_preview = random_preview
        self.tera = tera

    def choose_preview(self, view: SideView) -> Preview:
        order = list(range(len(view.team)))
        if self.random_preview:
            self.prng.shuffle(order)  # PRNG.shuffle, then 'team' with the first four
        return Preview(tuple(order[:PREVIEW_PICK]))

    def choose_turn(
        self, view: SideView, legal: Sequence[Sequence[MoveChoice | SwitchChoice]]
    ) -> list[Choice]:
        chosen: list[int] = []
        choices: list[Choice] = []
        can_tera = True
        for position, options in enumerate(legal):
            if not options:
                choices.append(PassChoice())
                continue
            user = next(p for p in view.team if p.position == position and not p.fainted)
            # the request leaves canTerastallize out with a locked move (Struggle: lockedMove)
            struggling = any(
                isinstance(c, MoveChoice) and c.move_index == STRUGGLE for c in options
            )
            # 020: so does a charged move's (twoturnmove's onLockMove): one move, no target
            can_tera = can_tera and view.can_terastallize and not struggling and not user.locked
            change = can_tera and self.tera > 0 and self.prng.random() < self.tera
            move_indices = list(
                dict.fromkeys(c.move_index for c in options if isinstance(c, MoveChoice))
            )
            # hasAlly: side.pokemon[i ^ 1] has not fainted; without one, moves aimed at the
            # ally are left out (unless that leaves nothing).
            ally = next((p for p in view.team if p.position == 1 - position), None)
            has_ally = ally is not None and not ally.fainted
            if not has_ally:
                kept = [
                    i
                    for i in move_indices
                    if i < 0 or user.moves[i].target not in ALLY_TARGETS  # (Struggle, Recharge)
                ]
                move_indices = kept or move_indices
            moves = []
            for index in move_indices:
                target = None
                if user.locked:
                    pass  # the request's move has no target type: no draw
                elif index != STRUGGLE and user.moves[index].target in SINGLE_TARGETS:
                    target = 1 + self.prng.random_int(2)
                elif index != STRUGGLE and user.moves[index].target in ALLY_TARGETS:
                    target = -(1 - position) - 1  # -((i ^ 1) + 1): no draw
                elif index != STRUGGLE and user.moves[index].target == ALLY_OR_SELF:
                    # 041-6f: -(1 + random(2)) with an ally, else its own location
                    target = -(1 + self.prng.random_int(2)) if has_ally else -position - 1
                moves.append(MoveChoice(index, target))
            switches = [
                c.team_index
                for c in options
                if isinstance(c, SwitchChoice) and c.team_index not in chosen
            ]
            if switches and (not moves or self.prng.random() > self.move):
                pick = self.prng.sample(switches)
                chosen.append(pick)
                choices.append(SwitchChoice(pick))
            else:
                move_choice = self.prng.sample(moves)
                if change and can_tera:
                    can_tera = False
                    move_choice = replace(move_choice, terastallize=True)
                choices.append(move_choice)
        return choices

    def choose_replacements(
        self, view: SideView, need: Sequence[bool], reviving: Sequence[bool] = ()
    ) -> list[SwitchChoice | PassChoice]:
        """041-6f: a ``reviving`` position (Revival Blessing) picks among the fainted ones."""
        by_index = {p.team_index: p for p in view.team}
        bench = [i for i in view.order if not by_index[i].fainted and by_index[i].position is None]
        choices: list[SwitchChoice | PassChoice] = []
        for must in need:
            pool = bench
            if len(reviving) > len(choices) and reviving[len(choices)]:
                pool = [i for i in view.order if by_index[i].fainted]
            options = [i for i in pool if i not in {c.team_index for c in _switches(choices)}]
            if not must or not options:
                choices.append(PassChoice())
                continue
            choices.append(SwitchChoice(self.prng.sample(options)))
        return choices


def _switches(choices: list[SwitchChoice | PassChoice]) -> list[SwitchChoice]:
    return [c for c in choices if isinstance(c, SwitchChoice)]
