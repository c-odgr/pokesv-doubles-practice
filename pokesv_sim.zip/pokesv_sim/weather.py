"""What the weather does (Showdown ``data/conditions.ts`` sunnyday, raindance, sandstorm,
snowscape, and the weather-dependent moves in ``data/moves.ts``).

The weather itself (which one, turns left, starting and ending) is in ``field.py``. Functions
here take the weather id (or None) so that damage calculation stays independent of the battle.
"""

from __future__ import annotations

from dataclasses import replace

from pokesv_sim.dex import Move
from pokesv_sim.field import RAIN, SAND, SNOW, SUN

# onWeatherModifyDamage: (weather, move type) -> modifier.
_DAMAGE = {
    (SUN, "Fire"): 1.5,
    (SUN, "Water"): 0.5,
    (RAIN, "Water"): 1.5,
    (RAIN, "Fire"): 0.5,
}
# onModifySpD (sandstorm, Rock) / onModifyDef (snowscape, Ice): (weather, stat) -> type.
_DEFENSE = {(SAND, "spd"): "Rock", (SNOW, "def"): "Ice"}
# Types that take no sandstorm damage (typechart ``sandstorm: 3``).
SAND_IMMUNE = frozenset({"Rock", "Ground", "Steel"})
SOLAR_MOVES = frozenset({"solarbeam", "solarblade"})  # 026: no charge in the sun (R1)
SOLAR_WEAK_WEATHER = frozenset({RAIN, SAND, SNOW})  # 026: half power (R2, effectiveWeather)
_WEATHER_BALL_TYPE = {SUN: "Fire", RAIN: "Water", SAND: "Rock", SNOW: "Ice"}
_RAIN_ALWAYS_HITS = frozenset({"thunder", "hurricane", "bleakwindstorm", "wildboltstorm",
                               "sandsearstorm"})  # fmt: skip
_SUN_HALF_ACCURACY = frozenset({"thunder", "hurricane"})
# 040-3c: Pokemon#effectiveWeather: sun and rain are '' for a Utility Umbrella holder
UTILITY_UMBRELLA = "utilityumbrella"
_SAME = "<same>"  # damage_modifier: the attacker's effective weather is the defender's


def effective_weather(weather: str | None, item: str) -> str | None:
    """040-3c: ``pokemon.effectiveWeather()``: no sun or rain for a Utility Umbrella holder."""
    if item == UTILITY_UMBRELLA and weather in (SUN, RAIN):
        return None
    return weather


def damage_modifier(weather: str | None, move: Move, attacker_weather: str | None = _SAME) -> float:
    """``WeatherModifyDamage`` (applied after the spread modifier, before the critical hit):
    the defender's effective weather. Hydro Steam is boosted, not weakened, when its user is
    in the sun (040-3c: the attacker's effective weather; by default the same as ``weather``)."""
    own = weather if attacker_weather == _SAME else attacker_weather
    if own == SUN and move.id == "hydrosteam":
        return 1.5
    return _DAMAGE.get((weather, move.type), 1.0) if weather else 1.0


def boosts_defense(weather: str | None, types: tuple[str, ...], stat: str) -> bool:
    """Sandstorm raises a Rock type's SpD, snow an Ice type's Def (x1.5, after stat stages)."""
    boosted_type = _DEFENSE.get((weather, stat)) if weather else None
    return boosted_type is not None and boosted_type in types


def modify_move(
    move: Move, weather: str | None, user_item: str = "", target_item: str = ""
) -> Move:
    """``onModifyType`` / ``onModifyMove`` of the moves that change with the weather (ported by
    hand: ``support.HAND_PORTED_MOVES``). 040-3c: Weather Ball looks at the user's effective
    weather, Thunder, Hurricane and the storms at the target's (Utility Umbrella)."""
    if weather is None:
        return move
    if move.id == "growth":  # 041-1d: onModifyMove: +2 / +2 in the user's sun
        if effective_weather(weather, user_item) == SUN:
            return replace(move, boosts={"atk": 2, "spa": 2})
        return move
    if move.id == "weatherball":
        own = effective_weather(weather, user_item)
        if own is None:
            return move
        return replace(move, type=_WEATHER_BALL_TYPE[own], base_power=move.base_power * 2)
    targets = effective_weather(weather, target_item)
    if targets == RAIN and move.id in _RAIN_ALWAYS_HITS:
        return replace(move, accuracy=None)  # accuracy = true
    if targets == SUN and move.id in _SUN_HALF_ACCURACY:
        return replace(move, accuracy=50)
    if weather == SNOW and move.id == "blizzard":
        return replace(move, accuracy=None)
    return move
