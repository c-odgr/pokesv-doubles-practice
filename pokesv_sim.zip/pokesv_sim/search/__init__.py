"""036 search-ai: an AI that looks ahead on hypothetical battles (specs/036-search-ai)."""

from pokesv_sim.search.player import SearchPlayer

__all__ = ["SearchPlayer"]
