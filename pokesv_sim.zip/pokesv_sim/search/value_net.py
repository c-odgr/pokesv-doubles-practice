"""052: the value network as a leaf evaluation (pure Python: no PyTorch, works in Pyodide).

The weights are ``data/value_net_NAME.json`` from ``tools/train_value.py``: input
normalization (mean, std) and dense layers with ReLU between them. The leaf is the network's
log-odds that ``side`` wins (the scale of 037's fitted leaf); a won battle is ``WIN_VALUE``.
"""

from __future__ import annotations

import json
from functools import cache
from importlib import resources
from operator import add, mul

from pokesv_sim.battle import Battle
from pokesv_sim.search.encode import SIZE, encode
from pokesv_sim.search.leaf import LEAVES, WIN_VALUE, LeafEval


class ValueNet:
    def __init__(self, data: dict) -> None:
        if data["size"] != SIZE:
            raise ValueError(f"value net expects {data['size']} inputs, encode gives {SIZE}")
        mean: list[float] = data["mean"]
        scale = [1.0 / s for s in data["std"]]
        layers = [(layer["w"], layer["b"]) for layer in data["layers"]]
        # the normalization folded into the first layer: w' = w / std, b' = b - w' . mean; its
        # columns kept apart so a zero input costs nothing (most inputs are 0: one-hots, empty)
        w0, b0 = layers[0]
        folded = [[wi * s for wi, s in zip(row, scale, strict=True)] for row in w0]
        self.bias0 = [
            bi - sum(map(mul, row, mean)) for row, bi in zip(folded, b0, strict=True)
        ]
        self.columns = [list(col) for col in zip(*folded, strict=True)]
        self.rest = layers[1:]

    def logit(self, x: list[float]) -> float:
        h = list(self.bias0)
        for xj, col in zip(x, self.columns, strict=True):
            if xj:
                h = list(map(add, h, [c * xj for c in col]))
        for w, b in self.rest:
            h = [o if o > 0 else 0.0 for o in h]
            h = [sum(map(mul, row, h)) + bi for row, bi in zip(w, b, strict=True)]
        return h[0]


@cache
def value_net(name: str) -> ValueNet:
    text = resources.files("pokesv_sim.data").joinpath(f"value_net_{name}.json").read_text("utf-8")
    return ValueNet(json.loads(text))


def net_leaf(name: str) -> LeafEval:
    """``NAME`` or ``NAME@SHARE``: the network, or SHARE x it + (1 - SHARE) x 038's fitted leaf."""
    name, _, mix = name.partition("@")
    share = float(mix) if mix else 1.0

    def leaf(battle: Battle, side: str) -> float:
        state = battle.state
        if state.ended and state.winner is not None:
            return WIN_VALUE if state.winner == side else -WIN_VALUE
        value = value_net(name).logit(encode(battle, side))
        if share < 1.0:
            value = share * value + (1.0 - share) * LEAVES["fitted"](battle, side)
        return value

    return leaf
