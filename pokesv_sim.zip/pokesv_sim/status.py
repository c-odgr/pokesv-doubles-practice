"""Status conditions (Showdown ``data/conditions.ts``: brn, par, psn, tox, slp, frz).

The battle calls these functions at fixed points: when a move or a secondary effect tries to
inflict a status, before a Pokémon moves, at the end of the turn and when a Pokémon switches in.
Events are reported through ``emit(kind, **fields)``, the battle's event recorder.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from pokesv_sim.dex import Move, get_dex
from pokesv_sim.field import MISTY, SUN, TERRAIN_NAMES
from pokesv_sim.prng import Prng
from pokesv_sim.state import BattlePokemon
from pokesv_sim.terrain import blocks_status, is_grounded
from pokesv_sim.volatiles import safeguarded

type Emit = Callable[..., Any]

# Showdown onResidualOrder: lower runs first.
RESIDUAL_ORDER = {"psn": 9, "tox": 9, "brn": 10}


from pokesv_sim.abilities import STATUS_GUARDS  # noqa: E402


def try_set_status(
    target: BattlePokemon,
    status: str,
    *,
    user: BattlePokemon,
    status_move: bool,
    prng: Prng,
    emit: Emit,
    weather: str | None = None,
    terrain: str | None = None,
    from_yawn: bool = False,
    sweet_veil: str | None = None,
    uproar: bool = False,
    uproar_first: bool = False,
    rest: bool = False,
    flower_veil: str | None = None,
    flower_veil_shown: bool = False,
) -> bool | None:
    """Showdown ``trySetStatus``/``setStatus``. ``status_move``: the source is a status move
    (which reports failures); otherwise it is a secondary effect (silent on failure).
    ``from_yawn`` (025): drowsiness ends; silent, but a terrain that stops it reports itself.
    ``runStatusImmunity``: type immunity (not for Corrosion's poison, 032), then the sun's
    ``onImmunity`` against freezing. ``sweet_veil`` (032): the label of a Sweet Veil holder
    on the target's side (``-block`` sleep). ``uproar`` (033): an active Pokémon is in an
    uproar (its onAnySetStatus: sleep fails with ``-fail … slp [from] Uproar``); ``uproar_first``:
    its handler sorts before Sweet Veil's (speed, then subOrder: volatile 2, ability 7)."""
    if target.hp <= 0:
        return False
    if target.status is not None:
        # trySetStatus re-applies the current status, which fails.
        if status_move:
            if target.status == status:
                emit("fail", actor=target.label, detail=status)
            else:
                emit("fail", actor=user.label)
        return False
    # (043-3a: Magma Armor's onImmunity frz, in runStatusImmunity like the sun's)
    sun_blocks = status == "frz" and (weather == SUN or target.ability_id == "magmaarmor")
    corrodes = user.ability_id == "corrosion" and status in ("psn", "tox")
    immune = get_dex().effect_immune("psn" if status == "tox" else status, target.types)
    if sun_blocks or (immune and not corrodes):
        if status_move:
            emit("immune", target=target.label)
        return False
    if status == "brn" and target.ability_id in ("thermalexchange", "waterbubble"):
        # 012: Thermal Exchange onSetStatus (before the terrain's: ability handlers are faster);
        # 030: Water Bubble's is the same
        if status_move:
            emit("immune", target=target.label)
        return False
    guard = STATUS_GUARDS.get(target.ability_id)
    leaf_guard = target.ability_id == "leafguard" and weather == SUN  # 043-3a
    if (guard is not None and status in guard[0]) or leaf_guard:
        # 041-3h: Insomnia's onSetStatus (-immune for a move with a primary status; 041-6f:
        # Limber's is the same for paralysis; 043-3a: Vital Spirit, Immunity, Water Veil,
        # Leaf Guard in the sun)
        if status_move:
            emit("immune", target=target.label)
        return False
    shielded = (  # 043-6d: Shields Down's onSetStatus in the Meteor forme
        target.ability_id == "shieldsdown" and target.species.name == "Minior-Meteor"
        and target.transform_base is None
    )  # fmt: skip
    if target.ability_id in ("purifyingsalt", "comatose") or shielded:  # (043-3c: Comatose)
        # 032 (R13): onSetStatus false; -immune when the effect is a status move
        if status_move:
            emit("immune", target=target.label)
        return False
    if flower_veil is not None and not from_yawn:
        # 043-3c: Flower Veil's onAllySetStatus: null (-block for a move without secondaries)
        if flower_veil_shown:
            emit("block", target=target.label, detail="ability: Flower Veil", actor=flower_veil)
        return None
    if status == "slp" and uproar and (sweet_veil is None or uproar_first):
        emit("fail", actor=target.label, detail=status)  # 033 (R13): any effect
        return None  # (041-6f: null, so Rest adds no -fail)
    if status == "slp" and sweet_veil is not None:
        # 032 (R13): Sweet Veil's onAllySetStatus: null with -block (any effect)
        emit("block", target=target.label, detail="ability: Sweet Veil", actor=sweet_veil)
        return None  # (041-6f: null)
    if not from_yawn and safeguarded(target, user):
        # 041-3e: Safeguard's onSetStatus (a message for a move without secondaries; a side
        # condition, so after the Pokemon's own and its allies' handlers: 043 review)
        if status_move:
            emit("activate", target=target.label, detail="move: Safeguard")
        return False
    grounded = is_grounded(
        target.types,
        target.ability_id,
        target.item,
        target.pinned,
        rising="magnetrise" in target.timed,
    )
    if terrain is not None and blocks_status(terrain, status, grounded=grounded):
        # 010: runEvent('SetStatus'): Misty / Electric Terrain (a message for status moves)
        # (041-6d: Misty Terrain's message needs the move's own status, which Rest has not;
        # Electric Terrain's any move without secondaries)
        if (status_move and not (rest and terrain == MISTY)) or from_yawn:
            emit("activate", target=target.label, detail=f"move: {TERRAIN_NAMES[terrain]}")
        return False
    target.status = status
    emit("status", target=target.label, detail=status)
    if status == "slp":
        target.sleep_turns = prng.random_range(2, 5)  # 1-3 turns asleep
    elif status == "tox":
        target.toxic_stage = 0
    return True


def cure(pokemon: BattlePokemon, emit: Emit) -> None:
    """Showdown ``cureStatus``: ``-curestatus`` and the status is gone."""
    if pokemon.hp <= 0 or pokemon.status is None:
        return
    emit("curestatus", target=pokemon.label, detail=pokemon.status)
    pokemon.status = None
    pokemon.sleep_turns = 0


def full_paralysis(pokemon: BattlePokemon, prng: Prng, emit: Emit) -> bool:
    """par ``onBeforeMove`` (priority 1): False when the Pokémon cannot move."""
    if pokemon.status == "par" and prng.random_chance(1, 4):
        emit("cant", actor=pokemon.label, detail="par")
        return False
    return True


def sleep_or_freeze(pokemon: BattlePokemon, move: Move, prng: Prng, emit: Emit) -> bool:
    """slp/frz ``onBeforeMove`` (priority 10): False when the Pokémon cannot move (a
    ``sleepUsable`` move goes on after ``cant … slp``)."""
    if pokemon.status == "slp":
        if pokemon.ability_id == "earlybird":
            pokemon.sleep_turns -= 1  # 043-3a: Early Bird (statusState.time--)
        pokemon.sleep_turns -= 1
        if pokemon.sleep_turns <= 0:
            cure(pokemon, emit)
            return True
        emit("cant", actor=pokemon.label, detail="slp")
        return "sleepUsable" in move.keys  # 025 (R4): Sleep Talk goes on
    elif pokemon.status == "frz":
        if "defrost" in move.flags:
            return True  # thawed by the move itself (``thaw_by_own_move``)
        if prng.random_chance(1, 5):
            cure(pokemon, emit)
            return True
        emit("cant", actor=pokemon.label, detail="frz")
        return False
    return True


def thaw_by_own_move(pokemon: BattlePokemon, move: Move, emit: Emit) -> None:
    """frz ``onModifyMove``: a defrost move thaws its user before it is used."""
    if pokemon.status == "frz" and "defrost" in move.flags:
        emit("curestatus", target=pokemon.label, detail="frz")
        pokemon.status = None


def residual_order(pokemon: BattlePokemon) -> int:
    """Showdown ``onResidualOrder`` of the Pokémon's status (lower runs first)."""
    assert pokemon.status in RESIDUAL_ORDER
    return RESIDUAL_ORDER[pokemon.status]


def residual_damage(pokemon: BattlePokemon) -> int:
    """End-of-turn damage of brn/psn/tox (advances the toxic stage). brn/psn keep the fraction
    until ``spreadDamage`` truncates it (minimum 1); tox floors 1/16 first (verified)."""
    if pokemon.status == "brn":
        raw = pokemon.max_hp / 16
    elif pokemon.status == "psn":
        raw = pokemon.max_hp / 8
    elif pokemon.status == "tox":
        pokemon.toxic_stage = min(15, pokemon.toxic_stage + 1)
        # clampIntRange floors: max(1, floor(maxhp / 16)) * stage
        raw = max(pokemon.max_hp // 16, 1) * pokemon.toxic_stage
    else:
        raise ValueError(f"no residual damage for {pokemon.status}")
    return max(1, int(raw))
