"""A common line format for battles from this engine and from Pokémon Showdown, and metrics on it.

Lines (positions such as ``p1a``)::

    switch p1a Garchomp 183    move p1a Earthquake    fail p1a    immune p2a    miss p2a
    crit p2a    damage p2a 120 (HP left)    damage p2a 100 psn (with the cause, if not a move)
    status p2a brn    curestatus p2a slp    cant p1a par    faint p2a    turn 3    win p1    tie
    start p2a confusion    activate p2a confusion    end p2a confusion
    fieldstart Trick Room    fieldend Trick Room    sidestart p1 Tailwind    sideend p1 Tailwind
    weather RainDance    weather RainDance upkeep    weather none    damage p1a 90 sandstorm
    singleturn p1a Protect    activate p2a move: Protect    swap p1a 1
    sethp p1a 120    clearboost p2a    item p1a Choice Scarf    fieldactivate move: Perish Song
    ability p1a Intimidate    enditem p1a Sitrus Berry    clearnegativeboost p1a
    terastallize p1a Water    detailschange p1a Ogerpon-Wellspring-Tera    clearallboost
    drag p2a Blissey 130 (Roar, 034)    replace p2a Zoroark-Hisui (Illusion ends, 034)

Type-effectiveness messages are left out: they follow from the damage and are not compared.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass

from pokesv_sim.events import Event

# Showdown log messages that are not compared (everything not listed in _SHOWDOWN_KINDS is
# skipped; these are named here because they do occur in battles within our support).
EXCLUDED_SHOWDOWN = frozenset(
    {"-supereffective", "-resisted", "upkeep", "debug", "t:", "split", "", "-hint"}
)
_SHOWDOWN_KINDS = {"switch", "move", "-fail", "-immune", "-miss", "-crit", "-damage", "faint",
                   "turn", "win", "tie", "-status", "-curestatus", "cant",
                   "-boost", "-unboost", "-heal", "-hitcount",
                   "-start", "-end", "-activate",
                   "-fieldstart", "-fieldend", "-sidestart", "-sideend", "-weather",
                   "-singleturn", "swap", "-ability",
                   "-enditem", "-clearnegativeboost",
                   "-terastallize", "detailschange", "-formechange", "-prepare",
                   "-sethp", "-clearboost", "-item", "-fieldactivate",
                   "-clearallboost", "-swapsideconditions", "-block", "-mustrecharge", "-setboost",
                   "drag", "replace", "-combine", "-waiting", "-transform",
                   "-copyboost"}  # fmt: skip


def _pos(ident: str) -> str:
    return ident.split(":")[0]  # "p1a: Garchomp" -> "p1a"; a fainted "p1: Garchomp" -> "p1"


def normalize_showdown_log(log: Iterable[str]) -> list[str]:
    """Showdown protocol lines (one copy of each split line) -> normalized lines."""
    out: list[str] = []
    started = False
    for line in log:
        parts = line.split("|")
        if len(parts) < 2:
            continue
        kind = parts[1]
        if kind == "switch":
            started = True
        if not started or kind not in _SHOWDOWN_KINDS:
            continue
        if kind in ("switch", "drag"):  # 034: drag (Roar), shown like a switch
            species = parts[3].split(",")[0]
            out.append(f"{kind} {_pos(parts[2])} {species} {parts[4].split('/')[0]}")
        elif kind == "replace":  # 034: Illusion ends (the true species)
            out.append(f"replace {_pos(parts[2])} {parts[3].split(',')[0]}")
        elif kind == "move":
            out.append(f"move {_pos(parts[2])} {parts[3]}")
        elif kind == "-miss":
            out.append(f"miss {_pos(parts[3])}")
        elif kind == "-damage":
            line = f"damage {_pos(parts[2])} {parts[3].split('/')[0].split()[0]}"
            if len(parts) > 4 and parts[4].startswith("[from] "):
                line += " " + parts[4].removeprefix("[from] ").lower()
            out.append(line)
        elif kind in ("-status", "-curestatus", "cant", "-hitcount", "-start", "-end",
                      "-activate", "-singleturn", "swap", "-ability", "-enditem",
                      "-terastallize", "-prepare", "-item", "-block"):  # fmt: skip
            out.append(f"{kind.lstrip('-')} {_pos(parts[2])} {parts[3]}")
        elif kind == "-copyboost":  # 043-1
            out.append(f"copyboost {_pos(parts[2])} {_pos(parts[3])}")
        elif kind == "-formechange":  # 042-3
            out.append(f"formechange {_pos(parts[2])} {parts[3]}")
        elif kind == "detailschange":
            out.append(f"detailschange {_pos(parts[2])} {parts[3].split(',')[0]}")
        elif kind in ("-boost", "-unboost", "-setboost"):  # 032: Belly Drum's -setboost
            out.append(f"{kind.lstrip('-')} {_pos(parts[2])} {parts[3]} {parts[4]}")
        elif kind == "-sethp":
            out.append(f"sethp {_pos(parts[2])} {parts[3].split('/')[0].split()[0]}")
        elif kind == "-heal":
            line = f"heal {_pos(parts[2])} {parts[3].split('/')[0].split()[0]}"
            if len(parts) > 4 and parts[4].startswith("[from] "):
                line += " " + parts[4].removeprefix("[from] ").lower()
            out.append(line)
        elif kind in ("-fieldstart", "-fieldend"):
            out.append(f"{kind[1:]} {parts[2].removeprefix('move: ')}")
        elif kind in ("-sidestart", "-sideend"):
            out.append(f"{kind[1:]} {_pos(parts[2])} {parts[3].removeprefix('move: ')}")
        elif kind == "-fieldactivate":
            out.append(f"fieldactivate {parts[2]}")
        elif kind == "-clearallboost":
            out.append("clearallboost")  # 023
        elif kind == "-swapsideconditions":
            out.append("swapsideconditions")  # 041-6f
        elif kind == "-weather":
            upkeep = " upkeep" if len(parts) > 3 and parts[3] == "[upkeep]" else ""
            out.append(f"weather {parts[2]}{upkeep}")
        elif kind == "-combine":
            out.append("combine")  # 041-5: Pledges
        elif kind == "-transform":
            out.append(f"transform {_pos(parts[2])} {_pos(parts[3])}")  # 041-6f
        elif kind == "-waiting":
            out.append(f"waiting {_pos(parts[2])} {_pos(parts[3])}")
        elif kind == "turn":
            out.append(f"turn {parts[2]}")
        elif kind == "win":
            out.append(f"win {parts[2]}")
        elif kind == "tie":
            out.append("tie")
        else:  # -fail, -immune, -crit, faint, -clearnegativeboost, -clearboost, -mustrecharge
            out.append(f"{kind.lstrip('-')} {_pos(parts[2])}")
    return out


def normalize_events(events: Iterable[Event]) -> list[str]:
    out: list[str] = []
    for e in events:
        if e.kind in ("switch", "drag"):
            out.append(f"{e.kind} {e.actor} {e.detail} {e.value}")
        elif e.kind == "replace":
            out.append(f"replace {e.target} {e.detail}")
        elif e.kind == "move":
            out.append(f"move {e.actor} {e.detail}")
        elif e.kind == "fail":
            out.append(f"fail {e.actor}")
        elif e.kind in ("immune", "miss", "crit", "faint", "clearnegativeboost", "clearboost",
                        "mustrecharge"):  # fmt: skip
            out.append(f"{e.kind} {e.target}")
        elif e.kind == "damage":
            cause = {"tox": "psn"}.get(e.detail or "", e.detail)  # Showdown shows toxic as psn
            out.append(f"damage {e.target} {e.hp}" + (f" {cause}" if cause else ""))
        elif e.kind in ("status", "curestatus", "start", "end", "activate", "singleturn",
                        "ability", "enditem", "terastallize", "detailschange", "formechange",
                        "prepare", "item", "block"):  # fmt: skip
            out.append(f"{e.kind} {e.target} {e.detail}")
        elif e.kind == "combine":
            out.append("combine")
        elif e.kind == "copyboost":
            out.append(f"copyboost {e.target} {e.actor}")
        elif e.kind == "transform":
            out.append(f"transform {e.actor} {e.target}")
        elif e.kind == "waiting":
            out.append(f"waiting {e.actor} {e.target}")
        elif e.kind == "swap":
            out.append(f"swap {e.actor} {e.value}")
        elif e.kind == "cant":
            out.append(f"cant {e.actor} {e.detail}")
        elif e.kind in ("boost", "unboost", "setboost"):
            out.append(f"{e.kind} {e.target} {e.detail} {e.value}")
        elif e.kind == "sethp":
            out.append(f"sethp {e.target} {e.hp}")
        elif e.kind == "heal":
            out.append(f"heal {e.target} {e.hp}" + (f" {e.detail}" if e.detail else ""))
        elif e.kind == "hitcount":
            out.append(f"hitcount {e.target} {e.value}")
        elif e.kind == "fieldactivate":
            out.append(f"fieldactivate {e.detail}")
        elif e.kind == "clearallboost":
            out.append("clearallboost")
        elif e.kind == "swapsideconditions":
            out.append("swapsideconditions")
        elif e.kind in ("fieldstart", "fieldend"):
            out.append(f"{e.kind} {e.detail}")
        elif e.kind in ("sidestart", "sideend"):
            out.append(f"{e.kind} {e.actor} {e.detail}")
        elif e.kind == "weather":
            out.append(f"weather {e.detail}")
        elif e.kind == "weatherupkeep":
            out.append(f"weather {e.detail} upkeep")
        elif e.kind == "turn":
            out.append(f"turn {e.value}")
        elif e.kind == "win":
            out.append(f"win {e.actor}")
        elif e.kind in ("tie", "aborted"):
            out.append(e.kind)
    return out


@dataclass(frozen=True, slots=True)
class Metrics:
    winner: str | None
    turns: int
    aborted: bool
    damage_p1: int  # HP taken off by p1's moves (allies included)
    damage_p2: int
    crits: int
    misses: int
    faints_p1: int  # p1's Pokémon that fainted
    faints_p2: int
    statuses: int = 0  # status conditions inflicted
    flinches: int = 0  # turns lost to flinching
    confusions: int = 0  # times a Pokémon became confused
    trick_rooms: int = 0  # times Trick Room was set
    tailwinds: int = 0  # times Tailwind was set
    weathers: int = 0  # times a weather was set
    screens: int = 0  # times Reflect, Light Screen or Aurora Veil was set
    protects: int = 0  # times a move was blocked by protection (Protect, Wide Guard, ...)
    single_turns: int = 0  # one-turn effects started (Protect, Follow Me, Helping Hand, ...)
    terrains: int = 0  # times a terrain was set (010)
    abilities: int = 0  # abilities announced (-ability: Intimidate, Defiant, Ruin, ...) (011)


_SCREEN_NAMES = frozenset({"Reflect", "Light Screen", "Aurora Veil"})


def metrics(lines: Sequence[str]) -> Metrics:
    hp: dict[str, int] = {}
    mover = ""
    damage = {"p1": 0, "p2": 0}
    faints = {"p1": 0, "p2": 0}
    crits = misses = turns = statuses = flinches = confusions = trick_rooms = tailwinds = 0
    weathers = screens = protects = single_turns = terrains = abilities = 0
    winner: str | None = None
    aborted = False
    for line in lines:
        words = line.split()
        kind = words[0]
        if kind in ("switch", "drag"):
            hp[words[1]] = int(words[-1])
        elif kind == "move":
            mover = words[1][:2]
        elif kind == "damage":
            left = int(words[2])
            if len(words) == 3:  # damage from a move (not from a status or recoil)
                damage[mover] += hp.get(words[1], left) - left
            hp[words[1]] = left
        elif kind == "status":
            statuses += 1
        elif kind == "cant" and words[2] == "flinch":
            flinches += 1
        elif kind == "start" and words[2] == "confusion":
            confusions += 1
        elif kind == "fieldstart" and line == "fieldstart Trick Room":
            trick_rooms += 1
        elif kind == "fieldstart" and words[-1] == "Terrain":
            terrains += 1
        elif kind == "sidestart" and words[-1] == "Tailwind":
            tailwinds += 1
        elif kind == "sidestart" and " ".join(words[2:]) in _SCREEN_NAMES:
            screens += 1
        elif kind == "weather" and len(words) == 2 and words[1] != "none":
            weathers += 1
        elif kind in ("heal", "sethp"):
            hp[words[1]] = int(words[2])
        elif kind == "singleturn":
            single_turns += 1
        elif kind == "ability":
            abilities += 1
        elif kind == "activate" and words[2] == "move:" and words[3] in ("Protect", "Wide",
                                                                        "Quick"):  # fmt: skip
            protects += 1
        elif kind == "crit":
            crits += 1
        elif kind == "miss":
            misses += 1
        elif kind == "faint":
            faints[words[1][:2]] += 1
        elif kind == "turn":
            turns = int(words[1])
        elif kind == "win":
            winner = words[1]
        elif kind == "aborted":
            aborted = True
    return Metrics(winner, turns, aborted, damage["p1"], damage["p2"], crits, misses,
                   faints["p1"], faints["p2"], statuses, flinches, confusions,
                   trick_rooms, tailwinds, weathers, screens, protects,
                   single_turns, terrains, abilities)  # fmt: skip
