"""036 (plan R4, US4): the value of a hypothetical battle for a side: what the search compares.

A leaf evaluation is any ``(battle, side) -> float`` (higher is better for ``side``); stage 3 is
to put a learned one here. The default counts what each side has left.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from importlib import resources

from pokesv_sim.ai.belief import Beliefs
from pokesv_sim.ai.score import Evaluator
from pokesv_sim.battle import Battle
from pokesv_sim.dex import Move, get_dex
from pokesv_sim.state import BattlePokemon, action_speed
from pokesv_sim.terrain import is_grounded
from pokesv_sim.view import side_view

type LeafEval = Callable[[Battle, str], float]

WIN_VALUE = 100.0  # a won battle: above any unfinished one (037 review P3)
ALIVE_VALUE = 0.5  # a Pokémon still standing, besides its HP (as 035's knock-out value)
OUTLOOK_WEIGHT = 0.5  # how much of next turn's expected hits counts (``outlook``)


def material(battle: Battle, side: str) -> float:
    """(HP shares + ``ALIVE_VALUE`` per Pokémon standing) of ``side`` minus the foe's; a won
    battle counts as everything the foe had."""
    state = battle.state
    foe = "p2" if side == "p1" else "p1"
    if state.ended and state.winner is not None:
        return WIN_VALUE if state.winner == side else -WIN_VALUE
    return _left(battle, side) - _left(battle, foe)


def _left(battle: Battle, side: str) -> float:
    total = 0.0
    for mon in battle.state.sides[side].team:
        if not mon.fainted and mon.hp > 0:
            total += mon.hp / mon.max_hp + ALIVE_VALUE
    return total


def outlook(battle: Battle, side: str) -> float:
    """``material`` plus what each side threatens next turn (036 plan R4): 035's value of each
    foe's best attack on the own Pokémon it hurts most, from each side's view, mine minus theirs
    times ``OUTLOOK_WEIGHT``."""
    base = material(battle, side)
    state = battle.state
    if state.ended:
        return base
    foe = "p2" if side == "p1" else "p1"
    return base + OUTLOOK_WEIGHT * (_threatened(battle, foe) - _threatened(battle, side))


def _threatened(battle: Battle, side: str) -> float:
    """How hard ``side``'s foes can hit it next turn, as ``side`` sees it (prior guesses)."""
    view = side_view(battle.state, side)
    beliefs = Beliefs(view.foe_preview, side)
    beliefs.see_field(view)
    evaluator = Evaluator(view, beliefs, frozenset(), frozenset())
    own = sorted(evaluator.own)
    if not own:
        return 0.0
    return sum(max(evaluator.threat(f, o, False) for o in own) for f in evaluator.foes)


# -- features (036, 依頼者「B で少しでも当てを増やす」: also the inputs of stage 3's learning) --

FEATURES = (
    "hp",  # HP shares of the Pokémon standing
    "alive",  # Pokémon standing
    "threat",  # next turn's expected hits (035's values), dealt minus taken
    "faster",  # pairs of opposing active Pokémon where this side's moves first
    "boosts",  # attacking and Speed stages of the active Pokémon (each capped at +-2)
    "status",  # foes with a major status minus own (sleep, paralysis, burn count)
    "tera",  # Terastallization still to use
    "tailwind",  # turns of Tailwind left
    "screens",  # turns of Reflect, Light Screen and Aurora Veil left
    # 038 (依頼者): what limits the foe's actions, terrain, the doubles moves
    "trickroom",  # turns of Trick Room left x the pairs this side moves first in (under it)
    "priority_block",  # active Pokémon stopping the foe's priority moves
    "terrain",  # turns of terrain left x active grounded Pokémon it helps
    "redirect",  # active Pokémon that can use Follow Me / Rage Powder
    "fakeout",  # active Pokémon that can still use Fake Out
    "wideguard",  # active Pokémon that can use Wide Guard
    # 048 (依頼者 2026-11-23: read the foe's likely attacks, abstractly, not per scene)
    "cover",  # how well this side's best receiver (field or bench) takes each foe's best hit
    "pierce",  # active Pokémon whose attacks go through Protect (Unseen Fist + contact, Feint)
    "punish",  # what the foes' best contact hits would cost them (Rocky Helmet, Rough Skin)
)
FEATURES_038 = FEATURES[:15]  # (the 038 weights' features; new ones weigh 0 there)

WEIGHTS: dict[str, float] = {
    "hp": 1.0, "alive": 0.5, "threat": 0.5, "faster": 0.1, "boosts": 0.05,
    "status": 0.15, "tera": 0.1, "tailwind": 0.03, "screens": 0.02,
}  # fmt: skip

_STATUS = {"slp": 1.0, "par": 1.0, "brn": 0.7, "frz": 1.0, "tox": 0.5, "psn": 0.3}
_SCREENS = ("reflect", "lightscreen", "auroraveil")


def features(battle: Battle, side: str, only: frozenset[str] | None = None) -> dict[str, float]:
    """Each feature as ``side``'s value minus the foe's (a won battle: see ``linear``).
    048: ``only``: just these (the others are 0), so a leaf skips what it does not weigh."""
    foe = "p2" if side == "p1" else "p1"
    if only is not None and not only & _NEW:
        out038 = _features038(battle, side, foe)
        return {f: out038.get(f, 0.0) for f in FEATURES}
    out = _features038(battle, side, foe) | {
        "cover": _cover(battle, side) - _cover(battle, foe),
        "pierce": _pierce(battle, side) - _pierce(battle, foe),
        "punish": _punish(battle, side) - _punish(battle, foe),
    }
    return out


_NEW = frozenset({"cover", "pierce", "punish"})


def _features038(battle: Battle, side: str, foe: str) -> dict[str, float]:
    state = battle.state
    out = {
        "hp": _hp(battle, side) - _hp(battle, foe),
        "alive": _alive(battle, side) - _alive(battle, foe),
        "threat": 0.0 if state.ended else _threatened(battle, foe) - _threatened(battle, side),
        "faster": _faster(battle, side) - _faster(battle, foe),
        "boosts": _boosts(battle, side) - _boosts(battle, foe),
        "status": _status(battle, foe) - _status(battle, side),
        "tera": float(not state.sides[side].tera_used) - float(not state.sides[foe].tera_used),
        "tailwind": _cond(battle, side, ("tailwind",)) - _cond(battle, foe, ("tailwind",)),
        "screens": _cond(battle, side, _SCREENS) - _cond(battle, foe, _SCREENS),
        "trickroom": _trick_room(battle, side) - _trick_room(battle, foe),
        "priority_block": _priority_block(battle, side) - _priority_block(battle, foe),
        "terrain": _terrain(battle, side) - _terrain(battle, foe),
        "redirect": _knows(battle, side, _REDIRECT) - _knows(battle, foe, _REDIRECT),
        "fakeout": _fake_out(battle, side) - _fake_out(battle, foe),
        "wideguard": _knows(battle, side, ("wideguard",)) - _knows(battle, foe, ("wideguard",)),
    }
    return out


def linear(weights: dict[str, float]) -> LeafEval:
    """The leaf ``sum(weights[f] * features[f])``; a won battle is worth ``WIN_VALUE``."""
    used = frozenset(f for f, w in weights.items() if w)

    def leaf(battle: Battle, side: str) -> float:
        state = battle.state
        if state.ended and state.winner is not None:
            return WIN_VALUE if state.winner == side else -WIN_VALUE
        values = features(battle, side, used)
        return sum(w * values[f] for f, w in weights.items())

    return leaf


def _standing(battle: Battle, side: str) -> list[BattlePokemon]:
    return [m for m in battle.state.sides[side].team if not m.fainted and m.hp > 0]


def _hp(battle: Battle, side: str) -> float:
    return sum(m.hp / m.max_hp for m in _standing(battle, side))


def _alive(battle: Battle, side: str) -> float:
    return float(len(_standing(battle, side)))


def _active(battle: Battle, side: str) -> list[BattlePokemon]:
    return [m for m in battle.state.sides[side].active if m is not None and m.hp > 0]


def _faster(battle: Battle, side: str) -> float:
    foe = "p2" if side == "p1" else "p1"
    field = battle.state.field
    return float(
        sum(
            action_speed(a, field) > action_speed(b, field)
            for a in _active(battle, side)
            for b in _active(battle, foe)
        )
    )


def _boosts(battle: Battle, side: str) -> float:
    return float(
        sum(
            max(-2, min(2, m.boosts.get(stat, 0)))
            for m in _active(battle, side)
            for stat in ("atk", "spa", "spe")
        )
    )


def _status(battle: Battle, side: str) -> float:
    return sum(_STATUS.get(m.status or "", 0.0) for m in _standing(battle, side))


_BLOCKERS = frozenset({"armortail", "dazzling", "queenlymajesty"})
_REDIRECT = ("followme", "ragepowder")
_TERRAIN_TYPES = {
    "electricterrain": "Electric",
    "grassyterrain": "Grass",
    "psychicterrain": "Psychic",
}


def _trick_room(battle: Battle, side: str) -> float:
    turns = battle.state.field.pseudo_weather.get("trickroom", 0)
    return turns * _faster(battle, side) if turns else 0.0


def _grounded(mon: BattlePokemon) -> bool:
    return is_grounded(mon.types, mon.ability, mon.item)


def _priority_block(battle: Battle, side: str) -> float:
    active = _active(battle, side)
    count = sum(m.ability in _BLOCKERS for m in active)
    if battle.state.field.terrain == "psychicterrain":
        count += sum(_grounded(m) for m in active)
    return float(count)


def _terrain(battle: Battle, side: str) -> float:
    field = battle.state.field
    if field.terrain is None:
        return 0.0
    boosted = _TERRAIN_TYPES.get(field.terrain)
    helped = sum(
        _grounded(m) and (boosted is None or boosted in m.types) for m in _active(battle, side)
    )  # (Misty Terrain guards every grounded Pokémon from status)
    return float(field.terrain_turns * helped)


def _knows(battle: Battle, side: str, ids: tuple[str, ...]) -> float:
    return float(
        sum(
            any(slot.move.id in ids and slot.pp > 0 for slot in m.moves)
            for m in _active(battle, side)
        )
    )


def _fake_out(battle: Battle, side: str) -> float:
    return float(
        sum(
            m.active_move_actions == 0 and any(s.move.id == "fakeout" and s.pp > 0 for s in m.moves)
            for m in _active(battle, side)
        )
    )


# -- 048: the foes' likely attacks ----------------------------------------------------------

_ABSORB = {
    "Ground": ("levitate", "eartheater"),
    "Fire": ("flashfire", "wellbakedbody"),
    "Water": ("waterabsorb", "stormdrain", "dryskin"),
    "Electric": ("voltabsorb", "lightningrod", "motordrive"),
    "Grass": ("sapsipper",),
}
_PIERCE_MOVES = frozenset(
    {"feint", "shadowforce", "phantomforce", "hyperspacefury", "hyperspacehole"}
)
_HELMET = {"rockyhelmet": 1 / 6}
_BARBS = {"roughskin": 1 / 8, "ironbarbs": 1 / 8}


def _hits(move: Move) -> float:
    if move.multihit is None:
        return 1.0
    low, high = move.multihit
    return 3.1 if (low, high) == (2, 5) else (low + high) / 2


def hit_share(attacker: BattlePokemon, move: Move, defender: BattlePokemon) -> float:
    """A rough share of ``defender``'s HP that ``move`` takes (no random roll, no field):
    the damage formula's level-50 core with STAB, type effectiveness and the immunities of
    types and common abilities. Capped at 1."""
    if move.category == "Status" or move.base_power <= 0:
        return 0.0
    dex = get_dex()
    if dex.is_immune(move.type, defender.types):
        return 0.0
    if defender.ability_id in _ABSORB.get(move.type, ()):
        return 0.0
    physical = move.category == "Physical"
    attack = attacker.stats["atk" if physical else "spa"]
    defense = max(1, defender.stats["def" if physical else "spd"])
    stab = 1.5 if move.type in attacker.types else 1.0
    effect = 2.0 ** dex.type_mod(move.type, defender.types)
    damage = (22 * move.base_power * attack / defense / 50 + 2) * stab * effect * 0.925
    return min(1.0, damage * _hits(move) / max(1, defender.max_hp))


def _attacks(mon: BattlePokemon) -> list[Move]:
    return [s.move for s in mon.moves if s.pp > 0 and s.move.category != "Status"]


def _best_hit(attacker: BattlePokemon, defender: BattlePokemon) -> tuple[float, Move | None]:
    best: tuple[float, Move | None] = (0.0, None)
    for move in _attacks(attacker):
        share = hit_share(attacker, move, defender)
        if share > best[0]:
            best = (share, move)
    return best


def _cover(battle: Battle, side: str) -> float:
    """For each foe on the field: 1 minus the share of HP its best attack takes from this
    side's best receiver (a Pokémon standing, on the field or on the bench), summed."""
    foe = "p2" if side == "p1" else "p1"
    own = _standing(battle, side)
    if not own:
        return 0.0
    return sum(
        1.0 - min(_best_hit(f, o)[0] for o in own) for f in _active(battle, foe)
    )  # fmt: skip


def _pierce(battle: Battle, side: str) -> float:
    count = 0
    for mon in _active(battle, side):
        moves = [s.move for s in mon.moves if s.pp > 0]
        if any(m.id in _PIERCE_MOVES for m in moves) or (
            mon.ability_id == "unseenfist" and any("contact" in m.flags for m in _attacks(mon))
        ):
            count += 1
    return float(count)


def _punish(battle: Battle, side: str) -> float:
    """What each foe on the field would lose (share of its HP) by its best attack on this
    side's field, if that attack makes contact with a Rocky Helmet or Rough Skin holder."""
    foe = "p2" if side == "p1" else "p1"
    total = 0.0
    own = _active(battle, side)
    for f in _active(battle, foe):
        best = max(((_best_hit(f, o), o) for o in own), key=lambda x: x[0][0], default=None)
        if best is None or best[0][1] is None or "contact" not in best[0][1].flags:
            continue
        move, holder = best[0][1], best[1]
        per_hit = _HELMET.get(holder.item, 0.0) + _BARBS.get(holder.ability_id, 0.0)
        total += min(1.0, per_hit * _hits(move) * _holder_scale(f))
    return total


def _holder_scale(attacker: BattlePokemon) -> float:
    """(the recoil is a share of the attacker's max HP; its current HP decides how much it
    matters)"""
    return attacker.max_hp / max(1, attacker.hp)


def _cond(battle: Battle, side: str, ids: tuple[str, ...]) -> float:
    conditions = battle.state.field.sides.get(side, {})
    return float(sum(conditions.get(i, 0) for i in ids))


def fitted_weights(name: str = "leaf_weights.json") -> dict[str, float]:
    """037: the weights ``tools/fit_leaf.py`` wrote (``data/leaf_weights.json``), else the hand
    ones (``WEIGHTS``)."""
    try:
        text = resources.files("pokesv_sim.data").joinpath(name).read_text("utf-8")
    except FileNotFoundError:
        return dict(WEIGHTS)
    weights: dict[str, float] = json.loads(text)["weights"]
    return {f: float(weights.get(f, 0.0)) for f in FEATURES}


def _fitted(battle: Battle, side: str) -> float:
    global _FITTED
    if _FITTED is None:
        _FITTED = linear(fitted_weights())
    return _FITTED(battle, side)


def _fitted037(battle: Battle, side: str) -> float:
    global _FITTED037
    if _FITTED037 is None:  # 039: 037's nine-feature weights, kept apart from 038's
        _FITTED037 = linear(fitted_weights("leaf_weights_037.json"))
    return _FITTED037(battle, side)


def _candidate(battle: Battle, side: str) -> float:
    global _CANDIDATE
    if _CANDIDATE is None:  # 048: weights under trial (``fit_leaf.py --write-candidate``)
        _CANDIDATE = linear(fitted_weights("leaf_weights_candidate.json"))
    return _CANDIDATE(battle, side)


_FITTED: LeafEval | None = None
_FITTED037: LeafEval | None = None
_CANDIDATE: LeafEval | None = None

LEAVES: dict[str, LeafEval] = {
    "material": material,
    "outlook": outlook,
    "features": linear(WEIGHTS),
    "features-speed": linear(WEIGHTS | {"faster": 0.25, "tailwind": 0.06}),
    "features-status": linear(WEIGHTS | {"status": 0.3, "boosts": 0.1}),
    "fitted": _fitted,  # 037, refitted in 038
    "fitted037": _fitted037,  # 039
    "candidate": _candidate,  # 048
}
