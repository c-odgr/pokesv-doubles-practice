"""Volatile statuses (Showdown ``data/conditions.ts``: flinch, confusion).

Volatile statuses last until the Pokémon leaves the field (switching out or fainting), or less:
flinch ends with the turn, confusion after a number of the Pokémon's moves. The battle calls these
functions when an effect adds one, before the Pokémon moves and at the end of the turn. Events
are reported through ``emit(kind, **fields)``, the battle's event recorder.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from pokesv_sim.boosts import boosted_stat, wonder_swapped
from pokesv_sim.damage import trunc
from pokesv_sim.prng import Prng
from pokesv_sim.state import BattlePokemon
from pokesv_sim.terrain import blocks_confusion, is_grounded

type Emit = Callable[..., Any]

CONFUSION_POWER = 40


HEAL_BLOCK = "healblock"  # 023
YAWN = "yawn"  # 025
YAWN_RESIDUAL_ORDER = 23
SALT_CURE = "saltcure"  # 032 (R16): no duration, residual order 13
SALT_CURE_RESIDUAL_ORDER = 13
SYRUP_BOMB = "syrupbomb"  # 041-6f: duration 4, residual order 14 (noCopy)
SYRUP_BOMB_RESIDUAL_ORDER = 14
MAGNET_RISE = "magnetrise"  # 041-6f: duration 5, residual order 18
MAGNET_RISE_RESIDUAL_ORDER = 18


def add_volatile(
    target: BattlePokemon,
    volatile: str,
    *,
    prng: Prng,
    emit: Emit,
    terrain: str | None = None,
    from_status_move: bool = False,
    min_confusion: int = 2,
    source: BattlePokemon | None = None,
) -> bool | None:
    """Showdown ``addVolatile``: False when the target has fainted or already has it; None
    (null) when Misty Terrain stops confusion (with a message for a move without secondary
    effects)."""
    if target.hp <= 0:
        return False
    if volatile == "focusenergy":  # 017: onModifyCritRatio +2 (no duration)
        if target.focus_energy or target.dragon_cheer:  # 041-3a: onStart false
            return False
        target.focus_energy = True
        emit("start", target=target.label, detail="move: Focus Energy")
        return True
    if volatile == "dragoncheer":  # 041-3a: no duration; fails with Focus Energy
        if target.dragon_cheer or target.focus_energy:
            return False
        emit("start", target=target.label, detail="move: Dragon Cheer")
        target.dragon_cheer = 2 if "Dragon" in target.types else 1
        return True
    if volatile == "destinybond":  # 041-4e: no duration (-singlemove, not compared)
        target.destiny_bond = True
        return True
    if volatile == "charge":  # 041-4e: no duration; onStart / onRestart -start Charge
        target.charge = True
        emit("start", target=target.label, detail="Charge")
        return True
    if volatile == "defensecurl":  # 041-3a: no duration, no message; onRestart null
        if target.defense_curl:
            return None
        target.defense_curl = True
        return True
    if volatile == "minimize":  # 034 (R5): no duration, no message; onRestart null
        if target.minimized:
            return None
        target.minimized = True
        return True
    if volatile == "imprison":  # 022: no duration (ends on switching out or fainting)
        if target.imprison:
            return False
        target.imprison = True
        emit("start", target=target.label, detail="move: Imprison")
        return True
    if volatile == YAWN:  # 025 (R1, R3): duration 2; no onRestart
        if YAWN in target.timed:
            return False
        if target.ability_id == "insomnia":  # 041-3h: Insomnia's onTryAddVolatile
            emit("immune", target=target.label)
            return None
        if safeguarded(target, source):  # 041-3e: Safeguard's onTryAddVolatile null
            if from_status_move:
                emit("activate", target=target.label, detail="move: Safeguard")
            return None
        grounded = is_grounded(
            target.types,
            target.ability_id,
            target.item,
            target.pinned,
            rising="magnetrise" in target.timed,
        )
        if terrain == "electricterrain" and grounded:
            # Electric Terrain onTryAddVolatile: null
            emit("activate", target=target.label, detail="move: Electric Terrain")
            return None
        target.timed[YAWN] = 2
        emit("start", target=target.label, detail="move: Yawn")
        return True
    if volatile == "torment":  # 041-3g: no duration, no onRestart
        if target.torment:
            return False
        target.torment = True
        emit("start", target=target.label, detail="Torment")
        return True
    if volatile == "leechseed":  # 041-4c: no duration, no onRestart; sourceSlot
        if "leechseed" in target.timed:
            return False
        assert source is not None and source.position is not None
        target.timed["leechseed"] = 0
        target.leech_slot = (source.side, source.position)
        emit("start", target=target.label, detail="move: Leech Seed")
        return True
    if volatile in ("aquaring", "ingrain"):  # 041-4c: no duration, no onRestart
        if volatile in target.timed:
            return False
        target.timed[volatile] = 0
        detail = "Aqua Ring" if volatile == "aquaring" else "move: Ingrain"
        emit("start", target=target.label, detail=detail)
        return True
    if volatile == SALT_CURE:  # 032 (R16): onStart -start; no onRestart
        if SALT_CURE in target.timed:
            return False
        target.timed[SALT_CURE] = 0
        emit("start", target=target.label, detail="Salt Cure")
        return True
    if volatile == HEAL_BLOCK:  # 023: Psychic Noise's (durationCallback 2; onRestart: nothing)
        if HEAL_BLOCK in target.timed:
            return False
        target.timed[HEAL_BLOCK] = 2
        emit("start", target=target.label, detail="move: Heal Block")
        return True
    if volatile == "sparklingaria":  # 041-6f: no condition (Sparkling Aria's onAfterMove)
        if target.sparkling_aria:
            return False
        target.sparkling_aria = True
        return True
    if volatile == MAGNET_RISE:  # 041-6f: duration 5, no onRestart
        if MAGNET_RISE in target.timed:
            return False
        target.timed[MAGNET_RISE] = 5
        emit("start", target=target.label, detail="Magnet Rise")
        return True
    if volatile == SYRUP_BOMB:  # 041-6f: no onRestart
        if SYRUP_BOMB in target.timed:
            return False
        target.timed[SYRUP_BOMB] = 4
        target.syrup_source = source
        emit("start", target=target.label, detail="Syrup Bomb")
        return True
    if volatile == "powertrick":
        # 041-6f: onStart swaps atk and def; onRestart removes it (onEnd swaps back)
        target.power_trick = not target.power_trick
        swap_attack_defense(target)
        emit("start" if target.power_trick else "end", target=target.label,
             detail="Power Trick")  # fmt: skip
        return True
    if volatile == "flinch":
        if target.flinched:
            return False
        if target.ability_id == "innerfocus":
            return None  # Inner Focus onTryAddVolatile (011)
        if "focuspunch" in target.timed:
            return None  # 041-4e: focuspunch's onTryAddVolatile
        target.flinched = True
        target.flinch_after = tuple(target.timed)
        return True
    if volatile == "confusion":
        if target.confusion_turns:
            return False
        if target.ability_id == "owntempo":
            return None  # Own Tempo onTryAddVolatile (011)
        if safeguarded(target, source):  # 041-3e
            if from_status_move:
                emit("activate", target=target.label, detail="move: Safeguard")
            return None
        grounded = is_grounded(
            target.types,
            target.ability_id,
            target.item,
            target.pinned,
            rising="magnetrise" in target.timed,
        )
        if blocks_confusion(terrain, grounded=grounded):
            if from_status_move:
                emit("activate", target=target.label, detail="move: Misty Terrain")
            return None
        emit("start", target=target.label, detail="confusion")
        # onStart: 1-4 of its moves (041-1c: Axe Kick's at least 2)
        target.confusion_turns = prng.random_range(min_confusion, 6)
        return True
    raise ValueError(f"unsupported volatile status {volatile}")


def _cant_suppress(ability_id: str) -> bool:
    from pokesv_sim.dex import get_dex

    data = get_dex().ability(ability_id)
    return data is not None and data.cant_suppress


def safeguarded(target: BattlePokemon, source: BattlePokemon | None) -> bool:
    """041-3e: Safeguard on the target's side stops another Pokemon's status / confusion /
    yawn (not the target's own; Infiltrator from a foe goes through)."""
    if source is None or source is target:
        return False
    arena = target.arena
    if arena is None or "safeguard" not in arena.field.sides[target.side]:
        return False
    return not (source.side != target.side and source.ability_id == "infiltrator")


PARTIALLY_TRAPPED = "partiallytrapped"  # 024
PARTIALLY_TRAPPED_RESIDUAL_ORDER = 13


def add_partially_trapped(
    target: BattlePokemon, source: BattlePokemon, move_id: str, move_name: str, *,
    prng: Prng, emit: Emit,
) -> bool:  # fmt: skip
    """024 (R1): a binding move's ``volatileStatus``. Nothing (no draw) when the target has
    fainted or is already bound (no onRestart); otherwise the durationCallback's
    ``random(5, 7)`` and onStart's ``-activate … move: X [of] source``."""
    if target.hp <= 0 or PARTIALLY_TRAPPED in target.timed:
        return False
    # 042-1: durationCallback: 8 with Grip Claw (no draw); onStart's boundDivisor
    grip = source.item == "gripclaw"
    target.timed[PARTIALLY_TRAPPED] = 8 if grip else prng.random_range(5, 7)
    target.trap_source, target.trap_move = source, move_id
    target.trap_divisor = 6 if source.item == "bindingband" else 8
    emit("activate", target=target.label, detail=f"move: {move_name}")
    return True


def is_active(pokemon: BattlePokemon) -> bool:
    """Showdown ``pokemon.isActive``: on the field and not fainted."""
    return pokemon.position is not None and not pokemon.fainted


def clear_volatiles(pokemon: BattlePokemon) -> None:
    """``clearVolatile``: the Pokémon left the field (switched out or fainted)."""
    if pokemon.species.name == "Morpeko-Hangry" and not pokemon.hangry_base:
        # 042-3: setSpecies(baseSpecies)
        from pokesv_sim.dex import get_dex

        base = get_dex().species("Morpeko")
        assert base is not None
        pokemon.set_species(base)
    pokemon.flinched = False
    pokemon.confusion_turns = 0
    pokemon.damaged_by.clear()  # 041-1e: attackedBy = []
    pokemon.damaged_log.clear()  # 041-4a
    pokemon.stockpile = None  # 041-4d
    pokemon.smacked_down = False  # 041-2
    pokemon.dragon_cheer, pokemon.defense_curl = 0, False  # 041-3a
    pokemon.charge = pokemon.destiny_bond = False  # 041-4e
    pokemon.trapper, pokemon.torment = None, False  # 041-3g (noCopy)
    pokemon.gastro_acid = False  # 041-3h
    pokemon.tar_shot = False  # 041-6c
    pokemon.no_retreat = False  # 041-6d
    pokemon.power_trick = False  # 041-6f (setSpecies restores the stats)
    pokemon.syrup_source = None  # 041-6f
    pokemon.attract_source = None  # 041-6f (noCopy)
    # 041-6f: moveSlots = baseMoveSlots.slice(). Not on a faint: the queue's action keeps its
    # move (action.move), which this engine reads from the slot (a fainted one never moves);
    # switching in again gives it back (Revival Blessing)
    if pokemon.mimicked is not None and not pokemon.fainted:
        index, slot = pokemon.mimicked
        pokemon.moves[index], pokemon.mimicked = slot, None
    pokemon.lock_on_target = None  # 041-6f
    if pokemon.transform_base is not None:  # 041-6f: setSpecies(baseSpecies), baseMoveSlots
        species, types, stats, moves = pokemon.transform_base
        pokemon.species, pokemon.base_types, pokemon.stats = species, types, stats
        if pokemon.fainted:  # (as Mimic's slot: not before it could act again)
            pokemon.base_moves = moves
        else:
            pokemon.moves = moves
        pokemon.mimicked = None
        pokemon.transform_base, pokemon.saved_stats = None, None
        pokemon.type_changed = False
        pokemon.cached_speed = stats["spe"]
    if pokemon.species.name in ("Minior-Meteor", "Cramorant-Gulping", "Cramorant-Gorging"):
        # 043-6d/f: setSpecies(baseSpecies): Shields Down's / Gulp Missile's formeChange
        from pokesv_sim.dex import get_dex

        own = pokemon.pokemon_set
        name = own.species if own is not None else pokemon.species.base_species
        base = get_dex().species(name)
        assert base is not None
        pokemon.set_species(base)
    if pokemon.species.name == "Meloetta-Pirouette":  # 042-4: setSpecies(baseSpecies)
        from pokesv_sim.dex import get_dex

        meloetta = get_dex().species("Meloetta")
        assert meloetta is not None
        pokemon.set_species(meloetta)
    if pokemon.saved_stats is not None:  # 041-6c: setSpecies(baseSpecies)
        pokemon.stats, pokemon.saved_stats = pokemon.saved_stats, None
    arena = pokemon.arena
    if arena is not None:  # removeLinkedVolatiles: the Pokemon it trapped are free (silent)
        for other in arena.all_active():
            if other.trapper is pokemon:
                other.trapper = None
    pokemon.added_type = None  # 041-6f: setSpecies clears addedType
    if pokemon.type_changed:  # 041-1g: setSpecies(baseSpecies) resets the types
        pokemon.base_types = pokemon.species.types
        pokemon.type_changed = False
    pokemon.apparent_type = pokemon.base_types  # 034: setSpecies(baseSpecies)
    pokemon.timed.clear()  # 009: Protect, Follow Me, Helping Hand, stall, ...
    pokemon.two_turn_move = None  # 020: twoturnmove and the charging move's volatile
    pokemon.charge_loc = None
    pokemon.charged = False
    pokemon.counters.clear()
    pokemon.booster_stat = None  # 011: Protosynthesis / Quark Drive
    pokemon.flash_fire = False  # 012
    pokemon.choice_lock = None  # 013: choicelock
    pokemon.unburden = False  # 013
    pokemon.booster_from_item = False
    pokemon.checked_berserk = None  # 013: the ability's state starts again on switching in
    pokemon.switch_flag = None  # 014
    pokemon.force_switch = False  # 034
    pokemon.skip_before_switch_out = False
    pokemon.eject_pending = False  # Eject Pack's onEnd
    pokemon.mirror_boosts.clear()  # 040-3b
    pokemon.last_move = None  # 015
    pokemon.last_move_used_type = None  # 041-6f: lastMoveUsed
    pokemon.encore_move = None
    pokemon.move_this_turn_result = None
    pokemon.move_last_turn_result = None
    pokemon.substitute_hp = 0  # 016: no message
    pokemon.focus_energy = False  # 017
    pokemon.imprison = False  # 022
    pokemon.locked_move = None
    pokemon.locked_turns = 0
    pokemon.hurt_this_turn = None  # 023
    pokemon.glaive_rush = False
    pokemon.minimized = False  # 034
    pokemon.disabled_move = None
    pokemon.trap_source = None  # 024 (pokemon.trapped stays until endTurn, as in Showdown)
    pokemon.trap_move = None
    pokemon.metronome = None  # 042-1
    pokemon.commanding = False  # 028
    pokemon.commanded_by = None


# 034 (R4): the conditions with ``noCopy`` (tools/oracle/out/nocopy034.mjs): Baton Pass does not
# pass them. Every other volatile is passed with its effectState (turns left included).
NO_COPY = frozenset({
    "attract", "choicelock", "commanded", "commanding", "counter", "defensecurl", "destinybond",
    "disable", "dynamax", "encore", "flashfire", "glaiverush", "imprison", "lockon", "minimize",
    "mirrorcoat",
    "protosynthesis", "quarkdrive", "saltcure", "smackdown", "spotlight", "stockpile",
    "syrupbomb", "torment", "trapped", "yawn",
})  # fmt: skip


def swap_attack_defense(pokemon: BattlePokemon) -> None:
    """041-6f: Power Trick swaps storedStats.atk and .def (clearVolatile's setSpecies
    restores them: ``saved_stats``)."""
    if pokemon.saved_stats is None:
        pokemon.saved_stats = pokemon.stats
    stats = pokemon.stats
    pokemon.stats = {**stats, "atk": stats["def"], "def": stats["atk"]}


def copy_volatiles(source: BattlePokemon, target: BattlePokemon) -> None:
    """034 (R4): ``copyVolatileFrom(source, 'copyvolatile')`` (Baton Pass): the stat stages and
    each volatile without ``noCopy``, in the order the source got them. Called before the
    source's switch-out; its unburden and Slow Start volatiles are removed by the ability's
    End before the copy in Showdown, so they are not passed (and are not copied here)."""
    target.boosts = dict(source.boosts)
    target.confusion_turns = source.confusion_turns
    target.timed = {k: v for k, v in source.timed.items() if k not in NO_COPY}
    target.counters = {k: v for k, v in source.counters.items() if k in target.timed}
    target.focus_energy = source.focus_energy
    target.dragon_cheer = source.dragon_cheer  # 041-3a (defensecurl: noCopy)
    # 041-3h: gastroacid is passed; its onCopy removes it from a cantsuppress ability
    target.gastro_acid = source.gastro_acid and not _cant_suppress(target.base_ability_id)
    target.substitute_hp = source.substitute_hp
    target.trap_source, target.trap_move = source.trap_source, source.trap_move
    target.trap_divisor = source.trap_divisor  # 042-1
    target.metronome = source.metronome  # 042-1: the metronome volatile (not noCopy)
    target.locked_move, target.locked_turns = source.locked_move, source.locked_turns
    target.two_turn_move, target.charge_loc = source.two_turn_move, source.charge_loc
    target.flinched, target.flinch_after = source.flinched, source.flinch_after
    target.leech_slot = source.leech_slot  # 041-4c: leechseed's effectState
    target.charge = source.charge  # 041-4e: charge (not noCopy)
    target.tar_shot = source.tar_shot  # 041-6c: tarshot (not noCopy)
    target.no_retreat = source.no_retreat  # 041-6d: noretreat (not noCopy)
    target.power_trick = source.power_trick  # 041-6f: powertrick's onCopy swaps again
    if target.power_trick:
        swap_attack_defense(target)


def flinch_before_move(pokemon: BattlePokemon, emit: Emit) -> bool:
    """flinch ``onBeforeMove`` (priority 8): False when the Pokémon cannot move."""
    if not pokemon.flinched:
        return True
    emit("cant", actor=pokemon.label, detail="flinch")
    return False


def confusion_before_move(
    pokemon: BattlePokemon,
    prng: Prng,
    emit: Emit,
    modify_boost: Callable[[], None] | None = None,
    on_damage: Callable[[int], int] | None = None,
    *,
    wonder_room: bool = False,
) -> bool:
    """confusion ``onBeforeMove`` (priority 3): counts down, then hits itself 33% of the time.

    False when the Pokémon hurt itself (the battle then checks whether it fainted).
    ``modify_boost``: runEvent('ModifyBoost')'s draws (028), once per calculateStat.
    ``on_damage``: runEvent('Damage') (032: Focus Band; the effect is a Move).
    """
    if not pokemon.confusion_turns:
        return True
    pokemon.confusion_turns -= 1
    if not pokemon.confusion_turns:
        emit("end", target=pokemon.label, detail="confusion")
        return True
    emit("activate", target=pokemon.label, detail="confusion")
    if not prng.random_chance(33, 100):
        return True
    if modify_boost is not None:
        modify_boost()  # getConfusionDamage: calculateStat('atk'), then ('def')
        modify_boost()
    dealt = confusion_damage(pokemon, prng, wonder_room=wonder_room)
    if on_damage is not None:
        dealt = on_damage(dealt)
    dealt = min(dealt, pokemon.hp)
    pokemon.hp -= dealt
    emit("damage", target=pokemon.label, value=dealt, hp=pokemon.hp, detail="confusion")
    return False


def confusion_damage(pokemon: BattlePokemon, prng: Prng, *, wonder_room: bool = False) -> int:
    """``getConfusionDamage``: a typeless 40-power physical hit on itself, with stat stages,
    without critical hits, STAB or burn."""
    attack = boosted_stat(pokemon.stats["atk"], pokemon.boosts["atk"])
    defense = boosted_stat(wonder_swapped(pokemon.stats, wonder_room)["def"], pokemon.boosts["def"])
    level_factor = trunc(2 * pokemon.level / 5 + 2)
    base = trunc(trunc(trunc(level_factor * CONFUSION_POWER * attack) / defense) / 50) + 2
    damage = trunc(base, 16)
    damage = trunc(trunc(damage * (100 - prng.random_int(16))) / 100)  # randomizer
    return max(1, damage)
