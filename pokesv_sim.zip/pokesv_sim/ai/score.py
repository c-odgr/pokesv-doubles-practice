"""035 (plan R5, US1): the value of a pair of actions, in shares of HP.

For every Pokémon a pair of actions hits, the damage of all the hits is added up as a
distribution (16 rolls each, a miss as 0) under each guess at the foe's set (the heaviest
``TOP_K``); the value is the expected HP taken (capped by the HP left), as a share of the
target's max HP, plus ``KO_VALUE`` times the chance of knocking it out. Foes count for, allies
against. Two attacks on one target are therefore valued together: a knockout neither makes
alone, or damage wasted on a target the other already knocks out (FR-003).

US2 (FR-004, plan R5) uses the same currency. Each foe is expected to use its best attack (under
its guesses) on the Pokémon of this side it hurts most; that threat is what Protect and Fake Out
take away, and what Terastallizing changes (its new types). Tailwind and Trick Room are valued by
the foe-own pairs whose order they turn round.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, replace

from pokesv_sim.ai.belief import Beliefs
from pokesv_sim.ai.estimate import (
    Field,
    field_of,
    foe_combatant,
    hypothesis_stats,
    own_combatant,
    rolls,
)
from pokesv_sim.ai.infer import own_speed
from pokesv_sim.ai.sets import SetHypothesis
from pokesv_sim.ai.status import status_value
from pokesv_sim.boosts import boosted_stat
from pokesv_sim.choices import MoveChoice, SwitchChoice
from pokesv_sim.damage import Combatant
from pokesv_sim.dex import Move, get_dex
from pokesv_sim.view import OwnPokemonView, SideView

TOP_K = 2
KO_VALUE = 0.5  # a knockout is worth half a Pokémon's HP on top of the HP it takes
SWITCH_COST = 0.1  # a turn without acting, for the Pokémon coming in too (US3)
# a switch only puts the hit off onto the switch-in, and it comes in without acting: half of
# the threat it takes away counts (vs. the random AI, 0.5 to 1 measured the same)
SWITCH_SHARE = 0.5
TERA_COST = 0.15  # a once-a-battle resource: only when it gains something (US2-3)
PROTECT_COST = 0.02  # a turn without acting
REPEAT_PROTECT = 1 / 3  # Protect used again in a row works one time in three
# Protect only puts a hit off, unless the attacker falls meanwhile (US2-1): the share of its
# threat it saves when the ally does not knock the attacker out
PROTECT_DELAY = 0.2
SPEED_VALUE = 0.15  # each foe-own pair a speed move turns round, over the turns it lasts
SPREAD = frozenset({"allAdjacentFoes", "allAdjacent"})
SINGLE = frozenset({"normal", "any", "adjacentFoe"})

type Dist = list[tuple[int, float]]  # (damage, probability)
type Attack = tuple[float, float, Move | None]  # (guess weight, value, move)


@dataclass(frozen=True, slots=True)
class Slot:
    """A Pokémon on the field: ``foe`` or not, and its position (0 or 1)."""

    foe: bool
    position: int


def _convolve(a: Dist, b: Dist, cap: int) -> Dist:
    out: dict[int, float] = {}
    for x, p in a:
        for y, q in b:
            v = min(cap, x + y)
            out[v] = out.get(v, 0.0) + p * q
    return list(out.items())


def _value(dist: Dist, hp: int, max_hp: int) -> float:
    taken = sum(min(d, hp) * p for d, p in dist)
    knockout = sum(p for d, p in dist if d >= hp)
    return taken / max_hp + KO_VALUE * knockout


class Evaluator:
    """Values pairs of actions for one decision (``view``, with the side's guesses)."""

    def __init__(
        self,
        view: SideView,
        beliefs: Beliefs,
        fresh: frozenset[int] = frozenset(),
        protected: frozenset[int] = frozenset(),
    ) -> None:
        """``fresh``: positions whose Pokémon came in since the last decision (Fake Out works);
        ``protected``: positions that used a protecting move last turn."""
        self.view = view
        self.fresh = fresh
        self.protected = protected
        self.beliefs = beliefs
        self.dex = get_dex()
        foe_labels = [f"{beliefs.foe}{c}" for c in "ab"]
        guesses = [beliefs.at(label) for label in foe_labels]
        self.field: Field = field_of(view, [b.ability for b in guesses if b and b.ability])
        self.own = {p.position: p for p in view.team if p.position is not None and not p.fainted}
        self.foes = {
            i: (shown, beliefs.at(foe_labels[i]))
            for i, shown in enumerate(view.foe_active)
            if shown is not None and not shown.fainted
        }
        self._hyps: dict[int, list[tuple[SetHypothesis, float]]] = {
            i: (b.top(TOP_K) if b is not None else []) for i, (_, b) in self.foes.items()
        }
        self._cache: dict[tuple[object, ...], list[tuple[Slot, list[Dist]]]] = {}
        self._threat_cache: dict[tuple[int, int, bool], list[Attack]] = {}
        self._aim: dict[int, int] = {f: self._target_of(f) for f in self.foes if self.own}

    # -- one action ---------------------------------------------------------------------------

    def _attacker(self, position: int, tera: bool) -> Combatant:
        me = self.own[position]
        if tera and me.tera_type:
            me = replace(me, terastallized=me.tera_type, types=(me.tera_type,))
        return own_combatant(me)

    def _targets(self, position: int, move: Move, loc: int | None) -> list[tuple[Slot, float]]:
        """The Pokémon the move hits, each with the chance it is the one hit."""
        foes = sorted(self.foes)
        ally = 1 - position
        if move.target in SPREAD:
            out = [(Slot(True, i), 1.0) for i in foes]
            if move.target == "allAdjacent" and ally in self.own:
                out.append((Slot(False, ally), 1.0))
            return out
        if move.target == "randomNormal":
            return [(Slot(True, i), 1 / len(foes)) for i in foes] if foes else []
        if move.target in SINGLE and loc is not None:
            if loc < 0:
                return [(Slot(False, -loc - 1), 1.0)] if -loc - 1 in self.own else []
            if loc - 1 in self.foes:
                return [(Slot(True, loc - 1), 1.0)]
            return [(Slot(True, i), 1.0) for i in foes[:1]]  # retargets the foe left
        return []

    def hits(
        self, position: int, choice: MoveChoice, helping_hand: bool = False
    ) -> list[tuple[Slot, list[Dist]]]:
        """For a move choice: each Pokémon it hits, with its damage distribution under each of
        the target's guesses (one distribution for this side's own Pokémon)."""
        key = (position, choice, helping_hand)
        if key in self._cache:
            return self._cache[key]
        me = self.own.get(position)
        out: list[tuple[Slot, list[Dist]]] = []
        if me is None or choice.move_index < 0 or (me.locked and not me.moves):
            self._cache[key] = out
            return out
        move = self.dex.move(me.moves[choice.move_index].name)
        if move is not None and move.id == "fakeout" and position not in self.fresh:
            move = None  # fails after the first turn out
        if move is None or move.category == "Status":
            self._cache[key] = out
            return out
        attacker = self._attacker(position, choice.terastallize)
        targets = self._targets(position, move, choice.target)
        spread = move.target in SPREAD and len(targets) > 1
        accuracy = 1.0 if move.accuracy is None else min(1.0, move.accuracy / 100)
        hits_n = _hit_count(move)
        for slot, chance in targets:
            p = accuracy * chance
            dists: list[Dist] = []
            for defender, _ in self._defenders(slot):
                values = rolls(
                    attacker, defender, move, self.field, attacker_is_own=True,
                    crit=bool(move.will_crit), spread=spread, helping_hand=helping_hand,
                )  # fmt: skip
                dist: Dist = [(int(v * hits_n), p / 16) for v in values] if values else []
                dist.append((0, 1 - sum(q for _, q in dist)))
                dists.append(dist)
            out.append((slot, dists))
        self._cache[key] = out
        return out

    def _defenders(self, slot: Slot) -> list[tuple[Combatant, float]]:
        if not slot.foe:
            return [(own_combatant(self.own[slot.position]), 1.0)]
        shown, belief = self.foes[slot.position]
        tera = belief.tera_type if belief is not None else None
        return [
            (
                foe_combatant(
                    h, shown, weather=self.field.weather, terrain=self.field.terrain, tera=tera
                ),
                w,
            )
            for h, w in self._hyps[slot.position]
        ]

    def _hp(self, slot: Slot, hyp_index: int) -> tuple[int, int]:
        """(HP left, max HP) of a target under its ``hyp_index``-th guess."""
        if not slot.foe:
            me = self.own[slot.position]
            return me.hp, me.max_hp
        shown, _ = self.foes[slot.position]
        hyp = self._hyps[slot.position][hyp_index][0]
        max_hp = hypothesis_stats(hyp)["hp"]
        return max(1, max_hp * shown.hp_percent // 100), max_hp

    # -- what the foes threaten (US2) -----------------------------------------------------------

    def _target_of(self, foe: int) -> int:
        """The own position foe ``foe`` is expected to attack: the one it hurts most."""
        return max(sorted(self.own), key=lambda o: self.threat(foe, o, False))

    def threat(self, foe: int, own: int, tera: bool) -> float:
        """The value (as in ``value``) of foe ``foe``'s best attack on own position ``own``,
        averaged over its guesses; ``tera``: with ``own`` terastallized."""
        return sum(w * v for w, v, _ in self.best_attacks(foe, own, tera))

    def best_attacks(self, foe: int, own: int, tera: bool) -> list[Attack]:
        """For each guess at foe ``foe``: (weight, value, move) of its best attack on ``own``."""
        key = (foe, own, tera)
        if key not in self._threat_cache:
            me = self.own[own]
            if tera and me.tera_type:
                me = replace(me, terastallized=me.tera_type, types=(me.tera_type,))
            self._threat_cache[key] = self._attacks_on(foe, me)
        return self._threat_cache[key]

    def threat_on(self, foe: int, me: OwnPokemonView) -> float:
        """``threat`` on a Pokémon of this side that is not on the field (a switch-in)."""
        key = (foe, -1 - me.team_index, False)
        if key not in self._threat_cache:
            self._threat_cache[key] = self._attacks_on(foe, me)
        return sum(w * v for w, v, _ in self._threat_cache[key])

    def _attacks_on(self, foe: int, me: OwnPokemonView) -> list[Attack]:
        shown, belief = self.foes[foe]
        foe_tera = belief.tera_type if belief is not None else None
        out: list[Attack] = []
        for hyp, weight in self._hyps[foe]:
            attacker = foe_combatant(
                hyp, shown, weather=self.field.weather, terrain=self.field.terrain, tera=foe_tera
            )
            out.append(
                (weight, *best_attack(attacker, me, hyp.moves, self.field, len(self.own) > 1))
            )
        return out

    def _switch_value(self, position: int, choice: SwitchChoice) -> float:
        """US3: the threat aimed at ``position`` minus what the switch-in takes instead."""
        incoming = next(p for p in self.view.team if p.team_index == choice.team_index)
        saved = sum(
            self.threat(f, aim, False) - self.threat_on(f, incoming)
            for f, aim in self._aim.items()
            if aim == position
        )
        return SWITCH_SHARE * saved - SWITCH_COST

    # -- what status moves need to know (US6, ``status.py``) -----------------------------------

    def aims(self) -> list[tuple[int, int]]:
        """(foe position, the own position it is expected to attack)."""
        return sorted(self._aim.items())

    def foe_threat(self, foe: int) -> float:
        aim = self._aim.get(foe)
        return 0.0 if aim is None else self.threat(foe, aim, False)

    def spread_aims(self) -> list[tuple[int, int]]:
        """(foe, own) pairs threatened by a foe's best attack when it hits both (Wide Guard)."""
        out = []
        for f in sorted(self.foes):
            for o in sorted(self.own):
                attacks = self.best_attacks(f, o, False)
                spread = sum(w for w, _, m in attacks if m is not None and m.target in SPREAD)
                if spread > 0.5:
                    out.append((f, o))
        return out

    def physical_share(self, foe: int) -> float:
        """The weight of the guesses whose best attack (on its aim) is physical."""
        aim = self._aim.get(foe)
        if aim is None:
            return 0.5
        known = [(w, m) for w, _, m in self.best_attacks(foe, aim, False) if m is not None]
        total = sum(w for w, _ in known)
        if not total:
            return 0.5
        return sum(w for w, m in known if m.category == "Physical") / total

    def status_share(self, foe: int) -> float:
        """The share of the foe's guessed moves that are status moves (Taunt)."""
        share = 0.0
        for hyp, weight in self._hyps[foe]:
            known = [m for m in (self.dex.move(i) for i in hyp.moves) if m is not None]
            if known:
                share += weight * sum(m.category == "Status" for m in known) / len(known)
        return share

    def foe_types(self, foe: int) -> tuple[str, ...]:
        shown, _ = self.foes[foe]
        if shown.terastallized:
            return (shown.terastallized,)
        species = self.dex.species(shown.species)
        return species.types if species is not None else ()

    def foe_ability_share(self, foe: int, abilities: frozenset[str]) -> float:
        return sum(w for h, w in self._hyps[foe] if (h.ability or "") in abilities)

    def powder_proof(self, foe: int) -> float:
        """The chance powder moves (Spore, Rage Powder) do not work on the foe."""
        if "Grass" in self.foe_types(foe):
            return 1.0
        return sum(
            w for h, w in self._hyps[foe] if h.ability == "overcoat" or h.item == "safetygoggles"
        )

    def foe_bench(self) -> int:
        """The foe's brought Pokémon not on the field and not fainted."""
        return max(0, self.view.foe_left - len(self.foes))

    def paralysis_flips(self, foe: int) -> float:
        """Speed value of halving the foe's speed: own Pokémon that then move first."""
        if any(k == "trickroom" for k, _ in self.view.field_conditions):
            return 0.0
        own_tw = any(k == "tailwind" for k, _ in self.view.own_side_conditions)
        foe_tw = any(k == "tailwind" for k, _ in self.view.foe_side_conditions)
        theirs = self._foe_speed(foe, foe_tw)
        flips = sum(theirs >= self._speed(o, own_tw) > theirs // 2 for o in self.own)
        return SPEED_VALUE * flips

    def own_best(self, position: int) -> tuple[float, float]:
        """The value of the best physical and the best special attack of own ``position``."""
        me = self.own.get(position)
        best = {"Physical": 0.0, "Special": 0.0}
        if me is None:
            return 0.0, 0.0
        for index, slot in enumerate(me.moves):
            move = self.dex.move(slot.name)
            if move is None or move.category == "Status":
                continue
            for f in sorted(self.foes):
                total = 0.0
                for sl, dists in self.hits(position, MoveChoice(index, f + 1)):
                    if not sl.foe:
                        continue
                    for k, (_, w) in enumerate(self._hyps[sl.position]):
                        hp, max_hp = self._hp(sl, k)
                        total += w * _value(dists[min(k, len(dists) - 1)], hp, max_hp)
                best[move.category] = max(best[move.category], total)
        return best["Physical"], best["Special"]

    def _move(self, position: int, choice: MoveChoice) -> Move | None:
        me = self.own.get(position)
        if me is None or choice.move_index < 0 or choice.move_index >= len(me.moves):
            return None
        return self.dex.move(me.moves[choice.move_index].name)

    def protects(self, position: int, choice: MoveChoice | SwitchChoice) -> bool:
        """Whether ``choice`` is a protecting move (Protect, Detect, Spiky Shield, ...)."""
        if not isinstance(choice, MoveChoice):
            return False
        move = self._move(position, choice)
        return move is not None and "stallingMove" in move.keys and move.target == "self"

    def _speed(self, position: int, tailwind: bool) -> int:
        return own_speed(self.own[position], tailwind)

    def _foe_speed(self, foe: int, tailwind: bool) -> int:
        shown, _ = self.foes[foe]
        hyps = self._hyps[foe]
        if not hyps:
            return 0
        hyp = hyps[0][0]
        speed = boosted_stat(hypothesis_stats(hyp)["spe"], dict(shown.boosts).get("spe", 0))
        if tailwind:
            speed *= 2
        if hyp.item == "choicescarf":
            speed = speed * 3 // 2
        if shown.status == "par":
            speed //= 2
        return speed

    def _speed_value(self, move: Move) -> float:
        """Pairs that move first after ``move`` minus before (Tailwind, Trick Room)."""
        own_tw = any(k == "tailwind" for k, _ in self.view.own_side_conditions)
        foe_tw = any(k == "tailwind" for k, _ in self.view.foe_side_conditions)
        room = any(k == "trickroom" for k, _ in self.view.field_conditions)
        after_tw, after_room = own_tw, room
        if move.side_condition == "tailwind":
            if own_tw:
                return 0.0
            after_tw = True
        elif move.pseudo_weather == "trickroom":
            after_room = not room
        else:
            return 0.0
        gained = 0
        for o in self.own:
            for f in self.foes:
                theirs = self._foe_speed(f, foe_tw)
                before = (self._speed(o, own_tw) > theirs) != room
                after = (self._speed(o, after_tw) > theirs) != after_room
                gained += int(after) - int(before)
        return SPEED_VALUE * gained

    def _support(
        self, choices: Sequence[MoveChoice | SwitchChoice | None], knocked: dict[int, float]
    ) -> float:
        """Protect, Fake Out's flinch, Terastallizing's new types, speed control (US2).
        ``knocked``: each foe's chance to be knocked out by this pair's attacks."""
        guarded: dict[int, float] = {}
        flinch: dict[int, float] = {}
        tera_at: int | None = None
        extra = 0.0
        speed_moves: set[str] = set()
        for position, choice in enumerate(choices):
            if not isinstance(choice, MoveChoice):
                continue
            if choice.terastallize:
                tera_at = position
            move = self._move(position, choice)
            if move is None:
                continue
            if self.protects(position, choice):
                guarded[position] = REPEAT_PROTECT if position in self.protected else 1.0
                extra -= PROTECT_COST
            elif move.id == "fakeout" and position in self.fresh:
                p = 1.0 if move.accuracy is None else min(1.0, move.accuracy / 100)
                for slot, dists in self.hits(position, choice):
                    if slot.foe and any(len(d) > 1 for d in dists):
                        flinch[slot.position] = max(flinch.get(slot.position, 0.0), p)
            elif move.side_condition == "tailwind" or move.pseudo_weather == "trickroom":
                if move.id not in speed_moves:
                    speed_moves.add(move.id)
                    extra += self._speed_value(move)
            elif move.category == "Status":
                extra += status_value(self, position, choice, move)
        for foe, aim in self._aim.items():
            before = self.threat(foe, aim, False)
            after = self.threat(foe, aim, tera_at == aim)
            ko = knocked.get(foe, 0.0)
            saved = guarded.get(aim, 0.0) * (PROTECT_DELAY + (1 - PROTECT_DELAY) * ko)
            keep = (1 - flinch.get(foe, 0.0)) * (1 - saved)
            extra += before - keep * after
        return extra

    # -- a pair of actions --------------------------------------------------------------------

    def value(self, choices: Sequence[MoveChoice | SwitchChoice | None]) -> float:
        """The value of this side's actions for its positions (None: no action)."""
        by_slot: dict[Slot, list[list[Dist]]] = {}
        extra = 0.0
        helped = {  # Helping Hand: the ally's attacks hit 1.5 times as hard (US6)
            1 - p
            for p, c in enumerate(choices)
            if isinstance(c, MoveChoice) and (m := self._move(p, c)) and m.id == "helpinghand"
        }
        for position, choice in enumerate(choices):
            if isinstance(choice, SwitchChoice):
                extra += self._switch_value(position, choice)
                continue
            if choice is None:
                continue
            if choice.terastallize:
                extra -= TERA_COST
            for slot, dists in self.hits(position, choice, position in helped):
                by_slot.setdefault(slot, []).append(dists)
        total = extra
        knocked: dict[int, float] = {}
        for slot, per_attack in by_slot.items():
            if slot.foe and not self._hyps.get(slot.position):
                continue  # no guess of its set: its HP and bulk are unknown, so no value
            weights = [w for _, w in self._hyps[slot.position]] if slot.foe else [1.0]
            value = 0.0
            for k, weight in enumerate(weights):
                hp, max_hp = self._hp(slot, k) if slot.foe else self._hp(slot, 0)
                dist: Dist = [(0, 1.0)]
                for dists in per_attack:
                    dist = _convolve(dist, dists[min(k, len(dists) - 1)], hp)
                value += weight * _value(dist, hp, max_hp)
                if slot.foe:
                    knocked[slot.position] = knocked.get(slot.position, 0.0) + weight * sum(
                        p for d, p in dist if d >= hp
                    )
            total += value if slot.foe else -value
        return total + self._support(choices, knocked)


def best_attack(
    attacker: Combatant, me: OwnPokemonView, moves: Sequence[str], field: Field, spread: bool
) -> tuple[float, Move | None]:
    """The value of the foe ``attacker``'s best attack among ``moves`` on own ``me`` (HP as it
    is now), and that move. ``spread``: spread moves hit two (their damage is cut)."""
    dex = get_dex()
    defender = own_combatant(me)
    best, best_move = 0.0, None
    for move_id in moves:
        move = dex.move(move_id)
        if move is None or move.category == "Status" or move.id == "fakeout":
            continue
        values = rolls(
            attacker, defender, move, field,
            attacker_is_own=False, spread=spread and move.target in SPREAD,
        )  # fmt: skip
        if not values:
            continue
        p = 1.0 if move.accuracy is None else min(1.0, move.accuracy / 100)
        n = _hit_count(move)
        dist: Dist = [(int(v * n), p / 16) for v in values]
        dist.append((0, 1 - p))
        value = _value(dist, me.hp, me.max_hp)
        if value > best:
            best, best_move = value, move
    return best, best_move


def attack_value(
    attacker: Combatant, defender: Combatant, move: Move, hp: int, max_hp: int, field: Field
) -> float:
    """The value of one own attack (single target, no spread cut) on a defender at ``hp``."""
    values = rolls(attacker, defender, move, field, attacker_is_own=True)
    if not values:
        return 0.0
    p = 1.0 if move.accuracy is None else min(1.0, move.accuracy / 100)
    n = _hit_count(move)
    dist: Dist = [(int(v * n), p / 16) for v in values]
    dist.append((0, 1 - p))
    return _value(dist, hp, max_hp)


def _hit_count(move: Move) -> float:
    if move.multihit is None:
        return 1.0
    low, high = move.multihit
    return 3.1 if (low, high) == (2, 5) else float(high)  # 2-5 hits: 3.1 on average
