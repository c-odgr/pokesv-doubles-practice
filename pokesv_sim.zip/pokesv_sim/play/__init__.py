"""039: battle an AI in the browser (a local server; the engine does not depend on it)."""
