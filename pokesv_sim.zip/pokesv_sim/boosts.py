"""Stat stages (Showdown ``Battle.boost``, ``Pokemon.calculateStat``, ``hitStepAccuracy``)."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

BOOST_IDS = ("atk", "def", "spa", "spd", "spe", "accuracy", "evasion")
_STAT_TABLE = (1, 1.5, 2, 2.5, 3, 3.5, 4)

type Emit = Callable[..., Any]


def _clamp(stage: int) -> int:
    return max(-6, min(6, stage))


def boosted_stat(stat: int, stage: int) -> int:
    """A stat at a stage: floor(stat * table[n]) or floor(stat / table[n])."""
    stage = _clamp(stage)
    if stage >= 0:
        return int(stat * _STAT_TABLE[stage])
    return int(stat / _STAT_TABLE[-stage])


def wonder_swapped[T](values: Mapping[str, T], wonder_room: bool) -> Mapping[str, T]:
    """041-6f: Wonder Room swaps def and spd: calculateStat reads the other stored stat;
    getStat(stat, false, true) keeps the stored stat but reads the other stage."""
    if not wonder_room:
        return values
    return {**values, "def": values["spd"], "spd": values["def"]}


def boosted_accuracy(accuracy: int, stage: int) -> int:
    """Accuracy at (user's accuracy - target's evasion): trunc(acc * (3+n)/3) or 3/(3-n)."""
    stage = _clamp(stage)
    if stage > 0:
        return int(accuracy * (3 + stage) / 3)
    if stage < 0:
        return int(accuracy * 3 / (3 - stage))
    return accuracy


def _flower_veil(target: Any) -> str | None:
    """043-3c: the label of the first Flower Veil holder among a Grass target and its ally."""
    arena = getattr(target, "arena", None)
    if arena is None or "Grass" not in target.types:
        return None
    holders = [  # (alliesAndSelf: HP left)
        p
        for p in arena.sides[target.side].alive_active()
        if p.ability_id == "flowerveil" and p.hp > 0
    ]
    holders.sort(key=lambda p: -p.cached_speed)
    return holders[0].label if holders else None


def apply_boosts(
    target: Any,
    changes: Mapping[str, int],
    *,
    primary: bool,
    foes_left: bool,
    emit: Emit,
    source: Any = None,
    ability: str | None = None,
    ability_self: bool = False,
) -> bool:
    """Showdown ``battle.boost``. Returns whether any stage changed.

    A move's effect: ``primary`` is its main effect (a status move), which reports a stage that
    cannot change any further; secondary and self effects stay silent.
    An ability's effect (``ability``: its name, 011): Intimidate is a secondary effect (a stage
    that cannot change is reported, the target does not announce it); Defiant, Competitive and
    Guard Dog are self effects (``ability_self``: announced, a stuck stage reported); Download
    is neither (announced, a stuck stage silent).

    ``source`` lowered the stats: a foe's drop makes Defiant / Competitive react (011).
    Mirror Armor's reflected drop is a secondary effect too (012).
    """
    from pokesv_sim.abilities import (
        CLEAR_BODY,
        GUARD_DOG,
        INTIMIDATE_BLOCKERS,
        MIRROR_ARMOR,
        ONE_STAT_GUARDS,
        STAT_DROP_REACTIONS,
    )

    if target.hp <= 0 or target.position is None or not foes_left:
        return False
    if target.ability_id == "simple":  # 041-3h: Simple's onChangeBoost doubles
        changes = {name: amount * 2 for name, amount in changes.items()}
    elif target.ability_id == "contrary":  # 043-4e: Contrary's onChangeBoost inverts
        changes = {name: -amount for name, amount in changes.items()}
    capped_changes = {}
    for name, amount in changes.items():
        if amount:  # getCappedBoost skips zero entries
            capped_changes[name] = _clamp(target.boosts[name] + amount) - target.boosts[name]
    from_other = source is not None and source is not target
    silent = not primary and ability is None
    # runEvent('TryBoost'): Clear Amulet first (priority 1, 013), then the target's ability.
    if from_other and target.item == "clearamulet":
        dropped = [name for name, capped in capped_changes.items() if capped < 0]
        for name in dropped:
            del capped_changes[name]
        if dropped and not silent:
            emit("fail", actor=target.label, detail="unboost")
    # the target's ability against Intimidate: ``boost.atk`` after getCappedBoost (020: 0 at
    # -6, so Oblivious and the others do nothing and the drop shows as 0)
    if ability == "Intimidate" and capped_changes.get("atk"):
        own = target.ability_id
        if own == GUARD_DOG:
            del capped_changes["atk"]
            apply_boosts(target, {"atk": 1}, primary=False, foes_left=foes_left, emit=emit,
                         source=target, ability="Guard Dog", ability_self=True)  # fmt: skip
        elif own in INTIMIDATE_BLOCKERS:
            del capped_changes["atk"]
            emit("fail", actor=target.label, detail="unboost")
    # 012: Clear Body, Mirror Armor, Mind's Eye against drops by another Pokémon. The message
    # is left out when the effect has secondaries (a move's secondary drop).
    own = target.ability_id
    if from_other and own in (CLEAR_BODY, "fullmetalbody", "whitesmoke"):  # (043-2b, 043-4a)
        dropped = [name for name, capped in capped_changes.items() if capped < 0]
        for name in dropped:
            del capped_changes[name]
        if dropped and not silent:
            emit("fail", actor=target.label, detail="unboost")
    elif from_other and own == MIRROR_ARMOR and ability != "Mirror Armor":
        for name in [n for n, capped in capped_changes.items() if capped < 0]:
            reflected = capped_changes.pop(name)
            if source.hp > 0:
                emit("ability", target=target.label, detail="Mirror Armor")
                apply_boosts(source, {name: reflected}, primary=False, foes_left=True, emit=emit,
                             source=target, ability="Mirror Armor")  # fmt: skip
    elif from_other and own in ONE_STAT_GUARDS and capped_changes.get(ONE_STAT_GUARDS[own], 0) < 0:
        del capped_changes[ONE_STAT_GUARDS[own]]  # (043-4a: Keen Eye, Hyper Cutter, Big Pecks)
        if not silent:
            emit("fail", actor=target.label, detail="unboost")
    veil = _flower_veil(target)
    if veil is not None and source is not target:
        # 043-3c: Flower Veil's onAllyTryBoost (a Grass target; -block unless the effect has
        # secondaries)
        dropped = [name for name, capped in capped_changes.items() if capped < 0]
        for name in dropped:
            del capped_changes[name]
        if dropped and not silent:
            emit("block", target=target.label, detail="ability: Flower Veil", actor=veil)
    if from_other and _in_mist(target, source):
        # 041-3e: Mist's onTryBoost (a side condition: after the Pokemon's own handlers)
        dropped = [name for name, capped in capped_changes.items() if capped < 0]
        for name in dropped:
            del capped_changes[name]
        if dropped and not silent:
            emit("activate", target=target.label, detail="move: Mist")
    secondary = ability in ("Intimidate", "Mirror Armor", "Gooey", "Tangling Hair",
                            "Supersweet Syrup", "Gulp Missile")  # (043-4d/4e/6f)  # fmt: skip
    announced = secondary  # an Intimidate drop is announced by the Intimidate user
    changed = False
    for name, capped in capped_changes.items():
        amount = changes[name]
        target.boosts[name] = target.boosts[name] + capped
        kind = "boost"
        shown = capped
        if capped < 0 or (capped == 0 and amount < 0) or target.boosts[name] == -6:
            kind, shown = "unboost", -capped
        if capped:
            changed = True
            if ability is not None and not announced:
                emit("ability", target=target.label, detail=ability)
                announced = True
            emit(kind, target=target.label, detail=name, value=shown)
            # runEvent('AfterEachBoost'): Defiant / Competitive on a drop by a foe.
            reaction = STAT_DROP_REACTIONS.get(target.ability_id)
            if (
                reaction is not None
                and capped < 0
                and source is not None
                and source.side != target.side
            ):
                stat, reaction_name = reaction
                apply_boosts(target, {stat: 2}, primary=False, foes_left=foes_left, emit=emit,
                             source=target, ability=reaction_name, ability_self=True)  # fmt: skip
        elif ability is not None:
            if secondary or ability_self:
                emit(kind, target=target.label, detail=name, value=0)
        elif primary:
            emit(kind, target=target.label, detail=name, value=0)
    if ability == "Intimidate" and capped_changes.get("atk") and target.ability_id == "rattled":
        # 043-4b: Rattled's onAfterBoost (Intimidate lowered Attack): Speed +1
        apply_boosts(target, {"spe": 1}, primary=False, foes_left=foes_left, emit=emit,
                     source=target, ability="Rattled")  # fmt: skip
    # runEvent('AfterBoost'): Eject Pack's onAfterBoost (014; Parting Shot is left out by the
    # caller)
    if target.item == "ejectpack" and any(capped < 0 for capped in capped_changes.values()):
        target.eject_pending = True
    if changed and any(capped > 0 for capped in capped_changes.values()):
        target.stats_raised_this_turn = True  # 027: boost's success
    if changed and any(capped < 0 for capped in capped_changes.values()):
        target.stats_lowered_this_turn = True  # 041-1e
    return changed


def _in_mist(target: Any, source: Any) -> bool:
    """041-3e: Mist is on the target's side (``arena``: the battle state, 029); a foe's
    Infiltrator goes through."""
    arena = getattr(target, "arena", None)
    if arena is None or "mist" not in arena.field.sides[target.side]:
        return False
    return not (source.side != target.side and source.ability_id == "infiltrator")
