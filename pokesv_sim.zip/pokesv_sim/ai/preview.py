"""035 US3 (plan R6): which four to bring, which two lead, and who replaces a fainted Pokémon.

Each own Pokémon is scored against each foe Pokémon by the trade of damage in ``score``'s
currency: the value of its best attack on the foe (under the foe's guessed sets) minus the value
of the foe's best attack on it, both at full HP. Team preview brings the four with the highest
total against the foe's six and leads with the best two of them; a replacement is the bench
Pokémon with the highest total against the foes on the field.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import replace
from functools import lru_cache

from pokesv_sim.ai.belief import Belief
from pokesv_sim.ai.estimate import Field, foe_combatant, hypothesis_stats, own_combatant
from pokesv_sim.ai.score import TOP_K, attack_value, best_attack
from pokesv_sim.dex import get_dex
from pokesv_sim.view import OwnPokemonView

PICK = 4
NEUTRAL = Field()


def matchup(me: OwnPokemonView, foe: Belief) -> float:
    """What ``me`` (at full HP) deals the foe minus what the foe deals it, over its guesses."""
    full = replace(me, hp=me.max_hp, status=None)
    attacker = own_combatant(full)
    dex = get_dex()
    moves = [m for m in (dex.move(slot.name) for slot in me.moves) if m is not None]
    total = 0.0
    for hyp, weight in foe.top(TOP_K):
        defender = foe_combatant(hyp)
        max_hp = hypothesis_stats(hyp)["hp"]
        dealt = max(
            (
                attack_value(attacker, defender, m, max_hp, max_hp, NEUTRAL)
                for m in moves
                if m.category != "Status"
            ),
            default=0.0,
        )
        taken, _ = best_attack(defender, full, hyp.moves, NEUTRAL, spread=True)
        total += weight * (dealt - taken)
    return total


@lru_cache(maxsize=4096)
def prior_matchup(me: OwnPokemonView, species: str) -> float:
    """``matchup`` against a foe nothing is known of yet (team preview): the same for every
    battle with the same teams, so it is kept (SC-005)."""
    return matchup(me, Belief(species))


def bring(team: Sequence[OwnPokemonView], foes: Sequence[Belief]) -> tuple[int, ...]:
    """Team indices to bring, the two leads first (ties: team order). ``foes``: as at team
    preview (their guesses are the prior)."""
    scores = {p.team_index: sum(prior_matchup(p, f.species) for f in foes) for p in team}
    ranked = sorted(scores, key=lambda i: (-scores[i], i))
    return tuple(ranked[: min(PICK, len(ranked))])


def replacement(bench: Sequence[OwnPokemonView], foes: Sequence[Belief]) -> int | None:
    """The bench Pokémon (team index) that trades best with the foes on the field. The
    matchups are team preview's (kept, SC-005): what was learned of the foes' sets since is
    left to the turn's own evaluation."""
    if not bench:
        return None

    def total(p: OwnPokemonView) -> float:
        full = replace(p, hp=p.max_hp, status=None)
        return sum(prior_matchup(full, f.species) for f in foes)

    return max(bench, key=lambda p: (total(p), -p.team_index)).team_index
