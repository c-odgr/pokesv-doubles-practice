"""Run one battle between two players from start to finish."""

from __future__ import annotations

from dataclasses import dataclass, replace

from pokesv_sim.battle import TURN_LIMIT, Battle
from pokesv_sim.choices import (
    STRUGGLE,
    Choice,
    MoveChoice,
    PassChoice,
    SwitchChoice,
    is_legal_turn,
    legal_move_choices,
)
from pokesv_sim.events import Event
from pokesv_sim.players import Player, RandomPlayer, seed_words
from pokesv_sim.prng import Prng, Seed
from pokesv_sim.state import ACTIVE_PER_SIDE, SIDE_IDS
from pokesv_sim.support import unsupported
from pokesv_sim.team import Team, TeamError, validate_team
from pokesv_sim.view import SideView, side_view


class TeamInvalidError(ValueError):
    """A team breaks the rules every team must follow (names, stat spreads, moves)."""

    def __init__(self, side: str, errors: list[TeamError]) -> None:
        self.side = side
        self.errors = errors
        super().__init__(f"{side}: " + "; ".join(e.message for e in errors))


class UnsupportedError(ValueError):
    """A team uses something the engine cannot simulate yet (constitution IV)."""

    def __init__(self, side: str, items: list[str]) -> None:
        self.side = side
        self.items = items
        super().__init__(f"{side}: not supported yet: " + "; ".join(items))


def _revive_first(
    battle: Battle,
    side_id: str,
    player: Player,
    view: SideView,
    need: list[bool],
    revive: list[bool],
) -> list[SwitchChoice | PassChoice]:
    """041-6f: a player without Revival Blessing's pick: the other positions from the player,
    a reviving one gets the first fainted Pokémon (Showdown's ``switch`` without a slot)."""
    rest = [n and not r for n, r in zip(need, revive, strict=True)]
    out: list[SwitchChoice | PassChoice] = (
        list(player.choose_replacements(view, rest))
        if any(rest)
        else [PassChoice() for _ in range(ACTIVE_PER_SIDE)]
    )
    side = battle.state.sides[side_id]
    fainted = [p.team_index for p in (side.order or side.brought) if p.fainted]
    for i, r in enumerate(revive):
        if r and need[i] and fainted:
            out[i] = SwitchChoice(fainted.pop(0))
    return out


def check_teams(team1: Team, team2: Team) -> None:
    """Raise before any battle event if a team is invalid or unsupported."""
    for side_id, team in zip(SIDE_IDS, (team1, team2), strict=True):
        errors = validate_team(team)
        if errors:
            raise TeamInvalidError(side_id, errors)
    for side_id, team in zip(SIDE_IDS, (team1, team2), strict=True):
        items = unsupported(team)
        if items:
            raise UnsupportedError(side_id, items)


# 014: the requests one battle may make (turns and switch requests) before it is stopped
MAX_DECISIONS = 10 * TURN_LIMIT


@dataclass(frozen=True, slots=True)
class BattleResult:
    winner: str | None  # "p1", "p2", or None for a tie / an aborted battle
    turns: int
    events: tuple[Event, ...]
    aborted: str | None = None  # why the battle was stopped early, if it was
    brought: dict[str, tuple[int, ...]] | None = None  # side -> team indices chosen at preview


def choose_turn(battle: Battle, side_id: str, player: Player, since: int = 0) -> list[Choice]:
    """The player's choices for the turn. 022: a move hidden as disabled (Imprison) is offered
    to the last Pokémon of the side to choose. When it is chosen, Showdown's ``chooseMove``
    turns it into Struggle if the Pokémon has no usable move left (``getMoves()`` is empty);
    otherwise it refuses the choice with an updated request (those moves disabled) and the AI
    chooses again for the side. 043-5b: a switch of a Pokemon a foe's ability traps (offered
    as maybeTrapped to the last one to choose) is refused the same way."""
    state = battle.state
    view = side_view(state, side_id, battle.events, since)  # 035: the log since ``since``
    choices = player.choose_turn(view, legal_move_choices(state, side_id))
    if is_legal_turn(state, side_id, choices):
        return choices
    strict = legal_move_choices(state, side_id, strict=True)
    loose = legal_move_choices(state, side_id)
    out: list[Choice] = []
    for choice, st, lo in zip(choices, strict, loose, strict=False):
        plain = replace(choice, terastallize=False) if isinstance(choice, MoveChoice) else choice
        if plain not in lo or plain in st:
            out.append(choice)
        elif (
            isinstance(plain, MoveChoice)  # (043-5b: a refused switch is chosen again)
            and st
            and all(c == MoveChoice(STRUGGLE, None) for c in st if isinstance(c, MoveChoice))
        ):
            out.append(MoveChoice(STRUGGLE, None))  # (the Terastallization flag is dropped)
        else:
            return player.choose_turn(replace(view, log=()), strict)  # (log already shown)
    return out  # illegal for another reason: play_turn raises


def run_battle(
    team1: Team,
    team2: Team,
    player1: Player,
    player2: Player,
    seed: int | Seed,
    *,
    trace: list[tuple[int, str]] | None = None,
) -> BattleResult:
    """Play a full battle. Same teams, players (with their seeds) and ``seed``: same result."""
    check_teams(team1, team2)
    prng = Prng(seed_words(seed))
    prng.trace = trace  # optional record of every battle draw (tools/trace_diff.py)
    battle = Battle(team1, team2, prng)
    players = dict(zip(SIDE_IDS, (player1, player2), strict=True))
    battle.start(
        player1.choose_preview(side_view(battle.state, "p1")),
        player2.choose_preview(side_view(battle.state, "p2")),
    )
    seen = dict.fromkeys(SIDE_IDS, 0)  # 035: events each side was shown (SideView.log)

    def view(side_id: str) -> SideView:
        out = side_view(battle.state, side_id, battle.events, seen[side_id])
        seen[side_id] = len(battle.events)
        return out

    decisions = 0
    while not battle.ended:
        decisions += 1
        if decisions > MAX_DECISIONS:
            # 014: a battle that makes no progress (an engine bug) ends instead of looping
            battle.abort(f"no progress after {MAX_DECISIONS} decisions")
            break
        if battle.awaiting_replacements:
            replacements: list[list[SwitchChoice | PassChoice]] = []
            for side_id in SIDE_IDS:
                need = battle.needs_replacement(side_id)
                if any(need):
                    revive = battle.reviving(side_id)
                    player = players[side_id]
                    if any(revive) and isinstance(player, RandomPlayer):
                        replacements.append(player.choose_replacements(view(side_id), need, revive))
                    elif any(revive):
                        replacements.append(
                            _revive_first(battle, side_id, player, view(side_id), need, revive)
                        )
                    else:
                        replacements.append(player.choose_replacements(view(side_id), need))
                else:
                    replacements.append([PassChoice()] * ACTIVE_PER_SIDE)
            battle.replace(replacements[0], replacements[1])
        else:
            turn = []
            for s in SIDE_IDS:
                turn.append(choose_turn(battle, s, players[s], seen[s]))
                seen[s] = len(battle.events)
            battle.play_turn(turn[0], turn[1])
    aborted = next((e.detail for e in battle.events if e.kind == "aborted"), None)
    brought = {s: tuple(p.team_index for p in battle.state.sides[s].brought) for s in SIDE_IDS}
    return BattleResult(
        battle.state.winner, battle.state.turn, tuple(battle.events), aborted, brought
    )
