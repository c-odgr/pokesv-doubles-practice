"""035 (plan R3, US5-2..4): how likely a hit or a move order is under each guessed set.

Each likelihood is the share of the damage rolls (16, with the critical hit as shown) that give
what the log shows, or whether the guessed speed allows the order; a small floor keeps a guess
alive when the view does not say everything about the conditions (``FLOOR``).
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import replace
from functools import cache

from pokesv_sim.ai.estimate import Field, foe_combatant, hypothesis_stats, own_combatant, rolls
from pokesv_sim.ai.observe import Hit
from pokesv_sim.ai.sets import SetHypothesis
from pokesv_sim.boosts import boosted_stat
from pokesv_sim.dex import get_dex, to_id
from pokesv_sim.view import FoePokemonView, OwnPokemonView, _percent

DAMAGE_FLOOR = 0.02
SKIPPED_BEST = 0.85  # US5-5: a weak cue (plan R3; the learning stage may change it)
ORDER_FLOOR = 0.05
TRICK_ROOM = "trickroom"
TAILWIND = "tailwind"


def _key(h: SetHypothesis) -> tuple[object, ...]:
    return (h.nature, h.evs, h.item, h.ability)


@cache
def _hp_at(max_hp: int) -> dict[int, list[int]]:
    """For a max HP: the shown percentage -> the HP values (1 to max) shown as it."""
    out: dict[int, list[int]] = {}
    for b in range(1, max_hp + 1):
        out.setdefault(_percent(b, max_hp), []).append(b)
    return out


def damage_taken(
    hit: Hit,
    own: OwnPokemonView,
    shown: FoePokemonView | None,
    field: Field,
    lost_item: bool,
    tera: str | None = None,
) -> Callable[[SetHypothesis], float]:
    """The foe (under each guess) hit this side's ``own`` Pokémon for ``hit.damage``."""
    assert hit.damage is not None
    defender = own_combatant(own)
    before = hit.hp_before if hit.hp_before is not None else hit.damage + hit.hp_after
    defender = replace(defender, hp=before, full_hp=before >= own.max_hp)
    cache: dict[tuple[object, ...], float] = {}

    def likelihood(h: SetHypothesis) -> float:
        key = _key(h)
        if key not in cache:
            attacker = foe_combatant(
                h,
                shown,
                item="" if lost_item else None,
                weather=field.weather,
                terrain=field.terrain,
                tera=tera,
            )
            values = rolls(
                attacker, defender, hit.move, field, attacker_is_own=False,
                crit=hit.crit, spread=hit.spread, helping_hand=hit.helping_hand,
            )  # fmt: skip
            assert hit.damage is not None
            if not values:
                share = 0.0
            elif hit.hp_after == 0:
                share = sum(v >= hit.damage for v in values) / len(values)
            else:
                share = sum(v == hit.damage for v in values) / len(values)
            cache[key] = DAMAGE_FLOOR + (1 - DAMAGE_FLOOR) * share
        return cache[key]

    return likelihood


def damage_dealt(
    hit: Hit,
    own: OwnPokemonView,
    shown: FoePokemonView | None,
    field: Field,
    lost_item: bool,
    tera: str | None = None,
) -> Callable[[SetHypothesis], float]:
    """This side's ``own`` Pokémon hit the foe: its shown HP went from ``hit.hp_before`` to
    ``hit.hp_after`` percent. Every true HP the first percentage allows counts the same."""
    assert hit.hp_before is not None
    attacker = own_combatant(own)
    cache: dict[tuple[object, ...], float] = {}

    def likelihood(h: SetHypothesis) -> float:
        key = (*_key(h), h.tera_type)
        if key not in cache:
            max_hp = hypothesis_stats(h)["hp"]
            assert hit.hp_before is not None
            starts = _hp_at(max_hp).get(hit.hp_before, [])
            defender = foe_combatant(
                h,
                shown,
                item="" if lost_item else None,
                weather=field.weather,
                terrain=field.terrain,
                tera=tera,
            )
            share = 0.0
            if starts:
                defender = replace(defender, hp=starts[0], full_hp=hit.hp_before >= 100)
                values = rolls(
                    attacker, defender, hit.move, field, attacker_is_own=True,
                    crit=hit.crit, spread=hit.spread, helping_hand=hit.helping_hand,
                )  # fmt: skip
                if values:
                    fits = sum(
                        _percent(max(0, b - v), max_hp) == hit.hp_after
                        for b in starts
                        for v in values
                    )
                    share = fits / (len(starts) * len(values))
            cache[key] = DAMAGE_FLOOR + (1 - DAMAGE_FLOOR) * share
        return cache[key]

    return likelihood


def own_speed(own: OwnPokemonView, tailwind: bool) -> int:
    speed = boosted_stat(dict(own.stats)["spe"], dict(own.boosts).get("spe", 0))
    if tailwind:
        speed *= 2
    if own.item == "choicescarf":
        speed = speed * 3 // 2
    if own.status == "par":
        speed //= 2
    return speed


def move_order(
    own: OwnPokemonView,
    shown: FoePokemonView | None,
    foe_first: bool,
    own_tailwind: bool,
    foe_tailwind: bool,
    trick_room: bool,
    lost_item: bool,
) -> Callable[[SetHypothesis], float]:
    """Who moved first among two moves of the same priority, under each guessed speed."""
    mine = own_speed(own, own_tailwind)

    def likelihood(h: SetHypothesis) -> float:
        speed = boosted_stat(
            hypothesis_stats(h)["spe"], dict(shown.boosts).get("spe", 0) if shown else 0
        )
        if foe_tailwind:
            speed *= 2
        item = "" if lost_item else (h.item or "")
        if item == "choicescarf":
            speed = speed * 3 // 2
        if shown is not None and shown.status == "par":
            speed //= 2
        if speed == mine:
            p = 0.5
        else:
            faster = speed > mine
            p = 1.0 if faster != trick_room else 0.0
            if not foe_first:
                p = 1 - p
        return ORDER_FLOOR + (1 - ORDER_FLOOR) * p

    return likelihood


def rough_power(move_id: str, user_types: Sequence[str], targets: Sequence[Sequence[str]]) -> float:
    """A quick measure of a damaging move against the targets: base power, same-type bonus and
    the best type effectiveness (US5-5 only needs to rank a set's moves)."""
    dex = get_dex()
    move = dex.move(move_id)
    if move is None or move.category == "Status" or not move.base_power:
        return 0.0
    best = 0.0
    for types in targets:
        if dex.is_immune(move.type, tuple(types)):
            continue
        best = max(best, 2.0 ** dex.type_mod(move.type, tuple(types)))
    stab = 1.5 if move.type in user_types else 1.0
    return move.base_power * stab * best


def skipped_best(
    used: str, user_types: Sequence[str], targets: Sequence[Sequence[str]]
) -> Callable[[SetHypothesis], float]:
    """US5-5: the foe attacked with ``used``. A guessed set whose strongest attack against the
    targets is another move it then did not use becomes a little less likely."""
    used_id = to_id(used)
    cache: dict[tuple[str, ...], float] = {}

    def likelihood(h: SetHypothesis) -> float:
        if h.generic or not h.moves:
            return 1.0
        if h.moves not in cache:
            powers = {m: rough_power(m, user_types, targets) for m in h.moves}
            best = max(powers, key=lambda m: powers[m])
            strongest = powers[best] > 0 and powers[best] > powers.get(used_id, 0.0)
            cache[h.moves] = SKIPPED_BEST if strongest and best != used_id else 1.0
        return cache[h.moves]

    return likelihood
