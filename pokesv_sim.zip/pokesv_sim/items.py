"""013: held items (Showdown ``data/items.ts``): ids and the checks the battle and the damage
calculation use. Effects that change the battle are applied by ``battle.py``."""

from __future__ import annotations

from pokesv_sim.dex import Move, Species, get_dex

# 029: its holder's ability is not suppressed by Neutralizing Gas, ignored by Mold Breaker or
# changed by Skill Swap (``BattlePokemon.ability_id``, ``battle._skill_swap``)
ABILITY_SHIELD = "abilityshield"
CHOICE_BAND = "choiceband"
CHOICE_SPECS = "choicespecs"
CHOICE_SCARF = "choicescarf"
ASSAULT_VEST = "assaultvest"
LIFE_ORB = "lifeorb"
EVIOLITE = "eviolite"
LOADED_DICE = "loadeddice"
FOCUS_SASH = "focussash"
SITRUS_BERRY = "sitrusberry"
BOOSTER_ENERGY = "boosterenergy"
LEFTOVERS = "leftovers"
BLACK_SLUDGE = "blacksludge"
FLAME_ORB = "flameorb"
TOXIC_ORB = "toxicorb"
ROCKY_HELMET = "rockyhelmet"
THROAT_SPRAY = "throatspray"
WHITE_HERB = "whiteherb"
EJECT_PACK = "ejectpack"  # 014
MENTAL_HERB = "mentalherb"
SAFETY_GOGGLES = "safetygoggles"
COVERT_CLOAK = "covertcloak"
CLEAR_AMULET = "clearamulet"
LIGHT_CLAY = "lightclay"
# 032 (R1): runEvent('ModifyAccuracy') handlers: (priority, modifier); the user's onSource ones
# and the target's own
WIDE_LENS = "widelens"
ZOOM_LENS = "zoomlens"
BRIGHT_POWDER = "brightpowder"
SOURCE_ACCURACY_ITEMS = {WIDE_LENS: (-2, 4505), ZOOM_LENS: (-2, 4915)}
TARGET_ACCURACY_ITEMS = {BRIGHT_POWDER: (-2, 3686)}
SCOPE_LENS = "scopelens"  # 032 (R2): onModifyCritRatio +1
KINGS_ROCK = "kingsrock"  # 032 (R2): onModifyMove: a 10% flinch secondary
FOCUS_BAND = "focusband"  # 032 (R2): onDamage: randomChance(1, 10), then 1 HP left from a move
POWER_BAND = "powerband"  # 032 (R3): onModifySpe x0.5
IRON_BALL = "ironball"  # 032 (R3): onModifySpe x0.5; grounds its holder
# 042-1: the berries with ``onEat: false`` (the EV berries): nothing on eating, and Bug Bite
# does not set ateBerry
NO_EAT_BERRIES = frozenset({"pomegberry", "kelpsyberry", "qualotberry", "hondewberry",
                            "grepaberry", "tamatoberry"})  # fmt: skip
# 042-1: the power items (onModifySpe x0.5, as Power Band)
POWER_ITEMS = frozenset({"poweranklet", "powerbelt", "powerbracer", "powerlens", "powerweight"})
HALF_SPEED_ITEMS = frozenset({POWER_BAND, IRON_BALL}) | POWER_ITEMS
AIR_BALLOON = "airballoon"  # 032 (R4): -item on start; not grounded; pops when hit
LUM_BERRY = "lumberry"  # 032 (R5): onAfterSetStatus / onUpdate: cures status and confusion
CUSTAP_BERRY = "custapberry"  # 032 (R6): onFractionalPriority: +0.1 at 1/4 HP
WEAKNESS_POLICY = "weaknesspolicy"  # 032 (R7): onDamagingHit: super effective -> Atk/SpA +2
# 017: Ogerpon's masks -> the forme that gets the x1.2 (onBasePower: baseSpecies startsWith)
OGERPON_MASKS = {
    "wellspringmask": "Ogerpon-Wellspring",
    "hearthflamemask": "Ogerpon-Hearthflame",
    "cornerstonemask": "Ogerpon-Cornerstone",
}
MASK_MODIFIER = (4915, 4096)

LIFE_ORB_MODIFIER = (5324, 4096)  # onModifyDamage
RESIST_BERRY_MODIFIER = (1, 2)

# onBasePower (priority 15): x4915/4096 for moves of the type.
TYPE_BOOSTERS: dict[str, str] = {
    "silkscarf": "Normal", "blackbelt": "Fighting", "sharpbeak": "Flying",
    "poisonbarb": "Poison", "softsand": "Ground", "hardstone": "Rock",
    "silverpowder": "Bug", "spelltag": "Ghost", "metalcoat": "Steel", "charcoal": "Fire",
    "mysticwater": "Water", "miracleseed": "Grass", "magnet": "Electric",
    "twistedspoon": "Psychic", "nevermeltice": "Ice", "dragonfang": "Dragon",
    "blackglasses": "Dark", "fairyfeather": "Fairy",
    "fistplate": "Fighting", "skyplate": "Flying", "toxicplate": "Poison",
    "earthplate": "Ground", "stoneplate": "Rock", "insectplate": "Bug",
    "spookyplate": "Ghost", "ironplate": "Steel", "flameplate": "Fire",
    "splashplate": "Water", "meadowplate": "Grass", "zapplate": "Electric",
    "mindplate": "Psychic", "icicleplate": "Ice", "dracoplate": "Dragon",
    "dreadplate": "Dark", "pixieplate": "Fairy",
}  # fmt: skip
TYPE_BOOSTER_MODIFIER = (4915, 4096)

# onSourceModifyDamage: x0.5 against a super effective move of the type (Chilan: any Normal).
RESIST_BERRIES: dict[str, str] = {
    "occaberry": "Fire", "passhoberry": "Water", "wacanberry": "Electric",
    "rindoberry": "Grass", "yacheberry": "Ice", "chopleberry": "Fighting",
    "kebiaberry": "Poison", "shucaberry": "Ground", "cobaberry": "Flying",
    "payapaberry": "Psychic", "tangaberry": "Bug", "chartiberry": "Rock",
    "kasibberry": "Ghost", "habanberry": "Dragon", "colburberry": "Dark",
    "babiriberry": "Steel", "roseliberry": "Fairy", "chilanberry": "Normal",
}  # fmt: skip
CHILAN_BERRY = "chilanberry"

# onUpdate at 1/4 HP: heal 1/3, confusion when the nature lowers the stat.
PINCH_BERRIES: dict[str, str] = {
    "figyberry": "atk", "wikiberry": "spa", "magoberry": "spe",
    "aguavberry": "spd", "iapapaberry": "def",
}  # fmt: skip

# 040-2: onBasePower (Punching Glove 23, Muscle Band / Wise Glasses 16), Punching Glove's
# onModifyMove (priority 1: a punch loses contact), Expert Belt's onModifyDamage
PUNCHING_GLOVE = "punchingglove"
EXPERT_BELT = "expertbelt"
EXPERT_BELT_MODIFIER = (4915, 4096)
# onDamagingHit: a move of this type -> useItem (the item's boosts)
HIT_BOOST_ITEMS: dict[str, str] = {
    "absorbbulb": "Water", "cellbattery": "Electric", "snowball": "Ice", "luminousmoss": "Water",
}  # fmt: skip
# onUpdate at 1/4 HP (Gluttony 1/2): eatItem, onEat boosts the stat by 1
STAT_PINCH_BERRIES: dict[str, str] = {
    "liechiberry": "atk", "ganlonberry": "def", "salacberry": "spe", "petayaberry": "spa",
    "apicotberry": "spd",
}  # fmt: skip

# 040-2b
BLUNDER_POLICY = "blunderpolicy"  # sim: a missed move (not OHKO) -> useItem, Spe +2
ROOM_SERVICE = "roomservice"  # onStart (-1) / onAnyPseudoWeatherChange: Trick Room -> useItem
# onAfterMoveSecondary: hit by a move of this category -> eatItem, the stat +1
HIT_BERRIES: dict[str, tuple[str, str]] = {
    "keeberry": ("Physical", "def"), "marangaberry": ("Special", "spd"),
}  # fmt: skip
LANSAT_BERRY = "lansatberry"  # onUpdate at 1/4 HP: addVolatile('focusenergy')
STARF_BERRY = "starfberry"  # onUpdate at 1/4 HP: a random stat (not maxed) +2

# 040-3a
EJECT_BUTTON = "ejectbutton"  # onAfterMoveSecondary (priority 2): the holder switches out
RED_CARD = "redcard"  # onAfterMoveSecondary: the attacker is dragged out
PROTECTIVE_PADS = "protectivepads"  # Battle#checkMoveMakesContact: the user makes no contact

# 040-3b: onBasePower (priority 15) x4915/4096 for baseSpecies.num's two types; the crystals
# (forcedForme: the Origin formes) also have onTakeItem false when holder or taker is that num
LEGEND_ORBS: dict[str, tuple[int, tuple[str, str]]] = {
    "adamantorb": (483, ("Steel", "Dragon")), "adamantcrystal": (483, ("Steel", "Dragon")),
    "lustrousorb": (484, ("Water", "Dragon")), "lustrousglobe": (484, ("Water", "Dragon")),
    "griseousorb": (487, ("Ghost", "Dragon")), "griseouscore": (487, ("Ghost", "Dragon")),
}  # fmt: skip
LEGEND_CRYSTALS = {"adamantcrystal": 483, "lustrousglobe": 484, "griseouscore": 487}
# 042-2: the rusted items (onTakeItem false for Zacian / Zamazenta, holder or taker)
RUSTED_ITEMS = {"rustedsword": 888, "rustedshield": 889}
# 042-2: the species condition's onBattleStart: the Crowned forme and its Iron Head
CROWNED = {("zacian", "rustedsword"): ("Zacian-Crowned", "Behemoth Blade"),
           ("zamazenta", "rustedshield"): ("Zamazenta-Crowned", "Behemoth Bash")}  # fmt: skip

# 040-3b: onResidual (no order) at 1/4 HP: eatItem, addVolatile('micleberry') (duration 2;
# onSourceAccuracy, not for an OHKO move: -enditem, removeVolatile, a number x4915/4096)
MICLE_BERRY = "micleberry"
MICLE_MODIFIER = 4915

# 040-3b: onFoeAfterBoost adds a foe's raised stages to effectState.boosts; onAnySwitchIn (-3),
# onAnyAfterTerastallization, onAnyAfterMove, onResidual (29): useItem, then boost them
MIRROR_HERB = "mirrorherb"

# 040-4a: onUpdate: the status -> eatItem, onEat cureStatus
STATUS_BERRIES: dict[str, tuple[str, ...]] = {
    "cheriberry": ("par",), "chestoberry": ("slp",), "pechaberry": ("psn", "tox"),
    "rawstberry": ("brn",), "aspearberry": ("frz",),
}  # fmt: skip
PERSIM_BERRY = "persimberry"  # onUpdate: confusion -> eatItem, removeVolatile('confusion')
ORAN_BERRY = "oranberry"  # onUpdate at 1/2 HP (onTryEatItem: TryHeal): heal 10
ENIGMA_BERRY = "enigmaberry"  # onHit: super effective -> eatItem, heal baseMaxhp / 4
LEPPA_BERRY = "leppaberry"  # onUpdate: a move at 0 PP -> eatItem, +10 PP
# onDamagingHit: hit by a move of this category -> eatItem, the attacker loses baseMaxhp / 8
RETALIATE_BERRIES: dict[str, str] = {"jabocaberry": "Physical", "rowapberry": "Special"}
# Berserk's onTryEatItem and the berries' TryHeal (onTryEatItem)
HEALING_BERRIES = frozenset({SITRUS_BERRY, ORAN_BERRY, ENIGMA_BERRY, *PINCH_BERRIES})

# 040-4b
SHELL_BELL = "shellbell"  # onAfterMoveSecondarySelf (-1): heal move.totalDamage / 8
QUICK_CLAW = "quickclaw"  # onFractionalPriority: randomChance(1, 5) -> -activate, +0.1
LAGGING_TAIL = "laggingtail"  # onFractionalPriority: -0.1
BIG_ROOT = "bigroot"  # onTryHeal (priority 1): drain / Strength Sap x5324/4096
BIG_ROOT_MODIFIER = 5324
SHED_SHELL = "shedshell"  # onTrapPokemon (-10): trapped = false
STICKY_BARB = "stickybarb"  # onResidual (28, 3): 1/8; onHit: to a contact attacker with no item
RING_TARGET = "ringtarget"  # onNegateImmunity: false
ADRENALINE_ORB = "adrenalineorb"  # onAfterBoost: Intimidate -> useItem (Spe +1)
TERRAIN_EXTENDER = "terrainextender"  # the terrains' durationCallback: 8 turns
RAZOR_CLAW = "razorclaw"  # onModifyCritRatio +1
RAZOR_FANG = "razorfang"  # onModifyMove (-1): a 10% flinch secondary (as King's Rock)

# durationCallback: 8 turns of the weather.
WEATHER_ROCKS: dict[str, str] = {
    "heatrock": "sunnyday", "damprock": "raindance", "smoothrock": "sandstorm",
    "icyrock": "snowscape",
}  # fmt: skip

# onStart / onTerrainChange: used in the terrain (Defense or Sp. Def +1).
SEEDS: dict[str, str] = {
    "electricseed": "electricterrain", "grassyseed": "grassyterrain",
    "psychicseed": "psychicterrain", "mistyseed": "mistyterrain",
}  # fmt: skip

CHOICE_STAT = {CHOICE_BAND: "atk", CHOICE_SPECS: "spa", CHOICE_SCARF: "spe"}


def is_choice(item: str) -> bool:
    return item in CHOICE_STAT


def type_booster(item: str, move: Move) -> bool:
    return TYPE_BOOSTERS.get(item) == move.type


SOUL_DEW = "souldew"  # 030 (R3)
_SOUL_DEW_SPECIES = frozenset({"Latios", "Latias"})  # baseSpecies.num 380 / 381


def soul_dew(item: str, species: str, move: Move) -> bool:
    """030: Soul Dew onBasePower (priority 15): x4915/4096 for Latios's and Latias's Psychic
    and Dragon moves."""
    return item == SOUL_DEW and species in _SOUL_DEW_SPECIES and move.type in ("Psychic", "Dragon")


def resist_berry(item: str, move_type: str, effectiveness: int) -> bool:
    """The berry halves this hit (``typeMod > 0``; Chilan Berry: any Normal move)."""
    berry_type = RESIST_BERRIES.get(item)
    if berry_type is None or berry_type != move_type:
        return False
    return item == CHILAN_BERRY or effectiveness > 0


def legend_orb(item: str, species: str, move: Move) -> bool:
    """040-3b: Adamant / Lustrous / Griseous Orb (and the crystals) onBasePower (priority 15)."""
    orb = LEGEND_ORBS.get(item)
    if orb is None or move.type not in orb[1]:
        return False
    data = get_dex().species(species) if species else None
    return data is not None and data.num == orb[0]


def can_be_taken(item: str, species: Species, source: Species | None = None) -> bool:
    """``TakeItem``: Booster Energy stays with a Paradox Pokémon, a plate with Arceus. 040-3b:
    a crystal stays when the holder or the taker (``source``) is its Pokémon."""
    if not item:
        return False
    if item in LEGEND_CRYSTALS or item in RUSTED_ITEMS:  # (042-2: the rusted items)
        num = LEGEND_CRYSTALS.get(item) or RUSTED_ITEMS[item]
        return species.num != num and (source is None or source.num != num)
    if item == BOOSTER_ENERGY:
        return "Paradox" not in species.tags
    if item.endswith("plate") and item in TYPE_BOOSTERS:
        return species.num != 493 and (source is None or source.num != 493)
    if item in OGERPON_MASKS:  # 017: onTakeItem is false for any Ogerpon
        return species.base_species != "Ogerpon"
    return True


def item_name(item: str) -> str:
    entry = get_dex().item(item)
    return entry.name if entry else item
