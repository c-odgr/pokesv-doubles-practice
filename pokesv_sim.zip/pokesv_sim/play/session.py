"""039: one battle between a person (in the browser) and an AI, run in its own thread."""

from __future__ import annotations

import threading
import traceback
from collections.abc import Callable, Sequence
from dataclasses import replace
from typing import Any, cast

from pokesv_sim.battle import Battle
from pokesv_sim.choices import Choice, MoveChoice, PassChoice, Preview, SwitchChoice
from pokesv_sim.play import labels
from pokesv_sim.players import Player, RandomPlayer, seed_words
from pokesv_sim.prng import Prng
from pokesv_sim.runner import BattleResult, run_battle
from pokesv_sim.team import Team
from pokesv_sim.view import SideView, public_log

HUMAN, FOE = "p1", "p2"


def _search(leaf: str, **wide: Any) -> Callable[[int], Player]:
    def make(seed: int) -> Player:
        from pokesv_sim.search import SearchPlayer
        from pokesv_sim.search.player import Settings

        return SearchPlayer(seed, Settings(leaf=leaf, **wide))

    return make


def _smart(seed: int) -> Player:
    from pokesv_sim.ai import SmartPlayer

    return SmartPlayer(seed)


# (id, label, factory); the last one is the default and the latest. 046: what each AI does,
# then its development number (names chosen with the requester, 2026-11-22)
AIS: tuple[tuple[str, str, Callable[[int], Player]], ...] = (
    ("random", "ランダム m000", lambda seed: RandomPlayer(seed, tera=0.3, random_preview=True)),
    ("smart035", "ダメ計判断 m035", _smart),
    ("search036", "先読み・手動評価 m036", _search("features")),
    ("search037", "先読み・学習評価9 m037", _search("fitted037")),
    ("search038", "先読み・学習評価15 m038", _search("fitted")),
    # 048: wider candidates (52.85% vs m038 over 2,000 battles)
    ("search048", "先読み広め・学習評価15 m048", _search("fitted", own=6, foe=10, extras=True)),
)
DESCRIPTIONS = {
    "random": "合法手から無作為に選ぶ",
    "smart035": "その場のダメージ計算と倒せる確率で、技・対象・まもる・交代を決める（先読みなし）",
    "search036": "相手の手を確率で見込んで1ターン先を読む。局面の良し悪しは手で決めた重み",
    "search037": "同じ先読み。局面の評価を試合データから学習（9 特徴）",
    "search038": "同じ先読み＋学習。特徴を 15 に増やした"
    "（トリックルーム・ねこだまし・ワイドガードなど）",
    "search048": "m038 と同じ評価で、比べる候補を広げた（自分 6 組・相手 10 組、"
    "交代とまもるの候補を必ず入れる）。考える時間は約 2 倍",
}
DEFAULT_AI = AIS[-1][0]
LATEST_AI = AIS[-1][0]  # 046: the one that recommends the person's choices
LABELS = {i: label for i, label, _ in AIS}


class Stopped(Exception):
    """The game was abandoned while waiting for the person."""


class HumanPlayer:
    """Waits for the browser's answer to each request."""

    def __init__(self) -> None:
        self.cond = threading.Condition()
        self.request: dict[str, Any] | None = None
        self.answer: Any = None
        self.view: SideView | None = None
        self.legal: Sequence[Sequence[MoveChoice | SwitchChoice]] = ()
        self.need: Sequence[bool] = ()
        self.log = labels.LogWriter(HUMAN)
        self.lines: list[str] = []
        self.feed: list[dict[str, Any]] = []  # 044: the lines as events the page replays
        self.seen = 0  # public events shown (for the tail after the battle)
        self.tail: list[dict[str, Any]] = []  # the feed after the last request (the board after)
        self.stopped = False
        self.advisor: Player | None = None  # 046: the latest AI, choosing for this side too
        self.advice: Any = None

    def _advise(self, kind: str, view: SideView) -> Any:
        """046: what the latest AI would choose here, as the page's answer would be."""
        if self.advisor is None:
            return None
        try:
            if kind == "preview":
                return list(self.advisor.choose_preview(view).order)
            if kind == "turn":
                out: list[list[Any]] = []
                for options, c in zip(
                    self.legal, self.advisor.choose_turn(view, self.legal), strict=True
                ):
                    plain = replace(c, terastallize=False) if isinstance(c, MoveChoice) else c
                    k = next((i for i, o in enumerate(options) if o == plain), None)
                    out.append([k, bool(isinstance(c, MoveChoice) and c.terastallize)])
                return out
            picks = self.advisor.choose_replacements(view, self.need)
            return [c.team_index if isinstance(c, SwitchChoice) else None for c in picks]
        except Exception:  # advice is only a hint: the battle goes on without it
            return None

    def _ask(self, kind: str, view: SideView) -> Any:
        self._add(self.log.entries(view.log))
        self.seen += len(view.log)
        advice = self._advise(kind, view)
        with self.cond:
            self.advice = advice
            self.view, self.answer = view, None
            self.request = {"kind": kind}
            while self.answer is None and not self.stopped:
                self.cond.wait()
            if self.stopped:
                raise Stopped
            answer, self.request = self.answer, None
            return answer

    def _add(self, entries: list[dict[str, Any]]) -> None:
        self.feed += entries
        self.lines += [entry["text"] for entry in entries]

    def give(self, answer: Any) -> None:
        with self.cond:
            self.answer = answer
            self.request = None  # answered: the page shows the AI thinking
            self.cond.notify_all()

    def stop(self) -> None:
        with self.cond:
            self.stopped = True
            self.cond.notify_all()

    def choose_preview(self, view: SideView) -> Preview:
        return Preview(tuple(self._ask("preview", view)))

    def choose_turn(
        self, view: SideView, legal: Sequence[Sequence[MoveChoice | SwitchChoice]]
    ) -> list[Choice]:
        self.legal = legal
        picks = self._ask("turn", view)  # [(option index or None, tera)]
        out: list[Choice] = []
        for options, (k, tera) in zip(legal, picks, strict=True):
            if not options or k is None:
                out.append(PassChoice())
                continue
            c = options[k]
            out.append(replace(c, terastallize=True) if tera and isinstance(c, MoveChoice) else c)
        return out

    def choose_replacements(
        self, view: SideView, need: Sequence[bool]
    ) -> list[SwitchChoice | PassChoice]:
        self.need = need
        picks = self._ask("replace", view)
        return [SwitchChoice(i) if i is not None else PassChoice() for i in picks]


class Recorder:
    """The AI, recording what it chose each turn (shown after the battle, FR-008)."""

    def __init__(self, inner: Player) -> None:
        self.inner = inner
        self.lines: list[str] = []

    def choose_preview(self, view: SideView) -> Preview:
        p = self.inner.choose_preview(view)
        names = [labels.species(view.team[i].species)["name"] for i in p.order]
        self.lines.append("選出: " + "・".join(names))
        return p

    def choose_turn(
        self, view: SideView, legal: Sequence[Sequence[MoveChoice | SwitchChoice]]
    ) -> list[Choice]:
        out = self.inner.choose_turn(view, legal)
        said = [labels.choice_label(c, i, view) for i, c in enumerate(out)]
        self.lines.append(f"ターン {view.turn}: " + " ／ ".join(said))
        return out

    def choose_replacements(
        self, view: SideView, need: Sequence[bool]
    ) -> list[SwitchChoice | PassChoice]:
        out = self.inner.choose_replacements(view, need)
        said = [labels.choice_label(c, i, view) for i, c in enumerate(out) if need[i]]
        self.lines.append(f"ターン {view.turn} 繰り出し: " + " ／ ".join(said))
        return out


class Game:
    def __init__(self, mine: Team, foe: Team, ai: str, seed: int) -> None:
        factory = next(f for i, _, f in AIS if i == ai)
        self.ai = ai
        self.human = HumanPlayer()
        latest = next(f for i, _, f in AIS if i == LATEST_AI)
        self.human.advisor = latest(seed + 2)
        self.foe = Recorder(factory(seed + 1))
        self.result: BattleResult | None = None
        self.error: str | None = None
        self.thread = threading.Thread(target=self._run, args=(mine, foe, seed), daemon=True)
        self.thread.start()

    def _run(self, mine: Team, foe: Team, seed: int) -> None:
        try:
            self.result = run_battle(mine, foe, self.human, self.foe, seed)
        except Stopped:
            return
        except Exception:  # shown in the browser rather than lost in a thread
            self.error = traceback.format_exc()
            return
        _add_tail(self.human, mine, foe, self.result)

    def state(self) -> dict[str, Any]:
        h = self.human
        out: dict[str, Any] = {
            "ai": self.ai, "ai_label": LABELS[self.ai], "log": h.lines, "feed": h.feed,
            "advisor": LABELS[LATEST_AI],
        }  # fmt: skip
        if self.error:
            return out | {"phase": "error", "error": self.error}
        if self.result is not None:
            r = self.result
            won = "win" if r.winner == HUMAN else "lose" if r.winner else "tie"
            out |= {"phase": "over", "outcome": won, "turns": r.turns, "ai_log": self.foe.lines}
            if h.view is not None:
                out["board"] = _board(h, h.view, over=True)
            return out
        with h.cond:
            request, view = h.request, h.view
        if request is None or view is None:
            return out | {"phase": "waiting"}
        out |= {"phase": request["kind"], "board": _board(h, view), "advice": h.advice}
        if request["kind"] == "turn":
            out["options"] = [
                [
                    {
                        "label": labels.choice_label(c, pos, view),
                        "move": isinstance(c, MoveChoice),
                        "index": c.move_index if isinstance(c, MoveChoice) else c.team_index,
                        "target": labels.target_label(c, pos, view),
                        "slot": _target_slot(c, pos),
                    }
                    for c in opts
                ]
                for pos, opts in enumerate(h.legal)
            ]
            out["tera"] = [_can_tera(view, pos, opts) for pos, opts in enumerate(h.legal)]
            out["matchups"] = [_matchups(view, pos) for pos in range(len(h.legal))]
        elif request["kind"] == "replace":
            out["need"] = list(h.need)
        return out

    def choose(self, answer: Any) -> None:
        self.human.give(answer)

    def stop(self) -> None:
        self.human.stop()
        if hasattr(self.foe.inner, "cancelled"):
            self.foe.inner.cancelled = True  # review P3: the search ends its table now


def _add_tail(human: HumanPlayer, mine: Team, foe: Team, result: BattleResult) -> None:
    """The events after the person's last request (the final blow, the faint, the result), with
    the foe's HP as the percentage the games show: ``public_log`` needs the foe's max HP, read
    from a battle set up with the same teams (the one played is not kept by ``run_battle``)."""
    teams = (mine, foe) if HUMAN == "p1" else (foe, mine)
    state = Battle(*teams, Prng(seed_words(0))).state
    shown = public_log(state, HUMAN, result.events)
    human.tail = human.log.entries(shown[human.seen :])
    human._add(human.tail)


def _board(h: HumanPlayer, view: SideView, over: bool = False) -> dict[str, Any]:
    b = labels.board(view)
    if over:
        b = labels.board_after(b, h.tail)
    return b | labels.foe_record(h.feed, b["foe_preview"])


def _can_tera(view: SideView, pos: int, opts: Sequence[MoveChoice | SwitchChoice]) -> bool:
    if not view.can_terastallize or not opts:
        return False
    user = next((p for p in view.team if p.position == pos and not p.fainted), None)
    struggling = any(isinstance(c, MoveChoice) and c.move_index < 0 for c in opts)
    return user is not None and not user.locked and not struggling and not user.terastallized


def _target_slot(c: MoveChoice | SwitchChoice, pos: int) -> str | None:
    """044: the board slot a move aims at ("foe0", "me1"), for highlighting it."""
    if not isinstance(c, MoveChoice) or c.target is None:
        return None
    if c.target > 0:
        return f"foe{c.target - 1}"
    return f"me{-c.target - 1}"


def _matchups(view: SideView, pos: int) -> list[list[float | None]]:
    """044: each move of the Pokémon at ``pos`` against each foe on the field (its type
    matchup), in move order."""
    user = next((p for p in view.team if p.position == pos and not p.fainted), None)
    if user is None:
        return []
    return [labels.effectiveness(m.name, view, user) for m in user.moves]


class NeedInput(Exception):
    """047: the replayed battle reached a request the person has not answered yet."""


class ReplayHuman(HumanPlayer):
    """047: answers from the list; at the first unanswered request, records it and stops the
    battle (no thread waits: the offline version runs in the browser without threads)."""

    def __init__(self, answers: list[Any], advice: list[Any], advisor: Player | None) -> None:
        super().__init__()
        self.answers, self.advice_cache, self.advisor = answers, advice, advisor
        self.n = 0

    def _ask(self, kind: str, view: SideView) -> Any:
        self._add(self.log.entries(view.log))
        self.seen += len(view.log)
        self.view = view  # (the board shown after the battle, as in HumanPlayer)
        if self.n < len(self.answers):
            self.n += 1
            return self.answers[self.n - 1]
        if self.n >= len(self.advice_cache):  # the advisor chooses once per request, in order
            self.advice_cache.append(self._advise(kind, view))
        self.advice = self.advice_cache[self.n]
        self.request = {"kind": kind}
        raise NeedInput


class CachedPlayer:
    """047: the AI's earlier decisions, given again when the battle is replayed; only a new
    request reaches the AI (so it decides once, in the same order as in a threaded game)."""

    def __init__(self, inner: Player) -> None:
        self.inner = inner
        self.done: list[Any] = []
        self.i = 0

    def _get(self, decide: Callable[[], Any]) -> Any:
        if self.i == len(self.done):
            self.done.append(decide())
        self.i += 1
        return self.done[self.i - 1]

    def choose_preview(self, view: SideView) -> Preview:
        return cast(Preview, self._get(lambda: self.inner.choose_preview(view)))

    def choose_turn(
        self, view: SideView, legal: Sequence[Sequence[MoveChoice | SwitchChoice]]
    ) -> list[Choice]:
        return cast(list[Choice], self._get(lambda: self.inner.choose_turn(view, legal)))

    def choose_replacements(
        self, view: SideView, need: Sequence[bool]
    ) -> list[SwitchChoice | PassChoice]:
        out = self._get(lambda: self.inner.choose_replacements(view, need))
        return cast(list[SwitchChoice | PassChoice], out)


class StepGame(Game):
    """047: the same game without a thread. Each answer replays the battle from the start
    (same seed, the answers so far, the AI's cached decisions) up to the next request."""

    def __init__(self, mine: Team, foe: Team, ai: str, seed: int) -> None:
        factory = next(f for i, _, f in AIS if i == ai)
        latest = next(f for i, _, f in AIS if i == LATEST_AI)
        self.ai, self.mine, self.foe_team, self.seed = ai, mine, foe, seed
        self.answers: list[Any] = []
        self.advice: list[Any] = []
        self.advisor = latest(seed + 2)
        self.foe = Recorder(factory(seed + 1))
        self.cached = CachedPlayer(self.foe)
        self.result: BattleResult | None = None
        self.error: str | None = None
        self._step()

    def _step(self) -> None:
        self.human = ReplayHuman(self.answers, self.advice, self.advisor)
        self.cached.i = 0
        try:
            self.result = run_battle(self.mine, self.foe_team, self.human, self.cached, self.seed)
        except NeedInput:
            return
        except Exception:
            self.error = traceback.format_exc()
            return
        _add_tail(self.human, self.mine, self.foe_team, self.result)

    def choose(self, answer: Any) -> None:
        if self.result is None and self.error is None:
            self.answers.append(answer)
            self._step()

    def stop(self) -> None:
        pass
