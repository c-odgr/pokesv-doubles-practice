"""Seeds for the i-th battle of a series, shared with the Showdown oracle (same formula in Node)."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

from pokesv_sim.prng import Prng, Seed


def derive(base: int, i: int, role: str) -> str:
    """Showdown seed string ``gen5,<16 hex>`` from ``sha256(f"{base}:{i}:{role}")``."""
    digest = hashlib.sha256(f"{base}:{i}:{role}".encode()).hexdigest()
    return f"gen5,{digest[:16]}"


@dataclass(frozen=True, slots=True)
class BattleSeeds:
    battle: str
    p1: str
    p2: str

    @property
    def battle_words(self) -> Seed:
        return Prng.from_showdown_seed(self.battle).seed

    @property
    def p1_words(self) -> Seed:
        return Prng.from_showdown_seed(self.p1).seed

    @property
    def p2_words(self) -> Seed:
        return Prng.from_showdown_seed(self.p2).seed


def battle_seeds(base: int, i: int) -> BattleSeeds:
    return BattleSeeds(derive(base, i, "battle"), derive(base, i, "p1"), derive(base, i, "p2"))
