"""Stat calculation (Showdown ``Battle.statModify``)."""

from __future__ import annotations

from collections.abc import Mapping

from pokesv_sim.dex import STAT_IDS, Nature


def calc_stat(stat: str, base: int, iv: int, ev: int, level: int, nature: Nature) -> int:
    if stat == "hp":
        return (2 * base + iv + ev // 4 + 100) * level // 100 + 10
    value = (2 * base + iv + ev // 4) * level // 100 + 5
    if nature.plus == stat:
        value = value * 110 // 100
    elif nature.minus == stat:
        value = value * 90 // 100
    return value


def calc_stats(
    base_stats: Mapping[str, int],
    ivs: Mapping[str, int],
    evs: Mapping[str, int],
    level: int,
    nature: Nature,
) -> dict[str, int]:
    """All six stats. Every input is a non-negative integer, so floor division matches ``trunc``."""
    return {s: calc_stat(s, base_stats[s], ivs[s], evs[s], level, nature) for s in STAT_IDS}
